package org.williamsindustries.dosewellclock;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.AlarmClock;
import android.view.WindowManager;
import android.widget.Toast;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.ECPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ClockActivity extends Activity {
    private static final String SITE = "https://sneakyzebra.github.io/dosewell/#reminders/android-clock";
    private static final long WINDOW = 5 * 60_000L;
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        prefs = getSharedPreferences("clock", MODE_PRIVATE);
        Uri uri = getIntent().getData();
        if (Intent.ACTION_MAIN.equals(getIntent().getAction()) || uri == null) {
            home();
            return;
        }
        try {
            if (!Intent.ACTION_VIEW.equals(getIntent().getAction()) || !"dosewellclock".equals(uri.getScheme())
                    || !"alarm".equals(uri.getHost()) || !"/set".equals(uri.getPath()) || uri.toString().length()>6000) {
                throw new IllegalArgumentException();
            }
            String pub = uri.getQueryParameter("k");
            String body = uri.getQueryParameter("p");
            byte[] spki = DECODER.decode(pub);
            PublicKey browser = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(spki));
            if (((ECPublicKey)browser).getParams().getCurve().getField().getFieldSize()!=256) throw new IllegalArgumentException();
            Signature check = Signature.getInstance("SHA256withECDSA");
            check.initVerify(browser);
            check.update(body.getBytes(StandardCharsets.US_ASCII));
            if (!check.verify(der(DECODER.decode(uri.getQueryParameter("s"))))) throw new SecurityException();
            JSONObject alarm = new JSONObject(new String(DECODER.decode(body), StandardCharsets.UTF_8));
            validate(alarm);
            String connected = prefs.getString("browser", "");
            if (connected.equals(pub)) {
                send(alarm,pub);
            } else if (!connected.isEmpty()) {
                message("Different browser", "Open the browser you first approved. To change browsers, open Dosewell Clock from your apps and disconnect the current one.");
            } else {
                byte[] digest = MessageDigest.getInstance("SHA-256").digest(spki);
                String code = String.format(Locale.US,"%02X%02X %02X%02X",digest[0],digest[1],digest[2],digest[3]);
                ZonedDateTime at = target(alarm);
                String when = at.format(DateTimeFormatter.ofPattern("EEE, MMM d, h:mm a",Locale.getDefault()));
                String detail = "Match this code with the one on your Dosewell page: "+code+
                    "\n\n"+alarm.getString("label")+"\n"+when+"\n"+repeatDescription(alarm.getInt("days"))+
                    "\n\nAllow this browser to send future alarms directly to Clock?";
                AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Connect and set this alarm?")
                    .setMessage(detail).setPositiveButton("Connect and set",(d,w)->send(alarm,pub))
                    .setNegativeButton("Cancel",(d,w)->finish()).setOnCancelListener(d->finish()).show();
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setFilterTouchesWhenObscured(true);
            }
        } catch (Exception invalid) {
            message("Alarm unavailable","Return to Dosewell for a fresh alarm. Check the time and date shown on your phone.");
        }
    }

    private void send(JSONObject alarm, String pub) {
        try {
            validate(alarm);
            long now = System.currentTimeMillis();
            String replay = "req:"+alarm.getString("nonce");
            SharedPreferences.Editor edit = prefs.edit();
            for (Map.Entry<String,?> item : prefs.getAll().entrySet()) {
                if (item.getKey().startsWith("req:") && (Long)item.getValue() < now-WINDOW-60_000) edit.remove(item.getKey());
            }
            if (prefs.contains(replay)) {
                message("Request already sent","Open Clock and check the existing alarm."); return;
            }
            ZonedDateTime at = target(alarm);
            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR,at.getHour())
                .putExtra(AlarmClock.EXTRA_MINUTES,at.getMinute())
                .putExtra(AlarmClock.EXTRA_MESSAGE,alarm.getString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI,true);
            int days = alarm.getInt("days");
            if (days != 0) {
                ArrayList<Integer> selected = new ArrayList<>();
                for (int i=0;i<7;i++) if ((days&(1<<i))!=0) selected.add(Calendar.SUNDAY+i);
                intent.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS,selected);
            }
            if (!edit.putString("browser",pub).putLong(replay,now).commit()) {
                message("Connection unavailable","This phone could not save the request. Check phone storage and try again."); return;
            }
            try { startActivity(intent); }
            catch (RuntimeException unavailable) {
                prefs.edit().remove(replay).commit();
                message("Clock unavailable","This phone could not open a compatible Clock app. Use the manual setup in Dosewell."); return;
            }
            Toast.makeText(this,"Sent to Clock",Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception expired) {
            message("Refresh this alarm","Return to Dosewell to get its current time and try again.");
        }
    }

    private static ZonedDateTime target(JSONObject alarm) throws Exception {
        return Instant.ofEpochMilli(alarm.getLong("at")).atZone(ZoneId.systemDefault());
    }

    private static String repeatDescription(int mask) {
        if (mask==0) return "One time";
        if (mask==127) return "Every day";
        String[] names = java.text.DateFormatSymbols.getInstance().getWeekdays();
        ArrayList<String> result = new ArrayList<>();
        for (int i=0;i<7;i++) if ((mask&(1<<i))!=0) result.add(names[Calendar.SUNDAY+i]);
        return String.join(", ",result);
    }

    private static void validate(JSONObject alarm) throws Exception {
        long now = System.currentTimeMillis(), issued = alarm.getLong("issued");
        int days = alarm.getInt("days");
        String label = alarm.getString("label");
        if (alarm.getInt("v")!=1 || issued<now-WINDOW || issued>now+15_000 || days<0 || days>127
                || !alarm.getString("nonce").matches("[A-Za-z0-9_-]{22}") || label.length()>500
                || !label.startsWith("Dosewell · ") || label.matches("(?s).*\\p{Cntrl}.*")) throw new IllegalArgumentException();
        ZonedDateTime at = target(alarm);
        if (at.getHour()!=alarm.getInt("hour") || at.getMinute()!=alarm.getInt("minute") ||
            at.getSecond()!=0 || at.getNano()!=0 || at.toInstant().toEpochMilli()<=now) throw new IllegalArgumentException();
        // Android Clock accepts a wall time and weekdays, with no arbitrary start
        // date. Reject requests whose first real alarm would differ or land in a DST fold.
        ZoneId zone = at.getZone();
        LocalDate today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        for (int offset=0;offset<=7;offset++) {
            LocalDate date = today.plusDays(offset);
            if (days!=0 && (days&(1<<(date.getDayOfWeek().getValue()%7)))==0) continue;
            LocalDateTime wall = date.atTime(at.toLocalTime());
            if (wall.atZone(zone).toInstant().toEpochMilli()<=now && zone.getRules().getValidOffsets(wall).size()==1) continue;
            if (zone.getRules().getValidOffsets(wall).size()!=1 || !wall.atZone(zone).equals(at)) throw new IllegalArgumentException();
            return;
        }
        throw new IllegalArgumentException();
    }

    // Web Crypto emits fixed-width r||s. Android's Signature expects DER.
    private static byte[] der(byte[] raw) {
        if (raw.length!=64) throw new IllegalArgumentException();
        byte[] r = new java.math.BigInteger(1,Arrays.copyOfRange(raw,0,32)).toByteArray();
        byte[] s = new java.math.BigInteger(1,Arrays.copyOfRange(raw,32,64)).toByteArray();
        java.nio.ByteBuffer out = java.nio.ByteBuffer.allocate(6+r.length+s.length);
        out.put((byte)0x30).put((byte)(4+r.length+s.length)).put((byte)2).put((byte)r.length).put(r);
        out.put((byte)2).put((byte)s.length).put(s);
        return out.array();
    }

    private void home() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("Dosewell Clock")
            .setMessage("Choose a dose or warning on the Dosewell website. Its time, name and repeat days go directly to the Clock app on this phone.")
            .setPositiveButton("Open Dosewell",(d,w)->{
                try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(SITE)));finish(); }
                catch (RuntimeException error) { message("Browser unavailable","Open Dosewell in your browser to continue."); }
            }).setNegativeButton("Close",(d,w)->finish()).setOnCancelListener(d->finish());
        if (prefs.contains("browser")) dialog.setNeutralButton("Disconnect browser",(d,w)->{
            prefs.edit().clear().commit();message("Browser disconnected","Existing alarms are still in Clock. Approve your next Dosewell alarm to reconnect.");
        });
        dialog.show();
    }

    private void message(String title,String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body)
            .setPositiveButton("Close",(d,w)->finish()).setOnCancelListener(d->finish()).show();
    }
}
