#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_JAR:?Path to Android platform 35 android.jar}"
: "${ANDROID_BUILD_TOOLS:?Path to Android SDK build tools 35.0.0}"
: "${CLOCK_KEYSTORE:?Path to private signing keystore}"
: "${CLOCK_KEY_PASSWORD_FILE:?Path to a file containing its password}"
out=${1:?Path to output APK}
src=$(cd "$(dirname "$0")" && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/classes" "$tmp/dex"
java -m jdk.compiler/com.sun.tools.javac.Main -source 8 -target 8 -bootclasspath "$ANDROID_BUILD_TOOLS/core-lambda-stubs.jar:$ANDROID_JAR" -d "$tmp/classes" "$src/src/org/williamsindustries/dosewellclock/ClockActivity.java"
java -m jdk.jartool/sun.tools.jar.Main --create --file "$tmp/classes.jar" -C "$tmp/classes" .
java -cp "$ANDROID_BUILD_TOOLS/lib/d8.jar" com.android.tools.r8.D8 --min-api 26 --lib "$ANDROID_JAR" --output "$tmp/dex" "$tmp/classes.jar"
"$ANDROID_BUILD_TOOLS/aapt2" compile --dir "$src/res" -o "$tmp/resources.zip"
"$ANDROID_BUILD_TOOLS/aapt2" link --manifest "$src/AndroidManifest.xml" -I "$ANDROID_JAR" "$tmp/resources.zip" -o "$tmp/raw.apk"
(cd "$tmp/dex" && zip -q -0 "$tmp/raw.apk" classes.dex)
"$ANDROID_BUILD_TOOLS/zipalign" -f 4 "$tmp/raw.apk" "$tmp/aligned.apk"
java -jar "$ANDROID_BUILD_TOOLS/lib/apksigner.jar" sign --ks "$CLOCK_KEYSTORE" --ks-key-alias dosewell --ks-pass "file:$CLOCK_KEY_PASSWORD_FILE" --v4-signing-enabled false --out "$out" "$tmp/aligned.apk"
java -jar "$ANDROID_BUILD_TOOLS/lib/apksigner.jar" verify --verbose "$out"
