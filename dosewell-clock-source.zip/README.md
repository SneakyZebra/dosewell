# Dosewell Clock for Android
Android 8.0 or later. Build with JDK 17 or later, Android SDK platform 35 and build tools 35.0.0. No Gradle dependencies or network permission. The one manifest permission lets the activity ask a compatible Clock app to create an alarm.

Run build.sh with an output APK path. Set ANDROID_JAR, ANDROID_BUILD_TOOLS, CLOCK_KEYSTORE and CLOCK_KEY_PASSWORD_FILE. Use the same private dosewell signing alias to ship updates. Increase versionCode for a new release.

The site signs a five-minute single-use request with a browser-local P-256 signing key. The companion requires permission to trust the first public key and refuses a different key until the user disconnects it in the launcher. It checks the next local occurrence before sending ACTION_SET_ALARM. The Clock app controls final behavior. To change or delete existing alarms, use Clock.
