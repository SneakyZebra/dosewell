(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key2 of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key2) && key2 !== except)
          __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // dosewell-apps/schedule.js
  var medicationTitle = (med) => med.strength ? med.name + " " + med.strength : med.name;
  var pad = (value) => String(value).padStart(2, "0");
  var dayKey = (date) => [date.getFullYear(), pad(date.getMonth() + 1), pad(date.getDate())].join("-");
  var localDay = (key2) => /* @__PURE__ */ new Date(key2 + "T12:00:00");
  function shiftDay(day2, offset) {
    const d = localDay(day2);
    d.setDate(d.getDate() + offset);
    return dayKey(d);
  }
  var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  function timeLabel(time) {
    const [h2, m] = time.split(":").map(Number);
    return (h2 % 12 || 12) + ":" + pad(m) + " " + (h2 < 12 ? "AM" : "PM");
  }
  function clockTime(date) {
    return pad(date.getHours()) + ":" + pad(date.getMinutes());
  }
  function hoursLabel(value) {
    return value + " hour" + (Number(value) === 1 ? "" : "s");
  }
  function doseTimeLabel(row) {
    return row.med.mode === "interval" ? row.when.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" }) : timeLabel(row.time);
  }
  function scheduleLabel(med) {
    if (med.mode === "list") return "List only";
    if (med.mode === "interval") return "Every " + hoursLabel(med.intervalHours) + " \xB7 first dose " + new Date(med.anchorAt).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" });
    return (med.days.length === 7 ? "Daily" : med.days.map((d) => dayNames[d]).join(", ")) + " \xB7 " + med.times.map(timeLabel).join(", ");
  }
  function nextInterval(med, from) {
    const step = med.intervalHours * 36e5;
    if (!Number.isSafeInteger(step) || step < 36e5 || !Number.isFinite(med.anchorAt)) return null;
    const n = Math.max(0, Math.ceil((from - med.anchorAt) / step));
    const stamp = med.anchorAt + n * step;
    if (med.untilAt != null && stamp >= med.untilAt) return null;
    const when = new Date(stamp);
    if (!Number.isFinite(when.getTime())) return null;
    return { med, when, day: dayKey(when), time: clockTime(when), key: med.id + "|interval|" + stamp };
  }
  function applies(med, day2) {
    return med.mode !== "list" && day2 >= med.start && (!med.end || day2 <= med.end) && med.days.includes(localDay(day2).getDay());
  }
  function fixedDose(med, day2, time) {
    return { med, day: day2, time, when: /* @__PURE__ */ new Date(day2 + "T" + time + ":00"), key: med.id + "|" + day2 + "|" + time };
  }
  function dosesFor(meds, day2) {
    const start = /* @__PURE__ */ new Date(day2 + "T00:00:00"), end = /* @__PURE__ */ new Date(shiftDay(day2, 1) + "T00:00:00");
    const rows = [];
    for (const med of meds) {
      if (med.mode === "interval") {
        for (let row = nextInterval(med, start); row && row.when < end; row = nextInterval(med, row.when.getTime() + 1)) rows.push(row);
      } else if (applies(med, day2)) {
        for (const time of med.times) rows.push(fixedDose(med, day2, time));
      }
    }
    return rows.sort((a, b) => a.when - b.when || a.med.name.localeCompare(b.med.name));
  }
  function firstNext(med, time, now) {
    if (med.mode === "interval") return nextInterval(med, now);
    const start = dayKey(now) > med.start ? dayKey(now) : med.start;
    for (let i = 0; i <= 7; i++) {
      const day2 = shiftDay(start, i);
      if (!applies(med, day2)) continue;
      const row = fixedDose(med, day2, time);
      if (row.when >= now) return row;
    }
    return null;
  }
  var advanceMinutes = (med, settings) => med.advance === null ? settings.advance : med.advance;
  function dueEvents(state2, now, since) {
    const today = dayKey(now), following = shiftDay(today, 1);
    const result = [];
    const warningHorizon = dayKey(new Date(now.getTime() + 864e5));
    const last = warningHorizon > following ? warningHorizon : following;
    for (let day2 = shiftDay(today, -1); day2 <= last; day2 = shiftDay(day2, 1)) {
      for (const dose of dosesFor(state2.meds, day2)) {
        if (state2.taken[dose.key] || state2.history?.[dose.key]?.status === "skipped") continue;
        const advance = advanceMinutes(dose.med, state2.settings);
        const snooze = state2.snoozes?.[dose.key];
        const events = snooze ? [{ kind: "snooze", at: snooze }] : [{ kind: "due", at: dose.when.getTime() }];
        if (!snooze && advance > 0) events.push({ kind: "advance", at: dose.when.getTime() - advance * 6e4 });
        for (const e of events) {
          const id = dose.key + "|" + e.kind + (e.kind === "snooze" ? "|" + e.at : "");
          if (state2.fired[id] || e.at <= since || e.at > now.getTime()) continue;
          if (e.kind === "advance" && dose.when <= now) continue;
          result.push({ ...dose, ...e, id });
        }
      }
    }
    return result.sort((a, b) => a.at - b.at);
  }
  function escCalendar(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
  }
  function fold(line) {
    const enc = new TextEncoder();
    let out = "", length = 0;
    for (const char of line) {
      const n = enc.encode(char).length;
      if (length + n > 75) {
        out += "\r\n ";
        length = 1;
      }
      out += char;
      length += n;
    }
    return out;
  }
  var utcStamp = (date) => new Date(date).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  function calendarSeries(med, now) {
    if (med.mode === "interval") {
      const first = nextInterval(med, now);
      if (!first) return [];
      let divisor = 24;
      while (24 % divisor !== 0 || med.intervalHours % divisor !== 0) divisor--;
      const phases = 24 / divisor, days2 = med.intervalHours / divisor, step = med.intervalHours * 36e5;
      let rule2 = "FREQ=DAILY;INTERVAL=" + days2;
      if (med.untilAt != null) rule2 += ";UNTIL=" + utcStamp(med.untilAt - 1e3);
      const series = [];
      for (let i = 0; i < phases; i++) {
        const at = first.when.getTime() + i * step;
        if (med.untilAt != null && at >= med.untilAt) break;
        const phase = (at - med.anchorAt) / step % phases;
        series.push({ uid: med.id + "-interval-" + med.anchorAt + "-" + med.intervalHours + "-" + phase, start: utcStamp(at), rule: rule2 });
      }
      return series;
    }
    const days = med.days.map((d) => ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][d]).join(",");
    let rule = med.days.length === 7 ? "FREQ=DAILY" : "FREQ=WEEKLY;BYDAY=" + days;
    if (med.end) rule += ";UNTIL=" + med.end.replaceAll("-", "") + "T235959";
    return med.times.flatMap((time) => {
      const next = firstNext(med, time, now);
      return next ? [{ uid: med.id + "-" + time.replace(":", ""), start: next.day.replaceAll("-", "") + "T" + time.replace(":", "") + "00", rule }] : [];
    });
  }
  function calendarFile(state2, now = /* @__PURE__ */ new Date()) {
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Dosewell//Medication Schedule//EN", "CALSCALE:GREGORIAN", "X-WR-CALNAME:Dosewell medications"];
    let count = 0;
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      for (const { uid, start, rule } of calendarSeries(med, now)) {
        count++;
        const summary = escCalendar(medicationTitle(med) + " \xB7 " + med.dose);
        lines.push("BEGIN:VEVENT", "UID:" + uid + "@dosewell", "DTSTAMP:" + utcStamp(now), "DTSTART:" + start, "DURATION:PT1M", "RRULE:" + rule, "SUMMARY:" + summary, "DESCRIPTION:" + escCalendar("Scheduled dose. Follow your current prescription."), "CLASS:PRIVATE", "TRANSP:TRANSPARENT");
        for (const minutes of [0, advanceMinutes(med, state2.settings)].filter((v, i) => i === 0 || v > 0)) {
          lines.push("BEGIN:VALARM", "ACTION:DISPLAY", "TRIGGER:" + (minutes ? "-PT" + minutes + "M" : "PT0M"), "DESCRIPTION:" + escCalendar((minutes ? "Upcoming dose in " + minutes + " minutes. " : "Scheduled dose. ") + medicationTitle(med) + " \xB7 " + med.dose), "END:VALARM");
        }
        lines.push("END:VEVENT");
      }
    }
    lines.push("END:VCALENDAR");
    return { count, text: lines.map(fold).join("\r\n") + "\r\n" };
  }

  // dosewell-apps/dose-log.js
  function prepareLog(state2) {
    state2.snoozes || (state2.snoozes = {});
    state2.supplies || (state2.supplies = {});
    state2.history || (state2.history = {});
    for (const [key2, recordedAt] of Object.entries(state2.taken)) {
      const [medId, day2, time] = key2.split("|");
      if (!day2 || !time || state2.history[key2]) continue;
      const med = state2.meds.find((item) => item.id === medId);
      state2.history[key2] = { medId, day: day2, time, recordedAt, status: "taken", name: med?.name || "Previously recorded medication", dose: "", legacy: true };
    }
    return state2;
  }
  function doseAt(state2, key2) {
    const [medId, kind, time] = key2.split("|");
    const day2 = kind === "interval" ? dayKey(new Date(Number(time))) : kind;
    if (kind === "interval") {
      const med2 = state2.meds.find((m) => m.id === medId && m.mode === "interval");
      return med2 ? dosesFor([med2], day2).find((row) => row.key === key2) || null : null;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day2) || !/^\d{2}:\d{2}$/.test(time)) return null;
    const med = state2.meds.find((m) => m.id === medId);
    return med ? dosesFor([med], day2).find((d) => d.key === key2) || null : null;
  }
  function recordedStatus(state2, key2) {
    return state2.history?.[key2]?.status || (state2.taken[key2] ? "taken" : "");
  }
  function debitSupply(state2, record) {
    const supply = state2.supplies[record.medId];
    if (!supply || supply.remaining <= 0) return;
    supply.remaining--;
    record.debited = supply.revision;
  }
  function logDose(state2, key2, status, now = /* @__PURE__ */ new Date()) {
    prepareLog(state2);
    if (!["taken", "skipped"].includes(status)) throw Error("Choose a dose status.");
    if (recordedStatus(state2, key2)) throw Error("This dose is already recorded. Undo the entry to change it.");
    const dose = doseAt(state2, key2);
    if (!dose || dose.when > now) throw Error("This scheduled dose is unavailable to record.");
    const { med, day: day2, time } = dose, record = { medId: med.id, day: day2, time, status, name: medicationTitle(med), dose: med.dose, recordedAt: now.getTime() };
    if (med.mode === "interval") record.scheduledLabel = doseTimeLabel(dose);
    if (status === "taken") {
      state2.taken[key2] = record.recordedAt;
      debitSupply(state2, record);
    }
    state2.history[key2] = record;
    delete state2.snoozes[key2];
  }
  function logAsNeeded(state2, medId, key2, now = /* @__PURE__ */ new Date()) {
    prepareLog(state2);
    if (state2.history[key2]) return;
    const med = state2.meds.find((m) => m.id === medId && m.mode === "list");
    if (!med) throw Error("Reopen the medication list to check this entry.");
    const record = { medId, day: dayKey(now), time: "", status: "taken", name: medicationTitle(med), dose: med.dose, recordedAt: now.getTime(), unscheduled: true };
    debitSupply(state2, record);
    state2.history[key2] = record;
  }
  function undoLog(state2, key2, expectedTime) {
    prepareLog(state2);
    const record = state2.history[key2];
    if (!record || record.recordedAt !== expectedTime) throw Error("This entry changed. Reopen its history to review it.");
    const supply = state2.supplies[record.medId];
    if (record.debited && supply?.revision === record.debited) supply.remaining++;
    delete state2.history[key2];
    delete state2.taken[key2];
    delete state2.snoozes[key2];
  }
  function snoozeDose(state2, key2, mins, now = /* @__PURE__ */ new Date()) {
    const dose = doseAt(state2, key2);
    if (!dose || dose.when > now || now - dose.when > 864e5 || recordedStatus(state2, key2) || ![5, 10, 15, 30, 60].includes(mins)) throw Error("This reminder cannot be snoozed.");
    state2.snoozes[key2] = now.getTime() + mins * 6e4;
  }
  function updateSupply(state2, medId, remaining, threshold, expected) {
    prepareLog(state2);
    if (!state2.meds.some((m) => m.id === medId)) throw Error("This medication is no longer on your list.");
    const old = state2.supplies[medId];
    if ((old?.revision || "") !== (expected?.revision || "") || old?.remaining !== expected?.remaining) throw Error("The supply changed. Reopen it to see the current count.");
    if (remaining === null) {
      delete state2.supplies[medId];
      return;
    }
    if (![remaining, threshold].every((v) => Number.isSafeInteger(v) && v >= 0 && v <= 99999)) throw Error("Enter whole numbers between 0 and 99999.");
    state2.supplies[medId] = { remaining, threshold, revision: crypto.randomUUID() };
  }
  function historyEntries(state2, period, now = /* @__PURE__ */ new Date()) {
    const first = localDay(dayKey(now));
    first.setDate(first.getDate() - (Number(period) || 1) + 1);
    const cutoff = period === "all" ? "" : dayKey(first);
    return Object.entries(state2.history || {}).filter(([, r]) => r.day >= cutoff).sort(([, a], [, b]) => b.day.localeCompare(a.day) || b.time.localeCompare(a.time) || b.recordedAt - a.recordedAt);
  }
  function recordClock(record) {
    return new Date(record.recordedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  }
  function recordTiming(record) {
    return record.unscheduled ? "Unscheduled dose" : (record.scheduledLabel || timeLabel(record.time)) + " scheduled";
  }
  function alignDoseKeys(state2, oldMed, newMed) {
    if (oldMed.mode === "interval" === (newMed.mode === "interval")) return;
    for (const [key2, record] of Object.entries(state2.history)) {
      if (record.medId !== oldMed.id || record.unscheduled) continue;
      const parts = key2.split("|");
      const instant = parts[1] === "interval" ? new Date(Number(parts[2])) : /* @__PURE__ */ new Date(record.day + "T" + record.time + ":00");
      if (!Number.isFinite(instant.getTime())) continue;
      const row = dosesFor([newMed], dayKey(instant)).find((r) => r.when.getTime() === instant.getTime());
      if (!row || row.key === key2 || state2.history[row.key]) continue;
      state2.history[row.key] = record;
      delete state2.history[key2];
      if (state2.taken[key2]) {
        state2.taken[row.key] = state2.taken[key2];
        delete state2.taken[key2];
      }
    }
  }

  // dosewell-apps/store.js
  var key = "dosewell.planner.v1";
  var empty = () => ({ version: 1, meds: [], taken: {}, fired: {}, snoozes: {}, supplies: {}, history: {}, settings: { advance: 15, sound: true, notifications: false } });
  var memory = empty();
  var volatile = false;
  var broken = false;
  function read() {
    if (volatile) return memory;
    let raw;
    try {
      raw = localStorage.getItem(key);
    } catch {
      volatile = true;
      return memory;
    }
    if (!raw) return memory = empty();
    try {
      const data = JSON.parse(raw);
      if (data.version !== 1 || !Array.isArray(data.meds) || !data.settings || !data.taken || !data.fired) throw Error();
      return memory = prepareLog(data);
    } catch {
      broken = true;
      return memory;
    }
  }
  function storageStatus() {
    return broken ? "Saved data could not be read. Changes are paused to protect your existing medication list." : volatile ? "This browser cannot save your changes. Your plan will be lost when you leave." : "";
  }
  async function change(update) {
    const write = () => {
      const data = read();
      if (broken) throw Error(storageStatus());
      update(data);
      memory = data;
      if (!volatile) try {
        localStorage.setItem(key, JSON.stringify(data));
      } catch {
        volatile = true;
      }
      return data;
    };
    return navigator.locks ? await navigator.locks.request(key, write) : write();
  }
  function onLocalChange(fn) {
    window.addEventListener("storage", (e) => {
      if (e.key === key || e.key === null) fn();
    });
  }

  // dosewell-apps/plan-backup.js
  var plain = (v) => v !== null && typeof v === "object" && !Array.isArray(v) && Object.getPrototypeOf(v) === Object.prototype;
  var allowedId = (v) => typeof v === "string" && /^[a-z0-9_-]{1,96}$/i.test(v) && !(v in Object.prototype);
  var text = (v) => typeof v === "string";
  var int = (v, min, max) => Number.isSafeInteger(v) && v >= min && v <= max;
  var timestamp = (v) => int(v, 0, 253402300799999);
  var day = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) && (/* @__PURE__ */ new Date(v + "T12:00:00Z")).toJSON()?.slice(0, 10) === v;
  var clock = (v) => typeof v === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  var objOf = (v, test) => plain(v) && Object.entries(v).every(([k, x]) => k.length > 0 && k.length < 250 && !(k in Object.prototype) && test(x, k));
  function validMedication(m) {
    if (!plain(m) || !allowedId(m.id) || !text(m.name) || !m.name.trim() || !text(m.dose) || !m.dose.trim() || !["stroke", "other"].includes(m.category)) return false;
    if (!["daily", "weekly", "interval", "list"].includes(m.mode) || !Array.isArray(m.days) || !m.days.length || !m.days.every((d) => int(d, 0, 6)) || !Array.isArray(m.times) || !m.times.every(clock) || new Set(m.times).size !== m.times.length) return false;
    if (!day(m.start) || m.end !== "" && (!day(m.end) || m.end < m.start) || m.advance !== null && !int(m.advance, 0, 1440)) return false;
    if (m.strength !== void 0 && !text(m.strength) || m.directions !== void 0 && !text(m.directions)) return false;
    if (m.mode !== "list" && !m.times.length) return false;
    return m.mode !== "interval" || int(m.intervalHours, 1, 72) && (m.intervalHours <= 24 || [36, 48, 72].includes(m.intervalHours)) && Number.isFinite(m.anchorAt) && (m.untilAt === null || Number.isFinite(m.untilAt) && m.untilAt > m.anchorAt) && m.times.length === 1;
  }
  function validHistory(r) {
    return plain(r) && allowedId(r.medId) && day(r.day) && (clock(r.time) || r.time === "" && r.unscheduled === true) && timestamp(r.recordedAt) && ["taken", "skipped"].includes(r.status) && text(r.name) && text(r.dose) && (r.scheduledLabel === void 0 || text(r.scheduledLabel));
  }
  function hasPlan(s) {
    return s.meds.length > 0 || Object.keys(s.history || {}).length > 0 || Object.keys(s.taken || {}).length > 0 || Object.keys(s.supplies || {}).length > 0;
  }
  function readBackup(raw) {
    const fail = () => {
      throw Error("Choose an unmodified Dosewell plan file downloaded from the previous address.");
    };
    let wrapper;
    try {
      wrapper = JSON.parse(raw, (k, v) => {
        if (["__proto__", "prototype", "constructor"].includes(k)) fail();
        return v;
      });
    } catch {
      fail();
    }
    if (!plain(wrapper) || wrapper.format !== "dosewell-plan-backup-v1") fail();
    const s = wrapper.plan;
    if (!plain(s) || s.version !== 1 || !Array.isArray(s.meds) || !s.meds.every(validMedication) || new Set(s.meds.map((m) => m.id)).size !== s.meds.length) fail();
    if (!plain(s.settings) || !int(s.settings.advance, 0, 1440) || typeof s.settings.sound !== "boolean" || typeof s.settings.notifications !== "boolean") fail();
    if (!objOf(s.taken, timestamp) || !objOf(s.fired, timestamp) || !objOf(s.snoozes, timestamp) || !objOf(s.history, validHistory)) fail();
    if (!objOf(s.supplies, (v, k) => allowedId(k) && plain(v) && int(v.remaining, 0, 99999) && int(v.threshold, 0, 99999) && allowedId(v.revision))) fail();
    if (!hasPlan(s)) throw Error("This backup contains no medication entries or dose history.");
    return { version: 1, meds: s.meds, history: s.history, taken: s.taken, fired: s.fired, snoozes: s.snoozes, supplies: s.supplies, settings: { advance: s.settings.advance, sound: s.settings.sound, notifications: false } };
  }

  // dosewell-apps/native-alarms.js
  var nativePlatform = window.DosewellNative ? "Android" : window.webkit?.messageHandlers?.dosewell ? "iPhone" : "";
  var lastStatus = "Open Reminders to enable Dosewell alarms.";
  function command(action, data = {}) {
    if (!nativePlatform) return;
    const message = JSON.stringify({ action, ...data });
    if (nativePlatform === "Android") window.DosewellNative.message(message);
    else window.webkit.messageHandlers.dosewell.postMessage(message);
  }
  function nativeStatus(message, attention) {
    lastStatus = String(message);
    const line = document.querySelector("#native-status");
    if (line) line.textContent = lastStatus;
    const banner = document.querySelector("#native-banner");
    if (banner) {
      banner.hidden = !attention;
      banner.querySelector("span").textContent = lastStatus;
    }
  }
  window.onDosewellAlarmStatus = nativeStatus;
  var soundDescription = "Dose and advance alarms use the Dosewell chime and vibration.";
  var usingOlderSound = false;
  window.onDosewellSoundStatus = (description, legacy) => {
    soundDescription = description;
    usingOlderSound = legacy;
    const note = document.getElementById("native-sound-status");
    if (note) note.textContent = description;
    const use = document.getElementById("use-dosewell-chime");
    if (use) use.hidden = !legacy;
  };
  function paintNative() {
    const p = document.getElementById("native-status");
    if (p) p.textContent = lastStatus;
    if (nativePlatform !== "Android" || !p) return;
    const section = document.createElement("section");
    section.setAttribute("aria-label", "Alarm sound");
    const title = document.createElement("h3");
    title.textContent = "Alarm sound";
    const note = document.createElement("p");
    note.id = "native-sound-status";
    note.textContent = soundDescription;
    const choose = document.createElement("button");
    choose.type = "button";
    choose.className = "btn small outline";
    choose.id = "use-dosewell-chime";
    choose.textContent = "Use gentle chime and vibration";
    choose.hidden = !usingOlderSound;
    choose.onclick = () => command("gentle");
    const settings = document.createElement("button");
    settings.type = "button";
    settings.className = "btn small outline";
    settings.textContent = "Android sound settings";
    settings.onclick = () => command("channel-settings");
    section.append(title, note, choose, settings);
    p.parentElement.append(section);
  }
  function nextTime(rule, after, skip) {
    const lead = rule.lead * 6e4;
    if (rule.mode === "snooze") return rule.at > after ? rule.at : null;
    if (rule.mode === "interval") {
      let n = Math.max(0, Math.floor((after + lead - rule.anchor) / rule.step) + 1);
      for (; ; n++) {
        const at = rule.anchor + n * rule.step;
        if (rule.until && at >= rule.until) return null;
        if (!skip.has(rule.med + "|interval|" + at)) return at - lead;
      }
    }
    let day2 = dayKey(new Date(after + lead));
    if (day2 < rule.start) day2 = rule.start;
    while (!rule.end || day2 <= rule.end) {
      const dose = /* @__PURE__ */ new Date(day2 + "T" + rule.time + ":00");
      if (rule.days & 1 << (/* @__PURE__ */ new Date(day2 + "T12:00:00")).getDay() && dose.getTime() - lead > after && !skip.has(rule.med + "|" + day2 + "|" + rule.time)) return dose.getTime() - lead;
      day2 = shiftDay(day2, 1);
    }
    return null;
  }
  function alarmRules(state2) {
    const rules2 = [], skip = /* @__PURE__ */ new Set([...Object.keys(state2.taken), ...Object.entries(state2.history || {}).filter(([, r]) => r.status === "skipped" || r.status === "taken").map(([k]) => k), ...Object.keys(state2.snoozes || {})]);
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      const name = medicationTitle(med) + " \xB7 " + med.dose;
      for (const lead of /* @__PURE__ */ new Set([0, advanceMinutes(med, state2.settings) || 0])) {
        const base = { med: med.id, lead, label: (lead ? "In " + lead + " min: " : "Dose: ") + name };
        if (med.mode === "interval") rules2.push({ ...base, id: med.id + "|interval|" + lead, mode: "interval", anchor: med.anchorAt, step: med.intervalHours * 36e5, until: med.untilAt || 0 });
        else for (const time of med.times) rules2.push({ ...base, id: med.id + "|" + time + "|" + lead, mode: "weekly", time, start: med.start, end: med.end, days: med.days.reduce((mask, d) => mask | 1 << d, 0) });
      }
      for (const [key2, at] of Object.entries(state2.snoozes || {})) if (key2.startsWith(med.id + "|") && !state2.taken[key2] && !state2.history?.[key2])
        rules2.push({ id: key2 + "|snooze", med: med.id, lead: 0, label: "Snoozed: " + name, mode: "snooze", at });
    }
    return { rules: rules2, skip: [...skip] };
  }
  function weeklyPattern(r, at, now) {
    if (r.mode !== "weekly" || r.end || r.start > dayKey(new Date(now))) return null;
    const [h2, m] = r.time.split(":").map(Number), wall = h2 * 60 + m - r.lead;
    const minute = (wall % 1440 + 1440) % 1440;
    const mask = wall < 0 ? r.days >> 1 | (r.days & 1) << 6 : r.days;
    const time = String(Math.floor(minute / 60)).padStart(2, "0") + ":" + String(minute % 60).padStart(2, "0");
    const natural = nextTime({ mode: "weekly", start: r.start, end: "", time, days: mask, lead: 0, med: r.med }, now, /* @__PURE__ */ new Set());
    if (at !== natural) return null;
    if (r.lead) {
      let d = dayKey(new Date(now));
      for (let i = 0; i < 370; i++, d = shiftDay(d, 1)) {
        const dose = /* @__PURE__ */ new Date(d + "T" + r.time + ":00");
        if (r.days & 1 << dose.getDay() && clockTime(new Date(dose - r.lead * 6e4)) !== time) return null;
      }
    }
    return { days: mask, hour: Math.floor(minute / 60), minute: minute % 60 };
  }
  function iphoneQueue(plan, now = Date.now(), limit = 24) {
    const skip = new Set(plan.skip), weekly = [], dated = [];
    for (const r of plan.rules) {
      const at = nextTime(r, now, skip);
      if (at === null) continue;
      const pattern = weeklyPattern(r, at, now);
      const upcomingException = plan.skip.some((k) => k.startsWith(r.med + "|") && k.split("|")[1] >= dayKey(new Date(now)));
      if (pattern && !upcomingException) weekly.push({ key: r.id, label: r.label, ...pattern });
      else dated.push({ rule: r, at });
    }
    if (weekly.length >= limit && dated.length || weekly.length > limit) {
      weekly.length = 0;
      dated.length = 0;
      for (const r of plan.rules) {
        const at = nextTime(r, now, skip);
        if (at !== null) dated.push({ rule: r, at });
      }
    }
    const alarms = [...weekly];
    while (dated.length && alarms.length < limit) {
      const at = Math.min(...dated.map((e) => e.at)), same = dated.filter((e) => e.at === at);
      alarms.push({ key: "date|" + at, label: same.map((e) => e.rule.label).join(" \u2022 "), at });
      for (const item of same) {
        const next = nextTime(item.rule, at, skip);
        if (next === null) dated.splice(dated.indexOf(item), 1);
        else item.at = next;
      }
    }
    return { alarms, refill: dated.length ? Math.min(...dated.map((e) => e.at)) : 0 };
  }
  function syncNative() {
    if (!nativePlatform) return;
    const plan = alarmRules(read());
    command("sync", nativePlatform === "iPhone" ? iphoneQueue(plan) : plan);
  }
  function nativeAction(action) {
    if (action === "enable-app-alarms") {
      syncNative();
      command("enable");
    }
    if (action === "test-app-alarm") command("test");
    if (action === "stop-app-alarms") command("disable");
  }
  async function importNativeFile(file) {
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) throw Error("Choose a Dosewell plan file smaller than 12 MB.");
    const imported = readBackup(await file.text());
    await change((s) => {
      if (hasPlan(s)) throw Error("Import into an empty plan to preserve your existing entries.");
      Object.assign(s, imported);
    });
  }

  // dosewell-apps/icons.js
  var paths = {
    message: '<path d="M4 4.5h16a1.5 1.5 0 0 1 1.5 1.5v10a1.5 1.5 0 0 1-1.5 1.5H9L3 21V6A1.5 1.5 0 0 1 4.5 4.5Z"/><path d="M7 9h10M7 13h6"/>',
    history: '<path d="M3 12a9 9 0 1 0 2.7-6.4L3 8m0-5v5h5"/><path d="M12 7v5l3 2"/>',
    sunset: '<path d="M2 16h20M4 20h16M7 15a5 5 0 0 1 10 0M12 2v7m-3-3 3 3 3-3M3 9l2 2m14 0 2-2"/>',
    print: '<path d="M7 8V3h10v5M7 16H3V9h18v7h-4"/><path d="M7 13h10v8H7zM17 11h1"/>',
    camera: '<path d="M8 6l1.5-2h5L16 6h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z"/><circle cx="12" cy="13" r="3.5"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="m4 17 5-5 4 4 3-4 5 5"/>',
    overview: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    pill: '<path d="M8.2 20a5.7 5.7 0 0 1-4-9.7l6.2-6.2a5.7 5.7 0 0 1 8.1 8.1l-6.3 6.2A5.6 5.6 0 0 1 8.2 20Z"/><path d="m7.3 7.3 8.1 8.1"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 10h18c0-3-3-3-3-10Z"/><path d="M10 21a2.5 2.5 0 0 0 4 0"/>',
    shield: '<path d="M12 2.5c2.4 2.1 6 3.3 8 3.5v5.8c0 4.4-3 7.7-8 10-5-2.3-8-5.6-8-10V6c2-.2 5.6-1.4 8-3.5Z"/><path d="m8.5 12 2.3 2.3 4.7-5"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M7 3v4m10-4v4M3 10h18m-13 4h2m4 0h2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.3 2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
    go: '<path d="m8 16 9-9m-9 0h9v9"/>',
    right: '<path d="m9 6 6 6-6 6"/>',
    left: '<path d="m15 6-6 6 6 6"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 4 2c-1.2.8-1.5 1.3-1.5 2.5M12 17h.01"/>',
    lock: '<rect x="5.5" y="10" width="13" height="11" rx="2"/><path d="M8.5 10V7a3.5 3.5 0 0 1 7 0v3M12 14v3"/>',
    morning: '<path d="M2 17h20M4 21h16M6.5 16a5.5 5.5 0 0 1 11 0M12 3v4M3 10l2 2m14 0 2-2M2 14l1 .3M21 14l1-.3"/>',
    sun: '<circle cx="12" cy="12" r="4.2"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.6 1.6m10.8 10.8L19 19M5 19l1.6-1.6M17.4 6.6 19 5"/>',
    moon: '<path d="M20.3 14.3A8.8 8.8 0 0 1 9.7 3.7a8.8 8.8 0 1 0 10.6 10.6Z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-9h.01"/>',
    heart: '<path d="m12 21-8-7.4a5.5 5.5 0 0 1 8-7.3 5.5 5.5 0 0 1 8 7.3Z"/><path d="M3 12h5l1.7-3.5 3 6 2-4H20"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    list: '<path d="M9 6h12M9 12h12M9 18h12M3 6h1M3 12h1M3 18h1"/>',
    sound: '<path d="M3 9h4l5-4v14l-5-4H3Zm13-1a5 5 0 0 1 0 8m3-11a9 9 0 0 1 0 14"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/>',
    edit: '<path d="m14.5 5.5 4 4M3 21l4.8-1.1L20 7.6a2.8 2.8 0 0 0-4-4L3.9 16Z"/>',
    alert: '<path d="m10.4 4.5-8 14A1.6 1.6 0 0 0 3.8 21h16.4a1.6 1.6 0 0 0 1.4-2.5l-8-14a1.8 1.8 0 0 0-3.2 0Z"/><path d="M12 9v5m0 3h.01"/>',
    bottle: '<rect x="7" y="2.5" width="10" height="4.5" rx="1"/><rect x="5" y="7" width="14" height="14" rx="3"/><path d="M5 11h14M5 17h14"/>',
    book: '<path d="M12 6c-2-2-6-3-9-2v15c3-1 7 0 9 2 2-2 6-3 9-2V4c-3-1-7 0-9 2Zm0 0v15"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>'
  };
  function icon(name, size = 20) {
    return '<svg aria-hidden="true" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">' + (paths[name] || "") + "</svg>";
  }

  // dosewell-apps/rules.js
  var labelId = {
    nimodipine: "e660fa26-b5c4-4d6d-8887-9e22b6666a10",
    atorvastatin: "e91c673d-c26c-4ff1-90d2-2b9d47a8d771",
    lisinopril: "838c2d78-d2d8-4981-9ec9-e50ef9e1a5d8",
    apixaban: "7be1f4c1-bb2f-4ded-ae9a-515d2a22f93e",
    rivaroxaban: "10db92f9-2300-4a80-836b-673e1ae91610",
    warfarin: "19a69a72-ac5d-45d5-a94d-a5aaecbe4730",
    clopidogrel: "de8b0b67-eb25-4684-83b5-7ad785314227"
  };
  var aspirinSource = "https://medlineplus.gov/druginfo/meds/a682878.html";
  var labelUrl = (drug) => "https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=" + labelId[drug];
  var brandNames = {
    nimodipine: ["Nymalize", "Nimotop"],
    atorvastatin: ["Lipitor", "Atorvastatin calcium"],
    lisinopril: ["Zestril", "Prinivil"],
    amlodipine: ["Norvasc"],
    metoprolol: ["Lopressor", "Toprol XL", "Metoprolol succinate", "Metoprolol tartrate"],
    losartan: ["Cozaar"],
    hydrochlorothiazide: ["Microzide", "HCTZ"],
    apixaban: ["Eliquis"],
    rivaroxaban: ["Xarelto"],
    warfarin: ["Coumadin", "Jantoven", "Warfarin sodium"],
    clopidogrel: ["Plavix", "Clopidogrel bisulfate"],
    aspirin: ["Acetylsalicylic acid", "ASA", "Ecotrin", "Bayer Aspirin", "Low dose aspirin", "Aspirin low dose"],
    ibuprofen: ["Advil", "Motrin"],
    naproxen: ["Aleve", "Naprosyn", "Naproxen sodium"],
    omeprazole: ["Prilosec", "Prilosec OTC"],
    esomeprazole: ["Nexium"],
    clarithromycin: ["Biaxin"],
    itraconazole: ["Sporanox"],
    ritonavir: ["Norvir"],
    carbamazepine: ["Tegretol", "Carbatrol"],
    phenytoin: ["Dilantin"],
    rifampin: ["Rifadin", "Rifampicin"],
    phenobarbital: [],
    "st johns wort": ["St. John\u2019s wort", "Saint John's wort"],
    gemfibrozil: ["Lopid"],
    "sacubitril/valsartan": ["Entresto", "sacubitril valsartan", "valsartan/sacubitril"],
    spironolactone: ["Aldactone"],
    amiloride: ["Midamor"],
    triamterene: ["Dyrenium"],
    "potassium chloride": ["Klor Con", "K Tab"],
    "potassium gluconate": [],
    lithium: ["Lithobid", "Lithium carbonate"],
    amiodarone: ["Pacerone", "Cordarone"],
    metronidazole: ["Flagyl"],
    fluconazole: ["Diflucan"],
    "trimethoprim/sulfamethoxazole": ["Bactrim", "Bactrim DS", "Septra", "Co-trimoxazole", "Sulfamethoxazole/trimethoprim", "TMP-SMX"],
    sertraline: ["Zoloft"],
    fluoxetine: ["Prozac"],
    venlafaxine: ["Effexor"],
    duloxetine: ["Cymbalta"]
  };
  function clean(s) {
    return s.toLowerCase().normalize("NFKD").replace(/[’'\.]/g, "").replace(/[-/(),]/g, " ").replace(/\s+/g, " ").trim();
  }
  var aliases = /* @__PURE__ */ new Map();
  for (const [drug, brands] of Object.entries(brandNames)) {
    for (const n of [drug, ...brands]) aliases.set(clean(n), drug);
  }
  var suggestions = Object.entries(brandNames).flatMap(([generic, brands]) => [generic, ...brands.slice(0, 1)]).sort();
  function ingredient(name) {
    let n = clean(name);
    if (aliases.has(n)) return aliases.get(n);
    n = n.replace(/\s+\d+(?:\.\d+)?\s*(?:mg|mcg|g)(?:\s+(?:oral\s+)?(?:tablet|capsule)s?)?$/i, "");
    if (aliases.has(n)) return aliases.get(n);
    const parens = name.match(/^([^()]+)\s*\(([^()]+)\)$/);
    if (parens) {
      const one = aliases.get(clean(parens[1])), two = aliases.get(clean(parens[2]));
      if (one && one === two) return one;
    }
    return null;
  }
  var rules = /* @__PURE__ */ new Map();
  function set(drug, others, level, reason, source = labelUrl(drug)) {
    for (const other of others) rules.set([drug, other].sort().join("|"), { level, reason, source });
  }
  var inducers = ["carbamazepine", "phenytoin", "rifampin", "st johns wort"];
  set("nimodipine", ["clarithromycin", "itraconazole", "ritonavir"], "avoid", "These medicines can raise nimodipine levels and cause a serious drop in blood pressure. The label generally advises avoiding this combination.");
  set("nimodipine", [...inducers, "phenobarbital"], "avoid", "This combination can lower nimodipine levels and reduce its effect. The label generally advises avoiding it.");
  set("nimodipine", ["lisinopril", "amlodipine", "metoprolol", "losartan", "hydrochlorothiazide"], "review", "Taking these together can lower blood pressure further. Ask your care team whether additional blood pressure checks are needed.");
  set("nimodipine", ["fluconazole", "fluoxetine", "amiodarone"], "review", "Nimodipine levels may rise and lower your blood pressure. Ask your prescriber about blood pressure checks.");
  set("atorvastatin", ["gemfibrozil"], "avoid", "This combination raises the risk of serious muscle injury. The atorvastatin label advises against using them together.");
  set("atorvastatin", ["clarithromycin", "itraconazole"], "review", "These medicines can raise atorvastatin levels and the risk of muscle injury. Ask your prescriber to review your dose.");
  set("lisinopril", ["sacubitril/valsartan"], "avoid", "Using these together can cause dangerous swelling. The label requires at least 36 hours between treatments when switching. Contact your prescriber promptly to confirm the plan.");
  set("lisinopril", ["spironolactone", "amiloride", "triamterene", "potassium chloride", "potassium gluconate"], "review", "Potassium levels can become too high. Ask your care team whether you need a potassium blood test.");
  set("lisinopril", ["lithium"], "review", "Lisinopril can increase the risk of lithium toxicity. Your prescriber may need to check your lithium level.");
  for (const drug of ["apixaban", "rivaroxaban"]) {
    set(drug, inducers, "avoid", "This combination can lower the blood thinner level and reduce protection against clots. The label advises avoiding concurrent use.");
    set(drug, ["aspirin", "clopidogrel", "ibuprofen", "naproxen", "warfarin"], "review", "Bleeding risk can increase when these are used together. Ask your pharmacist to confirm the plan, including any over the counter use.");
  }
  set("apixaban", ["rivaroxaban"], "review", "Both medicines reduce clotting. Taking them together can increase bleeding risk. Contact your prescriber to confirm whether this is a planned switch.");
  set("clopidogrel", ["aspirin"], "review", "Both reduce platelet activity and can increase bleeding. They are sometimes prescribed together. Confirm the planned duration with your prescriber before making a change.");
  set("clopidogrel", ["omeprazole", "esomeprazole"], "avoid", "This acid reducer can make clopidogrel less effective at preventing clots. The label advises avoiding the combination.");
  set("clopidogrel", ["ibuprofen", "naproxen", "warfarin", "sertraline", "fluoxetine", "venlafaxine", "duloxetine"], "review", "This combination can increase bleeding risk. Ask your pharmacist whether you need monitoring or a change in your plan.");
  set("warfarin", ["amiodarone", "metronidazole", "trimethoprim/sulfamethoxazole", "fluconazole"], "review", "This medicine can increase the effect of warfarin. Contact your anticoagulation team about INR checks when starting or stopping it.");
  set("warfarin", ["aspirin", "clopidogrel", "ibuprofen", "naproxen"], "review", "This combination can increase bleeding risk. Ask your pharmacist or anticoagulation team to review it.");
  set("aspirin", ["ibuprofen"], "review", "Ibuprofen can interfere with aspirin taken for stroke or heart protection. Ask your pharmacist before adding it.", aspirinSource);
  var pairReferences = {
    "clopidogrel|omeprazole": "https://www.drugs.com/drug-interactions/clopidogrel-with-omeprazole-1750-0-705-0.html",
    "clopidogrel|esomeprazole": "https://www.drugs.com/drug-interactions/clopidogrel-with-esomeprazole-1015-0-705-0.html",
    "apixaban|ibuprofen": "https://www.drugs.com/drug-interactions/apixaban-with-ibuprofen-3438-0-1310-0.html"
  };
  function compare(meds) {
    const result = [];
    for (let i = 0; i < meds.length; i++) for (let j = i + 1; j < meds.length; j++) {
      const a = meds[i], b = meds[j];
      if (a.category !== "stroke" && b.category !== "stroke") continue;
      const x = ingredient(a.name), y = ingredient(b.name);
      const key2 = [x, y].sort().join("|");
      let finding = x && y ? rules.get(key2) : null;
      if (x && x === y || clean(a.name) === clean(b.name)) finding = { level: "duplicate", reason: "These entries may contain the same medication. Confirm the intended dose and schedule with your pharmacist." };
      result.push({ a, b, pairReference: pairReferences[key2], ...finding || { level: "unassessed", reason: "This combination has not been assessed by this checker." } });
    }
    return result.sort((a, b) => ["avoid", "duplicate", "review", "unassessed"].indexOf(a.level) - ["avoid", "duplicate", "review", "unassessed"].indexOf(b.level));
  }
  var warningLabel = { avoid: "Label advises avoidance", review: "Pharmacist review", duplicate: "Possible duplicate", unassessed: "Unassessed" };

  // dosewell-apps/view.js
  var h = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  var dateLabel = (date, opts) => date.toLocaleDateString("en-US", opts);
  var btn = (action, label, ic, cls = "btn") => '<button class="' + cls + '" data-action="' + action + '">' + (ic ? icon(ic, 17) : "") + label + "</button>";
  var btnIcon = (action, label, ic) => '<button class="icon-button" aria-label="' + label + '" data-action="' + action + '">' + icon(ic, 17) + "</button>";
  var badge = (i, color = "mint", size = 22) => '<span class="badgeicon ' + color + '">' + icon(i, size) + "</span>";
  var counts = (meds) => ({ stroke: meds.filter((m) => m.category === "stroke").length, other: meds.filter((m) => m.category === "other").length });
  var plural = (n, s) => n + " " + s + (n === 1 ? "" : "s");
  var navItems = [["overview", "calendar", "Today"], ["medications", "pill", "Medications"], ["history", "history", "History"], ["reminders", "bell", "Reminders"], ["interactions", "shield", "Interactions"]];
  function nav(view2) {
    return navItems.map(([id, ic, label]) => '<a href="#' + id + '" ' + (id === view2 ? 'aria-current="page"' : "") + ">" + icon(ic, 17) + "<span>" + label + "</span></a>").join("");
  }
  var periods = [
    { name: "Morning", icon: "morning", hours: "6 AM \u2013 noon" },
    { name: "Afternoon", icon: "sun", hours: "Noon \u2013 5 PM" },
    { name: "Evening", icon: "sunset", hours: "5 PM \u2013 9 PM" },
    { name: "Night", icon: "moon", hours: "9 PM \u2013 6 AM" }
  ];
  function periodIndex(time) {
    const h2 = Number(time.slice(0, 2));
    return h2 < 6 || h2 >= 21 ? 3 : h2 < 12 ? 0 : h2 < 17 ? 1 : 2;
  }
  function scheduleRows(state2, day2, rows, part2, now) {
    if (!rows.length) {
      const title = part2 === null ? "No doses scheduled" : "No " + periods[part2].name.toLowerCase() + " doses";
      return '<div class="schedule-empty">' + icon(part2 === null ? "pill" : periods[part2].icon, 26) + "<h3>" + title + "</h3><p>" + (state2.meds.length ? "Choose another day or review your medication schedule." : "Add a medication with a dose time to start your pillbox.") + "</p></div>";
    }
    return rows.map((d) => {
      const status = recordedStatus(state2, d.key), snooze = state2.snoozes[d.key], future = d.when > now;
      const label = status === "taken" ? "Taken" : status === "skipped" ? "Skipped" : future ? "Upcoming" : snooze > now ? "Snoozed" : "Unrecorded";
      const key2 = h(d.key);
      const logged = state2.history[d.key];
      const statusText = '<span class="dose-status ' + label.toLowerCase() + '">' + label + "</span>";
      let actions = "";
      if (status) {
        actions = '<button class="text-link" data-log-undo="' + key2 + '" data-stamp="' + state2.history[d.key].recordedAt + '">Undo</button>';
      } else if (!future) {
        actions = '<button class="btn small primary" data-take="' + key2 + '">' + icon("check", 16) + 'Mark taken</button><button class="btn small outline" data-skip="' + key2 + '">Log skipped</button>' + (day2 === dayKey(now) ? '<button class="btn small quiet" data-snooze="' + key2 + '">' + icon("clock", 15) + "Snooze</button>" : "");
      }
      const extra = snooze > now && !status ? "<small>Reminder at " + h(new Date(snooze).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })) + "</small>" : "";
      return '<article class="pillbox-dose"><div class="scheduled-time">' + icon(periods[periodIndex(d.time)].icon, 17) + doseTimeLabel(d) + '</div><div class="dose-copy"><b>' + h(logged?.name || medicationTitle(d.med)) + "</b><small>" + h(logged ? logged.dose : d.med.dose) + "</small>" + extra + "</div>" + statusText + (actions ? '<div class="dose-controls">' + actions + "</div>" : "") + "</article>";
    }).join("");
  }
  function schedule(state2, selected2, part2 = null) {
    const d = localDay(selected2), now = /* @__PURE__ */ new Date(), today = dayKey(now), all = dosesFor(state2.meds, selected2);
    const start = shiftDay(selected2, -((d.getDay() + 6) % 7));
    const strip = Array.from({ length: 7 }, (_, i) => {
      const key2 = shiftDay(start, i), date = localDay(key2);
      return '<button data-date="' + key2 + '" class="day ' + (key2 === selected2 ? "selected" : "") + '" aria-label="' + dateLabel(date, { dateStyle: "full" }) + '" aria-pressed="' + (key2 === selected2) + '"><span>' + dayNames[date.getDay()] + "</span><b>" + date.getDate() + "</b>" + (key2 === today ? '<i aria-label="Today"></i>' : "") + "</button>";
    }).join("");
    const cells = periods.map((p, i) => {
      const count = all.filter((dose) => periodIndex(dose.time) === i).length;
      return '<button class="compartment slot-' + i + '" data-part="' + i + '" aria-pressed="' + (part2 === i) + '" aria-label="' + p.name + ", " + p.hours + ", " + plural(count, "dose") + '">' + icon(p.icon, 23) + "<b>" + p.name + "</b><span>" + plural(count, "dose") + "</span></button>";
    }).join("");
    const shown = part2 === null ? all : all.filter((dose) => periodIndex(dose.time) === part2);
    return '<section class="panel schedule"><div class="panel-head"><div class="section-title">' + icon("pill", 21) + '<h2>Daily pillbox</h2></div><span class="count">' + plural(all.length, "dose") + '</span></div><div class="calendar-top"><b>' + dateLabel(d, { month: "long", year: "numeric" }) + "</b><div>" + btnIcon("prev-week", "Previous week", "left") + btn("today", "Today", "", "today-button") + btnIcon("next-week", "Next week", "right") + '</div></div><div class="week">' + strip + '</div><div class="compartments" aria-label="Filter doses by time of day">' + cells + '</div><div class="pillbox-list">' + (part2 === null ? "" : '<div class="part-filter"><b>' + periods[part2].name + '</b><button data-action="all-periods" class="text-link">Show all times</button></div>') + scheduleRows(state2, selected2, shown, part2, now) + "</div></section>";
  }
  function nextDose(state2, now) {
    let next = null;
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      for (const time of med.times) {
        let row = firstNext(med, time, now);
        while (row && recordedStatus(state2, row.key)) row = firstNext(med, time, new Date(row.when.getTime() + 1));
        if (row && (!next || row.when < next.when)) next = row;
      }
    }
    return next;
  }
  function dailySummary(state2, now) {
    if (!state2.meds.length) {
      return '<section class="day-summary"><div class="summary-top">' + icon("clock", 20) + '<h2>Medication reminders</h2></div><p class="next-time">Set up your first dose</p><p>Enter the name and dose from your prescription label, or use a photo to fill in the details.</p><button class="start-scan" data-action="add">' + icon("camera", 17) + "Add from a label</button></section>";
    }
    const day2 = dayKey(now), rows = dosesFor(state2.meds, day2);
    const taken = rows.filter((d) => recordedStatus(state2, d.key) === "taken").length;
    const skipped = rows.filter((d) => recordedStatus(state2, d.key) === "skipped").length;
    const next = nextDose(state2, now);
    const when = next ? (next.day === day2 ? "Today" : next.day === shiftDay(day2, 1) ? "Tomorrow" : dateLabel(localDay(next.day), { month: "short", day: "numeric" })) + " \xB7 " + doseTimeLabel(next) : "";
    return '<section class="day-summary"><div class="summary-top">' + icon("clock", 20) + "<h2>Next scheduled dose</h2></div>" + (next ? '<p class="next-time">' + h(when) + "</p><p><b>" + h(medicationTitle(next.med)) + "</b> \xB7 " + h(next.med.dose) + "</p>" : '<p class="next-time">No upcoming doses</p>') + '<div class="daily-progress"><div><span>Today\u2019s record</span><b>' + taken + " / " + rows.length + ' taken</b></div><progress max="' + (rows.length || 1) + '" value="' + taken + '" aria-label="Scheduled doses marked taken today"></progress><small>' + skipped + " skipped \xB7 " + (rows.length - taken - skipped) + ' unrecorded</small></div><a href="#history">View dose history ' + icon("arrow", 16) + "</a></section>";
  }
  function refillNotices(state2) {
    const low = state2.meds.filter((m) => state2.supplies[m.id] && state2.supplies[m.id].remaining <= state2.supplies[m.id].threshold);
    if (!low.length) return "";
    return '<section class="panel refill-notices"><div class="section-title">' + icon("bottle", 20) + "<h2>Refill reminders</h2></div>" + low.map((m) => '<button class="refill-item" data-supply="' + h(m.id) + '"><span><b>' + h(medicationTitle(m)) + "</b><small>" + plural(state2.supplies[m.id].remaining, "dose") + " remaining</small></span>" + icon("right", 16) + "</button>").join("") + "</section>";
  }
  function checkerCard(state2) {
    const n = counts(state2.meds);
    const alerts = compare(state2.meds).filter((p) => p.level !== "unassessed").length;
    return '<section class="panel safety-card"><div class="section-title">' + badge("shield", "lilac", 23) + '<h2>Interaction checker</h2></div><p>Review possible interactions between stroke medications and other medicines you take.</p><div class="pair-lines"><a href="#medications/stroke">' + icon("heart", 18) + "Stroke medications <b>" + n.stroke + '</b></a><a href="#medications/other">' + icon("pill", 18) + "Other medications <b>" + n.other + "</b></a></div>" + (alerts ? '<div class="flag-line">' + icon("alert", 16) + plural(alerts, "warning") + " to review</div>" : "") + '<a href="#interactions" class="text-link">Review interactions ' + icon("arrow", 16) + "</a></section>";
  }
  function overview(state2, selected2, part2 = null) {
    const now = /* @__PURE__ */ new Date();
    return '<section class="planner-intro app-intro"><div class="intro-title"><p>' + dateLabel(now, { dateStyle: "full" }) + "</p><h1>Today</h1></div>" + btn("add", "Add medication", "plus", "btn primary") + '</section><div class="overview-grid">' + schedule(state2, selected2, part2) + "<aside>" + dailySummary(state2, now) + refillNotices(state2) + checkerCard(state2) + "</aside></div>";
  }
  var pageHead = (title, sub, action = "") => '<div class="page-head"><div><h1>' + title + "</h1><p>" + sub + "</p></div>" + action + "</div>";
  function medicationPage(state2, filter2) {
    const meds = state2.meds.filter((m) => filter2 === "all" || m.category === filter2);
    const tabs = [["all", "All medications"], ["stroke", "Stroke medications"], ["other", "Other medications"]];
    return pageHead("My medications", "Keep your prescribed doses and other medicines together.", btn("add", "Add medication", "plus", "btn primary")) + '<section class="panel listing"><div class="filters" aria-label="Filter medications">' + tabs.map(([v, t]) => "<a " + (filter2 === v ? 'aria-current="page"' : "") + ' href="#medications/' + v + '">' + t + " <span>" + (v === "all" ? state2.meds.length : state2.meds.filter((m) => m.category === v).length) + "</span></a>").join("") + "</div>" + (meds.length ? '<div class="med-list">' + meds.map((m) => '<article class="med-row">' + badge(m.category === "stroke" ? "heart" : "pill", m.category === "stroke" ? "mint" : "lilac") + '<div class="med-detail"><small>' + h(m.category === "stroke" ? "Stroke medication" : "Other medication") + "</small><h3>" + h(medicationTitle(m)) + "</h3><p>" + h(m.dose) + "</p>" + (m.directions ? '<div class="label-directions">' + h(m.directions) + "</div>" : "") + "<span>" + icon("clock", 14) + h(scheduleLabel(m)) + "</span>" + (m.end ? "<small>Through " + h(dateLabel(localDay(m.end), { dateStyle: "medium" })) + "</small>" : "") + '<div class="med-tools"><button class="text-link" data-supply="' + h(m.id) + '">' + icon("bottle", 15) + (state2.supplies[m.id] ? plural(state2.supplies[m.id].remaining, "dose") + " left \xB7 Update supply" : "Track refills") + "</button>" + (m.mode === "list" ? '<button class="text-link" data-as-needed="' + h(m.id) + '">' + icon("check", 16) + "Log a dose</button>" : "") + '</div></div><button class="icon-button" aria-label="Edit ' + h(m.name) + '" data-edit="' + h(m.id) + '">' + icon("edit", 18) + "</button></article>").join("") + "</div>" : '<div class="empty-state">' + badge("bottle", "mint", 29) + "<h3>No " + (filter2 === "all" ? "" : filter2 + " ") + "medications added</h3><p>Enter the name and dose exactly as they appear on your label.</p>" + btn("add", "Add medication", "plus", "btn outline") + "</div>") + "</section>";
  }
  function externalReference(url, label) {
    return '<a class="text-link" href="' + h(url) + '" target="_blank" rel="noopener noreferrer">' + h(label) + " " + icon("go", 15) + "</a>";
  }
  function findings(entries) {
    return entries.map((p) => {
      const links = [];
      if (p.source) links.push(externalReference(p.source, p.source.includes("medlineplus.gov") ? "MedlinePlus" : "DailyMed label"));
      if (p.pairReference) links.push(externalReference(p.pairReference, "Drugs.com pair report"));
      return '<article class="finding ' + p.level + '"><span class="status">' + h(warningLabel[p.level]) + "</span><h3>" + h(p.a.name) + " <span>+</span> " + h(p.b.name) + "</h3><p>" + h(p.reason) + '</p><div class="reference-links">' + links.join("") + "</div></article>";
    }).join("");
  }
  function checkerReferences() {
    return '<section class="panel side-note"><h2>Check your full list</h2><p>Open either checker and enter the medicines you want to review. Your list stays in Dosewell until you choose what to share.</p><div class="checker-ref">' + externalReference("https://www.drugs.com/drug_interactions.html", "Drugs.com Interaction Checker") + '<p>Read a plain language explanation of a possible interaction.</p></div><div class="checker-ref">' + externalReference("https://reference.medscape.com/drug-interactionchecker", "Medscape Interaction Checker") + "<p>Look up prescriptions, over the counter medicines, and herbal supplements together.</p></div></section>";
  }
  function interactionPage(state2) {
    const all = compare(state2.meds), flagged = all.filter((p) => p.level !== "unassessed"), rest = all.filter((p) => p.level === "unassessed");
    return pageHead("Interaction checker", "Review your medication list before adding a new medicine.", btn("add-other", "Add other medication", "plus", "btn primary")) + '<section class="notice purple">' + icon("shield", 24) + '<div><b>Check with your pharmacist before changing a medication.</b><p>This checker covers selected oral drug combinations involving a stroke medication. It cannot confirm a combination is safe or decide which dose to take or skip.</p></div></section><div class="inner-grid"><section class="panel"><div class="panel-head"><div class="section-title">' + icon("shield", 20) + '<h2>Medication review</h2></div><span class="count">' + plural(all.length, "pair") + "</span></div>" + (!all.length ? '<div class="empty-state">' + badge("shield", "lilac", 28) + "<h3>Add medications to compare</h3><p>Enter at least one stroke medication and one more medication, including prescriptions, over the counter products, or supplements.</p>" + btn(state2.meds.some((m) => m.category === "stroke") ? "add-other" : "add-stroke", "Add medication", "plus", "btn outline") + "</div>" : '<div class="results"><h3>' + plural(flagged.length, "listed warning") + "</h3>" + findings(flagged) + (rest.length ? "<details " + (!flagged.length ? "open" : "") + "><summary>" + plural(rest.length, "unassessed pair") + "</summary><p>These pairs have no matching rule here. Ask a pharmacist to check them before starting a new medicine.</p>" + rest.map((p) => '<div class="unchecked">' + h(p.a.name) + " + " + h(p.b.name) + "</div>").join("") + "</details>" : "") + "</div>") + "</section><aside>" + checkerReferences() + '<section class="panel side-note"><h2>What Dosewell checks</h2><p>Dosewell uses selected DailyMed labels and MedlinePlus guidance. Some warnings also link to the Drugs.com report for that pair.</p><p>Brand names, combination products, supplements, and spelling variations may need a manual check. Pairs of two other medications are outside this screen.</p><a href="#medications" class="text-link">Review my medication list ' + icon("arrow", 16) + "</a></section></aside></div>";
  }
  function remindersPage(state2) {
    const enabled = state2.settings.notifications && window.Notification?.permission === "granted";
    const has = state2.meds.some((m) => m.mode !== "list");
    return pageHead("Reminders", "Choose how you receive dose alarms and advance warnings.", '<div class="device-clock">' + icon("clock", 16) + 'Device time <b id="device-clock">' + h((/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" })) + "</b></div>") + (nativePlatform ? '<section class="panel side-note"><h2>Dosewell alarms</h2><p id="native-status" role="status"></p><div class="export-choices">' + btn("enable-app-alarms", "Enable Dosewell alarms", "bell", "btn primary") + btn("test-app-alarm", "Test in 15 seconds", "clock", "btn outline") + btn("stop-app-alarms", "Turn off alarms", "", "text-link") + '</div><form id="default-form"><label for="default-warning">Default advance warning in minutes</label> <input type="number" id="default-warning" name="minutes" min="0" max="1440" required value="' + state2.settings.advance + '"> <button class="btn small outline">Save</button></form><p>After enabling alarms, try a test with the screen locked. Dismissing an alarm leaves your dose history unchanged.</p>' + (!state2.meds.length ? '<label class="btn outline">Import a saved plan<input id="native-import" type="file" accept=".json,application/json"></label>' : "") + "</section>" : '<div class="inner-grid"><section class="panel"><div class="panel-head"><div class="section-title">' + icon("bell", 21) + '<h2>Alarm preferences</h2></div></div><div class="settings"><div class="setting"><label for="default-warning"><b>Default advance warning</b><small>Minutes before a scheduled dose. Enter 0 to turn it off.</small></label><form id="default-form"><input id="default-warning" name="minutes" type="number" min="0" max="1440" step="1" value="' + state2.settings.advance + '" required><span>min</span><button class="btn small outline">Save</button></form></div><div class="setting"><div><b>Alarm sound</b><small>Chime when an in-page reminder appears.</small></div><button class="switch ' + (state2.settings.sound ? "on" : "") + '" data-action="sound" role="switch" aria-checked="' + state2.settings.sound + '" aria-label="Alarm sound"><i></i></button></div><div class="setting"><div><b>Device notifications</b><small>' + (enabled ? "Allowed on this device." : window.Notification?.permission === "denied" ? "Blocked in browser settings. In-page alerts still appear." : "Show notifications with the medication name and dose.") + "</small></div>" + btn("notify", enabled ? "Turn off" : "Enable", "", "btn small outline") + '</div><div class="setting"><div><b>Test reminder</b><small>Try a sample alert on this device.</small></div>' + btn("test", "Test alarm", "bell", "btn small outline") + '</div></div></section><aside><section class="panel side-note calendar-note"><h2>Reminders on your phone</h2><p><a class="btn primary" href="./mobile-apps.html">Get the Dosewell app</a></p><p>Choose Clock alarms to set alarms on your phone. Calendar reminders downloads or shares events for a calendar app.</p><div class="export-choices">' + btn("phone-alarms", "Clock alarms", "clock", "btn primary") + btn("calendar-options", "Calendar reminders", "calendar", "btn outline") + "</div></section></aside></div>") + '<section class="panel reminder-list"><div class="panel-head"><div class="section-title">' + icon("clock", 20) + "<h2>Medication alarms</h2></div></div>" + (has ? state2.meds.filter((m) => m.mode !== "list").map((m) => '<div class="alarm-row"><div><b>' + h(medicationTitle(m)) + " \xB7 " + h(m.dose) + "</b><small>" + h(scheduleLabel(m)) + " \xB7 " + (advanceMinutes(m, state2.settings) ? advanceMinutes(m, state2.settings) + " min advance warning" : "At dose time only") + '</small></div><button class="icon-button" data-edit="' + h(m.id) + '" aria-label="Edit ' + h(m.name) + ' alarms">' + icon("edit", 18) + "</button></div>").join("") : '<p class="padded">Add a medication with a dose time to set up its alarms.</p>') + "</section>";
  }
  function historyPage(state2, period = "7") {
    const records = historyEntries(state2, period);
    const totals = { taken: 0, skipped: 0 };
    const days = /* @__PURE__ */ new Map();
    for (const [key2, r] of records) {
      totals[r.status]++;
      if (!days.has(r.day)) days.set(r.day, []);
      days.get(r.day).push([key2, r]);
    }
    const filters = [["7", "Last 7 days"], ["30", "Last 30 days"], ["all", "All history"]].map(([k, t]) => '<a href="#history/' + k + '" ' + (period === k ? 'aria-current="page"' : "") + ">" + t + "</a>").join("");
    const groups = [...days].map(([day2, entries]) => '<section class="history-day"><h2>' + h(dateLabel(localDay(day2), { dateStyle: "full" })) + "</h2>" + entries.map(([key2, r]) => '<article class="history-row"><div><b>' + h(r.name) + "</b>" + (r.dose ? " \xB7 " + h(r.dose) : "") + "<small>" + h(recordTiming(r)) + " \xB7 Logged " + h(recordClock(r)) + "</small>" + (r.legacy ? "<small>Earlier entry. Dose details were not saved.</small>" : "") + '</div><span class="dose-status ' + r.status + '">' + (r.status === "taken" ? "Taken" : "Skipped") + '</span><button class="text-link" data-log-undo="' + h(key2) + '" data-stamp="' + r.recordedAt + '">Undo</button></article>').join("") + "</section>").join("");
    return pageHead("Dose history", "Doses you have recorded on this device.", records.length ? btn("print-history", "Print / Save PDF", "print", "btn outline") : "") + '<section class="panel history-panel"><div class="filters">' + filters + '</div><div class="history-overview"><b>' + totals.taken + " taken</b><span>" + totals.skipped + " skipped</span><small>" + (period === "all" ? "All history" : "Last " + period + " days") + "</small></div>" + (groups || '<div class="empty-state">' + badge("history", "mint", 24) + '<h3>No doses recorded for this period</h3><p>Mark a scheduled dose as taken or skipped in Today. Your entries will appear here.</p><a class="text-link" href="#overview">Open daily pillbox ' + icon("arrow", 16) + "</a></div>") + "</section>";
  }

  // dosewell-apps/label-reader.js
  var strengthPattern = /(?:\d+(?:\.\d+)?|\.\d+)\s*(?:mcg|µg|μg|mg|grams?|g|units?|iu|%)(?![a-z])(?:\s*\/\s*(?:\d+(?:\.\d+)?\s*)?(?:ml|l|hr|h|g|actuation|dose)\b)?/i;
  var directionStart = /^(?:(?:sig|directions?|instructions?)\s*:\s*)?(?:take|give|use|apply|inject|instill|place|inhale|chew|dissolve|insert|swallow)\b/i;
  var metadata = /\b(?:doctor|prescriber|patient|pharmacist|pharmacy|refills?|quantity|qty|ndc|discard|expires?|expiration|rx|store|warning|caution|manufacturer|birth|DOB)\b/i;
  var continuation = /^(?:by|on|as|at|for|with|without|before|after|every|each|once|twice|three|four|daily|weekly|morning|evening|night|and|then|if|until|except|do not|one|two|half|\d|mouth|needed|day|hours?|times?|tablets?|capsules?)\b/i;
  var variableDose = /\b(?:or|then|except|alternate|alternating|sliding|taper|increase|decrease|needed|prn|directed|if|and|up to|hold|follow)\b|\d\s*[-–]\s*\d/i;
  var amountPattern = /^(?:take|give|use|apply|inject|instill|place|inhale|chew|dissolve|insert|swallow)\s+((?:\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?|\.\d+|one[- ]half|one[- ]quarter|one|two|three|four|half|½|¼)\s*(?:tablets?|tabs?|capsules?|caps?|milliliters?|ml|mcg|mg|grams?|units?|puffs?|drops?|patch(?:es)?))\b/i;
  function fieldLine(line) {
    return line.replace(/^(?:(?:medication|drug|medicine)(?: name)?|name of drug)\s*:\s*/i, "");
  }
  function cleanLine(s) {
    return s.trim().replace(/\s+/g, " ");
  }
  function normalized(s) {
    return cleanLine(s).toLowerCase();
  }
  function looksLikeName(s) {
    return s.length >= 3 && s.length <= 80 && /^[a-z][a-z0-9]*(?:[ '-][a-z0-9]+){0,8}$/i.test(s) && !/\d$/.test(s) && !metadata.test(s) && !directionStart.test(s) && !/\b(?:strength|each|contains|maximum|per|tablet|tablets|bottle|ref|daily|generic for)\b/i.test(s);
  }
  function readLabel(text3, confidence = 100, weakLines = []) {
    const empty2 = { name: "", strength: "", dose: "", directions: "" };
    if (!Number.isFinite(confidence) || confidence < 60) return { fields: empty2, issue: "unclear" };
    const lines = text3.split(/\r?\n/).map(cleanLine).filter(Boolean);
    const weak = new Set(weakLines.map(normalized));
    const candidates = [];
    let uncertainProduct = false;
    for (let i = 0; i < lines.length; i++) {
      const line = fieldLine(lines[i]);
      if (metadata.test(line) || directionStart.test(line)) continue;
      const strength = line.match(strengthPattern);
      if (!strength) continue;
      let name = line.slice(0, strength.index).trim();
      let nameLine = lines[i];
      if (!name && i && ingredient(fieldLine(lines[i - 1]))) {
        name = fieldLine(lines[i - 1]);
        nameLine = lines[i - 1];
      }
      if (!looksLikeName(name)) {
        uncertainProduct = true;
        continue;
      }
      const tail = line.slice(strength.index + strength[0].length);
      if (/\d|^\s*[/+–-]/.test(tail)) {
        uncertainProduct = true;
        continue;
      }
      const formulation = /\b(?:extended[- ]release|delayed[- ]release|sustained[- ]release|controlled[- ]release|immediate[- ]release|enteric[- ]coated|XR|ER|SR|CR|DR|XL|EC|LA)\b/i.exec(tail);
      const printedStrength = formulation ? strength[0] + " " + formulation[0] : strength[0];
      candidates.push({ name, strength: printedStrength, weak: weak.has(normalized(lines[i])) || weak.has(normalized(nameLine)), index: i });
    }
    const distinct = new Set(candidates.map((c) => normalized(c.name + " " + c.strength)));
    if (distinct.size > 1 || uncertainProduct && candidates.length) return { fields: empty2, issue: "multiple" };
    const product = candidates[0];
    if (!product || product.weak) return { fields: empty2, issue: "unclear" };
    const fields = { ...empty2, name: product.name, strength: product.strength };
    const start = lines.findIndex((line, i) => i > product.index && directionStart.test(line));
    if (start < 0) return { fields, issue: "partial" };
    const sig = [lines[start].replace(/^(?:sig|directions?|instructions?)\s*:\s*/i, "")];
    let unsafe = weak.has(normalized(lines[start]));
    for (let i = start + 1; i < lines.length; i++) {
      const line = lines[i];
      if (metadata.test(line)) break;
      if (directionStart.test(line) || continuation.test(line)) {
        sig.push(line);
        unsafe || (unsafe = weak.has(normalized(line)) || directionStart.test(line));
      } else break;
    }
    const directions = sig.join(" ");
    if (unsafe || directions.length > 500) return { fields, issue: "partial" };
    fields.directions = directions;
    const amount = directions.match(amountPattern);
    if (amount && !variableDose.test(directions) && !/\b(?:take|give|use)\b/i.test(directions.slice(amount[0].length))) fields.dose = amount[1];
    return { fields, issue: fields.dose ? "" : "partial" };
  }

  // dosewell-apps/scan.js
  var asset = (path) => new URL("./ocr/" + path, document.baseURI).href;
  var fieldNames = ["name", "strength", "dose", "directions"];
  var fieldTitles = { name: "Medication", strength: "Strength", dose: "Amount per dose", directions: "Directions" };
  var scanControls = '<section class="scan-panel" aria-labelledby="scan-heading"><h3 id="scan-heading">' + icon("camera", 20) + 'Scan a prescription label</h3><p>Photograph one English label with the name, strength, and directions in focus. The photo stays on this device.</p><div class="scan-actions"><button id="take-label" class="btn small outline" type="button">' + icon("camera", 16) + 'Take photo</button><button id="choose-label" class="btn small outline" type="button">' + icon("image", 16) + 'Choose photo</button><button id="stop-scan" type="button" class="btn small outline" hidden>Cancel scan</button></div><input type="file" id="camera-file" accept="image/*" capture="environment" hidden><input type="file" id="label-file" accept="image/*" hidden><div id="camera-view" hidden><video muted playsinline autoplay aria-label="Camera preview"></video><button type="button" id="capture-label" class="btn primary">Use this photo</button></div><p id="scan-status" role="status" aria-live="polite"></p><div id="scan-suggestion" hidden></div><details id="label-preview" hidden><summary>View label photo</summary></details></section>';
  function toCanvas(image, width, height) {
    if (!width || !height) throw Error("The photo could not be opened. Try a JPEG or PNG image.");
    const scale = Math.min(1, 2200 / Math.max(width, height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw Error("This browser cannot read the photo. You can enter the label below.");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", "Prescription label photo, available until the form closes");
    return canvas;
  }
  async function fileCanvas(file) {
    if (file.size > 32 * 1024 * 1024) throw Error("This photo is too large. Choose a smaller photo under 32 MB.");
    if (file.type === "image/svg+xml" || file.type && !file.type.startsWith("image/")) throw Error("Choose a photo such as JPEG or PNG.");
    const url = URL.createObjectURL(file), img = new Image();
    try {
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = () => reject(Error("This photo format could not be opened. Try a JPEG, PNG, or screenshot."));
        img.src = url;
      });
      return toCanvas(img, img.naturalWidth, img.naturalHeight);
    } finally {
      URL.revokeObjectURL(url);
    }
  }
  function attachScanner(dialog2, form) {
    const byId = (id) => form.querySelector("#" + id);
    const take = byId("take-label"), choose = byId("choose-label"), stop = byId("stop-scan");
    const preview = byId("label-preview"), suggest = byId("scan-suggestion"), message = byId("scan-status");
    const camera = byId("camera-view"), video = camera.querySelector("video");
    const review = byId("scan-review"), check = review.querySelector("input");
    const save2 = form.querySelector("[type=submit]");
    let generation = 0, worker = null, stream = null, timer = null, disposed = false;
    const valid = (id) => id === generation && !disposed && dialog2.open && form.isConnected;
    function endCamera() {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      stream = null;
      video.srcObject = null;
      camera.hidden = true;
    }
    function endJob() {
      clearTimeout(timer);
      endCamera();
      if (worker) {
        worker.terminate().catch(() => {
        });
        worker = null;
      }
    }
    function busy(value) {
      take.disabled = value;
      choose.disabled = value;
      stop.hidden = !value;
      save2.disabled = value;
    }
    function clearSuggestion() {
      suggest.replaceChildren();
      suggest.hidden = true;
    }
    function cancel(status = "Scan canceled. You can enter the label below.") {
      generation++;
      endJob();
      busy(false);
      clearSuggestion();
      message.textContent = status;
    }
    function dispose() {
      if (disposed) return;
      disposed = true;
      cancel("");
      preview.querySelector("canvas")?.remove();
      window.removeEventListener("pagehide", dispose);
      dialog2.removeEventListener("close", dispose);
    }
    dialog2.addEventListener("close", dispose, { once: true });
    window.addEventListener("pagehide", dispose, { once: true });
    stop.onclick = () => cancel();
    for (const key2 of fieldNames) form.elements.namedItem(key2).addEventListener("input", () => {
      if (!review.hidden) check.checked = false;
    });
    function apply(fields) {
      for (const key2 of fieldNames) form.elements.namedItem(key2).value = fields[key2];
      check.checked = false;
      check.required = true;
      review.hidden = false;
      clearSuggestion();
      message.textContent = "Fields filled. Compare them with the label, complete any blanks, and choose the schedule below.";
      form.elements.namedItem("name").focus({ preventScroll: true });
    }
    function finishScan(result) {
      if (!result.fields.name) {
        message.textContent = result.issue === "multiple" ? "There may be more than one medicine or strength. Photograph one label or enter its details below." : "The name or strength could not be read clearly. Try a closer photo, or enter the details below.";
        return;
      }
      if (!fieldNames.some((key2) => form.elements.namedItem(key2).value.trim())) {
        apply(result.fields);
        return;
      }
      message.textContent = "Review this scan before replacing the medication fields you already entered.";
      const dl = document.createElement("dl");
      for (const key2 of fieldNames) {
        const dt = document.createElement("dt"), dd = document.createElement("dd");
        dt.textContent = fieldTitles[key2];
        dd.textContent = result.fields[key2] || "Enter manually";
        dl.append(dt, dd);
      }
      const replace = document.createElement("button"), keep = document.createElement("button");
      replace.type = keep.type = "button";
      replace.className = "btn small primary";
      keep.className = "btn small outline";
      replace.textContent = "Use scanned fields";
      keep.textContent = "Keep my entries";
      replace.onclick = () => apply(result.fields);
      keep.onclick = () => {
        clearSuggestion();
        message.textContent = "Your existing entries were kept.";
      };
      suggest.replaceChildren(dl, replace, keep);
      suggest.hidden = false;
    }
    async function recognize(canvas, id) {
      if (!valid(id)) return;
      preview.querySelector("canvas")?.remove();
      preview.append(canvas);
      preview.hidden = false;
      preview.open = false;
      message.textContent = "Preparing the label reader\u2026";
      const { default: ocr } = await import("./ocr/tesseract.esm.min.js");
      if (!valid(id)) return;
      const initialized = await ocr.createWorker("eng", ocr.OEM.LSTM_ONLY, {
        workerPath: asset("worker.min.js"),
        workerBlobURL: false,
        corePath: asset("").replace(/\/$/, ""),
        langPath: asset("").replace(/\/$/, ""),
        errorHandler: () => {
        },
        logger: (step) => {
          if (valid(id) && step.status === "recognizing text") {
            const percent = Math.round(step.progress * 10) * 10;
            const note = "Reading the label\u2026 " + percent + "%";
            if (message.textContent !== note) message.textContent = note;
          }
        }
      });
      if (!valid(id)) {
        await initialized.terminate();
        return;
      }
      worker = initialized;
      const { data } = await worker.recognize(canvas, { rotateAuto: true }, { text: true, blocks: true });
      if (!valid(id)) return;
      const weak = [];
      for (const block of data.blocks || []) for (const para of block.paragraphs || []) for (const line of para.lines || []) {
        if (line.words?.some((w) => /[a-z0-9]/i.test(w.text) && w.confidence < 63)) weak.push(line.text);
      }
      finishScan(readLabel(data.text, data.confidence, weak));
    }
    async function scan2(getCanvas) {
      const id = ++generation;
      endJob();
      clearSuggestion();
      busy(true);
      check.checked = false;
      message.textContent = "Opening the photo\u2026";
      timer = setTimeout(() => {
        if (valid(id)) cancel("The scan took too long. Try a smaller, clearer photo or enter the label below.");
      }, 9e4);
      try {
        await recognize(await getCanvas(), id);
      } catch (err) {
        if (valid(id)) message.textContent = err instanceof Error && /^(This (photo|browser)|The photo|Choose a photo)/.test(err.message) ? err.message : "The label reader could not finish. Try another photo or enter the label below.";
      } finally {
        if (valid(id)) {
          endJob();
          busy(false);
        }
      }
    }
    for (const input of [byId("camera-file"), byId("label-file")]) {
      input.onchange = () => {
        const file = input.files[0];
        input.value = "";
        if (file) scan2(() => fileCanvas(file));
      };
    }
    choose.onclick = () => byId("label-file").click();
    take.onclick = async () => {
      if (navigator.maxTouchPoints > 0 || !navigator.mediaDevices?.getUserMedia) {
        byId("camera-file").click();
        return;
      }
      const id = ++generation;
      endJob();
      clearSuggestion();
      busy(true);
      message.textContent = "Allow camera access and center one label.";
      try {
        const live = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1440 } }, audio: false });
        if (!valid(id)) {
          live.getTracks().forEach((t) => t.stop());
          return;
        }
        stream = live;
        video.srcObject = stream;
        camera.hidden = false;
        await video.play();
        if (valid(id)) message.textContent = "When the label is sharp, select Use this photo.";
      } catch {
        if (valid(id)) cancel("The camera is unavailable. Choose a saved photo or enter the label below.");
      }
    };
    byId("capture-label").onclick = () => {
      if (!video.videoWidth) {
        message.textContent = "Wait for the camera preview to appear.";
        return;
      }
      const canvas = toCanvas(video, video.videoWidth, video.videoHeight);
      scan2(() => canvas);
    };
  }

  // dosewell-apps/form.js
  function timeRow(t = "") {
    return '<div class="time-row"><input type="time" aria-label="Dose time" name="times" required value="' + h(t) + '"><button type="button" class="icon-button" data-remove-time aria-label="Remove dose time">' + icon("close", 16) + "</button></div>";
  }
  var hourChoices = [...Array.from({ length: 24 }, (_, i) => i + 1), 36, 48, 72];
  function intervalOptions(value) {
    return '<option value="">Choose hours</option>' + hourChoices.map((n) => '<option value="' + n + '" ' + (n === value ? "selected" : "") + ">" + hoursLabel(n) + "</option>").join("");
  }
  function intervalSettings(original, date, time, hours, end) {
    if (!date || !time || !hourChoices.includes(hours)) return null;
    const typed = /* @__PURE__ */ new Date(date + "T" + time + ":00");
    if (!Number.isFinite(typed.getTime()) || dayKey(typed) !== date || clockTime(typed) !== time) return null;
    const originalStart = original?.mode === "interval" ? new Date(original.anchorAt) : null;
    const anchorAt = originalStart && dayKey(originalStart) === date && clockTime(originalStart) === time ? original.anchorAt : typed.getTime();
    let untilAt = null;
    if (end) {
      untilAt = original?.untilAt && dayKey(new Date(original.untilAt - 1)) === end ? original.untilAt : (/* @__PURE__ */ new Date(shiftDay(end, 1) + "T00:00:00")).getTime();
      if (!Number.isFinite(untilAt) || untilAt <= anchorAt) return null;
    }
    return { anchorAt, untilAt, intervalHours: hours };
  }
  function showEditor(dialog2, med, category, settings, onSave, onRemove) {
    const existing = med?.mode === "interval" ? { ...med, start: dayKey(new Date(med.anchorAt)), times: [clockTime(new Date(med.anchorAt))], end: med.untilAt == null ? "" : dayKey(new Date(med.untilAt - 1)) } : med;
    const m = existing || { category, name: "", dose: "", mode: category === "other" ? "list" : "daily", times: [""], days: [0, 1, 2, 3, 4, 5, 6], start: dayKey(/* @__PURE__ */ new Date()), end: "", advance: null };
    dialog2.innerHTML = '<div class="modal-head"><div><h2 id="dialog-title">' + (med ? "Edit medication" : "Add medication") + "</h2><p>Use the dose and schedule on your current label.</p></div>" + btnIcon("close", "Close dialog", "close") + '</div><form id="med-form" class="med-form">' + (med ? "" : scanControls) + '<fieldset><legend>Medication group</legend><div class="group-picker">' + ["stroke", "other"].map((c) => '<label><input type="radio" name="category" value="' + c + '" ' + (m.category === c ? "checked" : "") + "><span>" + icon(c === "stroke" ? "heart" : "pill", 17) + (c === "stroke" ? "Stroke medication" : "Other medication") + "</span></label>").join("") + '</div></fieldset><label>Medication name<input name="name" list="drug-names" autocomplete="off" placeholder="Name on the label" maxlength="120" required value="' + h(m.name) + '"></label><datalist id="drug-names">' + suggestions.map((s) => '<option value="' + h(s[0].toUpperCase() + s.slice(1)) + '"></option>').join("") + '</datalist><label>Strength on label <small>(optional)</small><input name="strength" maxlength="100" placeholder="Amount per tablet or concentration" value="' + h(m.strength) + '"></label><label>Dose per administration<input name="dose" maxlength="140" placeholder="Amount and unit from your label" required value="' + h(m.dose) + '"></label><label>Label directions <small>(optional)</small><textarea name="directions" maxlength="500" rows="2" placeholder="Instructions printed on the label">' + h(m.directions) + '</textarea></label><label>Schedule<select name="mode">' + [["daily", "Every day"], ["interval", "Every X hours"], ["weekly", "Selected days of the week"], ["list", "List only / as needed"]].map(([v, t]) => '<option value="' + v + '" ' + (m.mode === v ? "selected" : "") + ">" + t + "</option>").join("") + '</select></label><div class="schedule-fields"><fieldset id="weekdays"><legend>Days of the week</legend><div class="days-input">' + dayNames.map((n, i) => '<label><input type="checkbox" name="days" value="' + i + '" ' + (m.days.includes(i) ? "checked" : "") + "><span>" + n + "</span></label>").join("") + '</div></fieldset><fieldset id="fixed-times"><legend>Dose times</legend><div id="time-inputs">' + (m.times.length ? m.times : [""]).map(timeRow).join("") + '</div><button type="button" class="text-link add-time" id="add-time">' + icon("plus", 14) + 'Add another time</button><button type="button" class="text-link interval-shortcut" id="choose-interval">' + icon("clock", 14) + 'Use an hourly interval</button></fieldset><fieldset id="interval-fields" hidden><legend>Dose times</legend><div class="interval-grid"><label>Repeat every<select name="intervalHours" required>' + intervalOptions(m.intervalHours) + '</select></label><label>First dose time<input type="time" name="firstTime" required value="' + h(m.times[0] || "") + '"></label></div><p class="form-tip">The interval repeats around the clock from your first dose.</p></fieldset><label>Advance warning<select name="warning-mode"><option value="default" ' + (m.advance === null ? "selected" : "") + ">Use default (" + settings.advance + ' min)</option><option value="custom" ' + (m.advance > 0 ? "selected" : "") + '>Custom warning</option><option value="off" ' + (m.advance === 0 ? "selected" : "") + '>At dose time only</option></select></label><label id="custom-warning">Minutes before dose<input type="number" min="1" max="1440" step="1" required name="advance" value="' + (m.advance || 15) + '"></label><div class="date-inputs"><label><span id="start-label">Start date</span><input type="date" name="start" required value="' + h(m.start) + '"></label><label>End date <small>(optional)</small><input type="date" name="end" value="' + h(m.end) + '"></label></div><div id="interval-preview" class="interval-preview" aria-live="polite" hidden></div><p class="form-tip">' + icon("info", 16) + "Alarms use this device\u2019s local time. For alerts with the site closed, choose Set up phone reminders after saving.</p></div>" + (med ? "" : '<label id="scan-review" class="scan-review" hidden><input type="checkbox">I checked the medication name, strength, dose, and directions against the label.</label>') + '<p id="form-error" class="error" role="alert" hidden></p><div class="form-buttons">' + (med ? '<button class="danger-text" type="button" id="remove-med">Remove</button>' : "") + '<button type="button" class="btn outline" data-action="close">Cancel</button><button type="submit" class="btn primary">Save medication</button></div></form>';
    const form = dialog2.querySelector("form");
    const f = form.elements;
    if (!med) attachScanner(dialog2, form);
    const fixed = form.querySelector("#fixed-times"), interval = form.querySelector("#interval-fields"), preview = form.querySelector("#interval-preview");
    function updatePreview() {
      preview.hidden = f.mode.value !== "interval";
      if (preview.hidden) return;
      const settings2 = intervalSettings(med, f.start.value, f.firstTime.value, Number(f.intervalHours.value), f.end.value);
      if (!settings2) {
        preview.textContent = "Choose the interval, first dose date, and first dose time to preview your schedule.";
        return;
      }
      const draft = { ...settings2, mode: "interval", id: "preview" };
      const labels = [];
      let from = settings2.anchorAt;
      for (let i = 0; i < 4; i++) {
        const row = nextInterval(draft, from);
        if (!row) break;
        labels.push(row.when.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }) + " \xB7 " + doseTimeLabel(row));
        from = row.when.getTime() + 1;
      }
      preview.innerHTML = "<b>First scheduled doses</b><ul>" + labels.map((t) => "<li>" + h(t) + "</li>").join("") + "</ul>";
    }
    function sync() {
      const scheduled = f.mode.value !== "list", weekly = f.mode.value === "weekly", custom = f["warning-mode"].value === "custom";
      const fields = form.querySelector(".schedule-fields");
      fields.hidden = !scheduled;
      fields.querySelectorAll("input, select, button").forEach((el) => el.disabled = !scheduled);
      const hourly = f.mode.value === "interval";
      fixed.hidden = hourly;
      fixed.disabled = !scheduled || hourly;
      interval.hidden = !hourly;
      interval.disabled = !hourly;
      form.querySelector("#start-label").textContent = hourly ? "First dose date" : "Start date";
      form.querySelector("#weekdays").hidden = !weekly;
      form.querySelector("#custom-warning").hidden = !custom;
      f.advance.disabled = !scheduled || !custom;
      f.end.min = f.start.value;
      const rows = form.querySelectorAll(".time-row");
      rows.forEach((row) => row.querySelector("button").hidden = rows.length === 1);
      updatePreview();
    }
    function error(msg) {
      const e = form.querySelector("#form-error");
      e.hidden = !msg;
      e.textContent = msg;
    }
    form.addEventListener("change", (e) => {
      if (e.target.name === "category" && !med && form.dataset.modeSet !== "1") f.mode.value = e.target.value === "other" ? "list" : "daily";
      if (e.target.name === "mode") {
        form.dataset.modeSet = "1";
        if (f.mode.value === "interval" && !f.firstTime.value) f.firstTime.value = form.querySelector("[name=times]")?.value || "";
      }
      sync();
      error("");
    });
    form.querySelector("#choose-interval").onclick = () => {
      f.mode.value = "interval";
      f.mode.dispatchEvent(new Event("change", { bubbles: true }));
      f.intervalHours.focus();
    };
    form.addEventListener("input", (e) => {
      if (["firstTime", "intervalHours", "start", "end"].includes(e.target.name)) updatePreview();
    });
    form.querySelector("#add-time").onclick = () => {
      form.querySelector("#time-inputs").insertAdjacentHTML("beforeend", timeRow());
      sync();
      form.querySelector(".time-row:last-child input").focus();
    };
    form.addEventListener("click", (e) => {
      const r = e.target.closest("[data-remove-time]");
      if (r) {
        r.closest(".time-row").remove();
        sync();
      }
    });
    if (med) form.querySelector("#remove-med").onclick = () => onRemove(med);
    form.onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(form), mode = fd.get("mode");
      const name = fd.get("name").trim(), dose = fd.get("dose").trim();
      if (!name || !dose) {
        error("Enter the medication name and dose from the label.");
        return;
      }
      const times = mode === "list" ? [] : mode === "interval" ? [fd.get("firstTime")] : fd.getAll("times").sort();
      const days = mode === "weekly" ? fd.getAll("days").map(Number) : [0, 1, 2, 3, 4, 5, 6];
      if (!days.length) {
        error("Select at least one day for this schedule.");
        return;
      }
      if (new Set(times).size !== times.length) {
        error("Each dose time must be different.");
        return;
      }
      const start = mode === "list" ? m.start : fd.get("start"), end = mode === "list" ? "" : fd.get("end");
      if (end && end < start) {
        error("Choose an end date on or after the start date.");
        return;
      }
      const hourly = mode === "interval" ? intervalSettings(med, start, times[0], Number(fd.get("intervalHours")), end) : null;
      if (mode === "interval" && !hourly) {
        error("Choose an interval and a valid local first dose time. Check the start and end dates.");
        return;
      }
      const advance = mode === "list" || fd.get("warning-mode") === "default" ? null : fd.get("warning-mode") === "off" ? 0 : Number(fd.get("advance"));
      const save2 = form.querySelector('button[type="submit"]');
      save2.disabled = true;
      try {
        await onSave({ id: med?.id || crypto.randomUUID(), category: fd.get("category"), name, dose, strength: fd.get("strength").trim(), directions: fd.get("directions").trim(), mode, times, days, start, end, advance, ...hourly });
      } catch (err) {
        error(err.message);
        save2.disabled = false;
      }
    };
    sync();
    if (!dialog2.open) dialog2.showModal();
    dialog2.querySelector('[data-action="close"]').focus();
  }

  // dosewell-apps/reminder-transfer.js
  var calendarName = "Dosewell-medication-schedule.ics";
  var maxLinkLength = 4200;
  var invalid = () => new Error("This reminder link is incomplete or invalid. Ask the sender for a new link or the calendar file.");
  var encode = (bytes) => btoa(Array.from(bytes, (b) => String.fromCharCode(b)).join("")).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  var validText = (v, n) => typeof v === "string" && v.trim().length > 0 && v.length <= n && !/[\u0000-\u001f\u007f]/.test(v);
  var validTime = (v) => typeof v === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  function validDate(v) {
    return typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) && dayKey(/* @__PURE__ */ new Date(v + "T12:00:00")) === v;
  }
  function transferLink(state2, base, now = /* @__PURE__ */ new Date()) {
    const rows = [];
    for (const m of state2.meds) {
      if (m.mode === "list" || !m.times.some((t) => firstNext(m, t, now))) continue;
      const timing = m.mode === "interval" ? ["h", m.intervalHours, m.anchorAt, m.untilAt ?? null] : ["d", m.start, m.end || "", m.days.reduce((bits, d) => bits | 1 << d, 0), m.times];
      rows.push([m.id, medicationTitle(m), m.dose, advanceMinutes(m, state2.settings), timing]);
    }
    if (!rows.length || rows.length > 100) return null;
    const raw = JSON.stringify([1, rows]);
    if (raw.length > maxLinkLength) return null;
    const url = new URL("./receive.html", base);
    url.hash = encode(new TextEncoder().encode(raw));
    if (url.href.length > maxLinkLength) return null;
    try {
      readTransfer(url.hash);
    } catch {
      return null;
    }
    return url.href;
  }
  function readTransfer(hash) {
    const value = hash.replace(/^#/, "");
    if (!value || value.length > maxLinkLength || !/^[A-Za-z0-9_-]+$/.test(value)) throw invalid();
    let packet;
    try {
      const ascii = atob(value.replace(/-/g, "+").replace(/_/g, "/"));
      packet = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(ascii, (c) => c.charCodeAt(0))));
    } catch {
      throw invalid();
    }
    if (!Array.isArray(packet) || packet[0] !== 1 || !Array.isArray(packet[1]) || !packet[1].length || packet[1].length > 100) throw invalid();
    const ids = /* @__PURE__ */ new Set(), meds = [];
    for (const row of packet[1]) {
      if (!Array.isArray(row) || row.length !== 5) throw invalid();
      const [id, name, dose, advance, spec] = row;
      if (typeof id !== "string" || !/^[a-z0-9_-]{1,96}$/i.test(id) || ids.has(id) || !validText(name, 250) || !validText(dose, 140) || !Number.isInteger(advance) || advance < 0 || advance > 1440 || !Array.isArray(spec)) throw invalid();
      ids.add(id);
      const med = { id, name, dose, advance };
      if (spec[0] === "h" && spec.length === 4) {
        const [, hours, anchorAt, untilAt] = spec;
        const validStamp = (n) => Number.isSafeInteger(n) && n >= -22089888e5 && n <= 2534022144e5;
        if (!Number.isInteger(hours) || hours < 1 || hours > 72 || hours > 24 && ![36, 48, 72].includes(hours) || !validStamp(anchorAt) || untilAt !== null && (!validStamp(untilAt) || untilAt <= anchorAt)) throw invalid();
        const anchor = new Date(anchorAt);
        Object.assign(med, { mode: "interval", intervalHours: hours, anchorAt, untilAt, start: dayKey(anchor), end: untilAt ? dayKey(new Date(untilAt - 1)) : "", times: [clockTime(anchor)], days: [0, 1, 2, 3, 4, 5, 6] });
      } else if (spec[0] === "d" && spec.length === 5) {
        const [, start, end, mask, times] = spec;
        if (!validDate(start) || end !== "" && (!validDate(end) || end < start) || !Number.isInteger(mask) || mask < 1 || mask > 127 || !Array.isArray(times) || !times.length || times.length > 1440 || !times.every(validTime) || new Set(times).size !== times.length) throw invalid();
        Object.assign(med, { mode: mask === 127 ? "daily" : "weekly", start, end, days: [0, 1, 2, 3, 4, 5, 6].filter((d) => mask & 1 << d), times });
      } else throw invalid();
      meds.push(med);
    }
    return { meds, settings: { advance: 0 } };
  }
  function saveCalendarFile(state2, now = /* @__PURE__ */ new Date()) {
    const cal = calendarFile(state2, now);
    if (!cal.count) return false;
    const address = URL.createObjectURL(new Blob([cal.text], { type: "text/calendar;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = address;
    link.download = calendarName;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(address), 6e4);
    return true;
  }
  function shareableCalendar(cal, nav2 = navigator) {
    if (typeof File !== "function" || typeof nav2.share !== "function" || typeof nav2.canShare !== "function") return null;
    const file = new File([cal.text], calendarName, { type: "text/calendar" });
    try {
      return nav2.canShare({ files: [file] }) ? file : null;
    } catch {
      return null;
    }
  }
  function transferChoice(cal, url, nav2 = navigator) {
    const file = shareableCalendar(cal, nav2);
    if (file) return { kind: "file", data: { files: [file] } };
    if (url && typeof nav2.share === "function") {
      const data = { url, title: "Dosewell reminder file" };
      try {
        if (!nav2.canShare || nav2.canShare(data)) return { kind: "link", data };
      } catch {
      }
    }
    return { kind: "manual" };
  }

  // dosewell-apps/clock-bridge.js
  var keySpec = { name: "ECDSA", namedCurve: "P-256" };
  var utf8 = new TextEncoder();
  var currentIdentity;
  function base64url(bytes) {
    return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
  }
  async function openKeys() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("dosewell-clock-pairing", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("keys");
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function browserIdentity() {
    const db = await openKeys();
    try {
      const candidate = await crypto.subtle.generateKey(keySpec, false, ["sign", "verify"]);
      const pair = await new Promise((resolve, reject) => {
        const tx = db.transaction("keys", "readwrite");
        const store = tx.objectStore("keys");
        const read2 = store.get("browser");
        let selected2;
        read2.onsuccess = () => {
          selected2 = read2.result || candidate;
          if (!read2.result) store.put(selected2, "browser");
        };
        tx.oncomplete = () => resolve(selected2);
        tx.onabort = () => reject(tx.error);
      });
      const spki = await crypto.subtle.exportKey("spki", pair.publicKey);
      const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", spki));
      const code = Array.from(hash.slice(0, 4), (byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase();
      return { privateKey: pair.privateKey, pub: base64url(spki), code: code.slice(0, 4) + " " + code.slice(4) };
    } finally {
      db.close();
    }
  }
  function clockIdentity() {
    if (!currentIdentity) currentIdentity = browserIdentity().catch((error) => {
      currentIdentity = null;
      throw error;
    });
    return currentIdentity;
  }
  async function clockLink(identity, item, now = Date.now()) {
    const { entry, repeat } = item;
    const days = repeat ? entry.days.reduce((bits, d) => bits | 1 << d, 0) : 0;
    const nonce = base64url(crypto.getRandomValues(new Uint8Array(16)));
    const data = {
      v: 1,
      issued: now,
      nonce,
      at: entry.at.getTime(),
      hour: entry.at.getHours(),
      minute: entry.at.getMinutes(),
      days,
      label: "Dosewell \xB7 " + entry.label
    };
    const body = base64url(utf8.encode(JSON.stringify(data)));
    const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, identity.privateKey, utf8.encode(body));
    const fallback = encodeURIComponent(new URL("clock-install.html", document.baseURI).href);
    return "intent://alarm/set?p=" + body + "&s=" + base64url(signature) + "&k=" + identity.pub + "#Intent;scheme=dosewellclock;package=org.williamsindustries.dosewellclock;S.browser_fallback_url=" + fallback + ";end";
  }

  // dosewell-apps/phone-alarms.js
  function nextAlert(state2, med, time, minutes, now) {
    let from = new Date(now.getTime() + minutes * 6e4);
    let dose = firstNext(med, time, from);
    while (dose && (state2.taken?.[med.id + "|" + dose.day + "|" + time] || state2.history?.[med.id + "|" + dose.day + "|" + time]?.status === "skipped")) {
      from = new Date(dose.when.getTime() + 1);
      dose = firstNext(med, time, from);
    }
    if (!dose) return null;
    const at = new Date(dose.when.getTime() - minutes * 6e4);
    const alarmDay = dayKey(at);
    const previousDay = alarmDay < dose.day;
    const days = med.days.map((day2) => (day2 + (previousDay ? 6 : 0)) % 7).sort((a, b) => a - b);
    const label = (minutes ? "Upcoming in " + minutes + " min: " : "Dose: ") + medicationTitle(med) + " \xB7 " + med.dose;
    let lastDay2 = med.end;
    if (lastDay2) {
      while (!med.days.includes(localDay(lastDay2).getDay())) lastDay2 = shiftDay(lastDay2, -1);
      const lastDose = /* @__PURE__ */ new Date(lastDay2 + "T" + time + ":00");
      lastDay2 = dayKey(new Date(lastDose.getTime() - minutes * 6e4));
    }
    return {
      key: [med.id, time, minutes, alarmDay].join("|"),
      at,
      label,
      minutes,
      days,
      name: medicationTitle(med),
      dose: med.dose,
      doseTime: time,
      time: pad(at.getHours()) + ":" + pad(at.getMinutes()),
      until: lastDay2
    };
  }
  function intervalAlerts(state2, med, minutes, now) {
    const entries = [];
    const margin = minutes * 6e4, limit = now.getTime() + 864e5;
    let next = nextInterval(med, now.getTime() + margin);
    while (next) {
      const at = new Date(next.when.getTime() - margin);
      const outsideWindow = at.getTime() >= limit;
      if (outsideWindow && entries.length) break;
      if (!state2.taken?.[next.key] && state2.history?.[next.key]?.status !== "skipped") {
        entries.push({
          key: next.key + "|" + minutes,
          at,
          minutes,
          oneTime: true,
          label: (minutes ? "Upcoming in " + minutes + " min: " : "Dose: ") + medicationTitle(med) + " \xB7 " + med.dose,
          name: medicationTitle(med),
          dose: med.dose,
          doseTime: next.time,
          doseDay: next.day,
          time: clockTime(at)
        });
        if (outsideWindow) break;
      }
      next = nextInterval(med, next.when.getTime() + 1);
    }
    return entries;
  }
  function phoneAlarms(state2, now = /* @__PURE__ */ new Date()) {
    const alarms = [];
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      const warning = advanceMinutes(med, state2.settings);
      if (med.mode === "interval") {
        alarms.push(...intervalAlerts(state2, med, 0, now));
        if (warning > 0) alarms.push(...intervalAlerts(state2, med, warning, now));
        continue;
      }
      for (const time of med.times) {
        for (const minutes of warning > 0 ? [warning, 0] : [0]) {
          const entry = nextAlert(state2, med, time, minutes, now);
          if (entry) alarms.push(entry);
        }
      }
    }
    return alarms.sort((a, b) => a.at - b.at || a.name.localeCompare(b.name));
  }
  function clockCanSet(entry, now = /* @__PURE__ */ new Date()) {
    const next = new Date(now);
    next.setHours(entry.at.getHours(), entry.at.getMinutes(), 0, 0);
    if (next < now) next.setDate(next.getDate() + 1);
    return entry.at.getTime() === next.getTime();
  }
  function phoneHandoff(entry, platform, now = /* @__PURE__ */ new Date()) {
    if (!clockCanSet(entry, now)) return null;
    if (platform === "apple") {
      const input = entry.time + "\n" + entry.label;
      return "shortcuts://run-shortcut?name=Dosewell%20Alarm&input=text&text=" + encodeURIComponent(input);
    }
    return null;
  }
  function alarmTimeLabel(entry) {
    return entry.oneTime ? entry.at.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" }) : timeLabel(entry.time);
  }
  function repeatText(entry) {
    if (entry.oneTime) return "One time (Repeat off)";
    return entry.days.length === 7 ? "Every day" : entry.days.map((d) => dayNames[d]).join(", ");
  }
  function readableDate(day2) {
    return localDay(day2).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  }
  function alarmText(entry) {
    return [
      entry.label,
      "Alarm time: " + alarmTimeLabel(entry),
      "Next: " + readableDate(dayKey(entry.at)),
      "Repeat: " + repeatText(entry),
      ...entry.until ? ["Last alarm date: " + readableDate(entry.until)] : []
    ].join("\n");
  }
  function alarmFile(entries) {
    return "Dosewell phone alarms\nLocal device time\n\n" + entries.map(alarmText).join("\n\n") + (entries.some((e) => e.oneTime) ? "\n\nHourly schedules use dated, one-time alarms for the next 24 hours (or the next upcoming alert if later). Export to Calendar for the complete repeating schedule." : "") + "\n\nConfirm each time, label and repeat schedule in Clock. Remove alarms after the last scheduled date or if the prescription changes.\n";
  }

  // dosewell-apps/android-clock.js
  var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  var button = (title, cls = "btn small outline") => {
    const el = document.createElement("button");
    el.type = "button";
    el.className = cls;
    el.textContent = title;
    return el;
  };
  var text2 = (tag, value) => {
    const el = document.createElement(tag);
    el.textContent = value;
    return el;
  };
  function canRepeat(entry, now) {
    if (entry.oneTime || entry.until || !entry.days?.length) return false;
    const [hour, minute] = entry.time.split(":").map(Number);
    for (let offset = 0; offset <= 7; offset++) {
      const next = new Date(now);
      next.setDate(next.getDate() + offset);
      next.setHours(hour, minute, 0, 0);
      if (next >= now && entry.days.includes(next.getDay())) return next.getTime() === entry.at.getTime();
    }
    return false;
  }
  function androidRequests(state2, now = /* @__PURE__ */ new Date()) {
    return phoneAlarms(state2, now).map((entry) => {
      const repeat = canRepeat(entry, now);
      const schedule2 = repeat ? entry.days.length === 7 ? "every day" : "every " + entry.days.map((d) => weekdays[d]).join(" and ") : "once on " + readableDate(dayKey(entry.at));
      const label = "Dosewell \xB7 " + entry.label;
      const clock2 = entry.at.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
      const zone = entry.at.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" });
      const request = "Set an alarm on this phone at " + (repeat ? clock2 : zone) + " " + schedule2 + " named " + JSON.stringify(label) + ".";
      return { entry, schedule: schedule2, repeat, request };
    });
  }
  function androidSetupText(items) {
    if (!items.length) return "";
    const prefix = "Use the Clock app on this phone. Keep any alarm that already matches. If exactly one existing alarm and one requested repeating alarm share the same Dosewell name, update its time and repeat days. If a match is ambiguous, ask me before changing it. Leave other alarms alone.";
    return [prefix, ...items.map((r) => r.request), "Show me which alarms you set and flag any you could not create."].join("\n");
  }
  function showAndroidClock(container, getState, { allowShare = true } = {}) {
    const render2 = () => {
      const now = /* @__PURE__ */ new Date(), items = androidRequests(getState(), now);
      container.replaceChildren();
      if (!items.length) {
        container.append(text2("p", "There are no future scheduled doses to set in Clock."));
        return;
      }
      const native = document.createElement("section");
      const app = text2("a", "Get alarms from the Dosewell app");
      app.href = "./mobile-apps.html";
      app.className = "text-link";
      native.append(app, text2("h3", "Send an alarm to Android Clock"));
      const install = text2("a", "Download Dosewell Clock for Android");
      install.href = "./dosewell-clock.apk";
      install.download = "dosewell-clock.apk";
      install.className = "btn outline";
      native.append(text2("p", "On your Android phone, open the download and confirm installation once. Return here and tap a dose or warning to send it to Clock."), install);
      const connection = text2("p", "");
      connection.setAttribute("role", "status");
      native.append(connection);
      if (items.some((r) => !r.repeat)) native.append(text2("p", "Hourly reminders are individual alarms for the upcoming 24 hours. A course with an end date uses individual alarms for each upcoming time. Return for later alarms."));
      const links = [];
      for (const item of items) {
        const { entry } = item, card = document.createElement("article");
        card.className = "phone-entry";
        card.append(text2("b", entry.label), text2("p", alarmTimeLabel(entry) + " \xB7 " + item.schedule));
        if (item.repeat || clockCanSet(entry, now)) {
          const link = text2("a", "Set in Android Clock");
          link.className = "btn small primary";
          link.setAttribute("aria-label", "Set in Android Clock: " + entry.label + " at " + alarmTimeLabel(entry));
          link.hidden = true;
          link.onclick = (event) => {
            const current = androidRequests(getState()).find((r) => r.entry.key === entry.key && r.request === item.request);
            if (!current || !current.repeat && !clockCanSet(current.entry) || Date.now() - Number(link.dataset.issued) > 24e4) {
              event.preventDefault();
              render2();
              return;
            }
            connection.textContent = "If this is your first alarm, match the code " + link.dataset.code + " in Dosewell Clock. Check the alarm in Clock after the handoff.";
          };
          links.push({ link, item });
          card.append(link);
        } else card.append(text2("p", "This alarm starts later. Return closer to the date shown to add it to Clock."));
        native.append(card);
      }
      container.append(native);
      if (links.length) {
        const refresh = async () => {
          try {
            const identity = await clockIdentity(), issued = Date.now();
            await Promise.all(links.map(async ({ link, item }) => {
              link.href = await clockLink(identity, item, issued);
              link.dataset.issued = String(issued);
              link.dataset.code = identity.code;
              link.hidden = false;
            }));
            connection.textContent = "For the first alarm, match " + identity.code + " in the companion and approve. When a schedule changes, review older alarms in Clock.";
            setTimeout(() => {
              if (native.isConnected && native.closest("dialog:not([open])") === null) refresh();
            }, 18e4);
          } catch {
            connection.textContent = "This browser could not save a connection. Open Dosewell in Chrome on Android or use the other setup options below.";
          }
        };
        refresh();
      }
      const alternate = document.createElement("details");
      alternate.className = "export-guide";
      alternate.append(text2("summary", "Other ways to set up Clock"));
      container.append(alternate);
      const steps = document.createElement("ol");
      steps.className = "clock-steps";
      steps.append(text2("li", "Copy the alarm request below."), text2("li", "Open the Gemini mobile app on your phone, paste the request, and submit it. On Galaxy, you can also say an individual request to Bixby."), text2("li", "Open Clock \u2192 Alarm. Verify each dose time, advance warning, repeat day, and enabled switch. If an alarm is missing, use its individual request below. Review old Dosewell alarms after a schedule change."));
      const feedback = text2("p", "");
      feedback.setAttribute("role", "status");
      const display = document.createElement("textarea");
      display.readOnly = true;
      display.rows = 5;
      display.className = "transfer-copy";
      display.hidden = true;
      display.setAttribute("aria-label", "Text to copy");
      const copy = async (value, ok) => {
        try {
          await navigator.clipboard.writeText(value);
          feedback.textContent = ok;
          display.hidden = true;
        } catch {
          display.value = value;
          display.hidden = false;
          display.focus();
          display.select();
          feedback.textContent = "The text is selected. Choose Copy on your phone.";
        }
      };
      const copyAll = button("Copy Clock setup request", "btn primary");
      copyAll.onclick = () => {
        const current = androidRequests(getState());
        if (current.map((r) => r.entry.key).join("|") !== items.map((r) => r.entry.key).join("|") || androidSetupText(current) !== androidSetupText(items)) {
          render2();
          return;
        }
        copy(androidSetupText(current), "Copied. Paste into Gemini on your phone and submit, then check Clock.");
      };
      alternate.append(text2("p", "Downloading an .ics file adds calendar events when imported. Android Clock needs its own alarms."), steps, copyAll);
      container.append(feedback, display);
      alternate.append(text2("p", "The request includes the medication names, doses, and times shown below. Your phone assistant receives them when you paste or speak the request."));
      if (items.some((r) => !r.repeat)) alternate.append(text2("p", "Dated alarms are one-time entries. For an hourly schedule, this list covers the next 24 hours, or the first upcoming alert if later. For a course with an end date, it shows the next alarm for each scheduled time. Return here for later alarms."));
      const individual = document.createElement("details");
      individual.className = "export-guide";
      individual.open = items.length <= 3;
      individual.append(text2("summary", "Individual alarm requests (" + items.length + ")"));
      for (const item of items) {
        const { entry } = item, card = document.createElement("article");
        card.className = "phone-entry";
        card.append(text2("div", alarmTimeLabel(entry)), text2("b", entry.label), text2("p", item.schedule[0].toUpperCase() + item.schedule.slice(1)));
        const details = document.createElement("details");
        details.className = "export-guide";
        details.append(text2("summary", "View or copy this alarm"), text2("p", item.request));
        const single = button("Copy this alarm");
        single.onclick = () => {
          const current = androidRequests(getState()).find((r) => r.entry.key === entry.key && r.request === item.request);
          if (!current) {
            render2();
            return;
          }
          copy(current.request, "Alarm request copied. Paste or say it to your phone assistant.");
        };
        details.append(single);
        card.append(details);
        individual.append(card);
      }
      alternate.append(individual);
      const manual = document.createElement("details");
      manual.className = "export-guide";
      manual.append(text2("summary", "Set an alarm directly in Clock"), text2("p", "Open Clock \u2192 Alarm. Tap an existing alarm to update it, or tap + to add one. Enter the time, choose the repeat days, paste or type the label, and save. Set advance warnings as separate alarms."));
      alternate.append(manual);
      if (allowShare) {
        const send = button("Share Clock setup link");
        send.onclick = async () => {
          const link = transferLink(getState(), document.baseURI);
          if (!link) {
            feedback.textContent = "The full schedule does not fit in a setup link. Use the Clock requests on this device.";
            feedback.scrollIntoView({ block: "nearest" });
            return;
          }
          const url = new URL(link);
          url.searchParams.set("setup", "clock");
          if (navigator.share) {
            try {
              await navigator.share({ title: "Dosewell Clock setup", url: url.href });
              return;
            } catch (error) {
              if (error.name === "AbortError") return;
            }
          }
          await copy(url.href, "Clock setup link copied. Paste it into a message to your phone.");
          feedback.scrollIntoView({ block: "nearest" });
        };
        container.append(text2("p", "To open this setup on another phone, share the link with its intended recipient. Anyone with it can read these reminders."), send);
      }
    };
    render2();
  }

  // dosewell-apps/exports.js
  var shortcutHelp = '<details class="export-guide"><summary>Set up the iPhone shortcut once</summary><ol><li>In Shortcuts, create a shortcut named <b>Dosewell Alarm</b>.</li><li>Add <b>Split Text</b>. Set the input to <b>Shortcut Input</b> and the separator to <b>New Lines</b>.</li><li>Add <b>Get Item from List</b> twice. Use the split text list for both actions. Get the first item for the time and the last item for the label.</li><li>Add <b>Create Alarm</b>. For the time, choose the first item. For the label, choose the last item. Leave Repeat set to Never. Save your shortcut.</li></ol><p>Choose <b>Send to Shortcuts</b> for each alarm. Open Clock to verify it and set any repeat days. For a simpler setup, ask Siri to set an alarm at the time shown and give it the medication label.</p></details>';
  function download(name, type, text3) {
    const url = URL.createObjectURL(new Blob([text3], { type }));
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 6e4);
  }
  function calendarOptions(state2, openDialog2) {
    const cal = calendarFile(state2);
    if (!cal.count) {
      openDialog2("Calendar reminders", '<p>Add a medication with a future dose time to create a reminder file.</p><button class="btn primary" data-action="add-stroke">Add medication</button>');
      return;
    }
    openDialog2("Calendar reminders", '<p>The .ics file is for your calendar. Downloading or texting it does not add or update Android Clock alarms. To create Clock alarms, choose Android Clock setup.</p><div class="export-choices"><button class="btn primary" data-action="text-reminders">' + icon("message", 18) + 'Text to a phone</button><button class="btn outline" data-action="export">' + icon("calendar", 18) + 'Get calendar file (.ics)</button></div><p class="transfer-privacy">The file and reminder link include medication names, doses, and times. Anyone who receives them can read the schedule.</p><p id="calendar-feedback" role="status"></p><details class="export-guide"><summary>How to add the alerts</summary><p>In Messages, choose the phone number and tap Send. On the receiving phone, open the attachment or reminder link and confirm the calendar import. Check a dose alert and its advance warning.</p><p>Apple Mail can import an .ics attachment on iPhone. For Google Calendar, import the file on a computer into the calendar that syncs to your Android phone. Other calendar apps may open the file directly.</p><p>This file is a snapshot. Replace the old events when the schedule changes. Calendar alerts and Clock alarms are managed separately on your phone.</p></details><div class="export-choices"><button class="btn outline" data-action="android-clock">Android Clock setup</button><button class="text-link" data-action="manual-transfer">Other ways to send</button></div>');
  }
  function manualTransfer(state2, openDialog2, dialog2, reason = "") {
    if (!calendarFile(state2).count) {
      calendarOptions(state2, openDialog2);
      return;
    }
    const link = transferLink(state2, document.baseURI);
    const apple = /iPad|iPhone|iPod/.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
    const sms = apple ? "sms:" : "sms:?body=" + encodeURIComponent("Open your Dosewell reminder file: " + link);
    const actions = link ? '<div class="export-choices"><a class="btn primary" rel="noreferrer" href="' + h(sms) + '">' + icon("message", 17) + 'Open Messages</a><button type="button" class="btn outline" id="copy-transfer">Copy reminder link</button></div><p>' + (apple ? "Copy the reminder link, open Messages, and paste it into a text." : "Choose your phone number in the draft and send. If Messages does not open or the draft is empty, copy the link and paste it into your messaging app.") + "</p>" : "<p>This schedule is too large for a reliable text link. Download the complete calendar file and attach it in Messages or Mail.</p>";
    openDialog2("Text your reminders", (reason ? "<p>" + h(reason) + "</p>" : "") + actions + '<p class="transfer-privacy">Anyone with the message or file can see these medication names, doses, and times.</p><button class="btn outline" data-action="export">' + icon("download", 17) + 'Download calendar attachment</button><p id="calendar-feedback" role="status"></p>');
    if (!link) return;
    dialog2.querySelector("#copy-transfer").onclick = async () => {
      const feedback = dialog2.querySelector("#calendar-feedback");
      try {
        await navigator.clipboard.writeText(link);
        feedback.textContent = "Reminder link copied. Paste it into your message.";
      } catch {
        let input = dialog2.querySelector(".transfer-copy");
        if (!input) {
          input = document.createElement("textarea");
          input.className = "transfer-copy";
          input.readOnly = true;
          input.setAttribute("aria-label", "Reminder link to copy");
          input.value = link;
          feedback.after(input);
        }
        input.focus();
        input.select();
        feedback.textContent = "Copy the selected link and paste it into your message.";
      }
    };
  }
  async function textReminders(state2, openDialog2, dialog2, manual = false) {
    if (manual) {
      manualTransfer(state2, openDialog2, dialog2);
      return;
    }
    const cal = calendarFile(state2);
    if (!cal.count) {
      calendarOptions(state2, openDialog2);
      return;
    }
    const link = transferLink(state2, document.baseURI);
    const choice = transferChoice(cal, link);
    if (choice.kind === "manual") {
      manualTransfer(state2, openDialog2, dialog2);
      return;
    }
    const feedback = dialog2.querySelector("#calendar-feedback");
    feedback.textContent = choice.kind === "file" ? "Choose Messages to send your calendar attachment." : "Choose Messages to send the link to your calendar file.";
    try {
      await navigator.share(choice.data);
      if (feedback.isConnected) feedback.textContent = "On the receiving phone, open the attachment or link and confirm the calendar import.";
    } catch (error) {
      if (!feedback.isConnected) return;
      if (error.name === "AbortError") {
        feedback.textContent = "Sharing canceled. Your schedule is ready when you are.";
        return;
      }
      manualTransfer(state2, openDialog2, dialog2, "Sharing is unavailable in this browser. You can still send the reminders below.");
    }
  }
  function phoneExport(getState, openDialog2, dialog2, requestedPlatform = "") {
    const apple = /iPhone|iPad|iPod/i.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
    let platform = requestedPlatform || (apple ? "apple" : /Android/i.test(navigator.userAgent) ? "android" : "");
    const render2 = () => {
      const entries = phoneAlarms(getState());
      if (!entries.length && platform === "android") {
        openDialog2("Android Clock setup", '<p>Install the companion once. Add a medication with a future dose time to send your first alarm.</p><div class="export-choices"><a class="btn outline" href="./clock-install.html">Install Dosewell Clock</a><button class="btn primary" data-action="add-stroke">Add medication</button></div>');
        return;
      }
      if (!entries.length) {
        openDialog2("Phone alarms", '<p>Add a future dose time in your medication list to export a phone alarm.</p><button class="btn primary" data-action="add-stroke">Add medication</button>');
        return;
      }
      const option = (key2, text3) => '<button class="btn outline" data-platform="' + key2 + '" aria-pressed="' + (platform === key2) + '">' + text3 + "</button>";
      const tabs = '<div class="platform-picker">' + option("android", "Android") + option("apple", "iPhone") + "</div>";
      const bindTabs = () => dialog2.querySelectorAll("[data-platform]").forEach((b) => b.onclick = () => {
        platform = b.dataset.platform;
        render2();
        dialog2.querySelector('[data-platform="' + platform + '"]').focus();
      });
      if (platform === "android") {
        openDialog2("Android Clock setup", tabs + '<div id="android-clock-setup"></div>');
        showAndroidClock(dialog2.querySelector("#android-clock-setup"), getState);
        bindTabs();
        return;
      }
      const cards = entries.map((entry, i) => {
        const can = clockCanSet(entry);
        const name = "Send to Shortcuts";
        return '<article class="phone-entry"><div class="phone-time">' + h(alarmTimeLabel(entry)) + "</div><div><b>" + h(entry.name) + " \xB7 " + h(entry.dose) + "</b><p>" + (entry.minutes ? "Advance warning \xB7 dose at " + h(timeLabel(entry.doseTime)) + (entry.doseDay && entry.doseDay !== dayKey(entry.at) ? " on " + h(readableDate(entry.doseDay)) : "") : "Dose time") + "</p><p>Next " + h(readableDate(dayKey(entry.at))) + " \xB7 " + h(repeatText(entry)) + "</p>" + (entry.until ? "<p>Last alarm " + h(readableDate(entry.until)) + "</p>" : "") + '</div><div class="phone-actions">' + (platform && can ? '<button class="btn small primary" data-send="' + i + '">' + name + "</button>" : "") + '<button class="btn small outline" data-copy="' + i + '">Copy details</button></div>' + (platform && !can ? "<small>This alarm starts on a later date. Use the calendar export or set it in Clock on the date shown.</small>" : "") + "</article>";
      }).join("");
      openDialog2("Phone alarms", "<p>Each entry is one alarm, including advance warnings. Choose the phone you use.</p>" + tabs + (platform === "apple" ? shortcutHelp : "") + '<p class="export-note">Check the time and label in Clock. ' + (entries.some((e) => e.oneTime) ? "Hourly schedules show one-time alarms for the next 24 hours, or the first upcoming alert if later. Leave Repeat off for these alarms. Use Calendar alerts for the full repeating schedule." : "Set repeat days there and remove alarms when a course ends or a dose changes.") + '</p><div class="phone-entries">' + cards + '</div><button class="btn outline" id="download-alarms">' + icon("download", 17) + 'Download alarm list (.txt)</button><p class="export-feedback" role="status"></p>');
      const feedback = dialog2.querySelector(".export-feedback");
      bindTabs();
      dialog2.querySelector("#download-alarms").onclick = () => {
        download("Dosewell-phone-alarms.txt", "text/plain;charset=utf-8", alarmFile(phoneAlarms(getState())));
        feedback.textContent = "Reference list downloaded. A text file cannot install Clock alarms.";
      };
      dialog2.querySelectorAll("[data-copy]").forEach((b) => b.onclick = async () => {
        const txt = alarmText(entries[Number(b.dataset.copy)]);
        try {
          await navigator.clipboard.writeText(txt);
          b.textContent = "Copied";
        } catch {
          const field = document.createElement("textarea");
          field.readOnly = true;
          field.setAttribute("aria-label", "Alarm details to copy");
          field.value = txt;
          b.parentElement.after(field);
          field.focus();
          field.select();
        }
      });
      dialog2.querySelectorAll("[data-send]").forEach((b) => b.onclick = () => {
        const old = entries[Number(b.dataset.send)], current = phoneAlarms(getState()).find((a) => a.key === old.key && a.label === old.label);
        const href = current && phoneHandoff(current, platform);
        if (!href) {
          render2();
          return;
        }
        feedback.textContent = "Check your Clock app to confirm this alarm was created.";
        window.location.href = href;
      });
    };
    render2();
  }

  // dosewell-apps/app.js
  var main = document.querySelector("#main");
  var dialog = document.querySelector("#dialog");
  var state = read();
  var view = "overview";
  var filter = "all";
  var selected = dayKey(/* @__PURE__ */ new Date());
  var lastDay = selected;
  var part = null;
  var toastTimer;
  var audioContext;
  var workerRegistration;
  var checking = false;
  var lastCheck = Date.now() - 6e4;
  var visibleEvents = [];
  document.querySelector("#new-address").hidden = location.hostname !== "dosewell-medication-planner.starryfable2.chatgpt.site";
  var offerPhoneSetup = false;
  var alarmContainer = document.querySelector("#alarms");
  for (const el of document.querySelectorAll("[data-icon]")) el.innerHTML = icon(el.dataset.icon, 16);
  if (!nativePlatform && "serviceWorker" in navigator) navigator.serviceWorker.register("./worker.js").then((r) => {
    workerRegistration = r;
  }).catch(() => {
  });
  navigator.serviceWorker?.addEventListener("message", (e) => {
    if (e.data?.view === "overview") location.hash = "overview";
  });
  function toast(msg) {
    const t = document.querySelector("#toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.hidden = true, 5200);
  }
  function render() {
    state = read();
    const parts = location.hash.slice(1).split("/");
    view = navItems.some(([v]) => v === parts[0]) ? parts[0] : "overview";
    filter = ["all", "stroke", "other"].includes(parts[1]) ? parts[1] : "all";
    document.querySelector("#nav").innerHTML = nav(view);
    const period = ["7", "30", "all"].includes(parts[1]) ? parts[1] : "7";
    main.innerHTML = view === "overview" ? overview(state, selected, part) : view === "history" ? historyPage(state, period) : view === "medications" ? medicationPage(state, filter) : view === "interactions" ? interactionPage(state) : remindersPage(state);
    paintNative();
    document.title = (navItems.find(([v]) => view === v)?.[2] || "Overview") + " | Dosewell";
    document.querySelector("#setup-prompt").hidden = !offerPhoneSetup || view === "reminders" || view === "interactions" || !state.meds.some((m) => m.mode !== "list");
    const msg = storageStatus(), warning = document.querySelector("#storage-warning");
    warning.textContent = msg;
    warning.hidden = !msg;
  }
  function route() {
    if (location.hash === "#overview") {
      selected = dayKey(/* @__PURE__ */ new Date());
      part = null;
    }
    render();
    window.scrollTo({ top: 0 });
    main.focus({ preventScroll: true });
    if (location.hash === "#reminders/android-clock") phoneExport(read, openDialog, dialog, "android");
    if (location.hash === "#overview/schedule") {
      selected = dayKey(/* @__PURE__ */ new Date());
      render();
      document.querySelector(".schedule")?.scrollIntoView({ block: "start" });
    }
  }
  window.addEventListener("hashchange", route);
  onLocalChange(() => {
    render();
    refreshAlarms();
  });
  async function save(fn) {
    await change(fn);
    render();
    refreshAlarms();
    syncNative();
  }
  function openDialog(title, content) {
    dialog.innerHTML = '<div class="modal-head"><h2 id="dialog-title">' + title + "</h2>" + btnIcon("close", "Close dialog", "close") + '</div><div class="dialog-content">' + content + "</div>";
    if (!dialog.open) dialog.showModal();
  }
  function openEditor(med, cat) {
    showEditor(dialog, med, cat, state.settings, async (item) => {
      await save((s) => {
        const pos = s.meds.findIndex((m) => m.id === item.id);
        if (med && pos < 0) throw Error("This medication was removed in another tab. Close this form and review your list.");
        if (med && JSON.stringify(s.meds[pos]) !== JSON.stringify(med)) throw Error("This medication was edited in another tab. Reopen it to view the latest schedule.");
        if (pos < 0) s.meds.push(item);
        else {
          alignDoseKeys(s, s.meds[pos], item);
          s.meds[pos] = item;
          for (const key2 of Object.keys(s.snoozes)) if (key2.startsWith(item.id + "|")) delete s.snoozes[key2];
        }
      });
      dialog.close();
      const pairs = compare(state.meds).filter((p) => p.a.id === item.id || p.b.id === item.id);
      const flags = pairs.filter((p) => p.level !== "unassessed");
      if (flags.length) {
        location.hash = "interactions";
        toast("Medication saved. Review the interaction warning" + (flags.length === 1 ? "" : "s") + ".");
      } else if (pairs.length) {
        toast("Medication saved. This combination needs pharmacist review.");
        location.hash = "interactions";
      } else toast("Medication saved.");
      if (item.mode !== "list" && !nativePlatform) {
        offerPhoneSetup = true;
        render();
      }
      await scan();
    }, (m) => {
      openDialog("Remove medication?", "<p>Remove <b>" + h(m.name) + '</b> from this list and cancel its in-page reminders? Remove any exported calendar events and phone alarms for this entry as well.</p><p>This removes the entry from Dosewell only. Follow your prescriber\u2019s instructions for treatment.</p><div class="form-buttons"><button class="btn outline" id="keep-editing">Keep medication</button><button class="btn danger" id="confirm-remove">Remove entry</button></div>');
      document.querySelector("#keep-editing").onclick = () => openEditor(m, m.category);
      document.querySelector("#confirm-remove").onclick = async () => {
        await save((s) => {
          s.meds = s.meds.filter((v) => v.id !== m.id);
          delete s.supplies[m.id];
          for (const k of Object.keys(s.snoozes)) if (k.startsWith(m.id + "|")) delete s.snoozes[k];
        });
        dialog.close();
        toast("Medication removed from this planner.");
      };
    });
  }
  function openSupply(id) {
    const data = read(), med = data.meds.find((m) => m.id === id);
    if (!med) return;
    const prior = data.supplies[id];
    openDialog("Refill tracking", "<p><b>" + h(medicationTitle(med)) + '</b></p><p>Count how many complete prescribed doses you have. Recording a dose as taken subtracts one. A refill reminder appears in Today at the limit you choose.</p><form class="inventory-form"><label>Doses remaining<input type="number" name="remaining" min="0" max="99999" step="1" required value="' + (prior?.remaining ?? "") + '"></label><label>Show a refill reminder at this many doses<input type="number" name="threshold" min="0" max="99999" step="1" required value="' + (prior?.threshold ?? 5) + '"></label><div class="form-buttons">' + (prior ? '<button type="button" class="danger-text" id="stop-refills">Stop tracking</button>' : "") + '<button type="button" class="btn outline" data-action="close">Cancel</button><button class="btn primary" type="submit">Save supply</button></div><p role="status" class="inventory-feedback"></p></form>');
    const form = dialog.querySelector("form");
    async function commit(remaining, threshold) {
      try {
        await save((s) => updateSupply(s, id, remaining, threshold, prior));
        dialog.close();
        toast(remaining === null ? "Refill tracking turned off." : "Supply saved.");
      } catch (error) {
        form.querySelector(".inventory-feedback").textContent = error.message;
      }
    }
    form.onsubmit = (e) => {
      e.preventDefault();
      const data2 = new FormData(form);
      commit(Number(data2.get("remaining")), Number(data2.get("threshold")));
    };
    if (prior) form.querySelector("#stop-refills").onclick = () => commit(null, null);
  }
  function openSnooze(key2) {
    const row = doseAt(read(), key2);
    if (!row) return;
    openDialog("Snooze reminder", "<p><b>" + h(medicationTitle(row.med)) + "</b> \xB7 " + h(row.med.dose) + "</p><p>Choose when Dosewell should alert you again for the " + doseTimeLabel(row) + " dose. The prescribed time stays the same. " + (nativePlatform ? "Keep Dosewell alarms enabled." : "Keep the page open for this reminder.") + '</p><div class="snooze-options">' + [5, 10, 15, 30, 60].map((n) => '<button class="btn outline" data-snooze-minutes="' + n + '">' + n + " min</button>").join("") + '</div><p class="snooze-feedback" role="status"></p>');
    dialog.querySelectorAll("[data-snooze-minutes]").forEach((b) => b.onclick = async () => {
      try {
        await save((s) => snoozeDose(s, key2, Number(b.dataset.snoozeMinutes)));
        dialog.close();
        toast("Reminder snoozed for " + b.dataset.snoozeMinutes + " minutes.");
      } catch (err) {
        dialog.querySelector(".snooze-feedback").textContent = err.message;
      }
    });
  }
  function confirmUnscheduled(id) {
    const med = read().meds.find((m) => m.id === id && m.mode === "list");
    if (!med) return;
    const key2 = "unscheduled|" + crypto.randomUUID();
    openDialog("Record a dose already taken", "<p>Record <b>" + h(medicationTitle(med)) + " \xB7 " + h(med.dose) + '</b> in your history using the current time.</p><div class="form-buttons"><button class="btn outline" data-action="close">Cancel</button><button class="btn primary" id="confirm-unscheduled">Record as taken</button></div>');
    dialog.querySelector("#confirm-unscheduled").onclick = async (e) => {
      e.currentTarget.disabled = true;
      try {
        await save((s) => logAsNeeded(s, id, key2));
        dialog.close();
        toast("Dose recorded in History.");
      } catch (error) {
        toast(error.message);
        dialog.close();
      }
    };
  }
  function audioReady() {
    if (!state.settings.sound) return;
    try {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!Context) return;
      audioContext || (audioContext = new Context());
      if (audioContext.state === "suspended") audioContext.resume().catch(() => {
      });
    } catch {
    }
  }
  window.addEventListener("pointerdown", audioReady, { passive: true });
  window.addEventListener("keydown", audioReady, { passive: true });
  function chime() {
    if (!state.settings.sound || !audioContext || audioContext.state !== "running") return;
    for (const [i, f] of [660, 880, 740].entries()) {
      const osc = audioContext.createOscillator(), gain = audioContext.createGain(), t = audioContext.currentTime + i * 0.23;
      osc.frequency.value = f;
      gain.gain.setValueAtTime(1e-3, t);
      gain.gain.exponentialRampToValueAtTime(0.12, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(1e-3, t + 0.45);
      osc.connect(gain);
      gain.connect(audioContext.destination);
      osc.start(t);
      osc.stop(t + 0.48);
    }
  }
  function refreshAlarms() {
    visibleEvents = visibleEvents.filter((e) => {
      if (e.test) return true;
      const m = state.meds.find((m2) => m2.id === e.medId);
      return m && medicationTitle(m) === e.name && m.dose === e.dose && !recordedStatus(state, e.doseKey) && !(state.snoozes[e.doseKey] > Date.now()) && dosesFor([m], e.day).some((d) => d.key === e.doseKey) && (e.kind !== "advance" || Date.now() < e.when);
    });
    alarmContainer.innerHTML = visibleEvents.map((e) => {
      const key2 = h(e.doseKey);
      const actions = e.test || e.kind === "advance" ? "" : '<button class="btn small primary" data-take="' + key2 + '">Mark taken</button><button class="btn small outline" data-skip="' + key2 + '">Log skipped</button><button class="btn small outline" data-snooze="' + key2 + '">Snooze</button>';
      return '<div class="live-alarm">' + icon("bell", 23) + "<div><b>" + h(e.title) + "</b><p>" + h(e.body) + '</p></div><div class="alarm-actions">' + actions + '<button class="btn small outline" data-dismiss="' + h(e.id) + '">Dismiss</button></div></div>';
    }).join("");
  }
  async function present(event) {
    visibleEvents.push(event);
    refreshAlarms();
    chime();
    if (!state.settings.notifications || window.Notification?.permission !== "granted") return;
    const options = { body: event.body, tag: event.id, icon: "./icon.svg" };
    try {
      if (workerRegistration?.active) await workerRegistration.showNotification(event.title, options);
      else new Notification(event.title, options);
    } catch {
      toast("Device notifications could not be shown. The reminder is visible on this page.");
    }
  }
  async function scan() {
    if (checking || nativePlatform) return;
    checking = true;
    try {
      const now = /* @__PURE__ */ new Date(), day2 = dayKey(now);
      let changed = false;
      if (lastDay !== day2) {
        if (selected === lastDay) selected = day2;
        lastDay = day2;
        changed = true;
      }
      state = read();
      const clock2 = document.querySelector("#device-clock");
      if (clock2) clock2.textContent = now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" });
      const since = Math.max(lastCheck, now.getTime() - 6e4);
      lastCheck = now.getTime();
      let events = dueEvents(state, now, since);
      if (events.length) {
        state = await change((s) => {
          events = dueEvents(s, now, since);
          for (const e of events) s.fired[e.id] = now.getTime();
          for (const [k, v] of Object.entries(s.fired)) if (now - v > 3 * 864e5) delete s.fired[k];
        });
        for (const e of events) {
          const title = e.kind === "snooze" ? "Snoozed reminder" : e.kind === "due" ? "Scheduled dose reminder" : "Upcoming medication reminder";
          const body = medicationTitle(e.med) + " \xB7 " + e.med.dose + " \xB7 " + doseTimeLabel(e) + (e.day === day2 ? "" : e.day === shiftDay(day2, 1) ? " tomorrow" : e.day === shiftDay(day2, -1) ? " yesterday" : " on " + e.day) + ".";
          await present({ id: e.id, title, body, day: e.day, when: e.when.getTime(), kind: e.kind, medId: e.med.id, name: medicationTitle(e.med), dose: e.med.dose, doseKey: e.key });
        }
        changed = true;
      }
      if (changed) render();
      if (visibleEvents.length) refreshAlarms();
    } catch (err) {
      toast(err.message || "Unable to check reminders.");
    } finally {
      checking = false;
    }
  }
  async function notifications() {
    if (state.settings.notifications && window.Notification?.permission === "granted") {
      await save((s) => s.settings.notifications = false);
      toast("Device notifications turned off.");
      return;
    }
    if (!window.Notification) {
      toast("This browser does not support device notifications. Use the calendar export for device alerts.");
      return;
    }
    let permission;
    try {
      permission = await Notification.requestPermission();
    } catch {
      permission = "denied";
    }
    await save((s) => s.settings.notifications = permission === "granted");
    toast(permission === "granted" ? "Device notifications enabled. Test an alarm on this device." : "Permission unavailable. In-page alarms remain available while this page is open.");
  }
  document.addEventListener("submit", async (e) => {
    if (e.target.id !== "default-form") return;
    e.preventDefault();
    const value = Number(new FormData(e.target).get("minutes"));
    if (Number.isInteger(value) && value >= 0 && value <= 1440) {
      await save((s) => s.settings.advance = value);
      toast("Default advance warning saved.");
    }
  });
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("button, a");
    if (!b) return;
    if (b.classList.contains("skip")) {
      e.preventDefault();
      main.focus();
      main.scrollIntoView({ block: "start" });
      return;
    }
    const d = b.dataset;
    try {
      if (d.date) {
        selected = d.date;
        part = null;
        render();
        document.querySelector('[data-date="' + selected + '"]')?.focus({ preventScroll: true });
        return;
      }
      if (d.edit) {
        const m = state.meds.find((v) => v.id === d.edit);
        if (m) openEditor(m, m.category);
        return;
      }
      if (d.part !== void 0) {
        part = part === Number(d.part) ? null : Number(d.part);
        render();
        main.querySelector('[data-part="' + d.part + '"]')?.focus({ preventScroll: true });
        return;
      }
      if (d.take || d.skip) {
        const key2 = d.take || d.skip;
        await save((s) => logDose(s, key2, d.take ? "taken" : "skipped"));
        const supply = state.supplies[state.history[key2].medId];
        toast(d.take ? "Dose recorded as taken." + (supply && supply.remaining <= supply.threshold ? " Refill reminder: " + supply.remaining + " doses left." : "") : "Dose recorded as skipped.");
        return;
      }
      if (d.logUndo) {
        await save((s) => undoLog(s, d.logUndo, Number(d.stamp)));
        toast("Dose record undone.");
        return;
      }
      if (d.snooze) {
        openSnooze(d.snooze);
        return;
      }
      if (d.supply) {
        openSupply(d.supply);
        return;
      }
      if (d.asNeeded) {
        confirmUnscheduled(d.asNeeded);
        return;
      }
      if (d.dismiss) {
        visibleEvents = visibleEvents.filter((v) => v.id !== d.dismiss);
        refreshAlarms();
        return;
      }
      switch (d.action) {
        case "add":
        case "add-stroke":
        case "add-other":
          openEditor(null, d.action === "add-other" || d.action === "add" && filter === "other" ? "other" : "stroke");
          break;
        case "close":
          dialog.close();
          break;
        case "prev-week":
        case "next-week":
          selected = shiftDay(selected, d.action === "prev-week" ? -7 : 7);
          render();
          document.querySelector('[data-action="' + d.action + '"]')?.focus({ preventScroll: true });
          break;
        case "today":
          selected = dayKey(/* @__PURE__ */ new Date());
          part = null;
          render();
          break;
        case "all-periods":
          part = null;
          render();
          break;
        case "print-history":
          window.print();
          break;
        case "sound":
          await save((s) => s.settings.sound = !s.settings.sound);
          audioReady();
          break;
        case "notify":
          await notifications();
          break;
        case "test":
          audioReady();
          await present({ id: "sample", test: true, title: "Test reminder", body: "This is a sample alarm. No medication dose is due from this test." });
          break;
        case "dismiss-setup":
          offerPhoneSetup = false;
          render();
          break;
        case "phone-setup":
          offerPhoneSetup = false;
          document.querySelector("#setup-prompt").hidden = true;
          if (/Android/i.test(navigator.userAgent)) phoneExport(read, openDialog, dialog, "android");
          else calendarOptions(read(), openDialog);
          break;
        case "android-clock":
          phoneExport(read, openDialog, dialog, "android");
          break;
        case "calendar-options":
          offerPhoneSetup = false;
          document.querySelector("#setup-prompt").hidden = true;
          calendarOptions(read(), openDialog);
          break;
        case "text-reminders":
          await textReminders(read(), openDialog, dialog);
          break;
        case "manual-transfer":
          await textReminders(read(), openDialog, dialog, true);
          break;
        case "export":
          if (saveCalendarFile(read())) {
            const feedback = document.querySelector("#calendar-feedback");
            feedback.textContent = "Open the .ics file in your calendar, or attach it in Messages. Confirm the import and check the alerts on the receiving phone.";
            b.textContent = "Download again";
          } else calendarOptions(read(), openDialog);
          break;
        case "phone-alarms":
          phoneExport(read, openDialog, dialog);
          break;
        case "enable-app-alarms":
        case "test-app-alarm":
        case "stop-app-alarms":
          nativeAction(d.action);
          break;
        case "help":
          if (nativePlatform) {
            openDialog("Dosewell help", "<p>Enter your medications and schedules, then enable Dosewell alarms in Reminders. Dosewell stores your plan on this device. Record doses in Today. Dismissing an alarm does not record a dose.</p><p>Names and doses may appear on the lock screen. Ask your pharmacist to review your full medication list for interactions.</p>");
            break;
          }
          openDialog("Help & privacy", "<h3>Use Dosewell from your home screen</h3><p>On iPhone, use Safari\u2019s Share menu and choose Add to Home Screen. On Android, look for Install app or Add to Home screen in the browser menu.</p><h3>Your medication list</h3><p>Enter each medicine and dose from your current prescription, or use Take photo in Add medication to fill the label fields. Check the suggested text before saving. The photo is processed on this device and discarded when the form closes. Choose daily times, an hourly interval, selected days, or list only. In Today, record a dose after taking it, log a skipped dose, or snooze its reminder. History keeps your recorded entries. For a list only medicine, use Log a dose on the Medications page.</p><h3>Where your plan is saved</h3><p>Medication entries and dose history, and refill counts stay in this browser on this device. Anyone with access to this browser profile can view them. Clearing browser data removes the plan.</p><h3>Reminder delivery</h3><p>Keep the page open and your device awake for in-page alarms. Test the sound in Reminders. For reminders with the site closed, choose Clock alarms in Reminders for the Android assistant or iPhone Shortcuts setup. Calendar reminders creates a separate calendar file. Confirm the alerts on your device. Medication names may appear on the lock screen if you enable notifications.</p><h3>Interaction warnings</h3><p>The checker covers selected pairs. Ask a pharmacist to review your complete list, especially before adding a new medicine or changing a dose.</p>");
          break;
      }
    } catch (err) {
      toast(err.message || "The change could not be saved.");
    }
  });
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close();
    }
  });
  render();
  if (location.hash === "#reminders/android-clock") phoneExport(read, openDialog, dialog, "android");
  scan();
  setInterval(scan, 3e3);
  var currentMinute = (/* @__PURE__ */ new Date()).getMinutes();
  setInterval(() => {
    const m = (/* @__PURE__ */ new Date()).getMinutes();
    if (m !== currentMinute) {
      currentMinute = m;
      if (view === "overview" && !dialog.open && (document.activeElement === main || !main.contains(document.activeElement))) render();
    }
  }, 5e3);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      render();
      scan();
    }
  });
  if (nativePlatform) {
    document.querySelector(".app-download-link").hidden = true;
    document.querySelector(".plan-move-link").hidden = true;
    document.addEventListener("change", async (event) => {
      if (event.target.id !== "native-import") return;
      try {
        await importNativeFile(event.target.files[0]);
        render();
        syncNative();
        toast("Plan imported. Check your alarms in Reminders.");
      } catch (error) {
        toast(error.message);
      }
    });
    window.refreshDosewellAlarms = syncNative;
    window.addEventListener("pageshow", syncNative);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) syncNative();
    });
    syncNative();
  }
})();
