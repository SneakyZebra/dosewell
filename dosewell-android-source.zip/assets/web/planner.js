(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key3 of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key3) && key3 !== except)
          __defProp(to, key3, { get: () => from[key3], enumerable: !(desc = __getOwnPropDesc(from, key3)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // dosewell-interactions/rxterms.js
  var products = [
    ["A+D DIAPER RASH (Topical)", false, ["dimethicone", "zinc oxide"]],
    ["A+D ORIGINAL (Topical)", false, ["lanolin", "petrolatum"]],
    ["A.E.R. WITCH HAZEL (Topical)", false, ["witch hazel"]],
    ["AAGYLUR (Oral Pill)", true, ["penicillamine"]],
    ["Abacavir (Oral Liquid)", true, ["abacavir"]],
    ["Abacavir (Oral Pill)", true, ["abacavir"]],
    ["Abacavir/Dolutegravir/lamiVUDine (Oral Pill)", true, ["abacavir", "dolutegravir", "lamivudine"]],
    ["Abacavir/Dolutegravir/lamiVUDine (Oral Suspension Tablet)", true, ["abacavir", "dolutegravir", "lamivudine"]],
    ["Abacavir/lamiVUDine (Oral Pill)", true, ["abacavir", "lamivudine"]],
    ["Abacavir/lamiVUDine/Zidovudine (Oral Pill)", true, ["abacavir", "lamivudine", "zidovudine"]],
    ["Abaloparatide (Injectable)", false, ["abaloparatide"]],
    ["Abatacept (Injectable)", false, ["abatacept"]],
    ["ABECMA (Injectable)", false, ["idecabtagene vicleucel"]],
    ["ABELCET (Injectable)", false, ["amphotericin B"]],
    ["Abemaciclib (Oral Pill)", true, ["abemaciclib"]],
    ["ABIGALE 1/0.5 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["ABIGALE LO 0.5/0.1 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["ABILIFY (Injectable)", false, ["aripiprazole"]],
    ["ABILIFY (Oral Pill)", true, ["aripiprazole"]],
    ["Abiraterone (Oral Pill)", true, ["abiraterone"]],
    ["Abiraterone/Niraparib (Oral Pill)", true, ["abiraterone", "niraparib"]],
    ["ABIRTEGA (Oral Pill)", true, ["abiraterone"]],
    ["ABRAXANE (Injectable)", false, ["paclitaxel"]],
    ["ABREVA (Topical)", false, ["docosanol"]],
    ["ABREVA RAPID PAIN RELIEF (Topical)", false, ["glycerin", "lidocaine"]],
    ["ABRILADA (Injectable)", false, ["adalimumab"]],
    ["Abrocitinib (Oral Pill)", true, ["abrocitinib"]],
    ["ABRYSVO (Injectable)", false, ["respiratory syncytial virus pre-fusion F protein"]],
    ["ABSORBINE JR. (Topical)", false, ["menthol"]],
    ["ABSORBINE JR. ANTIFUNGAL (Topical)", false, ["tolnaftate"]],
    ["ABSORICA (Oral Pill)", true, ["isotretinoin"]],
    ["ABSTRAL (Sublingual)", false, ["fentanyl"]],
    ["Acalabrutinib (Oral Pill)", true, ["acalabrutinib"]],
    ["ACAM2000 (Injectable)", false, ["smallpox vaccine live, New York City Board of Health vaccinia strain"]],
    ["Acamprosate (Oral Pill)", true, ["acamprosate"]],
    ["ACANYA (Topical)", false, ["benzoyl peroxide", "clindamycin"]],
    ["Acarbose (Oral Pill)", true, ["acarbose"]],
    ["ACCOLATE (Oral Pill)", true, ["zafirlukast"]],
    ["ACCRUFER (Oral Pill)", true, ["ferric maltol"]],
    ["ACCUPRIL (Oral Pill)", true, ["quinapril"]],
    ["ACCURETIC (Oral Pill)", true, ["hydrochlorothiazide", "quinapril"]],
    ["ACCUTANE (Oral Pill)", true, ["isotretinoin"]],
    ["Acebutolol (Oral Pill)", true, ["acebutolol"]],
    ["Aceclidine (Ophthalmic)", false, ["aceclidine"]],
    ["Acellular nerve allograft (Implant)", false, ["acellular nerve allograft"]],
    ["Acellular tissue engineered vessel (Implant)", false, ["acellular tissue engineered vessel"]],
    ["ACEON (Oral Pill)", true, ["perindopril"]],
    ["ACEPHEN (Rectal)", false, ["acetaminophen"]],
    ["ACETADOTE (Injectable)", false, ["acetylcysteine"]],
    ["ACETADRYL (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen (Chewable)", true, ["acetaminophen"]],
    ["Acetaminophen (Effervescent)", true, ["acetaminophen"]],
    ["Acetaminophen (Injectable)", false, ["acetaminophen"]],
    ["Acetaminophen (Oral Disintegrating)", true, ["acetaminophen"]],
    ["Acetaminophen (Oral Liquid)", true, ["acetaminophen"]],
    ["Acetaminophen (Oral Pill)", true, ["acetaminophen"]],
    ["Acetaminophen (Oral Powder)", true, ["acetaminophen"]],
    ["Acetaminophen (Rectal)", false, ["acetaminophen"]],
    ["Acetaminophen XR (Oral Pill)", true, ["acetaminophen"]],
    ["Acetaminophen/Aspirin (Oral Powder)", true, ["acetaminophen", "aspirin"]],
    ["Acetaminophen/Benzhydrocodone (Oral Pill)", true, ["acetaminophen", "benzhydrocodone"]],
    ["Acetaminophen/Butalbital (Oral Pill)", true, ["acetaminophen", "butalbital"]],
    ["Acetaminophen/Caffeine (Oral Disintegrating)", true, ["acetaminophen", "caffeine"]],
    ["Acetaminophen/Caffeine (Oral Liquid)", true, ["acetaminophen", "caffeine"]],
    ["Acetaminophen/Caffeine (Oral Pill)", true, ["acetaminophen", "caffeine"]],
    ["Acetaminophen/Chlorpheniramine (Oral Pill)", true, ["acetaminophen", "chlorpheniramine"]],
    ["Acetaminophen/Codeine (Oral Liquid)", true, ["acetaminophen", "codeine"]],
    ["Acetaminophen/Codeine (Oral Pill)", true, ["acetaminophen", "codeine"]],
    ["Acetaminophen/Dexbrompheniramine (Oral Liquid)", true, ["acetaminophen", "dexbrompheniramine"]],
    ["Acetaminophen/Dexbrompheniramine (Oral Pill)", true, ["acetaminophen", "dexbrompheniramine"]],
    ["Acetaminophen/Dextromethorphan (Chewable)", true, ["acetaminophen", "dextromethorphan"]],
    ["Acetaminophen/Dextromethorphan (Oral Liquid)", true, ["acetaminophen", "dextromethorphan"]],
    ["Acetaminophen/Dextromethorphan (Oral Pill)", true, ["acetaminophen", "dextromethorphan"]],
    ["Acetaminophen/Dextromethorphan (Oral Solution Granules)", true, ["acetaminophen", "dextromethorphan"]],
    ["Acetaminophen/Dextromethorphan (Oral Solution Powder)", true, ["acetaminophen", "dextromethorphan"]],
    ["Acetaminophen/diphenhydrAMINE (Chewable)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen/diphenhydrAMINE (Oral Liquid)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen/diphenhydrAMINE (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen/diphenhydrAMINE (Oral Powder)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen/diphenhydrAMINE (Oral Solution Granules)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen/diphenhydrAMINE (Oral Solution Powder)", true, ["acetaminophen", "diphenhydramine"]],
    ["Acetaminophen/guaiFENesin (Oral Pill)", true, ["acetaminophen", "guaifenesin"]],
    ["Acetaminophen/HYDROcodone (Oral Liquid)", true, ["acetaminophen", "hydrocodone"]],
    ["Acetaminophen/HYDROcodone (Oral Pill)", true, ["acetaminophen", "hydrocodone"]],
    ["Acetaminophen/Ibuprofen (Injectable)", false, ["acetaminophen", "ibuprofen"]],
    ["Acetaminophen/Ibuprofen (Oral Pill)", true, ["acetaminophen", "ibuprofen"]],
    ["Acetaminophen/Melatonin (Oral Pill)", true, ["acetaminophen", "melatonin"]],
    ["Acetaminophen/Naproxen (Oral Pill)", true, ["acetaminophen", "naproxen"]],
    ["Acetaminophen/oxyCODONE (Oral Liquid)", true, ["acetaminophen", "oxycodone"]],
    ["Acetaminophen/oxyCODONE (Oral Pill)", true, ["acetaminophen", "oxycodone"]],
    ["Acetaminophen/Phenylephrine (Effervescent)", true, ["acetaminophen", "phenylephrine"]],
    ["Acetaminophen/Phenylephrine (Oral Pill)", true, ["acetaminophen", "phenylephrine"]],
    ["Acetaminophen/Phenyltoloxamine (Oral Pill)", true, ["acetaminophen", "phenyltoloxamine"]],
    ["Acetaminophen/Pseudoephedrine (Oral Pill)", true, ["acetaminophen", "pseudoephedrine"]],
    ["Acetaminophen/Pyrilamine (Oral Pill)", true, ["acetaminophen", "pyrilamine"]],
    ["Acetaminophen/traMADol (Oral Pill)", true, ["acetaminophen", "tramadol"]],
    ["acetaZOLAMIDE (Injectable)", false, ["acetazolamide"]],
    ["acetaZOLAMIDE (Oral Pill)", true, ["acetazolamide"]],
    ["acetaZOLAMIDE XR (Oral Pill)", true, ["acetazolamide"]],
    ["Acetic acid (Irrigation)", false, ["acetic acid"]],
    ["Acetic acid (Otic)", false, ["acetic acid"]],
    ["Acetic acid (Vaginal)", false, ["acetic acid"]],
    ["Acetic acid/Hydrocortisone (Otic)", false, ["acetic acid", "hydrocortisone"]],
    ["Acetic acid/Oxyquinoline (Vaginal)", false, ["acetic acid", "oxyquinoline"]],
    ["Acetohydroxamic acid (Oral Pill)", true, ["acetohydroxamic acid"]],
    ["Acetylcarnitine (Oral Pill)", true, ["acetylcarnitine"]],
    ["Acetylcarnitine/Thioctate (Oral Pill)", true, ["acetylcarnitine", "thioctate"]],
    ["Acetylcholine (Ophthalmic)", false, ["acetylcholine"]],
    ["Acetylcysteine (Inhalant)", false, ["acetylcysteine"]],
    ["Acetylcysteine (Injectable)", false, ["acetylcysteine"]],
    ["Acetylcysteine (Oral Pill)", true, ["acetylcysteine"]],
    ["ACID GONE (Chewable)", true, ["aluminum hydroxide", "magnesium carbonate"]],
    ["ACID GONE (Oral Liquid)", true, ["aluminum hydroxide", "magnesium carbonate"]],
    ["ACIPHEX (Oral Granules)", true, ["rabeprazole"]],
    ["ACIPHEX (Oral Pill)", true, ["rabeprazole"]],
    ["Acitretin (Oral Pill)", true, ["acitretin"]],
    ["Aclidinium (Inhalant)", false, ["aclidinium"]],
    ["Aclidinium/Formoterol (Inhalant)", false, ["aclidinium", "formoterol"]],
    ["ACNE-CLEAR (Topical)", false, ["benzoyl peroxide"]],
    ["ACNEVIR (Soap)", false, ["salicylic acid"]],
    ["ACNOMEL (Topical)", false, ["resorcinol", "sulfur"]],
    ["Acoltremon (Ophthalmic)", false, ["acoltremon"]],
    ["Acoramidis (Oral Pill)", true, ["acoramidis"]],
    ["ACT FLUORIDE RINSE (Mouthwash)", false, ["sodium fluoride"]],
    ["ACTEMRA (Injectable)", false, ["tocilizumab"]],
    ["ACTHAR (Injectable)", false, ["corticotropin"]],
    ["ACTHIB (Injectable)", false, ["Haemophilus influenzae type b, capsular polysaccharide inactivated tetanus toxoid conjugate vaccine"]],
    ["ACTICIN (Topical)", false, ["permethrin"]],
    ["ACTICLATE (Oral Pill)", true, ["doxycycline"]],
    ["ACTIDOSE (Oral Liquid)", true, ["activated charcoal"]],
    ["ACTIMMUNE (Injectable)", false, ["interferon gamma-1b"]],
    ["ACTIQ (Oral Lozenge)", true, ["fentanyl"]],
    ["ACTIVASE (Injectable)", false, ["alteplase"]],
    ["Activated charcoal (Oral Liquid)", true, ["activated charcoal"]],
    ["Activated charcoal (Oral Pill)", true, ["activated charcoal"]],
    ["Activated charcoal (Oral Suspension Powder)", true, ["activated charcoal"]],
    ["Activated charcoal/Calcium carbonate (Oral Pill)", true, ["activated charcoal", "calcium carbonate"]],
    ["ACTIVE Q (Oral Liquid)", true, ["ubiquinol"]],
    ["ACTIVELLA 0.5/0.1 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["ACTIVELLA 1/0.5 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["ACTIVICE (Topical)", false, ["menthol"]],
    ["ACTIVON ARTHRITIS (Topical)", false, ["histamine", "menthol"]],
    ["ACTIVON JOINT & MUSCLE (Topical)", false, ["menthol"]],
    ["ACTONEL (Oral Pill)", true, ["risedronate"]],
    ["ACTONEL 35 12-WEEK (Pack)", true, ["risedronate"]],
    ["ACTONEL 35 4-WEEK (Pack)", true, ["risedronate"]],
    ["ACTOPLUS MET (Oral Pill)", true, ["metformin", "pioglitazone"]],
    ["ACTOS (Oral Pill)", true, ["pioglitazone"]],
    ["ACULAR (Ophthalmic)", false, ["ketorolac"]],
    ["ACUVAIL (Ophthalmic)", false, ["ketorolac"]],
    ["Acyclovir (Buccal)", false, ["acyclovir"]],
    ["Acyclovir (Injectable)", false, ["acyclovir"]],
    ["Acyclovir (Ophthalmic)", false, ["acyclovir"]],
    ["Acyclovir (Oral Liquid)", true, ["acyclovir"]],
    ["Acyclovir (Oral Pill)", true, ["acyclovir"]],
    ["Acyclovir (Topical)", false, ["acyclovir"]],
    ["Acyclovir/Hydrocortisone (Topical)", false, ["acyclovir", "hydrocortisone"]],
    ["ACZONE (Topical)", false, ["dapsone"]],
    ["ADACEL (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["Adagrasib (Oral Pill)", true, ["adagrasib"]],
    ["ADAKVEO (Injectable)", false, ["crizanlizumab"]],
    ["Adalimumab (Injectable)", false, ["adalimumab"]],
    ["Adalimumab (Pack)", false, ["adalimumab"]],
    ["ADAMTS13, recombinant (Injectable)", false, ["ADAMTS13, recombinant"]],
    ["Adapalene (Topical)", false, ["adapalene"]],
    ["Adapalene/Benzoyl peroxide (Topical)", false, ["adapalene", "benzoyl peroxide"]],
    ["Adapalene/Benzoyl peroxide/Clindamycin (Topical)", false, ["adapalene", "benzoyl peroxide", "clindamycin"]],
    ["ADASUVE (Inhalant)", false, ["loxapine"]],
    ["ADBRY (Injectable)", false, ["tralokinumab"]],
    ["ADCETRIS (Injectable)", false, ["brentuximab vedotin"]],
    ["ADCIRCA (Oral Pill)", true, ["tadalafil"]],
    ["ADDAPRIN (Oral Pill)", true, ["ibuprofen"]],
    ["ADDERALL (Oral Pill)", true, ["amphetamine", "dextroamphetamine"]],
    ["ADDERALL XR (Oral Pill)", true, ["amphetamine", "dextroamphetamine"]],
    ["ADDYI (Oral Pill)", true, ["flibanserin"]],
    ["Adefovir (Oral Pill)", true, ["adefovir"]],
    ["ADEMPAS (Oral Pill)", true, ["riociguat"]],
    ["ADENOCARD (Injectable)", false, ["adenosine"]],
    ["Adenosine (Injectable)", false, ["adenosine"]],
    ["Adenosine triphosphate (Oral Pill)", true, ["adenosine triphosphate"]],
    ["Adenovirus type 4 vaccine live (Oral Pill)", true, ["adenovirus type 4 vaccine live"]],
    ["Adenovirus type 4 vaccine live/Adenovirus type 7 vaccine live (Pack)", true, ["adenovirus type 4 vaccine live", "adenovirus type 7 vaccine live"]],
    ["Adenovirus type 7 vaccine live (Oral Pill)", true, ["adenovirus type 7 vaccine live"]],
    ["ADIPEX-P (Oral Pill)", true, ["phentermine"]],
    ["ADLARITY (Transdermal)", false, ["donepezil"]],
    ["ADMELOG (Injectable)", false, ["insulin lispro"]],
    ["ADOXA (Oral Pill)", true, ["doxycycline"]],
    ["ADQUEY (Topical)", false, ["difamilast"]],
    ["ADRENALIN (Injectable)", false, ["epinephrine"]],
    ["ADRIAMYCIN (Injectable)", false, ["doxorubicin"]],
    ["ADRUCIL (Injectable)", false, ["fluorouracil"]],
    ["ADSTILADRIN (Intravesical)", false, ["nadofaragene firadenovec"]],
    ["ADTHYZA (Oral Pill)", true, ["thyroid (USP)"]],
    ["Aducanumab (Injectable)", false, ["aducanumab"]],
    ["ADUHELM (Injectable)", false, ["aducanumab"]],
    ["ADVAIR (Inhalant)", false, ["fluticasone", "salmeterol"]],
    ["ADVATE (Injectable)", false, ["factor VIII"]],
    ["ADVIL (Chewable)", true, ["ibuprofen"]],
    ["ADVIL (Oral Liquid)", true, ["ibuprofen"]],
    ["ADVIL (Oral Pill)", true, ["ibuprofen"]],
    ["ADYNOVATE (Injectable)", false, ["factor VIII"]],
    ["ADZENYS XR (Oral Pill)", true, ["amphetamine"]],
    ["ADZYNMA (Injectable)", false, ["ADAMTS13, recombinant"]],
    ["AEMCOLO (Oral Pill)", true, ["rifamycin SV"]],
    ["Afamelanotide (Implant)", false, ["afamelanotide"]],
    ["Afamitresgene autoleucel (Injectable)", false, ["afamitresgene autoleucel"]],
    ["Afatinib (Oral Pill)", true, ["afatinib"]],
    ["Aficamten (Oral Pill)", true, ["aficamten"]],
    ["AFINITOR (Oral Pill)", true, ["everolimus"]],
    ["AFINITOR (Oral Suspension Tablet)", true, ["everolimus"]],
    ["AFIRMELLE 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Aflibercept (Injectable)", false, ["aflibercept"]],
    ["AFLURIA 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["AFREZZA (Inhalant)", false, ["insulin, regular, human"]],
    ["AFREZZA 180 - 90 (8 UNT), 90 (12 UNT) (Pack)", false, ["insulin, regular, human"]],
    ["AFREZZA 180 TITRATION PACK- 60 (4 UNT), 60 (8 UNT), 60 (12 UNT) (Pack)", false, ["insulin, regular, human"]],
    ["AFREZZA SAMPLE PACK - 15 (4 UNT), 15 (8 UNT) (Pack)", false, ["insulin, regular, human"]],
    ["AFREZZA TITRATION PACK (Pack)", false, ["insulin, regular, human"]],
    ["AFRIN (Nasal)", false, ["oxymetazoline"]],
    ["AFSTYLA (Injectable)", false, ["factor VIII"]],
    ["AFTERA (Oral Pill)", true, ["levonorgestrel"]],
    ["AFTERPILL (Oral Pill)", true, ["levonorgestrel"]],
    ["Agalsidase beta (Injectable)", false, ["agalsidase beta"]],
    ["AGAMREE (Oral Liquid)", true, ["vamorolone"]],
    ["AGGRASTAT (Injectable)", false, ["tirofiban"]],
    ["AGRYLIN (Oral Pill)", true, ["anagrelide"]],
    ["AHIST ANTIHISTAMINE (Oral Pill)", true, ["chlorcyclizine"]],
    ["AHZANTIVE (Injectable)", false, ["aflibercept"]],
    ["AIMOVIG (Injectable)", false, ["erenumab"]],
    ["AIMOVIG AUTOINJECTOR (140 MG DOSE) (Pack)", false, ["erenumab"]],
    ["AIRDUO (Inhalant)", false, ["fluticasone", "salmeterol"]],
    ["AIRSUPRA (Inhalant)", false, ["albuterol", "budesonide"]],
    ["AJOVY (Injectable)", false, ["fremanezumab"]],
    ["AKEEGA (Oral Pill)", true, ["abiraterone", "niraparib"]],
    ["Akkermansia muciniphila/Inulin (Oral Pill)", true, ["Akkermansia muciniphila", "inulin"]],
    ["AKLIEF (Topical)", false, ["trifarotene"]],
    ["AKOVAZ (Injectable)", false, ["ephedrine"]],
    ["AKTEN (Ophthalmic)", false, ["lidocaine"]],
    ["AKYNZEO (Injectable)", false, ["netupitant", "palonosetron"]],
    ["AKYNZEO (Oral Pill)", true, ["netupitant", "palonosetron"]],
    ["ALA SEB T (Shampoo)", false, ["coal tar", "salicylic acid", "sulfur"]],
    ["ALA-CORT (Topical)", false, ["hydrocortisone"]],
    ["ALA-HIST IR (Oral Pill)", true, ["dexbrompheniramine"]],
    ["ALA-SCALP (Topical)", false, ["hydrocortisone"]],
    ["ALAHIST D (Oral Pill)", true, ["pheniramine", "phenylephrine"]],
    ["Alanine/Glutamate/Glycine (Oral Pill)", true, ["alanine", "glutamate", "glycine"]],
    ["ALAVERT (Oral Disintegrating)", true, ["loratadine"]],
    ["ALAVERT (Oral Pill)", true, ["loratadine"]],
    ["ALAVERT D XR (Oral Pill)", true, ["loratadine", "pseudoephedrine"]],
    ["ALAWAY (Ophthalmic)", false, ["ketotifen"]],
    ["Albendazole (Oral Pill)", true, ["albendazole"]],
    ["ALBENZA (Oral Pill)", true, ["albendazole"]],
    ["ALBUKED (Injectable)", false, ["albumin human, USP"]],
    ["Albumin human, USP (Injectable)", false, ["albumin human, USP"]],
    ["Albumin human, USP/DOCEtaxel (Pack)", false, ["albumin human, USP", "docetaxel"]],
    ["ALBUMINEX (Injectable)", false, ["albumin human, USP"]],
    ["ALBURX (Injectable)", false, ["albumin human, USP"]],
    ["ALBUTEIN (Injectable)", false, ["albumin human, USP"]],
    ["Albuterol (Inhalant)", false, ["albuterol"]],
    ["Albuterol (Oral Liquid)", true, ["albuterol"]],
    ["Albuterol (Oral Pill)", true, ["albuterol"]],
    ["Albuterol/Budesonide (Inhalant)", false, ["albuterol", "budesonide"]],
    ["Albuterol/Ipratropium (Inhalant)", false, ["albuterol", "ipratropium"]],
    ["Alcaftadine (Ophthalmic)", false, ["alcaftadine"]],
    ["ALCAINE (Ophthalmic)", false, ["proparacaine"]],
    ["Alclometasone (Topical)", false, ["alclometasone"]],
    ["ALCORTIN (Topical)", false, ["hydrocortisone", "iodoquinol"]],
    ["ALCORTIN A (Topical)", false, ["aloe polysaccharide", "hydrocortisone", "iodoquinol"]],
    ["ALDACTONE (Oral Pill)", true, ["spironolactone"]],
    ["Aldesleukin (Injectable)", false, ["aldesleukin"]],
    ["ALDEX AN (Chewable)", true, ["doxylamine"]],
    ["Aldioxa/Chloroxylenol (Topical)", false, ["aldioxa", "chloroxylenol"]],
    ["ALDURAZYME (Injectable)", false, ["laronidase"]],
    ["ALECENSA (Oral Pill)", true, ["alectinib"]],
    ["Alectinib (Oral Pill)", true, ["alectinib"]],
    ["Alemtuzumab (Injectable)", false, ["alemtuzumab"]],
    ["Alendronate (Effervescent)", true, ["alendronate"]],
    ["Alendronate (Oral Liquid)", true, ["alendronate"]],
    ["Alendronate (Oral Pill)", true, ["alendronate"]],
    ["Alendronate/Cholecalciferol (Oral Pill)", true, ["alendronate", "cholecalciferol"]],
    ["ALEVAZOL (Topical)", false, ["clotrimazole"]],
    ["ALEVE (Oral Pill)", true, ["naproxen"]],
    ["ALEVE ARTHRITIS PAIN (Topical)", false, ["diclofenac"]],
    ["ALEVE PM (Oral Pill)", true, ["diphenhydramine", "naproxen"]],
    ["ALfentanil (Injectable)", false, ["alfentanil"]],
    ["ALFERON N (Injectable)", false, ["interferon alfa-n3"]],
    ["Alfuzosin XR (Oral Pill)", true, ["alfuzosin"]],
    ["Alglucosidase alfa (Injectable)", false, ["alglucosidase alfa"]],
    ["ALHEMO (Injectable)", false, ["concizumab"]],
    ["ALIGN (Oral Pill)", true, ["Bifidobacterium infantis"]],
    ["ALIMTA (Injectable)", false, ["pemetrexed"]],
    ["ALINIA (Oral Liquid)", true, ["nitazoxanide"]],
    ["ALINIA (Oral Pill)", true, ["nitazoxanide"]],
    ["ALIQOPA (Injectable)", false, ["copanlisib"]],
    ["Alirocumab (Injectable)", false, ["alirocumab"]],
    ["Aliskiren (Oral Pill)", true, ["aliskiren"]],
    ["Aliskiren/hydroCHLOROthiazide (Oral Pill)", true, ["aliskiren", "hydrochlorothiazide"]],
    ["Alitretinoin (Topical)", false, ["alitretinoin"]],
    ["ALKA-MINTS (Chewable)", true, ["calcium carbonate"]],
    ["ALKA-SELTZER (Effervescent)", true, ["aspirin", "citric acid", "sodium bicarbonate"]],
    ["ALKERAN (Injectable)", false, ["melphalan"]],
    ["ALKERAN (Oral Pill)", true, ["melphalan"]],
    ["ALKINDI (Oral Granules)", true, ["hydrocortisone"]],
    ["ALKUMS (Chewable)", true, ["calcium carbonate"]],
    ["Allantoin (Topical)", false, ["allantoin"]],
    ["Allantoin/Camphor/Menthol (Nasal)", false, ["allantoin", "camphor", "menthol"]],
    ["Allantoin/Camphor/Menthol/Phenol (Topical)", false, ["allantoin", "camphor", "menthol", "phenol"]],
    ["Allantoin/Dimethicone (Topical)", false, ["allantoin", "dimethicone"]],
    ["Allantoin/diphenhydrAMINE (Topical)", false, ["allantoin", "diphenhydramine"]],
    ["Allantoin/Lidocaine/Petrolatum (Topical)", false, ["allantoin", "lidocaine", "petrolatum"]],
    ["Allantoin/Petrolatum (Topical)", false, ["allantoin", "petrolatum"]],
    ["ALLDAY (Toothpaste)", false, ["sodium fluoride"]],
    ["ALLEGRA (Oral Disintegrating)", true, ["fexofenadine"]],
    ["ALLEGRA (Oral Liquid)", true, ["fexofenadine"]],
    ["ALLEGRA (Oral Pill)", true, ["fexofenadine"]],
    ["ALLEGRA-D XR (Oral Pill)", true, ["fexofenadine", "pseudoephedrine"]],
    ["ALLER-CHLOR (Oral Pill)", true, ["chlorpheniramine"]],
    ["ALLER-CORT (Nasal)", false, ["triamcinolone"]],
    ["ALLER-FLO (Nasal)", false, ["fluticasone"]],
    ["ALLER-TEC (Oral Liquid)", true, ["cetirizine"]],
    ["ALLER-TEC (Oral Pill)", true, ["cetirizine"]],
    ["ALLER-TEC D XR (Oral Pill)", true, ["cetirizine", "pseudoephedrine"]],
    ["ALLERCLEAR XR (Oral Pill)", true, ["loratadine", "pseudoephedrine"]],
    ["ALLEREST 12 HOUR NASAL SPRAY (Nasal)", false, ["oxymetazoline"]],
    ["ALLERNAZE (Nasal)", false, ["triamcinolone"]],
    ["ALLFEN JR (Oral Pill)", true, ["guaifenesin"]],
    ["ALLI (Oral Pill)", true, ["orlistat"]],
    ["Allogeneic cultured keratinocytes and dermal fibroblasts in murine collagen (Topical)", false, ["allogeneic cultured keratinocytes and dermal fibroblasts in murine collagen"]],
    ["Allogeneic processed thymus tissue (Implant)", false, ["allogeneic processed thymus tissue"]],
    ["Allogeneic regulatory T cell immunotherapy with HSPC and T cells (Injectable)", false, ["allogeneic regulatory T cell immunotherapy with HSPC and T cells"]],
    ["Allopurinol (Injectable)", false, ["allopurinol"]],
    ["Allopurinol (Oral Pill)", true, ["allopurinol"]],
    ["Allopurinol/Lesinurad (Oral Pill)", true, ["allopurinol", "lesinurad"]],
    ["ALLZITAL (Oral Pill)", true, ["acetaminophen", "butalbital"]],
    ["ALMACONE (Oral Liquid)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["Almotriptan (Oral Pill)", true, ["almotriptan"]],
    ["ALOCANE (Topical)", false, ["lidocaine"]],
    ["ALOCANE MAX STRENGTH (Topical)", false, ["benzalkonium", "lidocaine"]],
    ["ALOCANE PLUS (Topical)", false, ["benzalkonium", "lidocaine"]],
    ["ALOCRIL (Ophthalmic)", false, ["nedocromil"]],
    ["ALODOX (Oral Pill)", true, ["doxycycline"]],
    ["Aloe polysaccharide/Iodoquinol (Topical)", false, ["aloe polysaccharide", "iodoquinol"]],
    ["ALOE VESTA ANTIFUNGAL (Topical)", false, ["miconazole"]],
    ["ALOE VESTA PROTECTIVE BARRIER (Topical)", false, ["petrolatum"]],
    ["Alogliptin (Oral Pill)", true, ["alogliptin"]],
    ["Alogliptin/metFORMIN (Oral Pill)", true, ["alogliptin", "metformin"]],
    ["Alogliptin/Pioglitazone (Oral Pill)", true, ["alogliptin", "pioglitazone"]],
    ["ALOMIDE (Ophthalmic)", false, ["lodoxamide"]],
    ["ALOPHEN REFORMULATED JAN 2008 (Oral Pill)", true, ["bisacodyl"]],
    ["ALOPRIM (Injectable)", false, ["allopurinol"]],
    ["ALORA (Transdermal)", false, ["estradiol"]],
    ["Alosetron (Oral Pill)", true, ["alosetron"]],
    ["Alpelisib (Oral Granules)", true, ["alpelisib"]],
    ["Alpelisib (Oral Pill)", true, ["alpelisib"]],
    ["Alpelisib (Pack)", false, ["alpelisib"]],
    ["Alpha 1-antitrypsin (Injectable)", false, ["alpha 1-antitrypsin"]],
    ["Alpha hydroxy acids/Urea (Topical)", false, ["alpha hydroxy acids", "urea"]],
    ["Alpha tocopherol/Cholecalciferol (Oral Pill)", true, ["alpha tocopherol", "cholecalciferol"]],
    ["Alpha-D-galactosidase enzyme (Chewable)", true, ["alpha-D-galactosidase enzyme"]],
    ["Alpha-D-galactosidase enzyme (Oral Disintegrating)", true, ["alpha-D-galactosidase enzyme"]],
    ["Alpha-D-galactosidase enzyme (Oral Pill)", true, ["alpha-D-galactosidase enzyme"]],
    ["ALPHAGAN (Ophthalmic)", false, ["brimonidine"]],
    ["ALPHANATE (Injectable)", false, ["factor VIII", "von Willebrand factor"]],
    ["ALPHANINE SD (Injectable)", false, ["factor IX"]],
    ["ALPRAZolam (Oral Disintegrating)", true, ["alprazolam"]],
    ["ALPRAZolam (Oral Liquid)", true, ["alprazolam"]],
    ["ALPRAZolam (Oral Pill)", true, ["alprazolam"]],
    ["ALPRAZolam XR (Oral Pill)", true, ["alprazolam"]],
    ["ALPROLIX (Injectable)", false, ["coagulation factor IX recombinant immunoglobulin G1 fusion protein"]],
    ["Alprostadil (Injectable)", false, ["alprostadil"]],
    ["Alprostadil (Urethral)", false, ["alprostadil"]],
    ["ALREX (Ophthalmic)", false, ["loteprednol etabonate"]],
    ["ALTABAX (Topical)", false, ["retapamulin"]],
    ["ALTACAINE (Ophthalmic)", false, ["tetracaine"]],
    ["ALTACE (Oral Pill)", true, ["ramipril"]],
    ["ALTAFLUOR (Ophthalmic)", false, ["benoxinate", "fluorescein"]],
    ["ALTALUBE (Ophthalmic)", false, ["mineral oil", "petrolatum"]],
    ["ALTAMIST (Nasal)", false, ["sodium chloride"]],
    ["ALTAVERA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["ALTAZINE (Ophthalmic)", false, ["tetrahydrozoline"]],
    ["Alteplase (Injectable)", false, ["alteplase"]],
    ["ALTOPREV XR (Oral Pill)", true, ["lovastatin"]],
    ["ALTRENO (Topical)", false, ["tretinoin"]],
    ["ALTUVIIIO (Injectable)", false, ["antihemophilic factor (recombinant), Fc-VWF-XTEN fusion protein"]],
    ["Aluminum acetate (Topical)", false, ["aluminum acetate"]],
    ["Aluminum chloride (Mucosal)", false, ["aluminum chloride"]],
    ["Aluminum chloride (Topical)", false, ["aluminum chloride"]],
    ["Aluminum hydroxide (Oral Liquid)", true, ["aluminum hydroxide"]],
    ["Aluminum hydroxide (Topical)", false, ["aluminum hydroxide"]],
    ["Aluminum hydroxide/Magnesium carbonate (Chewable)", true, ["aluminum hydroxide", "magnesium carbonate"]],
    ["Aluminum hydroxide/Magnesium carbonate (Oral Liquid)", true, ["aluminum hydroxide", "magnesium carbonate"]],
    ["Aluminum hydroxide/Magnesium hydroxide (Oral Liquid)", true, ["aluminum hydroxide", "magnesium hydroxide"]],
    ["Aluminum hydroxide/Magnesium trisilicate (Chewable)", true, ["aluminum hydroxide", "magnesium trisilicate"]],
    ["Aluminum sulfate/Calcium acetate (Topical)", false, ["aluminum sulfate", "calcium acetate"]],
    ["ALUNBRIG (Oral Pill)", true, ["brigatinib"]],
    ["ALUNBRIG INITIATION PACK (Pack)", true, ["brigatinib"]],
    ["ALUVEA (Topical)", false, ["urea"]],
    ["ALVAIZ (Oral Pill)", true, ["eltrombopag"]],
    ["ALVESCO (Inhalant)", false, ["ciclesonide"]],
    ["Alvimopan (Oral Pill)", true, ["alvimopan"]],
    ["ALYACEN 1/35 (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["ALYACEN 7/7/7 (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["ALYFTREK (Oral Pill)", true, ["deutivacaftor", "tezacaftor", "vanzacaftor"]],
    ["ALYGLO (Injectable)", false, ["immunoglobulin G"]],
    ["ALYMSYS (Injectable)", false, ["bevacizumab"]],
    ["ALYQ (Oral Pill)", true, ["tadalafil"]],
    ["AMABELZ 0.5/0.1 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["AMABELZ 1/0.5 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["Amantadine (Oral Liquid)", true, ["amantadine"]],
    ["Amantadine (Oral Pill)", true, ["amantadine"]],
    ["Amantadine (Pack)", true, ["amantadine"]],
    ["Amantadine XR (Oral Pill)", true, ["amantadine"]],
    ["AMBIEN (Oral Pill)", true, ["zolpidem"]],
    ["AMBIEN XR (Oral Pill)", true, ["zolpidem"]],
    ["AMBISOME (Injectable)", false, ["amphotericin B"]],
    ["Ambrisentan (Oral Pill)", true, ["ambrisentan"]],
    ["Amcinonide (Topical)", false, ["amcinonide"]],
    ["Amdinocillin pivoxil (Oral Pill)", true, ["amdinocillin pivoxil"]],
    ["AMELUZ (Topical)", false, ["aminolevulinic acid"]],
    ["AMERICAINE (Topical)", false, ["benzocaine"]],
    ["AMERICAINE HEMORRHOIDAL (Topical)", false, ["benzocaine"]],
    ["American house dust mite allergenic extract/European house dust mite allergenic extract (Sublingual)", false, ["American house dust mite allergenic extract", "European house dust mite allergenic extract"]],
    ["AMERITHROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["AMETHIA 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["AMETHYST 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["AMICAR (Oral Liquid)", true, ["6-aminocaproic acid"]],
    ["AMICAR (Oral Pill)", true, ["6-aminocaproic acid"]],
    ["AMIDATE (Injectable)", false, ["etomidate"]],
    ["Amifampridine (Oral Pill)", true, ["amifampridine"]],
    ["Amifostine (Injectable)", false, ["amifostine"]],
    ["Amikacin (Inhalant)", false, ["amikacin"]],
    ["Amikacin (Injectable)", false, ["amikacin"]],
    ["aMILoride (Oral Pill)", true, ["amiloride"]],
    ["aMILoride/hydroCHLOROthiazide (Oral Pill)", true, ["amiloride", "hydrochlorothiazide"]],
    ["aminobenzoate (Oral Pill)", true, ["4-aminobenzoate"]],
    ["aminobenzoic acid (Oral Pill)", true, ["4-aminobenzoic acid"]],
    ["aminocaproic acid (Injectable)", false, ["6-aminocaproic acid"]],
    ["aminocaproic acid (Oral Liquid)", true, ["6-aminocaproic acid"]],
    ["aminocaproic acid (Oral Pill)", true, ["6-aminocaproic acid"]],
    ["Aminolevulinate (Topical)", false, ["aminolevulinate"]],
    ["Aminolevulinic acid (Topical)", false, ["aminolevulinic acid"]],
    ["Aminophylline (Injectable)", false, ["aminophylline"]],
    ["Aminosalicylic acid (Oral Granules)", true, ["aminosalicylic acid"]],
    ["AMINOSYN 10%, SULFITE-FREE (Injectable)", false, ["alanine", "arginine", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN 3.5 % M, SULFITE FREE (Injectable)", false, ["alanine", "arginine", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium acetate", "methionine", "phenylalanine", "phosphoric acid", "potassium acetate", "proline", "serine", "sodium chloride", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN 8.5 % WITH ELECTROLYTES, SULFITE-FREE (Injectable)", false, ["alanine", "arginine", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "potassium chloride", "proline", "serine", "sodium chloride", "sodium phosphate", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN 8.5%, SULFITE-FREE (Injectable)", false, ["alanine", "arginine", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN II 10 % (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN II 15% (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN II 8.5 % WITH ELECTROLYTES, SULFITE-FREE (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "potassium chloride", "proline", "serine", "sodium chloride", "sodium phosphate, dibasic", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN II 8.5 %, SULFITE-FREE (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN-PF 10 %, SULFITE-FREE (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "taurine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["AMINOSYN-PF 7% (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "taurine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["Amiodarone (Injectable)", false, ["amiodarone"]],
    ["Amiodarone (Oral Pill)", true, ["amiodarone"]],
    ["Amisulpride (Injectable)", false, ["amisulpride"]],
    ["AMITIZA (Oral Pill)", true, ["lubiprostone"]],
    ["Amitriptyline (Oral Pill)", true, ["amitriptyline"]],
    ["Amitriptyline/chlordiazePOXIDE (Oral Pill)", true, ["amitriptyline", "chlordiazepoxide"]],
    ["Amitriptyline/Perphenazine (Oral Pill)", true, ["amitriptyline", "perphenazine"]],
    ["Amivantamab (Injectable)", false, ["amivantamab"]],
    ["Amivantamab/Hyaluronidase (Injectable)", false, ["amivantamab", "hyaluronidase"]],
    ["AMJEVITA (Injectable)", false, ["adalimumab"]],
    ["AMLACTIN (Topical)", false, ["lactate"]],
    ["Amlexanox (Oral Paste)", true, ["amlexanox"]],
    ["amLODIPine (Oral Liquid)", true, ["amlodipine"]],
    ["amLODIPine (Oral Pill)", true, ["amlodipine"]],
    ["amLODIPine (Oral Solution Powder)", true, ["amlodipine"]],
    ["amLODIPine/Atorvastatin (Oral Pill)", true, ["amlodipine", "atorvastatin"]],
    ["amLODIPine/Benazepril (Oral Pill)", true, ["amlodipine", "benazepril"]],
    ["amLODIPine/Celecoxib (Oral Pill)", true, ["amlodipine", "celecoxib"]],
    ["amLODIPine/hydroCHLOROthiazide/Olmesartan (Oral Pill)", true, ["amlodipine", "hydrochlorothiazide", "olmesartan"]],
    ["amLODIPine/hydroCHLOROthiazide/Valsartan (Oral Pill)", true, ["amlodipine", "hydrochlorothiazide", "valsartan"]],
    ["amLODIPine/Indapamide/Telmisartan (Oral Pill)", true, ["amlodipine", "indapamide", "telmisartan"]],
    ["amLODIPine/Olmesartan (Oral Pill)", true, ["amlodipine", "olmesartan"]],
    ["amLODIPine/Perindopril (Oral Pill)", true, ["amlodipine", "perindopril"]],
    ["amLODIPine/Telmisartan (Oral Pill)", true, ["amlodipine", "telmisartan"]],
    ["amLODIPine/Valsartan (Oral Pill)", true, ["amlodipine", "valsartan"]],
    ["Ammonia (Nasal)", false, ["ammonia"]],
    ["Ammonia (Topical)", false, ["ammonia"]],
    ["AMMONUL (Injectable)", false, ["benzoate", "phenylacetate"]],
    ["AMNESTEEM (Oral Pill)", true, ["isotretinoin"]],
    ["Amobarbital (Injectable)", false, ["amobarbital"]],
    ["AMONDYS 45 (Injectable)", false, ["casimersen"]],
    ["Amoxapine (Oral Pill)", true, ["amoxapine"]],
    ["Amoxicillin (Chewable)", true, ["amoxicillin"]],
    ["Amoxicillin (Oral Liquid)", true, ["amoxicillin"]],
    ["Amoxicillin (Oral Pill)", true, ["amoxicillin"]],
    ["Amoxicillin XR (Oral Pill)", true, ["amoxicillin"]],
    ["Amoxicillin/Clarithromycin/Lansoprazole (Pack)", true, ["amoxicillin", "clarithromycin", "lansoprazole"]],
    ["Amoxicillin/Clarithromycin/Omeprazole (Pack)", true, ["amoxicillin", "clarithromycin", "omeprazole"]],
    ["Amoxicillin/Clarithromycin/Vonoprazan (Pack)", true, ["amoxicillin", "clarithromycin", "vonoprazan"]],
    ["Amoxicillin/Clavulanate (Chewable)", true, ["amoxicillin", "clavulanate"]],
    ["Amoxicillin/Clavulanate (Oral Liquid)", true, ["amoxicillin", "clavulanate"]],
    ["Amoxicillin/Clavulanate (Oral Pill)", true, ["amoxicillin", "clavulanate"]],
    ["Amoxicillin/Clavulanate XR (Oral Pill)", true, ["amoxicillin", "clavulanate"]],
    ["Amoxicillin/Omeprazole/Rifabutin (Oral Pill)", true, ["amoxicillin", "omeprazole", "rifabutin"]],
    ["Amoxicillin/Vonoprazan (Pack)", true, ["amoxicillin", "vonoprazan"]],
    ["AMPHADASE (Injectable)", false, ["hyaluronidase"]],
    ["Amphetamine (Oral Disintegrating)", true, ["amphetamine"]],
    ["Amphetamine (Oral Pill)", true, ["amphetamine"]],
    ["Amphetamine XR (Oral Liquid)", true, ["amphetamine"]],
    ["Amphetamine XR (Oral Pill)", true, ["amphetamine"]],
    ["Amphetamine/Dextroamphetamine (Oral Pill)", true, ["amphetamine", "dextroamphetamine"]],
    ["Amphetamine/Dextroamphetamine XR (Oral Pill)", true, ["amphetamine", "dextroamphetamine"]],
    ["Amphotericin B (Injectable)", false, ["amphotericin B"]],
    ["Ampicillin (Injectable)", false, ["ampicillin"]],
    ["Ampicillin (Oral Pill)", true, ["ampicillin"]],
    ["Ampicillin/Sulbactam (Injectable)", false, ["ampicillin", "sulbactam"]],
    ["AMPYRA XR (Oral Pill)", true, ["dalfampridine"]],
    ["AMRIX XR (Oral Pill)", true, ["cyclobenzaprine"]],
    ["AMTAGVI (Injectable)", false, ["lifileucel"]],
    ["AMVISC (Injectable)", false, ["hyaluronate"]],
    ["AMVUTTRA (Injectable)", false, ["vutrisiran"]],
    ["Amyl nitrite (Nasal)", false, ["amyl nitrite"]],
    ["Amylase/Bacillus coagulans/Lipase/Protease (Oral Pill)", true, ["Bacillus coagulans", "amylase", "lipase", "protease"]],
    ["Amylase/Lipase/Protease (Oral Pill)", true, ["amylase", "lipase", "protease"]],
    ["Amylase/Papain (Chewable)", true, ["amylase", "papain"]],
    ["AMYTAL (Injectable)", false, ["amobarbital"]],
    ["AMZEEQ (Topical)", false, ["minocycline"]],
    ["ANA-LEX (Rectal)", false, ["hydrocortisone", "lidocaine"]],
    ["ANABAR (Oral Pill)", true, ["acetaminophen", "phenyltoloxamine", "salicylamide"]],
    ["ANACAINE (Topical)", false, ["benzocaine"]],
    ["Anacaulase (Topical)", false, ["anacaulase"]],
    ["ANACIN (Oral Pill)", true, ["aspirin", "caffeine"]],
    ["ANACIN ADVANCED HEADACHE FORMULA (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine"]],
    ["ANACIN AF (Oral Pill)", true, ["acetaminophen"]],
    ["ANAFRANIL (Oral Pill)", true, ["clomipramine"]],
    ["Anagrelide (Oral Pill)", true, ["anagrelide"]],
    ["Anakinra (Injectable)", false, ["anakinra"]],
    ["ANALPRAM HC (Rectal)", false, ["hydrocortisone", "pramoxine"]],
    ["ANALPRAM HC (Topical)", false, ["hydrocortisone", "pramoxine"]],
    ["ANAPROX (Oral Pill)", true, ["naproxen"]],
    ["ANASCORP (Injectable)", false, ["Centruroides (scorpion) immune F(ab')2 (equine)"]],
    ["ANASEPT (Irrigation)", false, ["hypochlorite"]],
    ["ANASEPT (Topical)", false, ["hypochlorite"]],
    ["ANASPAZ (Oral Disintegrating)", true, ["hyoscyamine"]],
    ["Anastrozole (Oral Pill)", true, ["anastrozole"]],
    ["ANAVIP (Injectable)", false, ["Crotalidae immune F(ab')2"]],
    ["ANBESOL (Mucosal)", false, ["benzocaine"]],
    ["ANBESOL (Oral Gel)", true, ["benzocaine"]],
    ["ANBESOL COLD SORE THERAPY (Topical)", false, ["allantoin", "benzocaine", "camphor", "petrolatum"]],
    ["ANCOBON (Oral Pill)", true, ["flucytosine"]],
    ["ANDEMBRY (Injectable)", false, ["garadacimab"]],
    ["Andexanet alfa (Injectable)", false, ["andexanet alfa"]],
    ["ANDEXXA (Injectable)", false, ["andexanet alfa"]],
    ["ANDROGEL (Topical)", false, ["testosterone"]],
    ["ANECREAM (Rectal)", false, ["lidocaine"]],
    ["ANECREAM (Topical)", false, ["lidocaine"]],
    ["ANECTINE (Injectable)", false, ["succinylcholine"]],
    ["ANGELIQ 0.25/0.5 28 DAY (Pack)", true, ["drospirenone", "estradiol"]],
    ["ANGELIQ 0.5/1 28 DAY (Pack)", true, ["drospirenone", "estradiol"]],
    ["ANGIOMAX (Injectable)", false, ["bivalirudin"]],
    ["Angiotensin II (Injectable)", false, ["angiotensin II"]],
    ["Anidulafungin (Injectable)", false, ["anidulafungin"]],
    ["Anifrolumab (Injectable)", false, ["anifrolumab"]],
    ["ANIMI-3 WITH VITAMIN D (Oral Pill)", true, ["cholecalciferol", "folic acid", "omega-3 acid ethyl esters (USP)", "phytosterols", "pyridoxine", "vitamin B12"]],
    ["ANJESO (Injectable)", false, ["meloxicam"]],
    ["ANKTIVA (Intravesical)", false, ["nogapendekin alfa inbakicept"]],
    ["ANNOVERA (Vaginal)", false, ["ethinyl estradiol", "segesterone"]],
    ["ANORO (Inhalant)", false, ["umeclidinium", "vilanterol"]],
    ["ANSAID (Oral Pill)", true, ["flurbiprofen"]],
    ["Ansuvimab (Injectable)", false, ["ansuvimab"]],
    ["ANTABUSE (Oral Pill)", true, ["disulfiram"]],
    ["ANTARA (Oral Pill)", true, ["fenofibrate"]],
    ["ANTHIM (Injectable)", false, ["obiltoxaximab"]],
    ["Anthralin (Shampoo)", false, ["anthralin"]],
    ["Anthralin (Topical)", false, ["anthralin"]],
    ["ANTHRASIL (Injectable)", false, ["anthrax immune globulin"]],
    ["Anthrax immune globulin (Injectable)", false, ["anthrax immune globulin"]],
    ["Anti-inhibitor coagulant complex (Injectable)", false, ["anti-inhibitor coagulant complex"]],
    ["ANTICHOLIUM (Injectable)", false, ["physostigmine"]],
    ["Antihemophilic factor (recombinant), Fc-VWF-XTEN fusion protein (Injectable)", false, ["antihemophilic factor (recombinant), Fc-VWF-XTEN fusion protein"]],
    ["Antithrombin III (Injectable)", false, ["antithrombin III"]],
    ["ANTIVERT (Chewable)", true, ["meclizine"]],
    ["ANTIVERT (Oral Pill)", true, ["meclizine"]],
    ["ANUCORT-HC (Rectal)", false, ["hydrocortisone"]],
    ["ANUSOL HC (Rectal)", false, ["hydrocortisone"]],
    ["ANUSOL HC (Topical)", false, ["hydrocortisone"]],
    ["ANZEMET (Oral Pill)", true, ["dolasetron"]],
    ["ANZUPGO (Topical)", false, ["delgocitinib"]],
    ["APADAZ (Oral Pill)", true, ["acetaminophen", "benzhydrocodone"]],
    ["Apalutamide (Oral Pill)", true, ["apalutamide"]],
    ["APEXICON (Topical)", false, ["diflorasone"]],
    ["APHEXDA (Injectable)", false, ["motixafortide"]],
    ["APIDRA (Injectable)", false, ["insulin glulisine, human"]],
    ["Apitegromab (Injectable)", false, ["apitegromab"]],
    ["Apixaban (Oral Pill)", true, ["apixaban"]],
    ["Apixaban (Oral Suspension Powder)", true, ["apixaban"]],
    ["Apixaban (Oral Suspension Tablet)", true, ["apixaban"]],
    ["Apixaban (Pack)", false, ["apixaban"]],
    ["APLENZIN XR (Oral Pill)", true, ["bupropion"]],
    ["APLISOL (Injectable)", false, ["purified protein derivative of tuberculin"]],
    ["APOKYN (Injectable)", false, ["apomorphine"]],
    ["Apomorphine (Injectable)", false, ["apomorphine"]],
    ["APONVIE (Injectable)", false, ["aprepitant"]],
    ["APPEAREX (Oral Pill)", true, ["biotin"]],
    ["Apple cider vinegar (Chewable)", true, ["apple cider vinegar"]],
    ["Apple cider vinegar (Oral Pill)", true, ["apple cider vinegar"]],
    ["Apple pectin/Lactobacillus acidophilus (Oral Pill)", true, ["Lactobacillus acidophilus", "apple pectin"]],
    ["Apraclonidine (Ophthalmic)", false, ["apraclonidine"]],
    ["Apremilast (Oral Pill)", true, ["apremilast"]],
    ["Apremilast (Pack)", true, ["apremilast"]],
    ["Apremilast XR (Oral Pill)", true, ["apremilast"]],
    ["Aprepitant (Injectable)", false, ["aprepitant"]],
    ["Aprepitant (Oral Pill)", true, ["aprepitant"]],
    ["Aprepitant (Oral Suspension Powder)", true, ["aprepitant"]],
    ["Aprepitant (Pack)", true, ["aprepitant"]],
    ["APRETUDE (Injectable)", false, ["cabotegravir"]],
    ["APRI 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["APRISO XR (Oral Pill)", true, ["mesalamine"]],
    ["Aprocitentan (Oral Pill)", true, ["aprocitentan"]],
    ["APTENSIO XR (Oral Pill)", true, ["methylphenidate"]],
    ["APTIOM (Oral Pill)", true, ["eslicarbazepine"]],
    ["APTIOM TITRATION SAMPLE PACK (Pack)", true, ["eslicarbazepine"]],
    ["APTIVUS (Oral Pill)", true, ["tipranavir"]],
    ["AQNEURSA (Oral Suspension Granules)", true, ["levacetylleucine"]],
    ["AQUA CARE (Topical)", false, ["urea"]],
    ["AQUA GLYCOLIC SHAMPOO AND BODY CLEANSER (Soap)", false, ["glycolate"]],
    ["AQUA-BAN (Oral Pill)", true, ["pamabrom"]],
    ["AQUANIL HC (Topical)", false, ["hydrocortisone"]],
    ["AQUAPHILIC WITH UREA (Topical)", false, ["urea"]],
    ["AQUAPHOR (Topical)", false, ["petrolatum"]],
    ["AQUAPHOR DIAPER RASH (Paste)", false, ["zinc oxide"]],
    ["AQUAPHOR DIAPER RASH (Topical)", false, ["zinc oxide"]],
    ["AQUAPHOR ITCH RELIEF (Topical)", false, ["hydrocortisone"]],
    ["AQUASOL A (Injectable)", false, ["vitamin A"]],
    ["AQUASOL E (Oral Liquid)", true, ["vitamin E"]],
    ["AQVESME (Oral Pill)", true, ["mitapivat"]],
    ["ARAKODA (Oral Pill)", true, ["tafenoquine"]],
    ["ARALAST (Injectable)", false, ["alpha 1-antitrypsin"]],
    ["ARANELLE 28 (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["ARANESP (Injectable)", false, ["darbepoetin alfa"]],
    ["ARAVA (Oral Pill)", true, ["leflunomide"]],
    ["ARAZLO (Topical)", false, ["tazarotene"]],
    ["ARBLI (Oral Liquid)", true, ["losartan"]],
    ["ARCALYST (Injectable)", false, ["rilonacept"]],
    ["AREPANRIX (Injectable)", false, ["influenza A virus (H5N8) antigen"]],
    ["ARESTIN (Oral Powder)", true, ["minocycline"]],
    ["AREXVY (Injectable)", false, ["respiratory syncytial virus pre-fusion F protein"]],
    ["Arformoterol (Inhalant)", false, ["arformoterol"]],
    ["Argatroban (Injectable)", false, ["argatroban"]],
    ["Arginine (Oral Pill)", true, ["arginine"]],
    ["Arginine XR (Oral Pill)", true, ["arginine"]],
    ["ARICEPT (Oral Pill)", true, ["donepezil"]],
    ["ARIKAYCE (Inhalant)", false, ["amikacin"]],
    ["ARIMIDEX (Oral Pill)", true, ["anastrozole"]],
    ["Arimoclomol (Oral Pill)", true, ["arimoclomol"]],
    ["ARIPiprazole (Injectable)", false, ["aripiprazole"]],
    ["ARIPiprazole (Oral Disintegrating)", true, ["aripiprazole"]],
    ["ARIPiprazole (Oral Film)", true, ["aripiprazole"]],
    ["ARIPiprazole (Oral Liquid)", true, ["aripiprazole"]],
    ["ARIPiprazole (Oral Pill)", true, ["aripiprazole"]],
    ["ARIPiprazole lauroxil (Injectable)", false, ["aripiprazole lauroxil"]],
    ["ARISTADA (Injectable)", false, ["aripiprazole lauroxil"]],
    ["ARIXTRA (Injectable)", false, ["fondaparinux"]],
    ["ARMLUPEG (Injectable)", false, ["pegfilgrastim"]],
    ["Armodafinil (Oral Pill)", true, ["armodafinil"]],
    ["ARMONAIR (Inhalant)", false, ["fluticasone"]],
    ["ARMOUR THYROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["ARNUITY (Inhalant)", false, ["fluticasone"]],
    ["AROMASIN (Oral Pill)", true, ["exemestane"]],
    ["ARRANON (Injectable)", false, ["nelarabine"]],
    ["Arsenic trioxide (Injectable)", false, ["arsenic trioxide"]],
    ["Artemether/Lumefantrine (Oral Pill)", true, ["artemether", "lumefantrine"]],
    ["Artesunate (Injectable)", false, ["artesunate"]],
    ["ARTHRITEN INFLAMMATORY PAIN (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine"]],
    ["ARTHRITIS HOT PAIN RELIEF (Topical)", false, ["menthol", "methyl salicylate"]],
    ["ARTHROTEC (Oral Pill)", true, ["diclofenac", "misoprostol"]],
    ["ARTICADENT (Injectable)", false, ["articaine", "epinephrine"]],
    ["Articaine/EPINEPHrine (Injectable)", false, ["articaine", "epinephrine"]],
    ["ARTISS (Injectable)", false, ["fibrinogen", "thrombin"]],
    ["ARYNTA (Oral Liquid)", true, ["lisdexamfetamine"]],
    ["ARZERRA (Injectable)", false, ["ofatumumab"]],
    ["ASCAREL (Oral Liquid)", true, ["pyrantel"]],
    ["ASCENIV (Injectable)", false, ["immunoglobulin G"]],
    ["Asciminib (Oral Pill)", true, ["asciminib"]],
    ["ASCLERA (Injectable)", false, ["polidocanol"]],
    ["ASCOMP (Oral Pill)", true, ["aspirin", "butalbital", "caffeine", "codeine"]],
    ["ASCOR (Injectable)", false, ["ascorbic acid"]],
    ["Ascorbic acid (Chewable)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Injectable)", false, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Disintegrating)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Liquid)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Pill)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Powder)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Solution Powder)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Suspension Powder)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Oral Wafer)", true, ["ascorbic acid"]],
    ["Ascorbic acid (Topical)", false, ["ascorbic acid"]],
    ["Ascorbic acid XR (Oral Pill)", true, ["ascorbic acid"]],
    ["Ascorbic acid/Astaxanthin (Chewable)", true, ["ascorbic acid", "astaxanthin"]],
    ["Ascorbic acid/Beta carotene/Copper sulfate/Lutein/Selenite/Vitamin E/Zinc oxide (Oral Pill)", true, ["ascorbic acid", "beta carotene", "copper sulfate", "lutein", "selenite", "vitamin E", "zinc oxide"]],
    ["Ascorbic acid/Beta carotene/Copper sulfate/Selenite/Vitamin E/Zinc oxide (Oral Pill)", true, ["ascorbic acid", "beta carotene", "copper sulfate", "selenite", "vitamin E", "zinc oxide"]],
    ["Ascorbic acid/Beta carotene/Cuprous oxide/Lutein/Sodium selenate/Vitamin E/Zinc oxide (Oral Pill)", true, ["ascorbic acid", "beta carotene", "cuprous oxide", "lutein", "sodium selenate", "vitamin E", "zinc oxide"]],
    ["Ascorbic acid/Beta carotene/Cuprous oxide/Vitamin E/Zinc oxide (Oral Pill)", true, ["ascorbic acid", "beta carotene", "cuprous oxide", "vitamin E", "zinc oxide"]],
    ["Ascorbic acid/Calcium carbonate (Oral Pill)", true, ["ascorbic acid", "calcium carbonate"]],
    ["Ascorbic acid/Calcium citrate/Cholecalciferol/Folic acid/Iron carbonyl/Pyridoxine (Oral Pill)", true, ["ascorbic acid", "calcium citrate", "cholecalciferol", "folic acid", "iron carbonyl", "pyridoxine"]],
    ["Ascorbic acid/Calcium citrate/Cholecalciferol/Folic acid/Iron carbonyl/Pyridoxine (Pack)", true, ["ascorbic acid", "calcium citrate", "cholecalciferol", "folic acid", "iron carbonyl", "pyridoxine"]],
    ["Ascorbic acid/Cholecalciferol/Sodium fluoride/Vitamin A (Oral Liquid)", true, ["ascorbic acid", "cholecalciferol", "sodium fluoride", "vitamin A"]],
    ["Ascorbic acid/Cholecalciferol/Vitamin A (Oral Liquid)", true, ["ascorbic acid", "cholecalciferol", "vitamin A"]],
    ["Ascorbic acid/Chondroitin sulfates/Glucosamine (Oral Pill)", true, ["ascorbic acid", "chondroitin sulfates", "glucosamine"]],
    ["Ascorbic acid/Collagen (Oral Pill)", true, ["ascorbic acid", "collagen"]],
    ["Ascorbic acid/Collagen, hydrolyzed (Oral Pill)", true, ["ascorbic acid", "collagen, hydrolyzed"]],
    ["Ascorbic acid/Cuprous oxide/Lutein/Vitamin E/Zinc oxide (Oral Pill)", true, ["ascorbic acid", "cuprous oxide", "lutein", "vitamin E", "zinc oxide"]],
    ["Ascorbic acid/Docusate/Folic acid/Iron carbonyl/Vitamin B12 (Oral Pill)", true, ["ascorbic acid", "docusate", "folic acid", "iron carbonyl", "vitamin B12"]],
    ["Ascorbic acid/Ferrous fumarate/Folic acid/Liver stomach concentrate/Vitamin B12 (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "liver stomach concentrate", "vitamin B12"]],
    ["Ascorbic acid/Ferrous fumarate/Folic acid/Niacin/Polysaccharide iron complex (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "niacin", "polysaccharide iron complex"]],
    ["Ascorbic acid/Ferrous fumarate/Folic acid/Niacinamide/Polysaccharide iron complex (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "niacinamide", "polysaccharide iron complex"]],
    ["Ascorbic acid/Ferrous fumarate/Folic acid/Vitamin B12 (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "vitamin B12"]],
    ["Ascorbic acid/Ferrous fumarate/Vitamin B12 (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "vitamin B12"]],
    ["Ascorbic acid/Ferrous sulfate XR (Oral Pill)", true, ["ascorbic acid", "ferrous sulfate"]],
    ["Ascorbic acid/Ferrous sulfate/Folic acid XR (Oral Pill)", true, ["ascorbic acid", "ferrous sulfate", "folic acid"]],
    ["Ascorbic acid/Folic acid/Iron carbonyl/Vitamin B12 (Oral Pill)", true, ["ascorbic acid", "folic acid", "iron carbonyl", "vitamin B12"]],
    ["Ascorbic acid/Hyaluronate (Oral Pill)", true, ["ascorbic acid", "hyaluronate"]],
    ["Ascorbic acid/Iron carbonyl (Oral Pill)", true, ["ascorbic acid", "iron carbonyl"]],
    ["Ascorbic acid/Polysaccharide iron complex (Oral Pill)", true, ["ascorbic acid", "polysaccharide iron complex"]],
    ["Ascorbic acid/Resveratrol (Oral Pill)", true, ["ascorbic acid", "resveratrol"]],
    ["Asenapine (Sublingual)", false, ["asenapine"]],
    ["Asenapine (Transdermal)", false, ["asenapine"]],
    ["Asfotase alfa (Injectable)", false, ["asfotase alfa"]],
    ["ASHLYNA 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["ASMANEX (Inhalant)", false, ["mometasone"]],
    ["Asparaginase (Injectable)", false, ["asparaginase"]],
    ["ASPARLAS (Injectable)", false, ["calaspargase pegol"]],
    ["ASPERCREME (Topical)", false, ["trolamine salicylate"]],
    ["ASPI-COR (Oral Pill)", true, ["aspirin"]],
    ["Aspirin (Chewable)", true, ["aspirin"]],
    ["Aspirin (Effervescent)", true, ["aspirin"]],
    ["Aspirin (Oral Pill)", true, ["aspirin"]],
    ["Aspirin (Rectal)", false, ["aspirin"]],
    ["Aspirin XR (Oral Pill)", true, ["aspirin"]],
    ["Aspirin/Caffeine (Effervescent)", true, ["aspirin", "caffeine"]],
    ["Aspirin/Caffeine (Oral Pill)", true, ["aspirin", "caffeine"]],
    ["Aspirin/Caffeine (Oral Powder)", true, ["aspirin", "caffeine"]],
    ["Aspirin/Calcium carbonate (Oral Pill)", true, ["aspirin", "calcium carbonate"]],
    ["Aspirin/Carisoprodol (Oral Pill)", true, ["aspirin", "carisoprodol"]],
    ["Aspirin/diphenhydrAMINE (Oral Pill)", true, ["aspirin", "diphenhydramine"]],
    ["Aspirin/Dipyridamole XR (Oral Pill)", true, ["aspirin", "dipyridamole"]],
    ["Aspirin/Omeprazole (Oral Pill)", true, ["aspirin", "omeprazole"]],
    ["Aspirin/oxyCODONE (Oral Pill)", true, ["aspirin", "oxycodone"]],
    ["ASPRUZYO (Oral Granules)", true, ["ranolazine"]],
    ["ASTAGRAF XR (Oral Pill)", true, ["tacrolimus"]],
    ["ASTEPRO (Nasal)", false, ["azelastine"]],
    ["ASTHMANEFRIN (Inhalant)", false, ["racepinephrine"]],
    ["ASTRINGYN (Topical)", false, ["ferric subsulfate solution"]],
    ["ATACAND (Oral Pill)", true, ["candesartan"]],
    ["ATACAND HCT (Oral Pill)", true, ["candesartan", "hydrochlorothiazide"]],
    ["Atacicept (Injectable)", false, ["atacicept"]],
    ["Atazanavir (Oral Pill)", true, ["atazanavir"]],
    ["Atazanavir (Oral Powder)", true, ["atazanavir"]],
    ["Atazanavir/Cobicistat (Oral Pill)", true, ["atazanavir", "cobicistat"]],
    ["ATEBRIOZ (Oral Pill)", true, ["zilurgisertib"]],
    ["ATELVIA (Pack)", true, ["risedronate"]],
    ["Atenolol (Oral Pill)", true, ["atenolol"]],
    ["Atenolol/Chlorthalidone (Oral Pill)", true, ["atenolol", "chlorthalidone"]],
    ["Atezolizumab (Injectable)", false, ["atezolizumab"]],
    ["Atezolizumab/Hyaluronidase (Injectable)", false, ["atezolizumab", "hyaluronidase"]],
    ["ATGAM (Injectable)", false, ["lymphocyte immune globulin, anti-thymocyte globulin"]],
    ["Atidarsagene autotemcel (Injectable)", false, ["atidarsagene autotemcel"]],
    ["ATIVAN (Injectable)", false, ["lorazepam"]],
    ["ATIVAN (Oral Pill)", true, ["lorazepam"]],
    ["ATMEKSI (Oral Liquid)", true, ["methocarbamol"]],
    ["Atogepant (Oral Pill)", true, ["atogepant"]],
    ["Atoltivimab/Maftivimab/Odesivimab (Injectable)", false, ["atoltivimab", "maftivimab", "odesivimab"]],
    ["Atomoxetine (Oral Liquid)", true, ["atomoxetine"]],
    ["Atomoxetine (Oral Pill)", true, ["atomoxetine"]],
    ["ATONCY (Oral Liquid)", true, ["atomoxetine"]],
    ["ATORVALIQ (Oral Liquid)", true, ["atorvastatin"]],
    ["Atorvastatin (Oral Liquid)", true, ["atorvastatin"]],
    ["Atorvastatin (Oral Pill)", true, ["atorvastatin"]],
    ["Atovaquone (Oral Liquid)", true, ["atovaquone"]],
    ["Atovaquone/Proguanil (Oral Pill)", true, ["atovaquone", "proguanil"]],
    ["ATRAC-TAIN (Topical)", false, ["lactate", "urea"]],
    ["Atracurium (Injectable)", false, ["atracurium"]],
    ["ATRALIN (Topical)", false, ["tretinoin"]],
    ["Atrasentan (Oral Pill)", true, ["atrasentan"]],
    ["ATRIPLA (Oral Pill)", true, ["efavirenz", "emtricitabine", "tenofovir disoproxil"]],
    ["ATROPEN (Injectable)", false, ["atropine"]],
    ["Atropine (Injectable)", false, ["atropine"]],
    ["Atropine (Ophthalmic)", false, ["atropine"]],
    ["Atropine/Difenoxin (Oral Pill)", true, ["atropine", "difenoxin"]],
    ["Atropine/Diphenoxylate (Oral Liquid)", true, ["atropine", "diphenoxylate"]],
    ["Atropine/Diphenoxylate (Oral Pill)", true, ["atropine", "diphenoxylate"]],
    ["Atropine/Pralidoxime (Injectable)", false, ["atropine", "pralidoxime"]],
    ["ATROVENT (Inhalant)", false, ["ipratropium"]],
    ["ATRYN (Injectable)", false, ["antithrombin III"]],
    ["ATTERO (Topical)", false, ["betamethasone", "calcipotriene"]],
    ["ATTRUBY (Oral Pill)", true, ["acoramidis"]],
    ["ATZUMI (Nasal)", false, ["dihydroergotamine"]],
    ["AUBAGIO (Oral Pill)", true, ["teriflunomide"]],
    ["AUBRA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["AUCATZYL (Injectable)", false, ["obecabtagene autoleucel"]],
    ["AUCATZYL KIT 3-5 BAGS (Pack)", false, ["obecabtagene autoleucel"]],
    ["AUDENZ (Injectable)", false, ["influenza A virus (H5N1) antigen"]],
    ["AUGMENTIN (Oral Liquid)", true, ["amoxicillin", "clavulanate"]],
    ["AUGMENTIN (Oral Pill)", true, ["amoxicillin", "clavulanate"]],
    ["AUGMENTIN XR (Oral Pill)", true, ["amoxicillin", "clavulanate"]],
    ["AUGTYRO (Oral Pill)", true, ["repotrectinib"]],
    ["AUKELSO (Injectable)", false, ["denosumab"]],
    ["Auranofin (Oral Pill)", true, ["auranofin"]],
    ["AURAPHENE-B (Otic)", false, ["carbamide peroxide"]],
    ["AURLUMYN (Injectable)", false, ["iloprost"]],
    ["AUROVELA 1.5/30 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["AUROVELA 1/20 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["AUROVELA FE 1.5/30 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["AUROVELA FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["AUROVELA FE 24 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["AURYXIA (Oral Pill)", true, ["ferric citrate"]],
    ["AUSTEDO (Oral Pill)", true, ["deutetrabenazine"]],
    ["AUSTEDO 12 MG STARTING DOSE PACK (Pack)", true, ["deutetrabenazine"]],
    ["AUSTEDO 12 MG STARTING DOSE, 4 WEEK TITRATION PACK (Pack)", true, ["deutetrabenazine"]],
    ["AUSTEDO XR (Oral Pill)", true, ["deutetrabenazine"]],
    ["AUSTEDO XR ONCE DAILY, 4 WEEK TITRATION PACK, 12 MG / 18 MG / 24 MG / 30 MG (Pack)", true, ["deutetrabenazine"]],
    ["AUSTEDO XR ONCE DAILY, 4 WEEK TITRATION PACK, 6 MG / 12 MG / 24 MG (Pack)", true, ["deutetrabenazine"]],
    ["AUVELITY SAMPLE TITRATION PACK (Pack)", true, ["bupropion", "dextromethorphan"]],
    ["AUVELITY TITRATION PACK (Pack)", true, ["bupropion", "dextromethorphan"]],
    ["AUVELITY XR (Oral Pill)", true, ["bupropion", "dextromethorphan"]],
    ["AUVI-Q (Injectable)", false, ["epinephrine"]],
    ["Avacincaptad pegol (Injectable)", false, ["avacincaptad pegol"]],
    ["AVACLYR (Ophthalmic)", false, ["acyclovir"]],
    ["Avacopan (Oral Pill)", true, ["avacopan"]],
    ["AVAGARD (Topical)", false, ["chlorhexidine", "ethanol"]],
    ["AVAILNEX (Chewable)", true, ["carbocysteine"]],
    ["Avalglucosidase alfa (Injectable)", false, ["avalglucosidase alfa"]],
    ["AVALIDE (Oral Pill)", true, ["hydrochlorothiazide", "irbesartan"]],
    ["Avanafil (Oral Pill)", true, ["avanafil"]],
    ["AVANCE (Implant)", false, ["acellular nerve allograft"]],
    ["Avapritinib (Oral Pill)", true, ["avapritinib"]],
    ["AVAPRO (Oral Pill)", true, ["irbesartan"]],
    ["AVAR (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["AVAR (Topical)", false, ["sulfacetamide", "sulfur"]],
    ["AVASTIN (Injectable)", false, ["bevacizumab"]],
    ["Avatrombopag (Oral Granules)", true, ["avatrombopag"]],
    ["Avatrombopag (Oral Pill)", true, ["avatrombopag"]],
    ["Avatrombopag (Pack)", true, ["avatrombopag"]],
    ["AVEED (Injectable)", false, ["testosterone"]],
    ["AVELOX (Injectable)", false, ["moxifloxacin"]],
    ["AVELOX (Oral Pill)", true, ["moxifloxacin"]],
    ["Avelumab (Injectable)", false, ["avelumab"]],
    ["AVERI 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol", "ferrous bisglycinate"]],
    ["AVGEMSI (Injectable)", false, ["gemcitabine"]],
    ["AVIANE 28 (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Avibactam/Aztreonam (Injectable)", false, ["avibactam", "aztreonam"]],
    ["Avibactam/cefTAZidime (Injectable)", false, ["avibactam", "ceftazidime"]],
    ["AVIDOXY (Oral Pill)", true, ["doxycycline"]],
    ["AVIDOXY PACK (Pack)", false, ["doxycycline", "salicylic acid"]],
    ["AVITA (Topical)", false, ["tretinoin"]],
    ["AVLAYAH (Injectable)", false, ["tividenofusp alfa"]],
    ["AVMAPKI (Oral Pill)", true, ["avutometinib"]],
    ["AVMAPKI FAKZYNJA CO-PACK (Pack)", true, ["avutometinib", "defactinib"]],
    ["AVOCA (Topical)", false, ["potassium nitrate", "silver nitrate"]],
    ["AVODART (Oral Pill)", true, ["dutasteride"]],
    ["AVONEX (Injectable)", false, ["interferon beta-1a"]],
    ["AVOPEF (Injectable)", false, ["etoposide"]],
    ["AVSOLA (Injectable)", false, ["infliximab"]],
    ["AVTOZMA (Injectable)", false, ["tocilizumab"]],
    ["Avutometinib (Oral Pill)", true, ["avutometinib"]],
    ["Avutometinib/Defactinib (Pack)", true, ["avutometinib", "defactinib"]],
    ["AVYCAZ (Injectable)", false, ["avibactam", "ceftazidime"]],
    ["AVZIVI (Injectable)", false, ["bevacizumab"]],
    ["AWIQLI (Injectable)", false, ["insulin icodec"]],
    ["Axatilimab (Injectable)", false, ["axatilimab"]],
    ["Axicabtagene ciloleucel (Injectable)", false, ["axicabtagene ciloleucel"]],
    ["Axitinib (Oral Pill)", true, ["axitinib"]],
    ["AXTLE (Injectable)", false, ["pemetrexed"]],
    ["AYR SALINE NASAL (Nasal)", false, ["sodium chloride"]],
    ["AYUNA 28 DAY PACK (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["AYVAKIT (Oral Pill)", true, ["avapritinib"]],
    ["azaCITIDine (Injectable)", false, ["azacitidine"]],
    ["azaCITIDine (Oral Pill)", true, ["azacitidine"]],
    ["AZACTAM (Injectable)", false, ["aztreonam"]],
    ["AZASAN (Oral Pill)", true, ["azathioprine"]],
    ["AZASITE (Ophthalmic)", false, ["azithromycin"]],
    ["azaTHIOprine (Injectable)", false, ["azathioprine"]],
    ["azaTHIOprine (Oral Pill)", true, ["azathioprine"]],
    ["AZEDRA (Injectable)", false, ["3-iodobenzylguanidine"]],
    ["Azelastine (Nasal)", false, ["azelastine"]],
    ["Azelastine (Ophthalmic)", false, ["azelastine"]],
    ["Azelastine/Fluticasone (Nasal)", false, ["azelastine", "fluticasone"]],
    ["Azelate (Topical)", false, ["azelate"]],
    ["Azelate/Cupric oxide/Folic acid/Niacinamide/Pyridoxine/Zinc oxide (Oral Pill)", true, ["azelate", "cupric oxide", "folic acid", "niacinamide", "pyridoxine", "zinc oxide"]],
    ["AZELEX (Topical)", false, ["azelate"]],
    ["AZILECT (Oral Pill)", true, ["rasagiline"]],
    ["Azilsartan (Oral Pill)", true, ["azilsartan"]],
    ["Azilsartan/Chlorthalidone (Oral Pill)", true, ["azilsartan", "chlorthalidone"]],
    ["Azithromycin (Injectable)", false, ["azithromycin"]],
    ["Azithromycin (Ophthalmic)", false, ["azithromycin"]],
    ["Azithromycin (Oral Liquid)", true, ["azithromycin"]],
    ["Azithromycin (Oral Pill)", true, ["azithromycin"]],
    ["Azithromycin (Oral Suspension Powder)", true, ["azithromycin"]],
    ["Azithromycin (Pack)", true, ["azithromycin"]],
    ["AZMIRO (Injectable)", false, ["testosterone"]],
    ["AZO URINARY PAIN RELIEF (Oral Pill)", true, ["phenazopyridine"]],
    ["AZO URINARY TRACT DEFENSE (Oral Pill)", true, ["methenamine", "salicylic acid"]],
    ["AZOPT (Ophthalmic)", false, ["brinzolamide"]],
    ["AZOR (Oral Pill)", true, ["amlodipine", "olmesartan"]],
    ["AZSTARYS (Oral Pill)", true, ["dexmethylphenidate", "serdexmethylphenidate"]],
    ["Aztreonam (Inhalant)", false, ["aztreonam"]],
    ["Aztreonam (Injectable)", false, ["aztreonam"]],
    ["AZULFIDINE (Oral Pill)", true, ["sulfasalazine"]],
    ["AZURETTE 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["B-CARO-T (Oral Pill)", true, ["beta carotene"]],
    ["BABEE COF (Oral Liquid)", true, ["dextromethorphan"]],
    ["BABY ANTI MONKEY BUTT DIAPER RASH CREAM (Topical)", false, ["calamine", "zinc oxide"]],
    ["BABYBIG (Injectable)", false, ["botulism immune globulin IV human"]],
    ["BACIGUENT (Ophthalmic)", false, ["bacitracin"]],
    ["Bacillus anthracis strain V770-NP1-R antigens (Injectable)", false, ["Bacillus anthracis strain V770-NP1-R antigens"]],
    ["Bacillus coagulans (Chewable)", true, ["Bacillus coagulans"]],
    ["Bacillus coagulans (Oral Pill)", true, ["Bacillus coagulans"]],
    ["Bacillus coagulans/Inulin (Chewable)", true, ["Bacillus coagulans", "inulin"]],
    ["Bacillus coagulans/Inulin (Oral Pill)", true, ["Bacillus coagulans", "inulin"]],
    ["Bacillus coagulans/Lactobacillus acidophilus (Oral Pill)", true, ["Bacillus coagulans", "Lactobacillus acidophilus"]],
    ["Bacillus subtilis/Inulin (Chewable)", true, ["Bacillus subtilis", "inulin"]],
    ["Bacitracin (Injectable)", false, ["bacitracin"]],
    ["Bacitracin (Ophthalmic)", false, ["bacitracin"]],
    ["Bacitracin (Topical)", false, ["bacitracin"]],
    ["Bacitracin/Dimethicone/Zinc oxide (Topical)", false, ["bacitracin", "dimethicone", "zinc oxide"]],
    ["Bacitracin/Polymyxin B (Ophthalmic)", false, ["bacitracin", "polymyxin B"]],
    ["Bacitracin/Polymyxin B (Topical)", false, ["bacitracin", "polymyxin B"]],
    ["Bacitracin/Pramoxine (Topical)", false, ["bacitracin", "pramoxine"]],
    ["BACKAID IPF (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine"]],
    ["BACKPRIN (Oral Pill)", true, ["acetaminophen", "caffeine", "magnesium salicylate"]],
    ["Baclofen (Injectable)", false, ["baclofen"]],
    ["Baclofen (Oral Granules)", true, ["baclofen"]],
    ["Baclofen (Oral Liquid)", true, ["baclofen"]],
    ["Baclofen (Oral Pill)", true, ["baclofen"]],
    ["BACTINE (Topical)", false, ["benzalkonium", "lidocaine"]],
    ["BACTINE WOUND WASH (Topical)", false, ["benzalkonium"]],
    ["BACTOSHIELD (Soap)", false, ["chlorhexidine"]],
    ["BACTRIM (Oral Pill)", true, ["sulfamethoxazole", "trimethoprim"]],
    ["BACTROBAN (Topical)", false, ["mupirocin"]],
    ["BAFIERTAM (Oral Pill)", true, ["monomethyl fumarate"]],
    ["BAL IN OIL (Injectable)", false, ["dimercaprol"]],
    ["BALCOLTRA 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous bisglycinate", "levonorgestrel"]],
    ["Bald-faced hornet venom protein (Injectable)", false, ["bald-faced hornet venom protein"]],
    ["BALFAXAR (Injectable)", false, ["factor IX", "factor VII", "factor X", "protein C", "protein S", "prothrombin"]],
    ["BALMEX (Topical)", false, ["zinc oxide"]],
    ["BALMEX OINTMENT (Topical)", false, ["petrolatum"]],
    ["BALNETAR (Topical)", false, ["coal tar"]],
    ["Baloxavir marboxil (Oral Pill)", true, ["baloxavir marboxil"]],
    ["Baloxavir marboxil (Oral Suspension Granules)", true, ["baloxavir marboxil"]],
    ["Baloxavir marboxil (Pack)", true, ["baloxavir marboxil"]],
    ["Balsalazide (Oral Pill)", true, ["balsalazide"]],
    ["BALVERSA (Oral Pill)", true, ["erdafitinib"]],
    ["BALZIVA 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["BAND-AID HURT-FREE (Topical)", false, ["benzalkonium", "lidocaine"]],
    ["BANOPHEN (Oral Liquid)", true, ["diphenhydramine"]],
    ["BANOPHEN (Oral Pill)", true, ["diphenhydramine"]],
    ["BANOPHEN CREAM (Topical)", false, ["diphenhydramine", "zinc acetate"]],
    ["BANZEL (Oral Liquid)", true, ["rufinamide"]],
    ["BANZEL (Oral Pill)", true, ["rufinamide"]],
    ["BAQSIMI (Nasal)", false, ["glucagon"]],
    ["BARACLUDE (Oral Liquid)", true, ["entecavir"]],
    ["BARACLUDE (Oral Pill)", true, ["entecavir"]],
    ["BARHEMSYS (Injectable)", false, ["amisulpride"]],
    ["Baricitinib (Oral Pill)", true, ["baricitinib"]],
    ["BARIDIUM (Oral Pill)", true, ["phenazopyridine"]],
    ["Barley grain (Oral Pill)", true, ["barley grain"]],
    ["BASAGLAR (Injectable)", false, ["insulin glargine"]],
    ["Basiliximab (Injectable)", false, ["basiliximab"]],
    ["BAVENCIO (Injectable)", false, ["avelumab"]],
    ["BAXDELA (Injectable)", false, ["delafloxacin"]],
    ["BAXDELA (Oral Pill)", true, ["delafloxacin"]],
    ["Baxdrostat (Oral Pill)", true, ["baxdrostat"]],
    ["BAXFENDY (Oral Pill)", true, ["baxdrostat"]],
    ["BAZA (Topical)", false, ["miconazole"]],
    ["BAZA CLEANSE AND PROTECT (Topical)", false, ["dimethicone"]],
    ["BAZA CLEAR (Topical)", false, ["petrolatum"]],
    ["BAZA-PROTECT (Topical)", false, ["dimethicone", "zinc oxide"]],
    ["Bazedoxifene/Estrogens, conjugated (USP) (Oral Pill)", true, ["bazedoxifene", "estrogens, conjugated (USP)"]],
    ["BC ARTHRITIS (Oral Powder)", true, ["aspirin", "caffeine"]],
    ["BC ORIGINAL FORMULA (Oral Powder)", true, ["aspirin", "caffeine"]],
    ["BCG, live, Tice strain (Injectable)", false, ["BCG, live, Tice strain"]],
    ["BCG, live, Tice strain (Intravesical)", false, ["BCG, live, Tice strain"]],
    ["BEANO (Oral Disintegrating)", true, ["alpha-D-galactosidase enzyme"]],
    ["Becaplermin (Topical)", false, ["becaplermin"]],
    ["Beclomethasone (Inhalant)", false, ["beclomethasone"]],
    ["Beclomethasone (Nasal)", false, ["beclomethasone"]],
    ["Beclomethasone/Formoterol/Glycopyrronium (Inhalant)", false, ["beclomethasone", "formoterol", "glycopyrronium"]],
    ["BECONASE (Nasal)", false, ["beclomethasone"]],
    ["Bedaquiline (Oral Pill)", true, ["bedaquiline"]],
    ["BEDSIDE-CARE (Topical)", false, ["benzethonium"]],
    ["Bee pollen (Oral Pill)", true, ["bee pollen"]],
    ["BEELITH (Oral Pill)", true, ["magnesium oxide", "pyridoxine"]],
    ["BEIZRAY (Injectable)", false, ["docetaxel"]],
    ["BEIZRAY 160 MG KIT (Pack)", false, ["albumin human, USP", "docetaxel"]],
    ["BEIZRAY 80 MG KIT (Pack)", false, ["albumin human, USP", "docetaxel"]],
    ["BEKYREE 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Belantamab mafodotin (Injectable)", false, ["belantamab mafodotin"]],
    ["Belatacept (Injectable)", false, ["belatacept"]],
    ["BELBUCA (Buccal)", false, ["buprenorphine"]],
    ["BELEODAQ (Injectable)", false, ["belinostat"]],
    ["Belimumab (Injectable)", false, ["belimumab"]],
    ["Belinostat (Injectable)", false, ["belinostat"]],
    ["Belladonna alkaloids/Opium (Rectal)", false, ["belladonna alkaloids", "opium"]],
    ["BELRAPZO (Injectable)", false, ["bendamustine"]],
    ["BELSOMRA (Oral Pill)", true, ["suvorexant"]],
    ["Belumosudil (Oral Pill)", true, ["belumosudil"]],
    ["Belzutifan (Oral Pill)", true, ["belzutifan"]],
    ["Bempedoic acid (Oral Pill)", true, ["bempedoic acid"]],
    ["Bempedoic acid/Ezetimibe (Oral Pill)", true, ["bempedoic acid", "ezetimibe"]],
    ["BENADRYL (Chewable)", true, ["diphenhydramine"]],
    ["BENADRYL (Oral Disintegrating)", true, ["diphenhydramine"]],
    ["BENADRYL (Oral Liquid)", true, ["diphenhydramine"]],
    ["BENADRYL (Oral Pill)", true, ["diphenhydramine"]],
    ["BENADRYL (Topical)", false, ["diphenhydramine"]],
    ["BENADRYL ALLERGY PLUS CONGESTION (Oral Pill)", true, ["diphenhydramine", "phenylephrine"]],
    ["BENADRYL CHILDREN'S ANTI-ITCH (Topical)", false, ["camphor"]],
    ["BENADRYL ITCH STOPPING (Topical)", false, ["diphenhydramine", "zinc acetate"]],
    ["BENADRYL-D ALLERGY AND SINUS (Oral Liquid)", true, ["diphenhydramine", "phenylephrine"]],
    ["Benazepril (Oral Pill)", true, ["benazepril"]],
    ["Benazepril/hydroCHLOROthiazide (Oral Pill)", true, ["benazepril", "hydrochlorothiazide"]],
    ["Bendamustine (Injectable)", false, ["bendamustine"]],
    ["BENDEKA (Injectable)", false, ["bendamustine"]],
    ["BENEFIBER (Chewable)", true, ["wheat dextrin"]],
    ["BENEFIBER (Oral Solution Powder)", true, ["wheat dextrin"]],
    ["BENEFIX (Injectable)", false, ["factor IX"]],
    ["BENICAR (Oral Pill)", true, ["olmesartan"]],
    ["BENICAR HCT (Oral Pill)", true, ["hydrochlorothiazide", "olmesartan"]],
    ["BENLYSTA (Injectable)", false, ["belimumab"]],
    ["Benoxinate/Fluorescein (Ophthalmic)", false, ["benoxinate", "fluorescein"]],
    ["Benphothiamine (Oral Pill)", true, ["benphothiamine"]],
    ["Benralizumab (Injectable)", false, ["benralizumab"]],
    ["BENSAL (Topical)", false, ["salicylic acid"]],
    ["BENTYL (Injectable)", false, ["dicyclomine"]],
    ["BENZ-O-STHETIC (Oral Gel)", true, ["benzocaine"]],
    ["BENZAC (Soap)", false, ["benzoyl peroxide"]],
    ["BENZAC (Topical)", false, ["benzoyl peroxide"]],
    ["Benzalkonium (Soap)", false, ["benzalkonium"]],
    ["Benzalkonium (Topical)", false, ["benzalkonium"]],
    ["Benzalkonium/Benzocaine (Oral Gel)", true, ["benzalkonium", "benzocaine"]],
    ["Benzalkonium/Benzocaine (Topical)", false, ["benzalkonium", "benzocaine"]],
    ["Benzalkonium/Benzocaine (Vaginal)", false, ["benzalkonium", "benzocaine"]],
    ["Benzalkonium/Camphor (Topical)", false, ["benzalkonium", "camphor"]],
    ["Benzalkonium/Lidocaine (Topical)", false, ["benzalkonium", "lidocaine"]],
    ["Benzalkonium/Piperonyl butoxide/Pyrethrins (Pack)", false, ["benzalkonium", "piperonyl butoxide", "pyrethrins"]],
    ["Benzalkonium/Pramoxine (Topical)", false, ["benzalkonium", "pramoxine"]],
    ["BENZAMYCIN (Topical)", false, ["benzoyl peroxide", "erythromycin"]],
    ["BENZEDREX (Nasal)", false, ["propylhexedrine"]],
    ["BENZEFOAM (Topical)", false, ["benzoyl peroxide"]],
    ["BENZEPRO (Soap)", false, ["benzoyl peroxide"]],
    ["BENZEPRO (Topical)", false, ["benzoyl peroxide"]],
    ["Benzethonium (Soap)", false, ["benzethonium"]],
    ["Benzethonium (Topical)", false, ["benzethonium"]],
    ["Benzethonium/Benzocaine (Topical)", false, ["benzethonium", "benzocaine"]],
    ["Benzethonium/Dyclonine (Topical)", false, ["benzethonium", "dyclonine"]],
    ["Benzethonium/Lidocaine (Topical)", false, ["benzethonium", "lidocaine"]],
    ["Benzethonium/Petrolatum (Pack)", false, ["benzethonium", "petrolatum"]],
    ["Benzethonium/Zinc oxide (Pack)", false, ["benzethonium", "zinc oxide"]],
    ["Benzgalantamine (Oral Pill)", true, ["benzgalantamine"]],
    ["Benznidazole (Oral Pill)", true, ["benznidazole"]],
    ["Benzoate/Caffeine (Injectable)", false, ["benzoate", "caffeine"]],
    ["Benzoate/Hyoscyamine/Methenamine/Methylene blue/Phenyl salicylate (Oral Pill)", true, ["benzoate", "hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate"]],
    ["Benzoate/Phenylacetate (Injectable)", false, ["benzoate", "phenylacetate"]],
    ["Benzocaine (Mucosal)", false, ["benzocaine"]],
    ["Benzocaine (Oral Cream)", true, ["benzocaine"]],
    ["Benzocaine (Oral Disintegrating)", true, ["benzocaine"]],
    ["Benzocaine (Oral Gel)", true, ["benzocaine"]],
    ["Benzocaine (Oral Liquid)", true, ["benzocaine"]],
    ["Benzocaine (Oral Lozenge)", true, ["benzocaine"]],
    ["Benzocaine (Oral Ointment)", true, ["benzocaine"]],
    ["Benzocaine (Oral Paste)", true, ["benzocaine"]],
    ["Benzocaine (Rectal)", false, ["benzocaine"]],
    ["Benzocaine (Topical)", false, ["benzocaine"]],
    ["Benzocaine/Chloroxylenol (Topical)", false, ["benzocaine", "chloroxylenol"]],
    ["Benzocaine/Dextromethorphan (Oral Lozenge)", true, ["benzocaine", "dextromethorphan"]],
    ["Benzocaine/Docusate (Rectal)", false, ["benzocaine", "docusate"]],
    ["Benzocaine/Isopropyl alcohol (Topical)", false, ["benzocaine", "isopropyl alcohol"]],
    ["Benzocaine/Menthol (Mucosal)", false, ["benzocaine", "menthol"]],
    ["Benzocaine/Menthol (Oral Gel)", true, ["benzocaine", "menthol"]],
    ["Benzocaine/Menthol (Oral Lozenge)", true, ["benzocaine", "menthol"]],
    ["Benzocaine/Menthol (Topical)", false, ["benzocaine", "menthol"]],
    ["Benzocaine/Phenol (Topical)", false, ["benzocaine", "phenol"]],
    ["Benzocaine/Resorcinol (Topical)", false, ["benzocaine", "resorcinol"]],
    ["Benzocaine/Resorcinol (Vaginal)", false, ["benzocaine", "resorcinol"]],
    ["Benzocaine/Salicylic acid (Topical)", false, ["benzocaine", "salicylic acid"]],
    ["Benzocaine/Triclosan (Topical)", false, ["benzocaine", "triclosan"]],
    ["Benzocaine/Zinc chloride (Mucosal)", false, ["benzocaine", "zinc chloride"]],
    ["Benzocaine/Zinc chloride (Oral Gel)", true, ["benzocaine", "zinc chloride"]],
    ["BENZODENT (Topical)", false, ["benzocaine"]],
    ["Benzoin resin (Topical)", false, ["benzoin resin"]],
    ["Benzonatate (Oral Pill)", true, ["benzonatate"]],
    ["Benzoyl peroxide (Soap)", false, ["benzoyl peroxide"]],
    ["Benzoyl peroxide (Topical)", false, ["benzoyl peroxide"]],
    ["Benzoyl peroxide/Clindamycin (Topical)", false, ["benzoyl peroxide", "clindamycin"]],
    ["Benzoyl peroxide/Erythromycin (Topical)", false, ["benzoyl peroxide", "erythromycin"]],
    ["Benzoyl peroxide/Hydrocortisone (Topical)", false, ["benzoyl peroxide", "hydrocortisone"]],
    ["Benzoyl peroxide/Salicylic acid (Pack)", false, ["benzoyl peroxide", "salicylic acid"]],
    ["Benzoyl peroxide/Salicylic acid (Topical)", false, ["benzoyl peroxide", "salicylic acid"]],
    ["Benzoyl peroxide/Sulfur (Topical)", false, ["benzoyl peroxide", "sulfur"]],
    ["Benzoyl peroxide/Tretinoin (Topical)", false, ["benzoyl peroxide", "tretinoin"]],
    ["Benzphetamine (Oral Pill)", true, ["benzphetamine"]],
    ["Benztropine (Injectable)", false, ["benztropine"]],
    ["Benztropine (Oral Pill)", true, ["benztropine"]],
    ["Benzyl alcohol (Oral Gel)", true, ["benzyl alcohol"]],
    ["Benzyl alcohol (Topical)", false, ["benzyl alcohol"]],
    ["Benzyl alcohol/Camphor/Menthol (Topical)", false, ["benzyl alcohol", "camphor", "menthol"]],
    ["Benzyl alcohol/Lidocaine (Topical)", false, ["benzyl alcohol", "lidocaine"]],
    ["Benzyl alcohol/Pramoxine (Topical)", false, ["benzyl alcohol", "pramoxine"]],
    ["Benzyl alcohol/Zinc chloride (Mucosal)", false, ["benzyl alcohol", "zinc chloride"]],
    ["BEOVU (Injectable)", false, ["brolucizumab"]],
    ["Bepotastine (Ophthalmic)", false, ["bepotastine"]],
    ["BEPREVE (Ophthalmic)", false, ["bepotastine"]],
    ["BEQALZI (Oral Pill)", true, ["sonrotoclax"]],
    ["BEQALZI STARTER PACK (Pack)", true, ["sonrotoclax"]],
    ["BEQVEZ (Injectable)", false, ["fidanacogene elaparvovec"]],
    ["BEQVEZ KIT 115 - 135 KG (Pack)", false, ["fidanacogene elaparvovec"]],
    ["BEQVEZ KIT 75 - 95 KG (Pack)", false, ["fidanacogene elaparvovec"]],
    ["BEQVEZ KIT 95 - 115 KG (Pack)", false, ["fidanacogene elaparvovec"]],
    ["BEQVEZ KIT < 75 KG (Pack)", false, ["fidanacogene elaparvovec"]],
    ["Beractant (Intratracheal)", false, ["beractant"]],
    ["Berahyaluronidase alfa/Pembrolizumab (Injectable)", false, ["berahyaluronidase alfa", "pembrolizumab"]],
    ["Berdazimer (Topical)", false, ["berdazimer"]],
    ["Beremagene geperpavec (Topical)", false, ["beremagene geperpavec"]],
    ["BERINERT (Injectable)", false, ["C1 esterase inhibitor"]],
    ["Berotralstat (Oral Pellet)", true, ["berotralstat"]],
    ["Berotralstat (Oral Pill)", true, ["berotralstat"]],
    ["BESER (Topical)", false, ["fluticasone"]],
    ["Besifloxacin (Ophthalmic)", false, ["besifloxacin"]],
    ["BESIVANCE (Ophthalmic)", false, ["besifloxacin"]],
    ["BESPONSA (Injectable)", false, ["inotuzumab ozogamicin"]],
    ["BESREMI (Injectable)", false, ["ropeginterferon alfa-2b"]],
    ["Beta carotene (Oral Pill)", true, ["beta carotene"]],
    ["BETA-HC (Topical)", false, ["hydrocortisone"]],
    ["BETADINE (Mouthwash)", false, ["povidone-iodine"]],
    ["BETADINE (Ophthalmic)", false, ["povidone-iodine"]],
    ["BETADINE (Soap)", false, ["povidone-iodine"]],
    ["BETADINE (Topical)", false, ["povidone-iodine"]],
    ["BETAGAN (Ophthalmic)", false, ["levobunolol"]],
    ["Betaine (Oral Pill)", true, ["betaine"]],
    ["Betaine (Oral Solution Powder)", true, ["betaine"]],
    ["Betaine/Bromelains/Pancreatin/Papain/Pepsin A (Oral Pill)", true, ["betaine", "bromelains", "pancreatin", "papain", "pepsin A"]],
    ["Betaine/Folic acid/Mecobalamin/Pyridoxine (Oral Pill)", true, ["betaine", "folic acid", "mecobalamin", "pyridoxine"]],
    ["Betamethasone (Injectable)", false, ["betamethasone"]],
    ["Betamethasone (Topical)", false, ["betamethasone"]],
    ["Betamethasone/Calcipotriene (Topical)", false, ["betamethasone", "calcipotriene"]],
    ["Betamethasone/Clotrimazole (Topical)", false, ["betamethasone", "clotrimazole"]],
    ["BETAPACE (Oral Pill)", true, ["sotalol"]],
    ["BETASEPT (Soap)", false, ["chlorhexidine"]],
    ["BETASERON (Injectable)", false, ["interferon beta-1b"]],
    ["Betaxolol (Ophthalmic)", false, ["betaxolol"]],
    ["Betaxolol (Oral Pill)", true, ["betaxolol"]],
    ["Bethanechol (Oral Pill)", true, ["bethanechol"]],
    ["BETHKIS (Inhalant)", false, ["tobramycin"]],
    ["Betibeglogene autotemcel (Injectable)", false, ["betibeglogene autotemcel"]],
    ["BETIMOL (Ophthalmic)", false, ["timolol"]],
    ["BETOPTIC S (Ophthalmic)", false, ["betaxolol"]],
    ["Bevacizumab (Injectable)", false, ["bevacizumab"]],
    ["BEVESPI (Inhalant)", false, ["formoterol", "glycopyrronium"]],
    ["Bexagliflozin (Oral Pill)", true, ["bexagliflozin"]],
    ["Bexarotene (Oral Pill)", true, ["bexarotene"]],
    ["Bexarotene (Topical)", false, ["bexarotene"]],
    ["BEXLUTRY (Injectable)", false, ["dotatate"]],
    ["BEXSERO (Injectable)", false, ["meningococcal group B vaccine"]],
    ["BEYAZ 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol", "levomefolate"]],
    ["BEYFORTUS (Injectable)", false, ["nirsevimab"]],
    ["Bezlotoxumab (Injectable)", false, ["bezlotoxumab"]],
    ["Bicalutamide (Oral Pill)", true, ["bicalutamide"]],
    ["BICARSIM (Chewable)", true, ["simethicone"]],
    ["BICARSIM (Oral Pill)", true, ["simethicone"]],
    ["BICILLIN (Injectable)", false, ["penicillin G benzathine", "penicillin G procaine"]],
    ["BICILLIN L-A (Injectable)", false, ["penicillin G benzathine"]],
    ["BICNU (Injectable)", false, ["carmustine"]],
    ["Bictegravir/Emtricitabine/Tenofovir alafenamide (Oral Pill)", true, ["bictegravir", "emtricitabine", "tenofovir alafenamide"]],
    ["Bictegravir/Lenacapavir (Oral Pill)", true, ["bictegravir", "lenacapavir"]],
    ["BIDEX (Oral Pill)", true, ["guaifenesin"]],
    ["BIDIL (Oral Pill)", true, ["hydralazine", "isosorbide dinitrate"]],
    ["BIFERA (Oral Pill)", true, ["Fe heme polypeptide", "polysaccharide iron complex"]],
    ["Bifidobacterium animalis (Oral Liquid)", true, ["Bifidobacterium animalis"]],
    ["Bifidobacterium animalis (Oral Pill)", true, ["Bifidobacterium animalis"]],
    ["Bifidobacterium animalis/Bifidobacterium longum/Lactobacillus acidophilus (Oral Pill)", true, ["Bifidobacterium animalis", "Bifidobacterium longum", "Lactobacillus acidophilus"]],
    ["Bifidobacterium animalis/Lactobacillus acidophilus (Oral Pill)", true, ["Bifidobacterium animalis", "Lactobacillus acidophilus"]],
    ["Bifidobacterium bifidum (Oral Powder)", true, ["Bifidobacterium bifidum"]],
    ["Bifidobacterium bifidum/Bifidobacterium longum (Oral Pill)", true, ["Bifidobacterium bifidum", "Bifidobacterium longum"]],
    ["Bifidobacterium infantis (Chewable)", true, ["Bifidobacterium infantis"]],
    ["Bifidobacterium infantis (Oral Pill)", true, ["Bifidobacterium infantis"]],
    ["Bifidobacterium infantis (Oral Suspension Powder)", true, ["Bifidobacterium infantis"]],
    ["BIJUVA (Oral Pill)", true, ["estradiol", "progesterone"]],
    ["BIKTARVY (Oral Pill)", true, ["bictegravir", "emtricitabine", "tenofovir alafenamide"]],
    ["BILDYOS (Injectable)", false, ["denosumab"]],
    ["BILPREVDA (Injectable)", false, ["denosumab"]],
    ["BILTRICIDE (Oral Pill)", true, ["praziquantel"]],
    ["Bimatoprost (Implant)", false, ["bimatoprost"]],
    ["Bimatoprost (Ophthalmic)", false, ["bimatoprost"]],
    ["Bimatoprost (Topical)", false, ["bimatoprost"]],
    ["Bimekizumab (Injectable)", false, ["bimekizumab"]],
    ["BIMZELX (Injectable)", false, ["bimekizumab"]],
    ["Binimetinib (Oral Pill)", true, ["binimetinib"]],
    ["BINOSTO (Effervescent)", true, ["alendronate"]],
    ["BIO-STATIN (Oral Pill)", true, ["nystatin"]],
    ["BIOFREEZE (Topical)", false, ["menthol"]],
    ["BIOLON (Ophthalmic)", false, ["hyaluronate"]],
    ["BION TEARS (Ophthalmic)", false, ["dextran 70", "hypromellose"]],
    ["BIONECT (Topical)", false, ["hyaluronate"]],
    ["BIORPHEN (Injectable)", false, ["phenylephrine"]],
    ["BIOTHRAX (Injectable)", false, ["Bacillus anthracis strain V770-NP1-R antigens"]],
    ["Biotin (Chewable)", true, ["biotin"]],
    ["Biotin (Oral Disintegrating)", true, ["biotin"]],
    ["Biotin (Oral Pill)", true, ["biotin"]],
    ["Biotin (Sublingual)", false, ["biotin"]],
    ["Biotin/Calcium carbonate (Oral Pill)", true, ["biotin", "calcium carbonate"]],
    ["Biotin/Chromium picolinate (Oral Pill)", true, ["biotin", "chromium picolinate"]],
    ["Biotin/Cysteine/Silicon dioxide (Oral Pill)", true, ["biotin", "cysteine", "silicon dioxide"]],
    ["Birch triterpenes (Topical)", false, ["birch triterpenes"]],
    ["BISAC-EVAC (Oral Pill)", true, ["bisacodyl"]],
    ["BISAC-EVAC (Rectal)", false, ["bisacodyl"]],
    ["Bisacodyl (Oral Pill)", true, ["bisacodyl"]],
    ["Bisacodyl (Rectal)", false, ["bisacodyl"]],
    ["Bisacodyl/Polyethylene glycol 3350/Potassium chloride/Sodium bicarbonate/Sodium chloride (Pack)", false, ["bisacodyl", "polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride"]],
    ["BISMAREX (Chewable)", true, ["bismuth subsalicylate"]],
    ["Bismuth subcitrate/metroNIDAZOLE/Tetracycline (Oral Pill)", true, ["bismuth subcitrate", "metronidazole", "tetracycline"]],
    ["Bismuth subgallate (Chewable)", true, ["bismuth subgallate"]],
    ["Bismuth subgallate (Oral Pill)", true, ["bismuth subgallate"]],
    ["Bismuth subsalicylate (Chewable)", true, ["bismuth subsalicylate"]],
    ["Bismuth subsalicylate (Oral Liquid)", true, ["bismuth subsalicylate"]],
    ["Bismuth subsalicylate (Oral Pill)", true, ["bismuth subsalicylate"]],
    ["Bismuth subsalicylate/metroNIDAZOLE/Tetracycline (Pack)", false, ["bismuth subsalicylate", "metronidazole", "tetracycline"]],
    ["Bismuth-formic-iodide (Topical)", false, ["bismuth-formic-iodide"]],
    ["Bisoprolol (Oral Pill)", true, ["bisoprolol"]],
    ["Bisoprolol/hydroCHLOROthiazide (Oral Pill)", true, ["bisoprolol", "hydrochlorothiazide"]],
    ["Bivalirudin (Injectable)", false, ["bivalirudin"]],
    ["BIVIGAM (Injectable)", false, ["immunoglobulin G"]],
    ["BIXLENVO (Oral Pill)", true, ["bictegravir", "lenacapavir"]],
    ["BIZENGRI (Injectable)", false, ["zenocutuzumab"]],
    ["BKEMV (Injectable)", false, ["eculizumab"]],
    ["Black currant oil/Vitamin E (Oral Pill)", true, ["black currant oil", "vitamin E"]],
    ["BLENREP (Injectable)", false, ["belantamab mafodotin"]],
    ["Bleomycin (Injectable)", false, ["bleomycin"]],
    ["BLEPHAMIDE (Ophthalmic)", false, ["prednisolone", "sulfacetamide"]],
    ["Blinatumomab (Injectable)", false, ["blinatumomab"]],
    ["BLINCYTO (Injectable)", false, ["blinatumomab"]],
    ["BLINK DRY EYE (Ophthalmic)", false, ["glycerin"]],
    ["BLINK TEARS (Ophthalmic)", false, ["polyethylene glycol 400"]],
    ["BLIS-TO-SOL (Topical)", false, ["tolnaftate"]],
    ["BLIS-TO-SOL POWDER (Topical)", false, ["undecylenate"]],
    ["BLISOVI 21 FE 1.5/30 28 DAY PACK (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["BLISOVI 21 FE 1/20 28 DAY PACK (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["BLISOVI 24 FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["BLOXIVERZ (Injectable)", false, ["neostigmine"]],
    ["BLUJEPA (Oral Pill)", true, ["gepotidacin"]],
    ["BOIL-EASE (Topical)", false, ["benzocaine"]],
    ["BOMYNTRA (Injectable)", false, ["denosumab"]],
    ["BONCRESA (Injectable)", false, ["denosumab"]],
    ["BONDLIDO (Topical)", false, ["lidocaine"]],
    ["BONINE (Chewable)", true, ["meclizine"]],
    ["BONIVA (Injectable)", false, ["ibandronate"]],
    ["BONIVA (Oral Pill)", true, ["ibandronate"]],
    ["BONJESTA XR (Oral Pill)", true, ["doxylamine", "pyridoxine"]],
    ["BONSITY (Injectable)", false, ["teriparatide"]],
    ["BOOSTRIX (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["Borage oil (Oral Pill)", true, ["borage oil"]],
    ["BOROLEUM (Topical)", false, ["camphor", "menthol", "petrolatum"]],
    ["Boron/Calcium carbonate (Oral Pill)", true, ["boron", "calcium carbonate"]],
    ["Bortezomib (Injectable)", false, ["bortezomib"]],
    ["BORUZU (Injectable)", false, ["bortezomib"]],
    ["BOSAYA (Injectable)", false, ["denosumab"]],
    ["Bosentan (Oral Pill)", true, ["bosentan"]],
    ["Bosentan (Oral Suspension Tablet)", true, ["bosentan"]],
    ["BOSULIF (Oral Pill)", true, ["bosutinib"]],
    ["Bosutinib (Oral Pill)", true, ["bosutinib"]],
    ["BOTOX (Injectable)", false, ["botulinum toxin type A"]],
    ["BOTOX COSMETIC (Injectable)", false, ["botulinum toxin type A"]],
    ["Botulinum toxin type A (Injectable)", false, ["botulinum toxin type A"]],
    ["Botulinum toxin type B (Injectable)", false, ["botulinum toxin type B"]],
    ["Botulism immune globulin IV human (Injectable)", false, ["botulism immune globulin IV human"]],
    ["BP 10-WASH (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["BP CLEANSING WASH (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["BRAFTOVI (Oral Pill)", true, ["encorafenib"]],
    ["Bran (Chewable)", true, ["bran"]],
    ["BREKIYA (Injectable)", false, ["dihydroergotamine"]],
    ["Bremelanotide (Injectable)", false, ["bremelanotide"]],
    ["Brensocatib (Oral Pill)", true, ["brensocatib"]],
    ["Brentuximab vedotin (Injectable)", false, ["brentuximab vedotin"]],
    ["BRENZAVVY (Oral Pill)", true, ["bexagliflozin"]],
    ["BREO (Inhalant)", false, ["fluticasone", "vilanterol"]],
    ["Brepocitinib (Oral Pill)", true, ["brepocitinib"]],
    ["Bretylium (Injectable)", false, ["bretylium"]],
    ["BREVIBLOC (Injectable)", false, ["esmolol"]],
    ["BREVITAL (Injectable)", false, ["methohexital"]],
    ["BREXAFEMME (Oral Pill)", true, ["ibrexafungerp"]],
    ["BREXAFEMME KIT (Pack)", true, ["ibrexafungerp"]],
    ["Brexanolone (Injectable)", false, ["brexanolone"]],
    ["Brexpiprazole (Oral Pill)", true, ["brexpiprazole"]],
    ["Brexucabtagene autoleucel (Injectable)", false, ["brexucabtagene autoleucel"]],
    ["BREYANZI (Injectable)", false, ["lisocabtagene maraleucel"]],
    ["BREYNA (Inhalant)", false, ["budesonide", "formoterol"]],
    ["BREZTRI (Inhalant)", false, ["budesonide", "formoterol", "glycopyrronium"]],
    ["BRIDION (Injectable)", false, ["sugammadex"]],
    ["BRIELLYN 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Brigatinib (Oral Pill)", true, ["brigatinib"]],
    ["Brigatinib (Pack)", true, ["brigatinib"]],
    ["BRILINTA (Oral Pill)", true, ["ticagrelor"]],
    ["Brilliant green/Gentian violet/Proflavine (Topical)", false, ["brilliant green", "gentian violet", "proflavine"]],
    ["Brimonidine (Ophthalmic)", false, ["brimonidine"]],
    ["Brimonidine (Topical)", false, ["brimonidine"]],
    ["Brimonidine/Brinzolamide (Ophthalmic)", false, ["brimonidine", "brinzolamide"]],
    ["Brimonidine/Carbachol (Ophthalmic)", false, ["brimonidine", "carbachol"]],
    ["Brimonidine/Timolol (Ophthalmic)", false, ["brimonidine", "timolol"]],
    ["Brincidofovir (Oral Liquid)", true, ["brincidofovir"]],
    ["Brincidofovir (Oral Pill)", true, ["brincidofovir"]],
    ["Brincidofovir (Pack)", true, ["brincidofovir"]],
    ["BRINEURA (Injectable)", false, ["cerliponase"]],
    ["BRINSUPRI (Oral Pill)", true, ["brensocatib"]],
    ["Brinzolamide (Ophthalmic)", false, ["brinzolamide"]],
    ["BRISDELLE (Oral Pill)", true, ["paroxetine"]],
    ["BRIUMVI (Injectable)", false, ["ublituximab"]],
    ["Brivaracetam (Injectable)", false, ["brivaracetam"]],
    ["Brivaracetam (Oral Liquid)", true, ["brivaracetam"]],
    ["Brivaracetam (Oral Pill)", true, ["brivaracetam"]],
    ["BRIVIACT (Injectable)", false, ["brivaracetam"]],
    ["BRIVIACT (Oral Liquid)", true, ["brivaracetam"]],
    ["BRIVIACT (Oral Pill)", true, ["brivaracetam"]],
    ["BRIXADI (Injectable)", false, ["buprenorphine"]],
    ["Brodalumab (Injectable)", false, ["brodalumab"]],
    ["Brolucizumab (Injectable)", false, ["brolucizumab"]],
    ["Bromelains (Chewable)", true, ["bromelains"]],
    ["Bromelains (Oral Pill)", true, ["bromelains"]],
    ["BROMFED DM (Oral Liquid)", true, ["brompheniramine", "dextromethorphan", "pseudoephedrine"]],
    ["Bromfenac (Ophthalmic)", false, ["bromfenac"]],
    ["Bromocriptine (Oral Pill)", true, ["bromocriptine"]],
    ["Brompheniramine (Chewable)", true, ["brompheniramine"]],
    ["Brompheniramine (Oral Liquid)", true, ["brompheniramine"]],
    ["Brompheniramine XR (Oral Pill)", true, ["brompheniramine"]],
    ["Brompheniramine/Codeine (Oral Pill)", true, ["brompheniramine", "codeine"]],
    ["Brompheniramine/Dextromethorphan (Oral Liquid)", true, ["brompheniramine", "dextromethorphan"]],
    ["Brompheniramine/Phenylephrine (Oral Liquid)", true, ["brompheniramine", "phenylephrine"]],
    ["Brompheniramine/Phenylephrine (Oral Pill)", true, ["brompheniramine", "phenylephrine"]],
    ["Brompheniramine/Phenylephrine XR (Oral Pill)", true, ["brompheniramine", "phenylephrine"]],
    ["Brompheniramine/Pseudoephedrine (Oral Liquid)", true, ["brompheniramine", "pseudoephedrine"]],
    ["Brompheniramine/Pseudoephedrine XR (Oral Pill)", true, ["brompheniramine", "pseudoephedrine"]],
    ["BROMSITE (Ophthalmic)", false, ["bromfenac"]],
    ["BRONCHITOL (Inhalant)", false, ["mannitol"]],
    ["BRONKAID (Oral Pill)", true, ["ephedrine", "guaifenesin"]],
    ["BRONKAID MAX (Oral Pill)", true, ["ephedrine"]],
    ["BROVANA (Inhalant)", false, ["arformoterol"]],
    ["BROVEX CB (Oral Pill)", true, ["brompheniramine", "codeine"]],
    ["BROVEX PBC (Oral Pill)", true, ["brompheniramine", "codeine", "phenylephrine"]],
    ["BRUKINSA (Oral Pill)", true, ["zanubrutinib"]],
    ["BRUSELIX (Topical)", false, ["lidocaine"]],
    ["BRYHALI (Topical)", false, ["halobetasol"]],
    ["BRYNOVIN (Oral Liquid)", true, ["sitagliptin"]],
    ["BSS OPHTHALMIC SOLUTION (Ophthalmic)", false, ["calcium chloride", "magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium citrate"]],
    ["BUCALSEP (Mucosal)", false, ["benzocaine", "cetylpyridinium", "menthol", "zinc chloride"]],
    ["BUCAPSOL (Oral Pill)", true, ["buspirone"]],
    ["BUCKLEY'S COUGH SUPPRESSANT (Oral Liquid)", true, ["dextromethorphan"]],
    ["Budesonide (Inhalant)", false, ["budesonide"]],
    ["Budesonide (Nasal)", false, ["budesonide"]],
    ["Budesonide (Oral Liquid)", true, ["budesonide"]],
    ["Budesonide (Oral Pill)", true, ["budesonide"]],
    ["Budesonide (Rectal)", false, ["budesonide"]],
    ["Budesonide XR (Oral Pill)", true, ["budesonide"]],
    ["Budesonide/Formoterol (Inhalant)", false, ["budesonide", "formoterol"]],
    ["Budesonide/Formoterol/Glycopyrronium (Inhalant)", false, ["budesonide", "formoterol", "glycopyrronium"]],
    ["BUFFERIN (Oral Pill)", true, ["aspirin"]],
    ["Bulevirtide (Injectable)", false, ["bulevirtide"]],
    ["Bumetanide (Injectable)", false, ["bumetanide"]],
    ["Bumetanide (Nasal)", false, ["bumetanide"]],
    ["Bumetanide (Oral Pill)", true, ["bumetanide"]],
    ["BUMEX (Oral Pill)", true, ["bumetanide"]],
    ["BUNAVAIL (Buccal)", false, ["buprenorphine", "naloxone"]],
    ["BUPAP (Oral Pill)", true, ["acetaminophen", "butalbital"]],
    ["BUPHENYL (Oral Pill)", true, ["phenylbutyrate"]],
    ["BUPHENYL (Oral Powder)", true, ["phenylbutyrate"]],
    ["BUPivacaine (Implant)", false, ["bupivacaine"]],
    ["BUPivacaine (Injectable)", false, ["bupivacaine"]],
    ["BUPivacaine (Pack)", false, ["bupivacaine"]],
    ["BUPivacaine/EPINEPHrine (Injectable)", false, ["bupivacaine", "epinephrine"]],
    ["BUPivacaine/Meloxicam (Injectable)", false, ["bupivacaine", "meloxicam"]],
    ["BUPRENEX (Injectable)", false, ["buprenorphine"]],
    ["Buprenorphine (Buccal)", false, ["buprenorphine"]],
    ["Buprenorphine (Injectable)", false, ["buprenorphine"]],
    ["Buprenorphine (Sublingual)", false, ["buprenorphine"]],
    ["Buprenorphine (Transdermal)", false, ["buprenorphine"]],
    ["Buprenorphine/Naloxone (Buccal)", false, ["buprenorphine", "naloxone"]],
    ["Buprenorphine/Naloxone (Sublingual)", false, ["buprenorphine", "naloxone"]],
    ["buPROPion (Oral Pill)", true, ["bupropion"]],
    ["buPROPion XR (Oral Pill)", true, ["bupropion"]],
    ["buPROPion/Dextromethorphan (Pack)", true, ["bupropion", "dextromethorphan"]],
    ["buPROPion/Dextromethorphan XR (Oral Pill)", true, ["bupropion", "dextromethorphan"]],
    ["buPROPion/Naltrexone XR (Oral Pill)", true, ["bupropion", "naltrexone"]],
    ["BURN JEL PLUS (Topical)", false, ["lidocaine"]],
    ["Burosumab (Injectable)", false, ["burosumab"]],
    ["BUSPAR (Oral Pill)", true, ["buspirone"]],
    ["busPIRone (Oral Pill)", true, ["buspirone"]],
    ["Busulfan (Injectable)", false, ["busulfan"]],
    ["Busulfan (Oral Pill)", true, ["busulfan"]],
    ["BUSULFEX (Injectable)", false, ["busulfan"]],
    ["Butenafine (Topical)", false, ["butenafine"]],
    ["Butoconazole (Vaginal)", false, ["butoconazole"]],
    ["Butorphanol (Injectable)", false, ["butorphanol"]],
    ["Butorphanol (Nasal)", false, ["butorphanol"]],
    ["BUTRANS (Transdermal)", false, ["buprenorphine"]],
    ["BYDUREON (Injectable)", false, ["exenatide"]],
    ["BYETTA (Injectable)", false, ["exenatide"]],
    ["BYFAVO (Injectable)", false, ["remimazolam"]],
    ["BYLVAY (Oral Pellet)", true, ["odevixibat"]],
    ["BYLVAY (Oral Pill)", true, ["odevixibat"]],
    ["BYNFEZIA (Injectable)", false, ["octreotide"]],
    ["BYOOVIZ (Injectable)", false, ["ranibizumab"]],
    ["BYQLOVI (Ophthalmic)", false, ["clobetasol"]],
    ["BYSANTI (Oral Pill)", true, ["milsaperidone"]],
    ["BYSANTI TITRATION PACK A (Pack)", true, ["milsaperidone"]],
    ["BYSANTI TITRATION PACK B (Pack)", true, ["milsaperidone"]],
    ["BYSANTI TITRATION PACK C (Pack)", true, ["milsaperidone"]],
    ["BYSTOLIC (Oral Pill)", true, ["nebivolol"]],
    ["BYVALSON (Oral Pill)", true, ["nebivolol", "valsartan"]],
    ["C-TIME (Oral Pill)", true, ["ascorbic acid"]],
    ["C1 esterase inhibitor (Injectable)", false, ["C1 esterase inhibitor"]],
    ["Cabazitaxel (Injectable)", false, ["cabazitaxel"]],
    ["CABENUVA 400 MG / 600 MG (Pack)", false, ["cabotegravir", "rilpivirine"]],
    ["CABENUVA 600 MG / 900 MG (Pack)", false, ["cabotegravir", "rilpivirine"]],
    ["Cabergoline (Oral Pill)", true, ["cabergoline"]],
    ["CABLIVI (Injectable)", false, ["caplacizumab"]],
    ["CABOMETYX (Oral Pill)", true, ["cabozantinib"]],
    ["Cabotegravir (Injectable)", false, ["cabotegravir"]],
    ["Cabotegravir (Oral Pill)", true, ["cabotegravir"]],
    ["Cabotegravir/Rilpivirine (Pack)", false, ["cabotegravir", "rilpivirine"]],
    ["Cabozantinib (Oral Pill)", true, ["cabozantinib"]],
    ["Cabozantinib (Pack)", true, ["cabozantinib"]],
    ["CABTREO (Topical)", false, ["adapalene", "benzoyl peroxide", "clindamycin"]],
    ["Cadexomer iodine (Topical)", false, ["cadexomer iodine"]],
    ["CADUET (Oral Pill)", true, ["amlodipine", "atorvastatin"]],
    ["CAELYX (Injectable)", false, ["doxorubicin"]],
    ["CAFCIT (Injectable)", false, ["caffeine"]],
    ["CAFERGOT (Oral Pill)", true, ["caffeine", "ergotamine"]],
    ["Caffeine (Chewable)", true, ["caffeine"]],
    ["Caffeine (Injectable)", false, ["caffeine"]],
    ["Caffeine (Oral Liquid)", true, ["caffeine"]],
    ["Caffeine (Oral Pill)", true, ["caffeine"]],
    ["Caffeine/Ergotamine (Oral Pill)", true, ["caffeine", "ergotamine"]],
    ["Caffeine/Ergotamine (Rectal)", false, ["caffeine", "ergotamine"]],
    ["Caffeine/Magnesium salicylate (Oral Pill)", true, ["caffeine", "magnesium salicylate"]],
    ["CAL GEST (Chewable)", true, ["calcium carbonate"]],
    ["CALACLEAR (Topical)", false, ["pramoxine", "zinc acetate"]],
    ["CALADRYL (Topical)", false, ["calamine", "pramoxine"]],
    ["CALADRYL CLEAR (Topical)", false, ["pramoxine", "zinc acetate"]],
    ["CALAGEL (Topical)", false, ["benzethonium", "diphenhydramine", "zinc acetate"]],
    ["CALAGEL REFORMULATED JUN 2019 (Topical)", false, ["diphenhydramine"]],
    ["CALAGESIC (Topical)", false, ["calamine", "pramoxine"]],
    ["Calamine/diphenhydrAMINE (Topical)", false, ["calamine", "diphenhydramine"]],
    ["Calamine/Menthol/Petrolatum/Zinc oxide (Paste)", false, ["calamine", "menthol", "petrolatum", "zinc oxide"]],
    ["Calamine/Menthol/Zinc oxide (Topical)", false, ["calamine", "menthol", "zinc oxide"]],
    ["Calamine/Phenol/Zinc oxide (Topical)", false, ["calamine", "phenol", "zinc oxide"]],
    ["Calamine/Pramoxine (Topical)", false, ["calamine", "pramoxine"]],
    ["Calamine/Zinc oxide (Topical)", false, ["calamine", "zinc oxide"]],
    ["CALAN XR (Oral Pill)", true, ["verapamil"]],
    ["Calaspargase pegol (Injectable)", false, ["calaspargase pegol"]],
    ["CALCET (Chewable)", true, ["calcium citrate", "cholecalciferol"]],
    ["CALCIDOL (Oral Liquid)", true, ["ergocalciferol"]],
    ["Calcifediol XR (Oral Pill)", true, ["calcifediol"]],
    ["Calcipotriene (Topical)", false, ["calcipotriene"]],
    ["CALCITRENE (Topical)", false, ["calcipotriene"]],
    ["Calcitriol (Injectable)", false, ["calcitriol"]],
    ["Calcitriol (Oral Liquid)", true, ["calcitriol"]],
    ["Calcitriol (Oral Pill)", true, ["calcitriol"]],
    ["Calcitriol (Topical)", false, ["calcitriol"]],
    ["Calcium acetate (Oral Liquid)", true, ["calcium acetate"]],
    ["Calcium acetate (Oral Pill)", true, ["calcium acetate"]],
    ["Calcium ascorbate/Calcium carbonate/Cholecalciferol/Folic acid/Pyridoxine (Oral Pill)", true, ["calcium ascorbate", "calcium carbonate", "cholecalciferol", "folic acid", "pyridoxine"]],
    ["Calcium ascorbate/Ferrous asparto glycinate/Polysaccharide iron complex/Succinic acid (Oral Pill)", true, ["calcium ascorbate", "ferrous asparto glycinate", "polysaccharide iron complex", "succinic acid"]],
    ["Calcium carbonate (Chewable)", true, ["calcium carbonate"]],
    ["Calcium carbonate (Oral Liquid)", true, ["calcium carbonate"]],
    ["Calcium carbonate (Oral Lozenge)", true, ["calcium carbonate"]],
    ["Calcium carbonate (Oral Pill)", true, ["calcium carbonate"]],
    ["Calcium carbonate (Oral Powder)", true, ["calcium carbonate"]],
    ["Calcium carbonate/Cholecalciferol (Chewable)", true, ["calcium carbonate", "cholecalciferol"]],
    ["Calcium carbonate/Cholecalciferol (Oral Liquid)", true, ["calcium carbonate", "cholecalciferol"]],
    ["Calcium carbonate/Cholecalciferol (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["Calcium carbonate/Cholecalciferol XR (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["Calcium carbonate/Cholecalciferol/Magnesium oxide (Oral Pill)", true, ["calcium carbonate", "cholecalciferol", "magnesium oxide"]],
    ["Calcium carbonate/Cholecalciferol/Vitamin K (Chewable)", true, ["calcium carbonate", "cholecalciferol", "vitamin K"]],
    ["Calcium carbonate/Cholecalciferol/Vitamin K1 (Chewable)", true, ["calcium carbonate", "cholecalciferol", "vitamin K1"]],
    ["Calcium carbonate/Ergocalciferol (Oral Pill)", true, ["calcium carbonate", "ergocalciferol"]],
    ["Calcium carbonate/Famotidine/Magnesium hydroxide (Chewable)", true, ["calcium carbonate", "famotidine", "magnesium hydroxide"]],
    ["Calcium carbonate/Folic acid/Pyridoxine/Vitamin B12 XR (Oral Pill)", true, ["calcium carbonate", "folic acid", "pyridoxine", "vitamin B12"]],
    ["Calcium carbonate/Folic acid/Vitamin B complex XR (Oral Pill)", true, ["calcium carbonate", "folic acid", "vitamin B complex"]],
    ["Calcium carbonate/Magnesium carbonate (Oral Pill)", true, ["calcium carbonate", "magnesium carbonate"]],
    ["Calcium carbonate/Magnesium chloride (Oral Pill)", true, ["calcium carbonate", "magnesium chloride"]],
    ["Calcium carbonate/Magnesium hydroxide (Chewable)", true, ["calcium carbonate", "magnesium hydroxide"]],
    ["Calcium carbonate/Magnesium hydroxide (Oral Liquid)", true, ["calcium carbonate", "magnesium hydroxide"]],
    ["Calcium carbonate/Magnesium oxide (Oral Pill)", true, ["calcium carbonate", "magnesium oxide"]],
    ["Calcium carbonate/Monofluorophosphate (Oral Pill)", true, ["calcium carbonate", "monofluorophosphate"]],
    ["Calcium carbonate/Prasterone (Oral Pill)", true, ["calcium carbonate", "prasterone"]],
    ["Calcium carbonate/Simethicone (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["Calcium carbonate/Simethicone (Oral Liquid)", true, ["calcium carbonate", "simethicone"]],
    ["Calcium carbonate/Sodium fluoride (Oral Pill)", true, ["calcium carbonate", "sodium fluoride"]],
    ["Calcium chloride (Injectable)", false, ["calcium chloride"]],
    ["Calcium chloride/Glucose/Lactate/Magnesium chloride/Sodium chloride (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["Calcium chloride/Glucose/Lactate/Potassium chloride/Sodium chloride (Injectable)", false, ["calcium chloride", "glucose", "lactate", "potassium chloride", "sodium chloride"]],
    ["Calcium chloride/Icodextrin/Lactate/Magnesium chloride/Sodium chloride (Injectable)", false, ["calcium chloride", "icodextrin", "lactate", "magnesium chloride", "sodium chloride"]],
    ["Calcium chloride/Lactate/Potassium chloride/Sodium chloride (Injectable)", false, ["calcium chloride", "lactate", "potassium chloride", "sodium chloride"]],
    ["Calcium chloride/Lactate/Potassium chloride/Sodium chloride (Irrigation)", false, ["calcium chloride", "lactate", "potassium chloride", "sodium chloride"]],
    ["Calcium chloride/Magnesium chloride/Potassium acetate/Sodium acetate/Sodium chloride (Injectable)", false, ["calcium chloride", "magnesium chloride", "potassium acetate", "sodium acetate", "sodium chloride"]],
    ["Calcium chloride/Magnesium chloride/Potassium chloride/Sodium acetate/Sodium chloride (Injectable)", false, ["calcium chloride", "magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride"]],
    ["Calcium chloride/Potassium chloride/Sodium chloride (Injectable)", false, ["calcium chloride", "potassium chloride", "sodium chloride"]],
    ["Calcium chloride/Potassium chloride/Sodium chloride (Irrigation)", false, ["calcium chloride", "potassium chloride", "sodium chloride"]],
    ["Calcium citrate (Oral Pill)", true, ["calcium citrate"]],
    ["Calcium citrate/Cholecalciferol (Chewable)", true, ["calcium citrate", "cholecalciferol"]],
    ["Calcium citrate/Cholecalciferol (Oral Pill)", true, ["calcium citrate", "cholecalciferol"]],
    ["Calcium citrate/Cholecalciferol/Magnesium citrate (Chewable)", true, ["calcium citrate", "cholecalciferol", "magnesium citrate"]],
    ["Calcium citrate/Ergocalciferol (Oral Pill)", true, ["calcium citrate", "ergocalciferol"]],
    ["Calcium gluconate (Injectable)", false, ["calcium gluconate"]],
    ["Calcium gluconate (Oral Pill)", true, ["calcium gluconate"]],
    ["Calcium gluconate (Topical)", false, ["calcium gluconate"]],
    ["Calcium glycerophosphate (Oral Pill)", true, ["calcium glycerophosphate"]],
    ["Calcium lactate (Oral Pill)", true, ["calcium lactate"]],
    ["Calcium phosphate/Magnesium carbonate/Potassium chloride (Oral Pill)", true, ["calcium phosphate", "magnesium carbonate", "potassium chloride"]],
    ["Calcium polycarbophil (Chewable)", true, ["calcium polycarbophil"]],
    ["Calcium polycarbophil (Oral Pill)", true, ["calcium polycarbophil"]],
    ["CALDECORT (Topical)", false, ["hydrocortisone"]],
    ["CALDESENE (Topical)", false, ["starch", "zinc oxide"]],
    ["CALDOLOR (Injectable)", false, ["ibuprofen"]],
    ["Calfactant (Intratracheal)", false, ["calfactant"]],
    ["CALGONATE (Topical)", false, ["calcium gluconate"]],
    ["CALMOL (Rectal)", false, ["cocoa butter", "zinc oxide"]],
    ["CALMOSEPTINE (Topical)", false, ["lanolin", "menthol", "petrolatum", "zinc oxide"]],
    ["CALPHRON (Oral Pill)", true, ["calcium acetate"]],
    ["CALPROTECT (Topical)", false, ["menthol", "zinc oxide"]],
    ["CALQUENCE (Oral Pill)", true, ["acalabrutinib"]],
    ["CALTRATE (Oral Pill)", true, ["calcium carbonate"]],
    ["CALTRATE GUMMY BITES (Chewable)", true, ["cholecalciferol", "tricalcium phosphate"]],
    ["CALTRATE PLUS D (Chewable)", true, ["calcium carbonate", "cholecalciferol"]],
    ["CALTRATE PLUS D (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["CAMBIA (Oral Solution Powder)", true, ["diclofenac"]],
    ["CAMCEVI (Injectable)", false, ["leuprolide"]],
    ["CAMILA 28 DAY (Pack)", true, ["norethindrone"]],
    ["Camizestrant (Oral Pill)", true, ["camizestrant"]],
    ["CAMPATH (Injectable)", false, ["alemtuzumab"]],
    ["CAMPHO-PHENIQUE (Topical)", false, ["camphor", "phenol"]],
    ["Camphor (Inhalant)", false, ["camphor"]],
    ["Camphor (Topical)", false, ["camphor"]],
    ["CAMPHOR ICE (Topical)", false, ["camphor"]],
    ["Camphor/Capsaicin/Menthol/Methyl salicylate (Topical)", false, ["camphor", "capsaicin", "menthol", "methyl salicylate"]],
    ["Camphor/Capsaicin/Methyl salicylate (Topical)", false, ["camphor", "capsaicin", "methyl salicylate"]],
    ["Camphor/Capsicum extract/Levomenthol (Topical)", false, ["Capsicum extract", "camphor", "levomenthol"]],
    ["Camphor/Capsicum extract/Menthol (Topical)", false, ["Capsicum extract", "camphor", "menthol"]],
    ["Camphor/Dimethicone/Lidocaine/Menthol (Topical)", false, ["camphor", "dimethicone", "lidocaine", "menthol"]],
    ["Camphor/Dimethicone/Menthol/Phenol (Topical)", false, ["camphor", "dimethicone", "menthol", "phenol"]],
    ["Camphor/Eucalyptus oil/Menthol (Topical)", false, ["Eucalyptus oil", "camphor", "menthol"]],
    ["Camphor/Levomenthol/Methyl salicylate (Topical)", false, ["camphor", "levomenthol", "methyl salicylate"]],
    ["Camphor/Lidocaine (Topical)", false, ["camphor", "lidocaine"]],
    ["Camphor/Lidocaine/Menthol (Topical)", false, ["camphor", "lidocaine", "menthol"]],
    ["Camphor/Lidocaine/Methyl salicylate (Topical)", false, ["camphor", "lidocaine", "methyl salicylate"]],
    ["Camphor/Menthol (Topical)", false, ["camphor", "menthol"]],
    ["Camphor/Menthol/Methyl salicylate (Topical)", false, ["camphor", "menthol", "methyl salicylate"]],
    ["Camphor/Menthol/Petrolatum (Topical)", false, ["camphor", "menthol", "petrolatum"]],
    ["Camphor/Phenol (Topical)", false, ["camphor", "phenol"]],
    ["Camphor/Phenol/Tannic acid/Zinc oxide (Topical)", false, ["camphor", "phenol", "tannic acid", "zinc oxide"]],
    ["CAMPTOSAR (Injectable)", false, ["irinotecan"]],
    ["CAMRESE 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["CAMRESELO 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["CAMZYOS (Oral Pill)", true, ["mavacamten"]],
    ["Canagliflozin (Oral Pill)", true, ["canagliflozin"]],
    ["Canagliflozin/metFORMIN (Oral Pill)", true, ["canagliflozin", "metformin"]],
    ["Canagliflozin/metFORMIN XR (Oral Pill)", true, ["canagliflozin", "metformin"]],
    ["Canakinumab (Injectable)", false, ["canakinumab"]],
    ["CANASA (Rectal)", false, ["mesalamine"]],
    ["CANCIDAS (Injectable)", false, ["caspofungin"]],
    ["Candesartan (Oral Pill)", true, ["candesartan"]],
    ["Candesartan/hydroCHLOROthiazide (Oral Pill)", true, ["candesartan", "hydrochlorothiazide"]],
    ["Cangrelor (Injectable)", false, ["cangrelor"]],
    ["Cannabidiol (Oral Liquid)", true, ["cannabidiol"]],
    ["Cantharidin (Topical)", false, ["cantharidin"]],
    ["CAPACET (Oral Pill)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["Capecitabine (Oral Pill)", true, ["capecitabine"]],
    ["Capivasertib (Oral Pill)", true, ["capivasertib"]],
    ["Caplacizumab (Injectable)", false, ["caplacizumab"]],
    ["CAPLYTA (Oral Pill)", true, ["lumateperone"]],
    ["Capmatinib (Oral Pill)", true, ["capmatinib"]],
    ["CAPRELSA (Oral Pill)", true, ["vandetanib"]],
    ["Capsaicin (Topical)", false, ["capsaicin"]],
    ["Capsaicin/Lidocaine (Topical)", false, ["capsaicin", "lidocaine"]],
    ["Capsaicin/Lidocaine/Menthol (Topical)", false, ["capsaicin", "lidocaine", "menthol"]],
    ["Capsaicin/Lidocaine/Menthol/Methyl salicylate (Topical)", false, ["capsaicin", "lidocaine", "menthol", "methyl salicylate"]],
    ["Capsaicin/Lidocaine/Trolamine salicylate (Topical)", false, ["capsaicin", "lidocaine", "trolamine salicylate"]],
    ["Capsaicin/Menthol (Topical)", false, ["capsaicin", "menthol"]],
    ["Capsaicin/Menthol/Methyl salicylate (Topical)", false, ["capsaicin", "menthol", "methyl salicylate"]],
    ["Capsaicin/Menthol/Methyl salicylate/Methylnicotinate (Topical)", false, ["capsaicin", "menthol", "methyl salicylate", "methylnicotinate"]],
    ["Capsaicin/Menthol/Methylnicotinate (Topical)", false, ["capsaicin", "menthol", "methylnicotinate"]],
    ["Capsaicin/Trolamine salicylate (Topical)", false, ["capsaicin", "trolamine salicylate"]],
    ["Capsaicin/Turpentine (Topical)", false, ["capsaicin", "turpentine"]],
    ["Capsicum extract/Levomenthol/Synthetic camphor (Topical)", false, ["Capsicum extract", "levomenthol", "synthetic camphor"]],
    ["Captopril (Oral Pill)", true, ["captopril"]],
    ["Captopril/hydroCHLOROthiazide (Oral Pill)", true, ["captopril", "hydrochlorothiazide"]],
    ["CAPVAXIVE (Injectable)", false, ["Streptococcus pneumoniae serotype 10A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 11A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 12F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 15A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 16F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 17F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 20A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 22F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 23A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 23B capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 24F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 3 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 31 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 33F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 35B capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 7F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 8 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 9N capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype DEOAC15B capsular antigen diphtheria CRM197 protein conjugate vaccine"]],
    ["CAPZASIN QUICK RELIEF (Topical)", false, ["capsaicin", "menthol"]],
    ["CAPZASIN-HP (Topical)", false, ["capsaicin"]],
    ["CAPZASIN-P (Topical)", false, ["capsaicin"]],
    ["CARAC (Topical)", false, ["fluorouracil"]],
    ["CARAFATE (Oral Liquid)", true, ["sucralfate"]],
    ["CARAFATE (Oral Pill)", true, ["sucralfate"]],
    ["Carbachol (Injectable)", false, ["carbachol"]],
    ["Carbachol (Ophthalmic)", false, ["carbachol"]],
    ["CARBAGLU (Oral Suspension Tablet)", true, ["carglumic acid"]],
    ["carBAMazepine (Chewable)", true, ["carbamazepine"]],
    ["carBAMazepine (Oral Liquid)", true, ["carbamazepine"]],
    ["carBAMazepine (Oral Pill)", true, ["carbamazepine"]],
    ["carBAMazepine XR (Oral Pill)", true, ["carbamazepine"]],
    ["Carbamide peroxide (Mucosal)", false, ["carbamide peroxide"]],
    ["Carbamide peroxide (Oral Gel)", true, ["carbamide peroxide"]],
    ["Carbamide peroxide (Otic)", false, ["carbamide peroxide"]],
    ["CARBATROL XR (Oral Pill)", true, ["carbamazepine"]],
    ["Carbetapentane/guaiFENesin (Oral Liquid)", true, ["carbetapentane", "guaifenesin"]],
    ["Carbidopa (Oral Pill)", true, ["carbidopa"]],
    ["Carbidopa/Entacapone/Levodopa (Oral Pill)", true, ["carbidopa", "entacapone", "levodopa"]],
    ["Carbidopa/Levodopa (Injectable)", false, ["carbidopa", "levodopa"]],
    ["Carbidopa/Levodopa (Oral Disintegrating)", true, ["carbidopa", "levodopa"]],
    ["Carbidopa/Levodopa (Oral Liquid)", true, ["carbidopa", "levodopa"]],
    ["Carbidopa/Levodopa (Oral Pill)", true, ["carbidopa", "levodopa"]],
    ["Carbidopa/Levodopa XR (Oral Pill)", true, ["carbidopa", "levodopa"]],
    ["Carbinoxamine (Oral Liquid)", true, ["carbinoxamine"]],
    ["Carbinoxamine (Oral Pill)", true, ["carbinoxamine"]],
    ["Carbinoxamine XR (Oral Liquid)", true, ["carbinoxamine"]],
    ["CARBOCAINE (Injectable)", false, ["mepivacaine"]],
    ["CARBOCAINE WITH NEOCOBEFRIN (Injectable)", false, ["levonordefrin", "mepivacaine"]],
    ["Carbocysteine (Chewable)", true, ["carbocysteine"]],
    ["Carbon dioxide (Inhalant)", false, ["carbon dioxide"]],
    ["Carbon dioxide/Nitrogen (Inhalant)", false, ["carbon dioxide", "nitrogen"]],
    ["Carbon dioxide/Oxygen (Inhalant)", false, ["carbon dioxide", "oxygen"]],
    ["CARBOplatin (Injectable)", false, ["carboplatin"]],
    ["Carboprost (Injectable)", false, ["carboprost"]],
    ["Carboxymethylcellulose (Ophthalmic)", false, ["carboxymethylcellulose"]],
    ["Carboxymethylcellulose/Glycerin (Ophthalmic)", false, ["carboxymethylcellulose", "glycerin"]],
    ["Carboxymethylcellulose/Glycerin/Polysorbate 80 (Ophthalmic)", false, ["carboxymethylcellulose", "glycerin", "polysorbate 80"]],
    ["CARBZAH (Oral Liquid)", true, ["carbinoxamine"]],
    ["CARDAMYST (Nasal)", false, ["etripamil"]],
    ["CARDENE (Injectable)", false, ["nicardipine"]],
    ["CARDIZEM (Oral Pill)", true, ["diltiazem"]],
    ["CARDIZEM XR (Oral Pill)", true, ["diltiazem"]],
    ["CARDURA (Oral Pill)", true, ["doxazosin"]],
    ["CARDURA XR (Oral Pill)", true, ["doxazosin"]],
    ["Carfilzomib (Injectable)", false, ["carfilzomib"]],
    ["Carglumic acid (Oral Suspension Tablet)", true, ["carglumic acid"]],
    ["Cariprazine (Oral Pill)", true, ["cariprazine"]],
    ["Cariprazine (Pack)", true, ["cariprazine"]],
    ["Carisoprodol (Oral Pill)", true, ["carisoprodol"]],
    ["CARMOL (Shampoo)", false, ["urea"]],
    ["CARMOL (Topical)", false, ["urea"]],
    ["Carmustine (Implant)", false, ["carmustine"]],
    ["Carmustine (Injectable)", false, ["carmustine"]],
    ["CARNITOR (Injectable)", false, ["levocarnitine"]],
    ["CARNITOR (Oral Liquid)", true, ["levocarnitine"]],
    ["CARNITOR (Oral Pill)", true, ["levocarnitine"]],
    ["CAROSPIR (Oral Liquid)", true, ["spironolactone"]],
    ["Carteolol (Ophthalmic)", false, ["carteolol"]],
    ["CARTIA XR (Oral Pill)", true, ["diltiazem"]],
    ["Carvedilol (Oral Pill)", true, ["carvedilol"]],
    ["Carvedilol XR (Oral Pill)", true, ["carvedilol"]],
    ["CARVYKTI (Injectable)", false, ["ciltacabtagene autoleucel"]],
    ["CASGEVY (Injectable)", false, ["exagamglogene autotemcel"]],
    ["Casimersen (Injectable)", false, ["casimersen"]],
    ["CASODEX (Oral Pill)", true, ["bicalutamide"]],
    ["Caspofungin (Injectable)", false, ["caspofungin"]],
    ["CASTELLANI PAINT (Topical)", false, ["phenol"]],
    ["CASTIVA COOLING (Topical)", false, ["menthol", "methyl salicylate"]],
    ["CASTIVA WARMING (Topical)", false, ["capsaicin"]],
    ["Castor oil (Oral Liquid)", true, ["castor oil"]],
    ["Castor oil/Peruvian balsam (Topical)", false, ["Peruvian balsam", "castor oil"]],
    ["CATAFLAM (Oral Pill)", true, ["diclofenac"]],
    ["CATAPRES (Transdermal)", false, ["clonidine"]],
    ["CAVERJECT (Injectable)", false, ["alprostadil"]],
    ["CAVHANZA (Oral Disintegrating)", true, ["nilotinib"]],
    ["CAYSTON (Inhalant)", false, ["aztreonam"]],
    ["CAZIANT 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Cedazuridine/Decitabine (Oral Pill)", true, ["cedazuridine", "decitabine"]],
    ["Cedazuridine/Decitabine (Pack)", true, ["cedazuridine", "decitabine"]],
    ["Cefaclor (Oral Liquid)", true, ["cefaclor"]],
    ["Cefaclor (Oral Pill)", true, ["cefaclor"]],
    ["Cefaclor XR (Oral Pill)", true, ["cefaclor"]],
    ["Cefadroxil (Oral Liquid)", true, ["cefadroxil"]],
    ["Cefadroxil (Oral Pill)", true, ["cefadroxil"]],
    ["ceFAZolin (Injectable)", false, ["cefazolin"]],
    ["Cefdinir (Oral Liquid)", true, ["cefdinir"]],
    ["Cefdinir (Oral Pill)", true, ["cefdinir"]],
    ["Cefepime (Injectable)", false, ["cefepime"]],
    ["Cefepime/Enmetazobactam (Injectable)", false, ["cefepime", "enmetazobactam"]],
    ["Cefepime/Zidebactam (Injectable)", false, ["cefepime", "zidebactam"]],
    ["Cefiderocol (Injectable)", false, ["cefiderocol"]],
    ["Cefixime (Oral Liquid)", true, ["cefixime"]],
    ["Cefixime (Oral Pill)", true, ["cefixime"]],
    ["CEFOTAN (Injectable)", false, ["cefotetan"]],
    ["Cefotaxime (Injectable)", false, ["cefotaxime"]],
    ["cefoTEtan (Injectable)", false, ["cefotetan"]],
    ["cefOXitin (Injectable)", false, ["cefoxitin"]],
    ["Cefpodoxime (Oral Liquid)", true, ["cefpodoxime"]],
    ["Cefpodoxime (Oral Pill)", true, ["cefpodoxime"]],
    ["Cefprozil (Oral Liquid)", true, ["cefprozil"]],
    ["Cefprozil (Oral Pill)", true, ["cefprozil"]],
    ["Ceftaroline fosamil (Injectable)", false, ["ceftaroline fosamil"]],
    ["cefTAZidime (Injectable)", false, ["ceftazidime"]],
    ["Ceftobiprole (Injectable)", false, ["ceftobiprole"]],
    ["Ceftolozane/Tazobactam (Injectable)", false, ["ceftolozane", "tazobactam"]],
    ["cefTRIAXone (Injectable)", false, ["ceftriaxone"]],
    ["Cefuroxime (Injectable)", false, ["cefuroxime"]],
    ["Cefuroxime (Oral Pill)", true, ["cefuroxime"]],
    ["CeleBREX (Oral Pill)", true, ["celecoxib"]],
    ["Celecoxib (Oral Liquid)", true, ["celecoxib"]],
    ["Celecoxib (Oral Pill)", true, ["celecoxib"]],
    ["Celecoxib/traMADol (Oral Pill)", true, ["celecoxib", "tramadol"]],
    ["CELESTONE SOLUSPAN (Injectable)", false, ["betamethasone"]],
    ["CeleXA (Oral Pill)", true, ["citalopram"]],
    ["CELLCEPT (Injectable)", false, ["mycophenolate mofetil"]],
    ["CELLCEPT (Oral Liquid)", true, ["mycophenolate mofetil"]],
    ["CELLCEPT (Oral Pill)", true, ["mycophenolate mofetil"]],
    ["CELLUGEL (Injectable)", false, ["hypromellose"]],
    ["Cellulose (Oral Powder)", true, ["cellulose"]],
    ["CELONTIN (Oral Pill)", true, ["methsuximide"]],
    ["CEM-UREA (Topical)", false, ["urea"]],
    ["Cemiplimab (Injectable)", false, ["cemiplimab"]],
    ["Cenegermin (Ophthalmic)", false, ["cenegermin"]],
    ["Cenobamate (Oral Pill)", true, ["cenobamate"]],
    ["Cenobamate (Pack)", true, ["cenobamate"]],
    ["CENTANY (Topical)", false, ["mupirocin"]],
    ["Centruroides (scorpion) immune F(ab')2 (equine) (Injectable)", false, ["Centruroides (scorpion) immune F(ab')2 (equine)"]],
    ["CEO-TWO (Rectal)", false, ["potassium bitartrate", "sodium bicarbonate"]],
    ["CEPACOL (Oral Disintegrating)", true, ["benzocaine"]],
    ["CEPACOL ANTIBACTERIAL MOUTHWASH (Mouthwash)", false, ["cetylpyridinium"]],
    ["CEPACOL SORE THROAT FROM POST NASAL DRIP (Oral Lozenge)", true, ["menthol"]],
    ["CEPACOL SORE THROAT PAIN RELIEF (Oral Lozenge)", true, ["benzocaine", "menthol"]],
    ["CEPACOL SORE THROAT PLUS COUGH (Oral Lozenge)", true, ["benzocaine", "dextromethorphan"]],
    ["CEPASTAT SORE THROAT & COUGH (Oral Lozenge)", true, ["benzocaine", "dextromethorphan", "menthol"]],
    ["Cephalexin (Oral Liquid)", true, ["cephalexin"]],
    ["Cephalexin (Oral Pill)", true, ["cephalexin"]],
    ["CEPROTIN (Injectable)", false, ["protein C"]],
    ["CEQUA (Ophthalmic)", false, ["cyclosporine"]],
    ["CERAXON (Oral Pill)", true, ["citicoline"]],
    ["CERDELGA (Oral Pill)", true, ["eliglustat"]],
    ["CEREBYX (Injectable)", false, ["fosphenytoin"]],
    ["CEREZYME (Injectable)", false, ["imiglucerase"]],
    ["Ceritinib (Oral Pill)", true, ["ceritinib"]],
    ["Cerliponase (Injectable)", false, ["cerliponase"]],
    ["Certolizumab pegol (Injectable)", false, ["certolizumab pegol"]],
    ["Certolizumab pegol (Pack)", false, ["certolizumab pegol"]],
    ["CERVIDIL (Vaginal)", false, ["dinoprostone"]],
    ["CESAMET (Oral Pill)", true, ["nabilone"]],
    ["CETACAINE (Mucosal)", false, ["benzocaine", "butamben", "tetracaine"]],
    ["CETACAINE (Topical)", false, ["benzocaine", "butamben", "tetracaine"]],
    ["CETAFEN (Oral Pill)", true, ["acetaminophen"]],
    ["Cetirizine (Chewable)", true, ["cetirizine"]],
    ["Cetirizine (Injectable)", false, ["cetirizine"]],
    ["Cetirizine (Ophthalmic)", false, ["cetirizine"]],
    ["Cetirizine (Oral Disintegrating)", true, ["cetirizine"]],
    ["Cetirizine (Oral Liquid)", true, ["cetirizine"]],
    ["Cetirizine (Oral Pill)", true, ["cetirizine"]],
    ["Cetirizine/Pseudoephedrine XR (Oral Pill)", true, ["cetirizine", "pseudoephedrine"]],
    ["CETRAXAL (Otic)", false, ["ciprofloxacin"]],
    ["Cetrorelix (Injectable)", false, ["cetrorelix"]],
    ["CETROTIDE (Injectable)", false, ["cetrorelix"]],
    ["Cetuximab (Injectable)", false, ["cetuximab"]],
    ["Cetylpyridinium (Mouthwash)", false, ["cetylpyridinium"]],
    ["Cetylpyridinium (Mucosal)", false, ["cetylpyridinium"]],
    ["Cevimeline (Oral Pill)", true, ["cevimeline"]],
    ["CHANTIX (Oral Pill)", true, ["varenicline"]],
    ["CHANTIX CONTINUING MONTHS OF THERAPY (Pack)", true, ["varenicline"]],
    ["CHANTIX FIRST MONTH OF THERAPY (Pack)", true, ["varenicline"]],
    ["CHARCOCAPS (Oral Pill)", true, ["activated charcoal"]],
    ["CHARLOTTE 24 FE CHEWABLE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["CHATEAL 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["CHEMET (Oral Pill)", true, ["succimer"]],
    ["CHENODAL (Oral Pill)", true, ["chenodeoxycholate"]],
    ["Chenodeoxycholate (Oral Pill)", true, ["chenodeoxycholate"]],
    ["CHERATUSSIN (Oral Liquid)", true, ["codeine", "guaifenesin"]],
    ["Chia seed oil (Oral Pill)", true, ["chia seed oil"]],
    ["Chikungunya virus antigen, live attenuated LR2006 OPY1 strain (Injectable)", false, ["chikungunya virus antigen, live attenuated LR2006 OPY1 strain"]],
    ["Chikungunya virus antigen, recombinant Senegal strain 37997 (Injectable)", false, ["chikungunya virus antigen, recombinant Senegal strain 37997"]],
    ["CHIRHOSTIM (Injectable)", false, ["secretin human, synthetic"]],
    ["Chlophedianol/Dexbrompheniramine (Oral Liquid)", true, ["chlophedianol", "dexbrompheniramine"]],
    ["Chlophedianol/Dexchlorpheniramine (Oral Liquid)", true, ["chlophedianol", "dexchlorpheniramine"]],
    ["Chlophedianol/Pseudoephedrine (Oral Liquid)", true, ["chlophedianol", "pseudoephedrine"]],
    ["Chlophedianol/Pyrilamine (Chewable)", true, ["chlophedianol", "pyrilamine"]],
    ["Chlophedianol/Pyrilamine (Oral Liquid)", true, ["chlophedianol", "pyrilamine"]],
    ["Chlophedianol/Pyrilamine (Oral Pill)", true, ["chlophedianol", "pyrilamine"]],
    ["Chlophedianol/Thonzylamine (Oral Liquid)", true, ["chlophedianol", "thonzylamine"]],
    ["CHLOR-TRIMETON (Oral Pill)", true, ["chlorpheniramine"]],
    ["CHLOR-TRIMETON XR (Oral Pill)", true, ["chlorpheniramine"]],
    ["Chlorambucil (Oral Pill)", true, ["chlorambucil"]],
    ["Chloramphenicol (Injectable)", false, ["chloramphenicol"]],
    ["CHLORAPREP (Topical)", false, ["chlorhexidine", "isopropyl alcohol"]],
    ["CHLORASEPTIC (Oral Lozenge)", true, ["benzocaine"]],
    ["CHLORASEPTIC MAX SPRAY (Mucosal)", false, ["glycerin", "phenol"]],
    ["CHLORASEPTIC SORE THROAT (Oral Lozenge)", true, ["benzocaine", "menthol"]],
    ["CHLORASEPTIC SORE THROAT + COUGH (Oral Lozenge)", true, ["benzocaine", "dextromethorphan", "menthol"]],
    ["CHLORASEPTIC SPRAY (Mucosal)", false, ["phenol"]],
    ["Chlorcyclizine (Oral Pill)", true, ["chlorcyclizine"]],
    ["Chlorcyclizine/Phenylephrine (Chewable)", true, ["chlorcyclizine", "phenylephrine"]],
    ["Chlorcyclizine/Pseudoephedrine (Oral Pill)", true, ["chlorcyclizine", "pseudoephedrine"]],
    ["chlordiazePOXIDE (Oral Pill)", true, ["chlordiazepoxide"]],
    ["chlordiazePOXIDE/Clidinium (Oral Pill)", true, ["chlordiazepoxide", "clidinium"]],
    ["Chlorhexidine (Implant)", false, ["chlorhexidine"]],
    ["Chlorhexidine (Mouthwash)", false, ["chlorhexidine"]],
    ["Chlorhexidine (Soap)", false, ["chlorhexidine"]],
    ["Chlorhexidine (Topical)", false, ["chlorhexidine"]],
    ["Chlorhexidine/Ethanol (Topical)", false, ["chlorhexidine", "ethanol"]],
    ["Chlorhexidine/Isopropyl alcohol (Topical)", false, ["chlorhexidine", "isopropyl alcohol"]],
    ["Chlorophyll (Oral Pill)", true, ["chlorophyll"]],
    ["Chlorophyllin copper complex (Oral Pill)", true, ["chlorophyllin copper complex"]],
    ["Chloroprocaine (Injectable)", false, ["chloroprocaine"]],
    ["Chloroprocaine (Ophthalmic)", false, ["chloroprocaine"]],
    ["Chloroquine (Oral Pill)", true, ["chloroquine"]],
    ["Chlorothiazide (Injectable)", false, ["chlorothiazide"]],
    ["Chlorothiazide (Oral Liquid)", true, ["chlorothiazide"]],
    ["Chlorothiazide (Oral Pill)", true, ["chlorothiazide"]],
    ["Chloroxylenol (Soap)", false, ["chloroxylenol"]],
    ["Chloroxylenol (Topical)", false, ["chloroxylenol"]],
    ["Chloroxylenol/Undecylenate (Topical)", false, ["chloroxylenol", "undecylenate"]],
    ["Chlorpheniramine (Oral Liquid)", true, ["chlorpheniramine"]],
    ["Chlorpheniramine (Oral Lozenge)", true, ["chlorpheniramine"]],
    ["Chlorpheniramine (Oral Pill)", true, ["chlorpheniramine"]],
    ["Chlorpheniramine XR (Oral Pill)", true, ["chlorpheniramine"]],
    ["Chlorpheniramine/Codeine (Oral Liquid)", true, ["chlorpheniramine", "codeine"]],
    ["Chlorpheniramine/Codeine XR (Oral Pill)", true, ["chlorpheniramine", "codeine"]],
    ["Chlorpheniramine/Dextromethorphan (Chewable)", true, ["chlorpheniramine", "dextromethorphan"]],
    ["Chlorpheniramine/Dextromethorphan (Oral Liquid)", true, ["chlorpheniramine", "dextromethorphan"]],
    ["Chlorpheniramine/Dextromethorphan (Oral Pill)", true, ["chlorpheniramine", "dextromethorphan"]],
    ["Chlorpheniramine/HYDROcodone XR (Oral Liquid)", true, ["chlorpheniramine", "hydrocodone"]],
    ["Chlorpheniramine/Phenylephrine (Oral Liquid)", true, ["chlorpheniramine", "phenylephrine"]],
    ["Chlorpheniramine/Phenylephrine (Oral Pill)", true, ["chlorpheniramine", "phenylephrine"]],
    ["Chlorpheniramine/Pseudoephedrine (Oral Liquid)", true, ["chlorpheniramine", "pseudoephedrine"]],
    ["Chlorpheniramine/Pseudoephedrine (Oral Pill)", true, ["chlorpheniramine", "pseudoephedrine"]],
    ["chlorproMAZINE (Injectable)", false, ["chlorpromazine"]],
    ["chlorproMAZINE (Oral Liquid)", true, ["chlorpromazine"]],
    ["chlorproMAZINE (Oral Pill)", true, ["chlorpromazine"]],
    ["Chlorthalidone (Oral Pill)", true, ["chlorthalidone"]],
    ["Chlorzoxazone (Oral Pill)", true, ["chlorzoxazone"]],
    ["CHOLBAM (Oral Pill)", true, ["cholic acid"]],
    ["Cholecalciferol (Chewable)", true, ["cholecalciferol"]],
    ["Cholecalciferol (Mucosal)", false, ["cholecalciferol"]],
    ["Cholecalciferol (Oral Disintegrating)", true, ["cholecalciferol"]],
    ["Cholecalciferol (Oral Film)", true, ["cholecalciferol"]],
    ["Cholecalciferol (Oral Liquid)", true, ["cholecalciferol"]],
    ["Cholecalciferol (Oral Pill)", true, ["cholecalciferol"]],
    ["Cholecalciferol (Oral Wafer)", true, ["cholecalciferol"]],
    ["Cholecalciferol/Folic acid (Oral Pill)", true, ["cholecalciferol", "folic acid"]],
    ["Cholecalciferol/Glucose (Oral Gel)", true, ["cholecalciferol", "glucose"]],
    ["Cholecalciferol/Glucose (Oral Liquid)", true, ["cholecalciferol", "glucose"]],
    ["Cholecalciferol/Inulin (Chewable)", true, ["cholecalciferol", "inulin"]],
    ["Cholecalciferol/Levomefolate (Oral Pill)", true, ["cholecalciferol", "levomefolate"]],
    ["Cholecalciferol/Menatetrenone (Oral Pill)", true, ["cholecalciferol", "menatetrenone"]],
    ["Cholecalciferol/Polysaccharide iron complex (Oral Liquid)", true, ["cholecalciferol", "polysaccharide iron complex"]],
    ["Cholecalciferol/Sodium fluoride (Oral Liquid)", true, ["cholecalciferol", "sodium fluoride"]],
    ["Cholecalciferol/Soy protein isolate (Oral Pill)", true, ["cholecalciferol", "soy protein isolate"]],
    ["Cholecalciferol/Tricalcium phosphate (Chewable)", true, ["cholecalciferol", "tricalcium phosphate"]],
    ["Cholecalciferol/Vitamin A (Oral Pill)", true, ["cholecalciferol", "vitamin A"]],
    ["Cholecalciferol/Vitamin E (Oral Wafer)", true, ["cholecalciferol", "vitamin E"]],
    ["Cholecalciferol/Vitamin K2 (Oral Disintegrating)", true, ["cholecalciferol", "vitamin K2"]],
    ["Cholecalciferol/Vitamin K2 (Oral Pill)", true, ["cholecalciferol", "vitamin K2"]],
    ["Cholestyramine resin (Oral Suspension Powder)", true, ["cholestyramine resin"]],
    ["Cholic acid (Oral Pill)", true, ["cholic acid"]],
    ["Choline (Oral Pill)", true, ["choline"]],
    ["Choline XR (Oral Pill)", true, ["choline"]],
    ["Choline/Magnesium salicylate (Oral Liquid)", true, ["choline", "magnesium salicylate"]],
    ["Choline/Magnesium salicylate (Oral Pill)", true, ["choline", "magnesium salicylate"]],
    ["Chondroitin sulfates (Oral Pill)", true, ["chondroitin sulfates"]],
    ["Chondroitin sulfates/Glucosamine (Chewable)", true, ["chondroitin sulfates", "glucosamine"]],
    ["Chondroitin sulfates/Glucosamine (Oral Liquid)", true, ["chondroitin sulfates", "glucosamine"]],
    ["Chondroitin sulfates/Glucosamine (Oral Pill)", true, ["chondroitin sulfates", "glucosamine"]],
    ["Chondroitin sulfates/Glucosamine XR (Oral Pill)", true, ["chondroitin sulfates", "glucosamine"]],
    ["Chondroitin sulfates/Glucosamine/Hyaluronate/Methylsulfonylmethane (Oral Pill)", true, ["chondroitin sulfates", "glucosamine", "hyaluronate", "methylsulfonylmethane"]],
    ["Chondroitin sulfates/Glucosamine/Methylsulfonylmethane (Oral Pill)", true, ["chondroitin sulfates", "glucosamine", "methylsulfonylmethane"]],
    ["Chondroitin sulfates/Hyaluronate (Injectable)", false, ["chondroitin sulfates", "hyaluronate"]],
    ["Chondroitin sulfates/Hyaluronate (Pack)", false, ["chondroitin sulfates", "hyaluronate"]],
    ["CHOOZ (Chewable)", true, ["calcium carbonate"]],
    ["Chorionic gonadotropin (Injectable)", false, ["chorionic gonadotropin"]],
    ["CHROMELIN (Topical)", false, ["dihydroxyacetone"]],
    ["Chromic chloride (Injectable)", false, ["chromic chloride"]],
    ["Chromic chloride/Copper sulfate/Manganese sulfate/Selenious acid/Zinc sulfate (Injectable)", false, ["chromic chloride", "copper sulfate", "manganese sulfate", "selenious acid", "zinc sulfate"]],
    ["Chromic chloride/Copper sulfate/Manganese sulfate/Zinc sulfate (Injectable)", false, ["chromic chloride", "copper sulfate", "manganese sulfate", "zinc sulfate"]],
    ["Chromium nicotinic acid complex (Oral Pill)", true, ["chromium nicotinic acid complex"]],
    ["Chromium picolinate (Oral Pill)", true, ["chromium picolinate"]],
    ["Chromium picolinate/Cinnamon bark (Oral Pill)", true, ["chromium picolinate", "cinnamon bark"]],
    ["Chromium picolinate/Gamboge (Oral Pill)", true, ["chromium picolinate", "gamboge"]],
    ["Chromium picolinate/Inulin (Chewable)", true, ["chromium picolinate", "inulin"]],
    ["Chromium, chelated (Oral Pill)", true, ["chromium, chelated"]],
    ["Chromium, chelated/Manganese gluconate/Zinc citrate (Oral Pill)", true, ["chromium, chelated", "manganese gluconate", "zinc citrate"]],
    ["Chymotrypsin (Oral Pill)", true, ["chymotrypsin"]],
    ["CIALIS (Oral Pill)", true, ["tadalafil"]],
    ["CIBINQO (Oral Pill)", true, ["abrocitinib"]],
    ["Ciclesonide (Inhalant)", false, ["ciclesonide"]],
    ["Ciclesonide (Nasal)", false, ["ciclesonide"]],
    ["CICLODAN (Topical)", false, ["ciclopirox"]],
    ["Ciclopirox (Shampoo)", false, ["ciclopirox"]],
    ["Ciclopirox (Topical)", false, ["ciclopirox"]],
    ["CIDAFLEX (Oral Pill)", true, ["chondroitin sulfates", "glucosamine"]],
    ["Cider vinegar (Oral Pill)", true, ["cider vinegar"]],
    ["Cidofovir (Injectable)", false, ["cidofovir"]],
    ["Cilastatin/Imipenem (Injectable)", false, ["cilastatin", "imipenem"]],
    ["Cilastatin/Imipenem/Relebactam (Injectable)", false, ["cilastatin", "imipenem", "relebactam"]],
    ["Cilostazol (Oral Pill)", true, ["cilostazol"]],
    ["CILOXAN (Ophthalmic)", false, ["ciprofloxacin"]],
    ["Ciltacabtagene autoleucel (Injectable)", false, ["ciltacabtagene autoleucel"]],
    ["CIMDUO (Oral Pill)", true, ["lamivudine", "tenofovir disoproxil"]],
    ["CIMERLI (Injectable)", false, ["ranibizumab"]],
    ["Cimetidine (Oral Liquid)", true, ["cimetidine"]],
    ["Cimetidine (Oral Pill)", true, ["cimetidine"]],
    ["CIMZIA (2 COUNT) (Pack)", false, ["certolizumab pegol"]],
    ["CIMZIA (Injectable)", false, ["certolizumab pegol"]],
    ["CIMZIA STARTER KIT (6 COUNT) (Pack)", false, ["certolizumab pegol"]],
    ["Cinacalcet (Oral Pill)", true, ["cinacalcet"]],
    ["Cinnamon bark (Oral Pill)", true, ["cinnamon bark"]],
    ["CINQAIR (Injectable)", false, ["reslizumab"]],
    ["CINRYZE (Injectable)", false, ["C1 esterase inhibitor"]],
    ["CINVANTI (Injectable)", false, ["aprepitant"]],
    ["Cipaglucosidase alfa (Injectable)", false, ["cipaglucosidase alfa"]],
    ["CIPRO (Oral Liquid)", true, ["ciprofloxacin"]],
    ["CIPRO (Oral Pill)", true, ["ciprofloxacin"]],
    ["CIPRO HC (Otic)", false, ["ciprofloxacin", "hydrocortisone"]],
    ["CIPRO XR (Oral Pill)", true, ["ciprofloxacin"]],
    ["CIPRODEX (Otic)", false, ["ciprofloxacin", "dexamethasone"]],
    ["Ciprofloxacin (Injectable)", false, ["ciprofloxacin"]],
    ["Ciprofloxacin (Ophthalmic)", false, ["ciprofloxacin"]],
    ["Ciprofloxacin (Oral Liquid)", true, ["ciprofloxacin"]],
    ["Ciprofloxacin (Oral Pill)", true, ["ciprofloxacin"]],
    ["Ciprofloxacin (Otic)", false, ["ciprofloxacin"]],
    ["Ciprofloxacin XR (Oral Pill)", true, ["ciprofloxacin"]],
    ["Ciprofloxacin/dexAMETHasone (Otic)", false, ["ciprofloxacin", "dexamethasone"]],
    ["Ciprofloxacin/Fluocinolone (Otic)", false, ["ciprofloxacin", "fluocinolone"]],
    ["Ciprofloxacin/Hydrocortisone (Otic)", false, ["ciprofloxacin", "hydrocortisone"]],
    ["Cisatracurium (Injectable)", false, ["cisatracurium"]],
    ["CISplatin (Injectable)", false, ["cisplatin"]],
    ["Citalopram (Oral Liquid)", true, ["citalopram"]],
    ["Citalopram (Oral Pill)", true, ["citalopram"]],
    ["CITANEST (Injectable)", false, ["prilocaine"]],
    ["CITANEST FORTE (Injectable)", false, ["epinephrine", "prilocaine"]],
    ["Citicoline (Oral Pill)", true, ["citicoline"]],
    ["CITRANATAL B-CALM KIT (Pack)", true, ["ascorbic acid", "calcium citrate", "cholecalciferol", "folic acid", "iron carbonyl", "pyridoxine"]],
    ["Citric acid/Gluconolactone/Magnesium carbonate (Irrigation)", false, ["citric acid", "gluconolactone", "magnesium carbonate"]],
    ["Citric acid/Lactate/Potassium bitartrate (Vaginal)", false, ["citric acid", "lactate", "potassium bitartrate"]],
    ["Citric acid/Potassium bicarbonate/Sodium bicarbonate (Effervescent)", true, ["citric acid", "potassium bicarbonate", "sodium bicarbonate"]],
    ["Citric acid/Potassium citrate (Oral Liquid)", true, ["citric acid", "potassium citrate"]],
    ["Citric acid/Potassium citrate (Oral Solution Powder)", true, ["citric acid", "potassium citrate"]],
    ["Citric acid/Potassium citrate/Sodium citrate (Oral Liquid)", true, ["citric acid", "potassium citrate", "sodium citrate"]],
    ["Citric acid/Sodium bicarbonate (Effervescent)", true, ["citric acid", "sodium bicarbonate"]],
    ["Citric acid/Sodium citrate (Oral Liquid)", true, ["citric acid", "sodium citrate"]],
    ["CITROMA (Oral Liquid)", true, ["magnesium citrate"]],
    ["CITRUCEL (Oral Pill)", true, ["methylcellulose"]],
    ["CITRUCEL (Oral Suspension Powder)", true, ["methylcellulose"]],
    ["Citrulline (Oral Pill)", true, ["citrulline"]],
    ["Cladribine (Injectable)", false, ["cladribine"]],
    ["Cladribine (Oral Pill)", true, ["cladribine"]],
    ["Cladribine (Pack)", true, ["cladribine"]],
    ["CLAFORAN (Injectable)", false, ["cefotaxime"]],
    ["CLARAVIS (Oral Pill)", true, ["isotretinoin"]],
    ["CLARINEX (Oral Pill)", true, ["desloratadine"]],
    ["CLARINEX-D XR (Oral Pill)", true, ["desloratadine", "pseudoephedrine"]],
    ["CLARISPRAY (Nasal)", false, ["fluticasone"]],
    ["Clarithromycin (Oral Liquid)", true, ["clarithromycin"]],
    ["Clarithromycin (Oral Pill)", true, ["clarithromycin"]],
    ["Clarithromycin XR (Oral Pill)", true, ["clarithromycin"]],
    ["CLARITIN (Chewable)", true, ["loratadine"]],
    ["CLARITIN (Oral Disintegrating)", true, ["loratadine"]],
    ["CLARITIN (Oral Liquid)", true, ["loratadine"]],
    ["CLARITIN (Oral Pill)", true, ["loratadine"]],
    ["CLARITIN EYE (Ophthalmic)", false, ["ketotifen"]],
    ["CLARITIN-D XR (Oral Pill)", true, ["loratadine", "pseudoephedrine"]],
    ["CLARUS (Topical)", false, ["tolnaftate"]],
    ["Clascoterone (Topical)", false, ["clascoterone"]],
    ["CLEARCANAL (Otic)", false, ["carbamide peroxide"]],
    ["CLEARLAX (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["CLEARPLEX (Topical)", false, ["benzoyl peroxide"]],
    ["CLEARSKIN (Topical)", false, ["benzoyl peroxide"]],
    ["CLEARTIME INDOOR & OUTDOOR ALLERGIES (Oral Pill)", true, ["loratadine"]],
    ["CLEERAVUE-M (Oral Pill)", true, ["minocycline"]],
    ["Clemastine (Oral Liquid)", true, ["clemastine"]],
    ["Clemastine (Oral Pill)", true, ["clemastine"]],
    ["Clemastine XR (Oral Pill)", true, ["clemastine"]],
    ["CLEMASZ (Oral Pill)", true, ["clemastine"]],
    ["CLEMSZA (Oral Pill)", true, ["clemastine"]],
    ["CLENIA (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["CLENPIQ (Oral Liquid)", true, ["citric acid", "magnesium oxide", "picosulfurate"]],
    ["CLEOCIN (Injectable)", false, ["clindamycin"]],
    ["CLEOCIN (Oral Liquid)", true, ["clindamycin"]],
    ["CLEOCIN (Oral Pill)", true, ["clindamycin"]],
    ["CLEOCIN (Vaginal)", false, ["clindamycin"]],
    ["CLEOCIN-T (Topical)", false, ["clindamycin"]],
    ["Clesrovimab (Injectable)", false, ["clesrovimab"]],
    ["Clevidipine (Injectable)", false, ["clevidipine"]],
    ["CLEVIPREX (Injectable)", false, ["clevidipine"]],
    ["CLIGAVYX (Injectable)", false, ["fulvestrant"]],
    ["CLIMARA (Transdermal)", false, ["estradiol"]],
    ["CLIMARA PRO (Transdermal)", false, ["estradiol", "levonorgestrel"]],
    ["CLINDACIN (Topical)", false, ["clindamycin"]],
    ["CLINDAGEL (Topical)", false, ["clindamycin"]],
    ["CLINDAMAX (Topical)", false, ["clindamycin"]],
    ["Clindamycin (Injectable)", false, ["clindamycin"]],
    ["Clindamycin (Oral Liquid)", true, ["clindamycin"]],
    ["Clindamycin (Oral Pill)", true, ["clindamycin"]],
    ["Clindamycin (Topical)", false, ["clindamycin"]],
    ["Clindamycin (Vaginal)", false, ["clindamycin"]],
    ["Clindamycin/Tretinoin (Topical)", false, ["clindamycin", "tretinoin"]],
    ["CLINDESSE (Vaginal)", false, ["clindamycin"]],
    ["CLINIDINE (Topical)", false, ["povidone-iodine"]],
    ["CLINIMIX 4.25/10 (Injectable)", false, ["alanine", "arginine", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX 4.25/5 (Injectable)", false, ["alanine", "arginine", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX 5/15 (Injectable)", false, ["alanine", "arginine", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX 5/20 (Injectable)", false, ["alanine", "arginine", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX E 2.75/5 (Injectable)", false, ["alanine", "arginine", "calcium chloride", "dibasic potassium phosphate", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX E 4.25/10 (Injectable)", false, ["alanine", "arginine", "calcium chloride", "dibasic potassium phosphate", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX E 4.25/5 (Injectable)", false, ["alanine", "arginine", "calcium chloride", "dibasic potassium phosphate", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX E 5/15 (Injectable)", false, ["alanine", "arginine", "calcium chloride", "dibasic potassium phosphate", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINIMIX E 5/20 (Injectable)", false, ["alanine", "arginine", "calcium chloride", "dibasic potassium phosphate", "glucose", "glycine", "histidine", "isoleucine", "leucine", "lysine", "magnesium chloride", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINISOL 15 (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["CLINOLIPID (Injectable)", false, ["olive oil", "soybean oil"]],
    ["CLINPRO 5000 (Toothpaste)", false, ["sodium fluoride"]],
    ["cloBAZam (Oral Film)", true, ["clobazam"]],
    ["cloBAZam (Oral Liquid)", true, ["clobazam"]],
    ["cloBAZam (Oral Pill)", true, ["clobazam"]],
    ["Clobetasol (Ophthalmic)", false, ["clobetasol"]],
    ["Clobetasol (Shampoo)", false, ["clobetasol"]],
    ["Clobetasol (Topical)", false, ["clobetasol"]],
    ["CLOBEX (Shampoo)", false, ["clobetasol"]],
    ["CLOBEX (Topical)", false, ["clobetasol"]],
    ["Clocortolone (Topical)", false, ["clocortolone"]],
    ["CLODAN (Shampoo)", false, ["clobetasol"]],
    ["CLODERM (Topical)", false, ["clocortolone"]],
    ["Clofarabine (Injectable)", false, ["clofarabine"]],
    ["Clofazimine (Oral Pill)", true, ["clofazimine"]],
    ["CLOLAR (Injectable)", false, ["clofarabine"]],
    ["CLOMID (Oral Pill)", true, ["clomiphene"]],
    ["clomiPHENE (Oral Pill)", true, ["clomiphene"]],
    ["clomiPRAMINE (Oral Pill)", true, ["clomipramine"]],
    ["clonazePAM (Oral Disintegrating)", true, ["clonazepam"]],
    ["clonazePAM (Oral Pill)", true, ["clonazepam"]],
    ["cloNIDine (Injectable)", false, ["clonidine"]],
    ["cloNIDine (Oral Liquid)", true, ["clonidine"]],
    ["cloNIDine (Oral Pill)", true, ["clonidine"]],
    ["cloNIDine (Transdermal)", false, ["clonidine"]],
    ["cloNIDine XR (Oral Liquid)", true, ["clonidine"]],
    ["cloNIDine XR (Oral Pill)", true, ["clonidine"]],
    ["Clopidogrel (Oral Pill)", true, ["clopidogrel"]],
    ["Clorazepate (Oral Pill)", true, ["clorazepate"]],
    ["CLOROTEKAL (Injectable)", false, ["chloroprocaine"]],
    ["CLORPACTIN WCS-90 (Topical)", false, ["oxychlorosene"]],
    ["CLOTIC (Otic)", false, ["clotrimazole"]],
    ["Clotrimazole (Oral Lozenge)", true, ["clotrimazole"]],
    ["Clotrimazole (Otic)", false, ["clotrimazole"]],
    ["Clotrimazole (Topical)", false, ["clotrimazole"]],
    ["Clotrimazole (Vaginal)", false, ["clotrimazole"]],
    ["cloZAPine (Oral Disintegrating)", true, ["clozapine"]],
    ["cloZAPine (Oral Liquid)", true, ["clozapine"]],
    ["cloZAPine (Oral Pill)", true, ["clozapine"]],
    ["CLOZARIL (Oral Pill)", true, ["clozapine"]],
    ["CNJ-016 (Injectable)", false, ["human vaccinia immune globulin"]],
    ["COAGADEX (Injectable)", false, ["factor X"]],
    ["Coagulation factor IX recombinant immunoglobulin G1 fusion protein (Injectable)", false, ["coagulation factor IX recombinant immunoglobulin G1 fusion protein"]],
    ["Coal tar (Shampoo)", false, ["coal tar"]],
    ["Coal tar (Topical)", false, ["coal tar"]],
    ["Coal tar/Menthol (Shampoo)", false, ["coal tar", "menthol"]],
    ["Coal tar/Salicylic acid (Shampoo)", false, ["coal tar", "salicylic acid"]],
    ["COARTEM (Oral Pill)", true, ["artemether", "lumefantrine"]],
    ["Cobamamide/Vitamin B12 (Sublingual)", false, ["cobamamide", "vitamin B12"]],
    ["COBENFY (Oral Pill)", true, ["trospium", "xanomeline"]],
    ["COBENFY 28-DAY STARTER KIT (Pack)", true, ["trospium", "xanomeline"]],
    ["COBENFY 7-DAY TITRATION PACK - 50 MG/20 MG (4), 100 MG/20 MG (10) 14 COUNT (Pack)", true, ["trospium", "xanomeline"]],
    ["Cobicistat (Oral Pill)", true, ["cobicistat"]],
    ["Cobicistat/Darunavir (Oral Pill)", true, ["cobicistat", "darunavir"]],
    ["Cobicistat/Darunavir (Oral Suspension Tablet)", true, ["cobicistat", "darunavir"]],
    ["Cobicistat/Darunavir/Emtricitabine/Tenofovir alafenamide (Oral Pill)", true, ["cobicistat", "darunavir", "emtricitabine", "tenofovir alafenamide"]],
    ["Cobicistat/Elvitegravir/Emtricitabine/Tenofovir alafenamide (Oral Pill)", true, ["cobicistat", "elvitegravir", "emtricitabine", "tenofovir alafenamide"]],
    ["Cobicistat/Elvitegravir/Emtricitabine/Tenofovir disoproxil (Oral Pill)", true, ["cobicistat", "elvitegravir", "emtricitabine", "tenofovir disoproxil"]],
    ["Cobimetinib (Oral Pill)", true, ["cobimetinib"]],
    ["Cocaine (Nasal)", false, ["cocaine"]],
    ["Coccidioides immitis spherule (Injectable)", false, ["Coccidioides immitis spherule"]],
    ["Cocoa butter/Phenylephrine (Rectal)", false, ["cocoa butter", "phenylephrine"]],
    ["Cocoa butter/Zinc oxide (Rectal)", false, ["cocoa butter", "zinc oxide"]],
    ["Coconut oil (Oral Pill)", true, ["coconut oil"]],
    ["Coconut oil/Linseed oil (Oral Pill)", true, ["coconut oil", "linseed oil"]],
    ["Codeine (Oral Pill)", true, ["codeine"]],
    ["Codeine/Dexbrompheniramine (Oral Liquid)", true, ["codeine", "dexbrompheniramine"]],
    ["Codeine/guaiFENesin (Oral Liquid)", true, ["codeine", "guaifenesin"]],
    ["Codeine/guaiFENesin (Oral Pill)", true, ["codeine", "guaifenesin"]],
    ["Codeine/Promethazine (Oral Liquid)", true, ["codeine", "promethazine"]],
    ["COLACE (Oral Pill)", true, ["docusate"]],
    ["COLACE W/SENNOSIDES (Oral Pill)", true, ["docusate", "sennosides, USP"]],
    ["COLAZAL (Oral Pill)", true, ["balsalazide"]],
    ["Colchicine (Oral Liquid)", true, ["colchicine"]],
    ["Colchicine (Oral Pill)", true, ["colchicine"]],
    ["Colchicine/Probenecid (Oral Pill)", true, ["colchicine", "probenecid"]],
    ["COLCRYS (Oral Pill)", true, ["colchicine"]],
    ["Colesevelam (Oral Pill)", true, ["colesevelam"]],
    ["Colesevelam (Oral Suspension Powder)", true, ["colesevelam"]],
    ["COLESTID (Oral Pill)", true, ["colestipol"]],
    ["COLESTID (Oral Suspension Granules)", true, ["colestipol"]],
    ["Colestipol (Oral Pill)", true, ["colestipol"]],
    ["Colestipol (Oral Suspension Granules)", true, ["colestipol"]],
    ["Colistin (Injectable)", false, ["colistin"]],
    ["Collagenase (Topical)", false, ["collagenase"]],
    ["Collagenase Clostridium histolyticum (Injectable)", false, ["collagenase Clostridium histolyticum"]],
    ["Colloidal oatmeal (Soap)", false, ["colloidal oatmeal"]],
    ["Colloidal oatmeal (Topical)", false, ["colloidal oatmeal"]],
    ["COLUMVI (Injectable)", false, ["glofitamab"]],
    ["COLY MYCIN M (Injectable)", false, ["colistin"]],
    ["COMBIGAN (Ophthalmic)", false, ["brimonidine", "timolol"]],
    ["COMBIPATCH (Transdermal)", false, ["estradiol", "norethindrone"]],
    ["COMBIVENT (Inhalant)", false, ["albuterol", "ipratropium"]],
    ["COMBIVIR (Oral Pill)", true, ["lamivudine", "zidovudine"]],
    ["COMBOGESIC (Injectable)", false, ["acetaminophen", "ibuprofen"]],
    ["COMBOGESIC (Oral Pill)", true, ["acetaminophen", "ibuprofen"]],
    ["COMETRIQ (Oral Pill)", true, ["cabozantinib"]],
    ["COMETRIQ 100 MG DAILY DOSE CARTON (Pack)", true, ["cabozantinib"]],
    ["COMETRIQ 140 MG DAILY DOSE CARTON (Pack)", true, ["cabozantinib"]],
    ["COMETRIQ 60 MG DAILY DOSE CARTON (Pack)", true, ["cabozantinib"]],
    ["COMFORT CAINE (Oral Ointment)", true, ["benzocaine"]],
    ["COMFORT GEL (Oral Liquid)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["COMFORT SHIELD (Topical)", false, ["dimethicone"]],
    ["COMIRNATY 2025-2026 (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["COMIRNATY 2026-2027 (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["COMPAZINE (Oral Pill)", true, ["prochlorperazine"]],
    ["COMPAZINE (Rectal)", false, ["prochlorperazine"]],
    ["COMPLERA (Oral Pill)", true, ["emtricitabine", "rilpivirine", "tenofovir disoproxil"]],
    ["COMPRO (Rectal)", false, ["prochlorperazine"]],
    ["COMTAN (Oral Pill)", true, ["entacapone"]],
    ["CONCEPT OB (Oral Pill)", true, ["ascorbic acid", "biotin", "copper sulfate", "ferrous fumarate", "folic acid", "magnesium sulfate", "manganese sulfate", "niacin", "pantothenate", "polysaccharide iron complex", "pyridoxine", "riboflavin", "thiamine", "vitamin B12", "zinc sulfate"]],
    ["CONCEPTROL (Vaginal)", false, ["nonoxynol-9"]],
    ["CONCERTA XR (Oral Pill)", true, ["methylphenidate"]],
    ["Concizumab (Injectable)", false, ["concizumab"]],
    ["CONDYLOX (Topical)", false, ["podofilox"]],
    ["CONEXXENCE (Injectable)", false, ["denosumab"]],
    ["Conivaptan (Injectable)", false, ["conivaptan"]],
    ["CONJUPRI (Oral Pill)", true, ["levamlodipine"]],
    ["CONSENSI (Oral Pill)", true, ["amlodipine", "celecoxib"]],
    ["CONSTULOSE (Oral Liquid)", true, ["lactulose"]],
    ["CONTAC COLD XR (Oral Pill)", true, ["pseudoephedrine"]],
    ["CONTEPO (Injectable)", false, ["fosfomycin"]],
    ["CONTRAGESIC (Oral Pill)", true, ["acetaminophen", "phenyltoloxamine"]],
    ["CONTRAVE XR (Oral Pill)", true, ["bupropion", "naltrexone"]],
    ["CONZIP XR (Oral Pill)", true, ["tramadol"]],
    ["COOL BOTTOMS (Topical)", false, ["dimethicone"]],
    ["Copanlisib (Injectable)", false, ["copanlisib"]],
    ["COPAXONE (Injectable)", false, ["glatiramer"]],
    ["COPIKTRA (Oral Pill)", true, ["duvelisib"]],
    ["Copper (Implant)", false, ["copper"]],
    ["Copper gluconate (Oral Pill)", true, ["copper gluconate"]],
    ["Copper histidinate (Injectable)", false, ["copper histidinate"]],
    ["Copper sulfate/Manganese sulfate/Selenious acid/Zinc sulfate (Injectable)", false, ["copper sulfate", "manganese sulfate", "selenious acid", "zinc sulfate"]],
    ["CORDRAN (Topical)", false, ["flurandrenolide"]],
    ["COREG (Oral Pill)", true, ["carvedilol"]],
    ["COREG XR (Oral Pill)", true, ["carvedilol"]],
    ["CORGARD (Oral Pill)", true, ["nadolol"]],
    ["CORIFACT (Injectable)", false, ["factor XIII"]],
    ["CORLANOR (Oral Liquid)", true, ["ivabradine"]],
    ["CORLANOR (Oral Pill)", true, ["ivabradine"]],
    ["Corn starch (Topical)", false, ["corn starch"]],
    ["Corn starch/Kaolin/Zinc oxide (Topical)", false, ["corn starch", "kaolin", "zinc oxide"]],
    ["Cornsilk (Oral Pill)", true, ["cornsilk"]],
    ["CORRECT (NEW FORMULA) (Oral Pill)", true, ["bisacodyl"]],
    ["CORRECTOL LAXATIVE REFORMULATED FEB 2008 (Oral Pill)", true, ["bisacodyl"]],
    ["CORTAID (Topical)", false, ["hydrocortisone"]],
    ["CORTANE-B (Otic)", false, ["chloroxylenol", "hydrocortisone", "pramoxine"]],
    ["CORTANE-B (Topical)", false, ["chloroxylenol", "hydrocortisone", "pramoxine"]],
    ["CORTEF (Oral Pill)", true, ["hydrocortisone"]],
    ["CORTENEMA (Rectal)", false, ["hydrocortisone"]],
    ["CORTICOOL (Topical)", false, ["hydrocortisone"]],
    ["Corticotropin (Injectable)", false, ["corticotropin"]],
    ["CORTIFOAM (Rectal)", false, ["hydrocortisone"]],
    ["Cortisone (Oral Pill)", true, ["cortisone"]],
    ["CORTISPORIN (Otic)", false, ["hydrocortisone", "neomycin", "polymyxin B"]],
    ["CORTISPORIN-TC (Otic)", false, ["colistin", "hydrocortisone", "neomycin", "thonzonium"]],
    ["CORTIZONE (Topical)", false, ["hydrocortisone"]],
    ["CORTROPHIN (Injectable)", false, ["corticotropin"]],
    ["CORVERT (Injectable)", false, ["ibutilide"]],
    ["COSAMIN (Oral Pill)", true, ["chondroitin sulfates", "glucosamine"]],
    ["COSELA (Injectable)", false, ["trilaciclib"]],
    ["COSENTYX (Injectable)", false, ["secukinumab"]],
    ["Cosibelimab (Injectable)", false, ["cosibelimab"]],
    ["COSMEGEN (Injectable)", false, ["dactinomycin"]],
    ["COSOPT (Ophthalmic)", false, ["dorzolamide", "timolol"]],
    ["COTELLIC (Oral Pill)", true, ["cobimetinib"]],
    ["COTEMPLA (Oral Disintegrating)", true, ["methylphenidate"]],
    ["COVARYX (Oral Pill)", true, ["estrogens, esterified (USP)", "methyltestosterone"]],
    ["COXANTO (Oral Pill)", true, ["oxaprozin"]],
    ["COZAAR (Oral Pill)", true, ["losartan"]],
    ["Creatine (Chewable)", true, ["creatine"]],
    ["CRENESSITY (Oral Liquid)", true, ["crinecerfont"]],
    ["CRENESSITY (Oral Pill)", true, ["crinecerfont"]],
    ["CREOMULSION (Oral Liquid)", true, ["dextromethorphan"]],
    ["CREON (Oral Pill)", true, ["amylase", "lipase", "protease"]],
    ["CRESEMBA (Injectable)", false, ["isavuconazonium"]],
    ["CRESEMBA (Oral Pill)", true, ["isavuconazonium"]],
    ["CREST MOUTHWASH (Mouthwash)", false, ["cetylpyridinium"]],
    ["CRESTOR (Oral Pill)", true, ["rosuvastatin"]],
    ["cresyl acetate (Otic)", false, ["4-cresyl acetate"]],
    ["CRESYLATE (Otic)", false, ["4-cresyl acetate"]],
    ["CREXONT XR (Oral Pill)", true, ["carbidopa", "levodopa"]],
    ["Crinecerfont (Oral Liquid)", true, ["crinecerfont"]],
    ["Crinecerfont (Oral Pill)", true, ["crinecerfont"]],
    ["CRINONE (Vaginal)", false, ["progesterone"]],
    ["Crisaborole (Topical)", false, ["crisaborole"]],
    ["CRITIC-AID CLEAR (Topical)", false, ["miconazole"]],
    ["CRITIC-AID CLEAR MOISTURE (Topical)", false, ["petrolatum"]],
    ["CRITIC-AID SKIN (Paste)", false, ["zinc oxide"]],
    ["Crizanlizumab (Injectable)", false, ["crizanlizumab"]],
    ["Crizotinib (Oral Pellet)", true, ["crizotinib"]],
    ["Crizotinib (Oral Pill)", true, ["crizotinib"]],
    ["CROFAB (Injectable)", false, ["Agkistrodon piscivorus antivenin", "Crotalus adamanteus antivenin", "Crotalus atrox antivenin", "Crotalus scutulatus antivenin"]],
    ["Crofelemer (Oral Pill)", true, ["crofelemer"]],
    ["Cromolyn (Inhalant)", false, ["cromolyn"]],
    ["Cromolyn (Nasal)", false, ["cromolyn"]],
    ["Cromolyn (Ophthalmic)", false, ["cromolyn"]],
    ["Cromolyn (Oral Liquid)", true, ["cromolyn"]],
    ["Crotalidae immune F(ab')2 (Injectable)", false, ["Crotalidae immune F(ab')2"]],
    ["Crotamiton (Topical)", false, ["crotamiton"]],
    ["CROTAN (Topical)", false, ["crotamiton"]],
    ["Crovalimab (Injectable)", false, ["crovalimab"]],
    ["CRUEX ANTIFUNGAL (Topical)", false, ["clotrimazole"]],
    ["CRUEX PRESCRIPTION STRENGTH (Topical)", false, ["miconazole"]],
    ["CRYSELLE 28 (Pack)", true, ["ethinyl estradiol", "norgestrel"]],
    ["CRYSVITA (Injectable)", false, ["burosumab"]],
    ["CTEXLI (Oral Pill)", true, ["chenodeoxycholate"]],
    ["Cupric chloride (Injectable)", false, ["cupric chloride"]],
    ["Cupric oxide/Folic acid/Niacinamide/Zinc oxide (Oral Pill)", true, ["cupric oxide", "folic acid", "niacinamide", "zinc oxide"]],
    ["CUPRIMINE (Oral Pill)", true, ["penicillamine"]],
    ["CURAE (Oral Pill)", true, ["levonorgestrel"]],
    ["Curcumin (Oral Pill)", true, ["curcumin"]],
    ["CUROSURF (Intratracheal)", false, ["poractant alfa"]],
    ["CUTAQUIG (Injectable)", false, ["immunoglobulin G"]],
    ["CUTAR (Topical)", false, ["coal tar"]],
    ["CUTIVATE (Topical)", false, ["fluticasone"]],
    ["CUVITRU (Injectable)", false, ["immunoglobulin G"]],
    ["CUVPOSA (Oral Liquid)", true, ["glycopyrronium"]],
    ["CUVRIOR (Oral Pill)", true, ["trientine"]],
    ["CYANOKIT (Injectable)", false, ["hydroxocobalamin"]],
    ["Cyclobenzaprine (Oral Pill)", true, ["cyclobenzaprine"]],
    ["Cyclobenzaprine (Sublingual)", false, ["cyclobenzaprine"]],
    ["Cyclobenzaprine XR (Oral Pill)", true, ["cyclobenzaprine"]],
    ["CYCLOGYL (Ophthalmic)", false, ["cyclopentolate"]],
    ["CYCLOMYDRIL (Ophthalmic)", false, ["cyclopentolate", "phenylephrine"]],
    ["Cyclopentolate (Ophthalmic)", false, ["cyclopentolate"]],
    ["Cyclopentolate/Phenylephrine (Ophthalmic)", false, ["cyclopentolate", "phenylephrine"]],
    ["cycloPHOSphamide (Injectable)", false, ["cyclophosphamide"]],
    ["cycloPHOSphamide (Oral Pill)", true, ["cyclophosphamide"]],
    ["cycloSERINE (Oral Pill)", true, ["cycloserine"]],
    ["CYCLOSET (Oral Pill)", true, ["bromocriptine"]],
    ["cycloSPORINE (Injectable)", false, ["cyclosporine"]],
    ["cycloSPORINE (Ophthalmic)", false, ["cyclosporine"]],
    ["cycloSPORINE (Oral Liquid)", true, ["cyclosporine"]],
    ["cycloSPORINE (Oral Pill)", true, ["cyclosporine"]],
    ["CYFENDUS (Injectable)", false, ["Bacillus anthracis strain V770-NP1-R antigens"]],
    ["CYKLOKAPRON (Injectable)", false, ["tranexamic acid"]],
    ["CYLATE (Ophthalmic)", false, ["cyclopentolate"]],
    ["CYLTEZO (Injectable)", false, ["adalimumab"]],
    ["CYLTEZO PEN 40 MG/0.4 ML STARTER PACK - CROHN'S DISEASE OR ULCERATIVE COLITIS (Pack)", false, ["adalimumab"]],
    ["CYLTEZO PEN 40 MG/0.4 ML STARTER PACK - PSORIASIS (Pack)", false, ["adalimumab"]],
    ["CYLTEZO PEN 40 MG/0.8 ML STARTER PACK - PSORIASIS (Pack)", false, ["adalimumab"]],
    ["CYLTEZO PEN 40 MG/0.8 ML STARTER PACKAGE FOR CROHN'S DISEASE OR ULCERATIVE COLITIS (Pack)", false, ["adalimumab"]],
    ["CYMBALTA (Oral Pill)", true, ["duloxetine"]],
    ["CYONANZ 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Cyproheptadine (Oral Liquid)", true, ["cyproheptadine"]],
    ["Cyproheptadine (Oral Pill)", true, ["cyproheptadine"]],
    ["CYPROLARA (Oral Pill)", true, ["cyproheptadine"]],
    ["CYRAMZA (Injectable)", false, ["ramucirumab"]],
    ["CYRED 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["CYSTADANE (Oral Solution Powder)", true, ["betaine"]],
    ["CYSTADROPS (Ophthalmic)", false, ["cysteamine"]],
    ["CYSTAGON (Oral Pill)", true, ["cysteamine"]],
    ["CYSTARAN (Ophthalmic)", false, ["cysteamine"]],
    ["Cysteamine (Ophthalmic)", false, ["cysteamine"]],
    ["Cysteamine (Oral Granules)", true, ["cysteamine"]],
    ["Cysteamine (Oral Pill)", true, ["cysteamine"]],
    ["Cysteine (Injectable)", false, ["cysteine"]],
    ["CYSTEX (Oral Pill)", true, ["methenamine", "salicylic acid"]],
    ["Cytarabine (Injectable)", false, ["cytarabine"]],
    ["Cytarabine/DAUNOrubicin (Injectable)", false, ["cytarabine", "daunorubicin"]],
    ["CYTOGAM (Injectable)", false, ["cytomegalovirus immune globulin"]],
    ["Cytomegalovirus immune globulin (Injectable)", false, ["cytomegalovirus immune globulin"]],
    ["CYTOMEL (Oral Pill)", true, ["liothyronine"]],
    ["CYTOTEC (Oral Pill)", true, ["misoprostol"]],
    ["CYTRA 2 (Oral Liquid)", true, ["citric acid", "sodium citrate"]],
    ["CYTRA-3 (Oral Liquid)", true, ["citric acid", "potassium citrate", "sodium citrate"]],
    ["CYTRA-K (Oral Liquid)", true, ["citric acid", "potassium citrate"]],
    ["CYTRA-K (Oral Solution Powder)", true, ["citric acid", "potassium citrate"]],
    ["D-biotin (Oral Pill)", true, ["D-biotin"]],
    ["D-VI-SOL (Oral Liquid)", true, ["cholecalciferol"]],
    ["Dabigatran etexilate (Oral Pellet)", true, ["dabigatran etexilate"]],
    ["Dabigatran etexilate (Oral Pill)", true, ["dabigatran etexilate"]],
    ["Dabrafenib (Oral Pill)", true, ["dabrafenib"]],
    ["Dabrafenib (Oral Suspension Tablet)", true, ["dabrafenib"]],
    ["Dacarbazine (Injectable)", false, ["dacarbazine"]],
    ["DACOGEN (Injectable)", false, ["decitabine"]],
    ["Dacomitinib (Oral Pill)", true, ["dacomitinib"]],
    ["DACTINomycin (Injectable)", false, ["dactinomycin"]],
    ["Dalbavancin (Injectable)", false, ["dalbavancin"]],
    ["Dalfampridine XR (Oral Pill)", true, ["dalfampridine"]],
    ["DALIRESP (Oral Pill)", true, ["roflumilast"]],
    ["DALLERGY REFORMULATED NOV 2011 (Chewable)", true, ["chlorcyclizine", "phenylephrine"]],
    ["Dalteparin (Injectable)", false, ["dalteparin"]],
    ["DALVANCE (Injectable)", false, ["dalbavancin"]],
    ["Damoctocog alfa pegol (Injectable)", false, ["damoctocog alfa pegol"]],
    ["Danazol (Oral Pill)", true, ["danazol"]],
    ["DANDREX (Shampoo)", false, ["selenium sulfide"]],
    ["Danicopan (Oral Pill)", true, ["danicopan"]],
    ["Danicopan (Pack)", true, ["danicopan"]],
    ["DANTRIUM (Injectable)", false, ["dantrolene"]],
    ["DANTRIUM (Oral Pill)", true, ["dantrolene"]],
    ["Dantrolene (Injectable)", false, ["dantrolene"]],
    ["Dantrolene (Oral Pill)", true, ["dantrolene"]],
    ["DANYELZA (Injectable)", false, ["naxitamab"]],
    ["DANZITEN (Oral Pill)", true, ["nilotinib"]],
    ["Dapagliflozin (Oral Pill)", true, ["dapagliflozin"]],
    ["Dapagliflozin/metFORMIN XR (Oral Pill)", true, ["dapagliflozin", "metformin"]],
    ["Dapagliflozin/sAXagliptin (Oral Pill)", true, ["dapagliflozin", "saxagliptin"]],
    ["Dapiprazole (Ophthalmic)", false, ["dapiprazole"]],
    ["Daprodustat (Oral Pill)", true, ["daprodustat"]],
    ["Dapsone (Oral Pill)", true, ["dapsone"]],
    ["Dapsone (Topical)", false, ["dapsone"]],
    ["DAPTACEL (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["DAPTOmycin (Injectable)", false, ["daptomycin"]],
    ["DAPZURA (Injectable)", false, ["daptomycin"]],
    ["DARAPRIM (Oral Pill)", true, ["pyrimethamine"]],
    ["Daratumumab (Injectable)", false, ["daratumumab"]],
    ["Daratumumab/Hyaluronidase (Injectable)", false, ["daratumumab", "hyaluronidase"]],
    ["Daraxonrasib (Oral Pill)", true, ["daraxonrasib"]],
    ["Darbepoetin alfa (Injectable)", false, ["darbepoetin alfa"]],
    ["Daridorexant (Oral Pill)", true, ["daridorexant"]],
    ["Darifenacin XR (Oral Pill)", true, ["darifenacin"]],
    ["Darolutamide (Oral Pill)", true, ["darolutamide"]],
    ["DARTISLA (Oral Disintegrating)", true, ["glycopyrronium"]],
    ["Darunavir (Oral Liquid)", true, ["darunavir"]],
    ["Darunavir (Oral Pill)", true, ["darunavir"]],
    ["DARZALEX (Injectable)", false, ["daratumumab"]],
    ["DARZALEX FASPRO (Injectable)", false, ["daratumumab", "hyaluronidase"]],
    ["Dasatinib (Oral Pill)", true, ["dasatinib"]],
    ["DASETTA 1/35 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["DASETTA 7/7/7 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Dasiglucagon (Injectable)", false, ["dasiglucagon"]],
    ["Datopotamab deruxtecan (Injectable)", false, ["datopotamab deruxtecan"]],
    ["DATROWAY (Injectable)", false, ["datopotamab deruxtecan"]],
    ["DAUNOrubicin (Injectable)", false, ["daunorubicin"]],
    ["DAURISMO (Oral Pill)", true, ["glasdegib"]],
    ["DAWNZERA (Injectable)", false, ["donidalorsen"]],
    ["DAXXIFY (Injectable)", false, ["botulinum toxin type A"]],
    ["DAYBUE (Oral Liquid)", true, ["trofinetide"]],
    ["DAYBUE (Oral Solution Powder)", true, ["trofinetide"]],
    ["DAYHIST-1 (Oral Pill)", true, ["clemastine"]],
    ["DAYPRO (Oral Pill)", true, ["oxaprozin"]],
    ["DAYQUIL COUGH (Oral Liquid)", true, ["dextromethorphan"]],
    ["DAYSEE 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["DAYTRANA (Transdermal)", false, ["methylphenidate"]],
    ["DAYVIGO (Oral Pill)", true, ["lemborexant"]],
    ["DDAVP (Injectable)", false, ["desmopressin"]],
    ["DDAVP (Nasal)", false, ["desmopressin"]],
    ["DDAVP (Oral Pill)", true, ["desmopressin"]],
    ["DEBACTEROL (Mucosal)", false, ["sulfonated phenol", "sulfuric acid"]],
    ["DEBACTEROL (Topical)", false, ["sulfonated phenol", "sulfuric acid"]],
    ["DEBLITANE 28 DAY (Pack)", true, ["norethindrone"]],
    ["DEBROX (Otic)", false, ["carbamide peroxide"]],
    ["DECADRON (Oral Pill)", true, ["dexamethasone"]],
    ["DECARA (Oral Pill)", true, ["cholecalciferol"]],
    ["Decitabine (Injectable)", false, ["decitabine"]],
    ["DECNUPAZ (Injectable)", false, ["pivekimab sunirine"]],
    ["DEEP SEA (Nasal)", false, ["sodium chloride"]],
    ["Defactinib (Oral Pill)", true, ["defactinib"]],
    ["DEFENCATH (Injectable)", false, ["heparin", "taurolidine"]],
    ["Deferasirox (Oral Granules)", true, ["deferasirox"]],
    ["Deferasirox (Oral Pill)", true, ["deferasirox"]],
    ["Deferasirox (Oral Suspension Tablet)", true, ["deferasirox"]],
    ["Deferiprone (Oral Liquid)", true, ["deferiprone"]],
    ["Deferiprone (Oral Pill)", true, ["deferiprone"]],
    ["Deferoxamine (Injectable)", false, ["deferoxamine"]],
    ["Defibrotide (Injectable)", false, ["defibrotide"]],
    ["DEFITELIO (Injectable)", false, ["defibrotide"]],
    ["Deflazacort (Oral Liquid)", true, ["deflazacort"]],
    ["Deflazacort (Oral Pill)", true, ["deflazacort"]],
    ["Degarelix (Injectable)", false, ["degarelix"]],
    ["DEL-AQUA (Topical)", false, ["benzoyl peroxide"]],
    ["DEL-BETA (Topical)", false, ["betamethasone"]],
    ["Delafloxacin (Injectable)", false, ["delafloxacin"]],
    ["Delafloxacin (Oral Pill)", true, ["delafloxacin"]],
    ["Delandistrogene moxeparvovec (Injectable)", false, ["delandistrogene moxeparvovec"]],
    ["Delandistrogene moxeparvovec (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["DELESTROGEN (Injectable)", false, ["estradiol"]],
    ["Delgocitinib (Topical)", false, ["delgocitinib"]],
    ["DELSTRIGO (Oral Pill)", true, ["doravirine", "lamivudine", "tenofovir disoproxil"]],
    ["DELSYM XR (Oral Liquid)", true, ["dextromethorphan"]],
    ["DELTA D3 (Oral Pill)", true, ["cholecalciferol"]],
    ["DELTASONE (Oral Pill)", true, ["prednisone"]],
    ["DELYLA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["DELZICOL (Oral Pill)", true, ["mesalamine"]],
    ["Demeclocycline (Oral Pill)", true, ["demeclocycline"]],
    ["DEMEROL (Injectable)", false, ["meperidine"]],
    ["DEMEROL (Oral Pill)", true, ["meperidine"]],
    ["DEMSER (Oral Pill)", true, ["metyrosine"]],
    ["DENAVIR (Topical)", false, ["penciclovir"]],
    ["DENDRACIN NEURODENDRAXCIN (Topical)", false, ["capsaicin", "menthol", "methyl salicylate"]],
    ["DENGVAXIA (Injectable)", false, ["dengue virus live antigen, CYD serotype 1", "dengue virus live antigen, CYD serotype 2", "dengue virus live antigen, CYD serotype 3", "dengue virus live antigen, CYD serotype 4"]],
    ["Denileukin diftitox (Injectable)", false, ["denileukin diftitox"]],
    ["DENOREX EXTRA STRENGTH REFORMULATED AUG 2012 (Shampoo)", false, ["salicylic acid"]],
    ["DENOREX THERAPEUTIC REFORMULATED MAR 2013 (Shampoo)", false, ["coal tar", "menthol"]],
    ["Denosumab (Injectable)", false, ["denosumab"]],
    ["DENTA 5000 PLUS (Toothpaste)", false, ["sodium fluoride"]],
    ["DENTAGEL (Toothpaste)", false, ["sodium fluoride"]],
    ["DENTAL RESOURCES PERIO MAINTENANCE RINSE (Mouthwash)", false, ["stannous fluoride"]],
    ["DENTICARE NEUTRAL (Mouthwash)", false, ["sodium fluoride"]],
    ["Deoxycholate (Injectable)", false, ["deoxycholate"]],
    ["DEPAKOTE (Oral Pill)", true, ["valproate"]],
    ["DEPAKOTE XR (Oral Pill)", true, ["valproate"]],
    ["Depemokimab (Injectable)", false, ["depemokimab"]],
    ["DEPEN (Oral Pill)", true, ["penicillamine"]],
    ["DEPO-ESTRADIOL (Injectable)", false, ["estradiol"]],
    ["DEPO-Medrol (Injectable)", false, ["methylprednisolone"]],
    ["DEPO-PROVERA (Injectable)", false, ["medroxyprogesterone"]],
    ["DEPO-SUBQ PROVERA (Injectable)", false, ["medroxyprogesterone"]],
    ["DEPO-TESTOSTERONE (Injectable)", false, ["testosterone"]],
    ["DERIFIL (Oral Pill)", true, ["chlorophyll"]],
    ["DERMA GRAN (Topical)", false, ["aluminum hydroxide"]],
    ["DERMA GRAN SPRAY (Topical)", false, ["zinc acetate"]],
    ["DERMA-SMOOTHE FS (Topical)", false, ["fluocinolone"]],
    ["DERMACERIN (Topical)", false, ["petrolatum"]],
    ["DERMACORT (Topical)", false, ["hydrocortisone"]],
    ["DERMAFIX (Topical)", false, ["petrolatum"]],
    ["DERMAFUNGAL (Topical)", false, ["miconazole"]],
    ["DERMAGRAN (Topical)", false, ["miconazole"]],
    ["DERMALZONE (Topical)", false, ["salicylic acid"]],
    ["DERMAMYCIN (Topical)", false, ["diphenhydramine"]],
    ["DERMAPHOR (Topical)", false, ["petrolatum"]],
    ["DERMASARRA (Topical)", false, ["camphor", "menthol"]],
    ["DERMASIL (Topical)", false, ["dimethicone"]],
    ["DERMATOP (Topical)", false, ["prednicarbate"]],
    ["DERMAZENE (Topical)", false, ["hydrocortisone", "iodoquinol"]],
    ["DERMAZINC (Shampoo)", false, ["zinc pyrithione"]],
    ["DERMAZINC (Topical)", false, ["zinc pyrithione"]],
    ["DERMELEVE (Topical)", false, ["aluminum acetate"]],
    ["DERMOPLAST (Topical)", false, ["benzocaine"]],
    ["DERMOPLAST ANTIBACTERIAL (Topical)", false, ["benzethonium", "benzocaine"]],
    ["DERMOPLAST PAIN (Topical)", false, ["benzocaine", "menthol"]],
    ["DERMOTIC (Otic)", false, ["fluocinolone"]],
    ["DERMTEX HC (Topical)", false, ["hydrocortisone"]],
    ["DESCOVY (Oral Pill)", true, ["emtricitabine", "tenofovir alafenamide"]],
    ["DESENEX (Topical)", false, ["miconazole"]],
    ["DESFERAL (Injectable)", false, ["deferoxamine"]],
    ["Desflurane (Inhalant)", false, ["desflurane"]],
    ["Desipramine (Oral Pill)", true, ["desipramine"]],
    ["Desirudin (Injectable)", false, ["desirudin"]],
    ["DESITIN (Paste)", false, ["zinc oxide"]],
    ["DESITIN (Topical)", false, ["zinc oxide"]],
    ["DESITIN CLEAR (Topical)", false, ["petrolatum"]],
    ["Desloratadine (Oral Disintegrating)", true, ["desloratadine"]],
    ["Desloratadine (Oral Liquid)", true, ["desloratadine"]],
    ["Desloratadine (Oral Pill)", true, ["desloratadine"]],
    ["Desloratadine/Pseudoephedrine XR (Oral Pill)", true, ["desloratadine", "pseudoephedrine"]],
    ["DESMODA (Oral Liquid)", true, ["desmopressin"]],
    ["Desmopressin (Injectable)", false, ["desmopressin"]],
    ["Desmopressin (Nasal)", false, ["desmopressin"]],
    ["Desmopressin (Oral Liquid)", true, ["desmopressin"]],
    ["Desmopressin (Oral Pill)", true, ["desmopressin"]],
    ["Desmopressin (Sublingual)", false, ["desmopressin"]],
    ["Desogestrel/Ethinyl estradiol (Oral Pill)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Desogestrel/Ethinyl estradiol (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Desonide (Topical)", false, ["desonide"]],
    ["DESOWEN (Topical)", false, ["desonide"]],
    ["Desoximetasone (Topical)", false, ["desoximetasone"]],
    ["DESOXYN (Oral Pill)", true, ["methamphetamine"]],
    ["DESQUAM (Soap)", false, ["benzoyl peroxide"]],
    ["DESQUAM (Topical)", false, ["benzoyl peroxide"]],
    ["Desvenlafaxine XR (Oral Pill)", true, ["desvenlafaxine"]],
    ["DETROL (Oral Pill)", true, ["tolterodine"]],
    ["DETROL XR (Oral Pill)", true, ["tolterodine"]],
    ["Deucravacitinib (Oral Pill)", true, ["deucravacitinib"]],
    ["Deuruxolitinib (Oral Pill)", true, ["deuruxolitinib"]],
    ["Deutetrabenazine (Oral Pill)", true, ["deutetrabenazine"]],
    ["Deutetrabenazine (Pack)", true, ["deutetrabenazine"]],
    ["Deutetrabenazine XR (Oral Pill)", true, ["deutetrabenazine"]],
    ["Deutivacaftor/Tezacaftor/Vanzacaftor (Oral Pill)", true, ["deutivacaftor", "tezacaftor", "vanzacaftor"]],
    ["DEVROM (Chewable)", true, ["bismuth subgallate"]],
    ["DEVROM (Oral Pill)", true, ["bismuth subgallate"]],
    ["DEX4 (Chewable)", true, ["glucose"]],
    ["DEX4 (Oral Gel)", true, ["glucose"]],
    ["DEX4 (Oral Liquid)", true, ["glucose"]],
    ["dexAMETHasone (Implant)", false, ["dexamethasone"]],
    ["dexAMETHasone (Injectable)", false, ["dexamethasone"]],
    ["dexAMETHasone (Ophthalmic)", false, ["dexamethasone"]],
    ["dexAMETHasone (Oral Liquid)", true, ["dexamethasone"]],
    ["dexAMETHasone (Oral Pill)", true, ["dexamethasone"]],
    ["dexAMETHasone (Pack)", true, ["dexamethasone"]],
    ["dexAMETHasone/Tobramycin (Ophthalmic)", false, ["dexamethasone", "tobramycin"]],
    ["Dexbrompheniramine (Chewable)", true, ["dexbrompheniramine"]],
    ["Dexbrompheniramine (Oral Liquid)", true, ["dexbrompheniramine"]],
    ["Dexbrompheniramine (Oral Pill)", true, ["dexbrompheniramine"]],
    ["Dexbrompheniramine/Phenylephrine (Oral Liquid)", true, ["dexbrompheniramine", "phenylephrine"]],
    ["Dexbrompheniramine/Phenylephrine (Oral Pill)", true, ["dexbrompheniramine", "phenylephrine"]],
    ["Dexbrompheniramine/Pseudoephedrine (Oral Liquid)", true, ["dexbrompheniramine", "pseudoephedrine"]],
    ["Dexbrompheniramine/Pseudoephedrine (Oral Pill)", true, ["dexbrompheniramine", "pseudoephedrine"]],
    ["Dexchlorpheniramine (Oral Liquid)", true, ["dexchlorpheniramine"]],
    ["Dexchlorpheniramine/Dextromethorphan (Oral Liquid)", true, ["dexchlorpheniramine", "dextromethorphan"]],
    ["Dexchlorpheniramine/Phenylephrine (Oral Pill)", true, ["dexchlorpheniramine", "phenylephrine"]],
    ["Dexchlorpheniramine/Pseudoephedrine (Oral Liquid)", true, ["dexchlorpheniramine", "pseudoephedrine"]],
    ["Dexchlorpheniramine/Pseudoephedrine (Oral Pill)", true, ["dexchlorpheniramine", "pseudoephedrine"]],
    ["DEXEDRINE (Oral Pill)", true, ["dextroamphetamine"]],
    ["DEXEDRINE XR (Oral Pill)", true, ["dextroamphetamine"]],
    ["DEXILANT (Oral Pill)", true, ["dexlansoprazole"]],
    ["Dexlansoprazole (Oral Pill)", true, ["dexlansoprazole"]],
    ["DEXLYT (Oral Pill)", true, ["dexamethasone"]],
    ["dexmedeTOMIDine (Injectable)", false, ["dexmedetomidine"]],
    ["dexmedeTOMIDine (Sublingual)", false, ["dexmedetomidine"]],
    ["Dexmethylphenidate (Oral Pill)", true, ["dexmethylphenidate"]],
    ["Dexmethylphenidate XR (Oral Pill)", true, ["dexmethylphenidate"]],
    ["Dexmethylphenidate/Serdexmethylphenidate (Oral Pill)", true, ["dexmethylphenidate", "serdexmethylphenidate"]],
    ["Dexpanthenol/Niacinamide/Riboflavin/Thiamine/Vitamin B6 (Injectable)", false, ["dexpanthenol", "niacinamide", "riboflavin", "thiamine", "vitamin B6"]],
    ["Dexrazoxane (Injectable)", false, ["dexrazoxane"]],
    ["DEXTENZA (Implant)", false, ["dexamethasone"]],
    ["Dextran 40 (Injectable)", false, ["dextran 40"]],
    ["Dextran 70/Glycerin/Hypromellose (Ophthalmic)", false, ["dextran 70", "glycerin", "hypromellose"]],
    ["Dextran 70/Hypromellose (Ophthalmic)", false, ["dextran 70", "hypromellose"]],
    ["Dextran 70/Polyethylene glycol 400/Povidone/Tetrahydrozoline (Ophthalmic)", false, ["dextran 70", "polyethylene glycol 400", "povidone", "tetrahydrozoline"]],
    ["Dextroamphetamine (Oral Liquid)", true, ["dextroamphetamine"]],
    ["Dextroamphetamine (Oral Pill)", true, ["dextroamphetamine"]],
    ["Dextroamphetamine (Transdermal)", false, ["dextroamphetamine"]],
    ["Dextroamphetamine XR (Oral Pill)", true, ["dextroamphetamine"]],
    ["Dextromethorphan (Chewable)", true, ["dextromethorphan"]],
    ["Dextromethorphan (Oral Disintegrating)", true, ["dextromethorphan"]],
    ["Dextromethorphan (Oral Liquid)", true, ["dextromethorphan"]],
    ["Dextromethorphan (Oral Lozenge)", true, ["dextromethorphan"]],
    ["Dextromethorphan (Oral Pill)", true, ["dextromethorphan"]],
    ["Dextromethorphan XR (Oral Liquid)", true, ["dextromethorphan"]],
    ["Dextromethorphan/Doxylamine (Chewable)", true, ["dextromethorphan", "doxylamine"]],
    ["Dextromethorphan/Doxylamine (Oral Liquid)", true, ["dextromethorphan", "doxylamine"]],
    ["Dextromethorphan/Doxylamine (Pack)", false, ["dextromethorphan", "doxylamine"]],
    ["Dextromethorphan/guaiFENesin (Effervescent)", true, ["dextromethorphan", "guaifenesin"]],
    ["Dextromethorphan/guaiFENesin (Oral Granules)", true, ["dextromethorphan", "guaifenesin"]],
    ["Dextromethorphan/guaiFENesin (Oral Liquid)", true, ["dextromethorphan", "guaifenesin"]],
    ["Dextromethorphan/guaiFENesin (Oral Pill)", true, ["dextromethorphan", "guaifenesin"]],
    ["Dextromethorphan/guaiFENesin XR (Oral Pill)", true, ["dextromethorphan", "guaifenesin"]],
    ["Dextromethorphan/Hexylresorcinol (Oral Lozenge)", true, ["dextromethorphan", "hexylresorcinol"]],
    ["Dextromethorphan/Menthol (Oral Lozenge)", true, ["dextromethorphan", "menthol"]],
    ["Dextromethorphan/Phenylephrine (Oral Liquid)", true, ["dextromethorphan", "phenylephrine"]],
    ["Dextromethorphan/Phenylephrine (Oral Spray)", true, ["dextromethorphan", "phenylephrine"]],
    ["Dextromethorphan/Promethazine (Oral Liquid)", true, ["dextromethorphan", "promethazine"]],
    ["Dextromethorphan/Pseudoephedrine (Oral Pill)", true, ["dextromethorphan", "pseudoephedrine"]],
    ["Dextromethorphan/Pyrilamine (Oral Liquid)", true, ["dextromethorphan", "pyrilamine"]],
    ["Dextromethorphan/Pyrilamine (Oral Pill)", true, ["dextromethorphan", "pyrilamine"]],
    ["Dextromethorphan/quiNIDine (Oral Pill)", true, ["dextromethorphan", "quinidine"]],
    ["Dextromethorphan/Triprolidine (Oral Liquid)", true, ["dextromethorphan", "triprolidine"]],
    ["DEXYCU (Injectable)", false, ["dexamethasone"]],
    ["DHIVY (Oral Pill)", true, ["carbidopa", "levodopa"]],
    ["DHS SALICYLIC ACID 3% (Shampoo)", false, ["salicylic acid"]],
    ["DHS TAR SHAMPOO (Shampoo)", false, ["coal tar"]],
    ["DHS ZINC (Shampoo)", false, ["zinc pyrithione"]],
    ["DI-DAK-SOL (Topical)", false, ["hypochlorite"]],
    ["DIABETIC TUSSIN EX (Oral Liquid)", true, ["guaifenesin"]],
    ["DIACOMIT (Oral Pill)", true, ["stiripentol"]],
    ["DIACOMIT (Oral Suspension Powder)", true, ["stiripentol"]],
    ["DIALYVITE 800 (Oral Pill)", true, ["ascorbic acid", "biotin", "folic acid", "mecobalamin", "niacinamide", "pantothenate", "pyridoxine", "riboflavin", "thiamine"]],
    ["DIALYVITE 800 WITH IRON (Oral Pill)", true, ["ascorbic acid", "biotin", "ferrous fumarate", "folic acid", "mecobalamin", "niacinamide", "pantothenate", "pyridoxine", "riboflavin", "thiamine"]],
    ["DIALYVITE 800 WITH ZINC (Oral Pill)", true, ["ascorbic acid", "biotin", "folic acid", "mecobalamin", "niacinamide", "pantothenate", "pyridoxine", "riboflavin", "thiamine", "zinc citrate"]],
    ["DIALYVITE VITAMIN D3 MAX (Oral Pill)", true, ["cholecalciferol"]],
    ["DIAMODE (Oral Pill)", true, ["loperamide"]],
    ["DIANEAL LOW CALCIUM 1.5 (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["DIANEAL LOW CALCIUM 2.5 (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["DIANEAL LOW CALCIUM 4.25 (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["DIANEAL PD-2/1.5 (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["DIANEAL PD-2/2.5 (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["DIANEAL PD-2/4.25 (Intraperitoneal)", false, ["calcium chloride", "glucose", "lactate", "magnesium chloride", "sodium chloride"]],
    ["DIASTAT (Rectal)", false, ["diazepam"]],
    ["diazePAM (Buccal)", false, ["diazepam"]],
    ["diazePAM (Injectable)", false, ["diazepam"]],
    ["diazePAM (Nasal)", false, ["diazepam"]],
    ["diazePAM (Oral Liquid)", true, ["diazepam"]],
    ["diazePAM (Oral Pill)", true, ["diazepam"]],
    ["diazePAM (Pack)", false, ["diazepam"]],
    ["diazePAM (Rectal)", false, ["diazepam"]],
    ["Diazoxide (Oral Liquid)", true, ["diazoxide"]],
    ["Diazoxide XR (Oral Pill)", true, ["diazoxide"]],
    ["Dibasic potassium phosphate/Potassium phosphate (Injectable)", false, ["dibasic potassium phosphate", "potassium phosphate"]],
    ["DIBENZYLINE (Oral Pill)", true, ["phenoxybenzamine"]],
    ["Dibucaine (Rectal)", false, ["dibucaine"]],
    ["Dibucaine (Topical)", false, ["dibucaine"]],
    ["Dichlorphenamide (Oral Pill)", true, ["dichlorphenamide"]],
    ["DICLEGIS (Oral Pill)", true, ["doxylamine", "pyridoxine"]],
    ["Diclofenac (Ophthalmic)", false, ["diclofenac"]],
    ["Diclofenac (Oral Pill)", true, ["diclofenac"]],
    ["Diclofenac (Oral Solution Powder)", true, ["diclofenac"]],
    ["Diclofenac (Topical)", false, ["diclofenac"]],
    ["Diclofenac XR (Oral Pill)", true, ["diclofenac"]],
    ["Diclofenac/Lidocaine (Topical)", false, ["diclofenac", "lidocaine"]],
    ["Diclofenac/Lidocaine/Menthol (Topical)", false, ["diclofenac", "lidocaine", "menthol"]],
    ["Diclofenac/Methyl salicylate (Topical)", false, ["diclofenac", "methyl salicylate"]],
    ["Diclofenac/miSOPROStol (Oral Pill)", true, ["diclofenac", "misoprostol"]],
    ["Dicloxacillin (Oral Pill)", true, ["dicloxacillin"]],
    ["Dicyclomine (Injectable)", false, ["dicyclomine"]],
    ["Dicyclomine (Oral Liquid)", true, ["dicyclomine"]],
    ["Dicyclomine (Oral Pill)", true, ["dicyclomine"]],
    ["Didanosine (Oral Pill)", true, ["didanosine"]],
    ["Dienestrol (Vaginal)", false, ["dienestrol"]],
    ["Dienogest/Estradiol (Oral Pill)", true, ["dienogest", "estradiol"]],
    ["Dienogest/Estradiol (Pack)", true, ["dienogest", "estradiol"]],
    ["Diethylpropion (Oral Pill)", true, ["diethylpropion"]],
    ["Diethylpropion XR (Oral Pill)", true, ["diethylpropion"]],
    ["Difamilast (Topical)", false, ["difamilast"]],
    ["Difelikefalin (Injectable)", false, ["difelikefalin"]],
    ["DIFFERIN (Topical)", false, ["adapalene"]],
    ["DIFFERIN ACNE CLEARING (Soap)", false, ["salicylic acid"]],
    ["DIFFERIN ACNE CLEARING (Topical)", false, ["salicylic acid"]],
    ["DIFFERIN EPIDUO (Topical)", false, ["adapalene", "benzoyl peroxide"]],
    ["DIFICID (Oral Liquid)", true, ["fidaxomicin"]],
    ["DIFICID (Oral Pill)", true, ["fidaxomicin"]],
    ["Diflorasone (Topical)", false, ["diflorasone"]],
    ["DIFLUCAN (Oral Liquid)", true, ["fluconazole"]],
    ["DIFLUCAN (Oral Pill)", true, ["fluconazole"]],
    ["Diflunisal (Oral Pill)", true, ["diflunisal"]],
    ["Difluprednate (Ophthalmic)", false, ["difluprednate"]],
    ["DIGENYX (Oral Pill)", true, ["hyoscyamine"]],
    ["DIGEX (Oral Pill)", true, ["hyoscyamine", "phenyltoloxamine"]],
    ["DIGIFAB (Injectable)", false, ["digoxin antibodies Fab fragments"]],
    ["DIGOX (Oral Pill)", true, ["digoxin"]],
    ["Digoxin (Injectable)", false, ["digoxin"]],
    ["Digoxin (Oral Liquid)", true, ["digoxin"]],
    ["Digoxin (Oral Pill)", true, ["digoxin"]],
    ["Digoxin antibodies Fab fragments (Injectable)", false, ["digoxin antibodies Fab fragments"]],
    ["Dihematoporphyrin ether (Injectable)", false, ["dihematoporphyrin ether"]],
    ["Dihydroergotamine (Injectable)", false, ["dihydroergotamine"]],
    ["Dihydroergotamine (Nasal)", false, ["dihydroergotamine"]],
    ["Dihydroxyacetone (Topical)", false, ["dihydroxyacetone"]],
    ["DILANTIN (Chewable)", true, ["phenytoin"]],
    ["DILANTIN (Oral Liquid)", true, ["phenytoin"]],
    ["DILANTIN XR (Oral Pill)", true, ["phenytoin"]],
    ["DILAUDID (Injectable)", false, ["hydromorphone"]],
    ["DILAUDID (Oral Liquid)", true, ["hydromorphone"]],
    ["DILAUDID (Oral Pill)", true, ["hydromorphone"]],
    ["DILT XR (Oral Pill)", true, ["diltiazem"]],
    ["dilTIAZem (Injectable)", false, ["diltiazem"]],
    ["dilTIAZem (Oral Pill)", true, ["diltiazem"]],
    ["dilTIAZem XR (Oral Pill)", true, ["diltiazem"]],
    ["DILTZAC XR (Oral Pill)", true, ["diltiazem"]],
    ["dimenhyDRINATE (Chewable)", true, ["dimenhydrinate"]],
    ["dimenhyDRINATE (Injectable)", false, ["dimenhydrinate"]],
    ["dimenhyDRINATE (Oral Pill)", true, ["dimenhydrinate"]],
    ["Dimercaprol (Injectable)", false, ["dimercaprol"]],
    ["Dimethicone (Topical)", false, ["dimethicone"]],
    ["Dimethicone/Menthol (Topical)", false, ["dimethicone", "menthol"]],
    ["Dimethicone/Miconazole/Zinc oxide (Topical)", false, ["dimethicone", "miconazole", "zinc oxide"]],
    ["Dimethicone/Petrolatum (Topical)", false, ["dimethicone", "petrolatum"]],
    ["Dimethicone/Pramoxine (Topical)", false, ["dimethicone", "pramoxine"]],
    ["Dimethicone/Triamcinolone (Pack)", false, ["dimethicone", "triamcinolone"]],
    ["Dimethicone/Zinc oxide (Topical)", false, ["dimethicone", "zinc oxide"]],
    ["Dimethyl fumarate (Oral Pill)", true, ["dimethyl fumarate"]],
    ["Dimethyl fumarate (Pack)", true, ["dimethyl fumarate"]],
    ["Dimethyl sulfoxide (Irrigation)", false, ["dimethyl sulfoxide"]],
    ["Dimethyl sulfoxide/Miconazole (Topical)", false, ["dimethyl sulfoxide", "miconazole"]],
    ["Dinoprostone (Vaginal)", false, ["dinoprostone"]],
    ["Dinutuximab (Injectable)", false, ["dinutuximab"]],
    ["Diosmin/Hesperidin (Oral Pill)", true, ["diosmin", "hesperidin"]],
    ["DIOVAN (Oral Pill)", true, ["valsartan"]],
    ["DIOVAN HCT (Oral Pill)", true, ["hydrochlorothiazide", "valsartan"]],
    ["DIPENTUM (Oral Pill)", true, ["olsalazine"]],
    ["DIPHEDRYL (Oral Pill)", true, ["diphenhydramine"]],
    ["DIPHENHIST (Oral Pill)", true, ["diphenhydramine"]],
    ["diphenhydrAMINE (Chewable)", true, ["diphenhydramine"]],
    ["diphenhydrAMINE (Injectable)", false, ["diphenhydramine"]],
    ["diphenhydrAMINE (Oral Disintegrating)", true, ["diphenhydramine"]],
    ["diphenhydrAMINE (Oral Liquid)", true, ["diphenhydramine"]],
    ["diphenhydrAMINE (Oral Pill)", true, ["diphenhydramine"]],
    ["diphenhydrAMINE (Topical)", false, ["diphenhydramine"]],
    ["diphenhydrAMINE/Ibuprofen (Oral Pill)", true, ["diphenhydramine", "ibuprofen"]],
    ["diphenhydrAMINE/Magnesium salicylate (Oral Pill)", true, ["diphenhydramine", "magnesium salicylate"]],
    ["diphenhydrAMINE/Menthol (Topical)", false, ["diphenhydramine", "menthol"]],
    ["diphenhydrAMINE/Naproxen (Oral Pill)", true, ["diphenhydramine", "naproxen"]],
    ["diphenhydrAMINE/Phenylephrine (Oral Liquid)", true, ["diphenhydramine", "phenylephrine"]],
    ["diphenhydrAMINE/Phenylephrine (Oral Pill)", true, ["diphenhydramine", "phenylephrine"]],
    ["diphenhydrAMINE/Phenylephrine (Pack)", true, ["diphenhydramine", "phenylephrine"]],
    ["diphenhydrAMINE/Pramoxine (Topical)", false, ["diphenhydramine", "pramoxine"]],
    ["diphenhydrAMINE/Tripelennamine (Topical)", false, ["diphenhydramine", "tripelennamine"]],
    ["diphenhydrAMINE/Zinc acetate (Topical)", false, ["diphenhydramine", "zinc acetate"]],
    ["Diphtheria toxoid vaccine, inactivated/Tetanus toxoid vaccine, inactivated (Injectable)", false, ["diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["DIPRIVAN (Injectable)", false, ["propofol"]],
    ["DIPROLENE (Topical)", false, ["betamethasone"]],
    ["Dipyridamole (Injectable)", false, ["dipyridamole"]],
    ["Dipyridamole (Oral Pill)", true, ["dipyridamole"]],
    ["Diroximel fumarate (Oral Pill)", true, ["diroximel fumarate"]],
    ["DISALCID (Oral Pill)", true, ["salsalate"]],
    ["DISCOVISC (Injectable)", false, ["chondroitin sulfates", "hyaluronate"]],
    ["DISKETS (Oral Suspension Tablet)", true, ["methadone"]],
    ["Disopyramide (Oral Pill)", true, ["disopyramide"]],
    ["Disopyramide XR (Oral Pill)", true, ["disopyramide"]],
    ["Disulfiram (Oral Pill)", true, ["disulfiram"]],
    ["DIURIL (Oral Liquid)", true, ["chlorothiazide"]],
    ["DIVIGEL (Topical)", false, ["estradiol"]],
    ["DOANS (Oral Pill)", true, ["magnesium salicylate"]],
    ["DOANS PM (Oral Pill)", true, ["diphenhydramine", "magnesium salicylate"]],
    ["DOBUTamine (Injectable)", false, ["dobutamine"]],
    ["DOCEtaxel (Injectable)", false, ["docetaxel"]],
    ["DOCIVYX (Injectable)", false, ["docetaxel"]],
    ["Docosaenoic acid/Eicosapentaenoate (Oral Pill)", true, ["docosaenoic acid", "eicosapentaenoate"]],
    ["Docosahexaenoate (Oral Pill)", true, ["docosahexaenoate"]],
    ["Docosahexaenoate/Eicosapentaenoate (Oral Pill)", true, ["docosahexaenoate", "eicosapentaenoate"]],
    ["Docosahexaenoate/Eicosapentaenoate/Folic acid/Phytosterols/Vitamin B12/Vitamin B6 (Oral Pill)", true, ["docosahexaenoate", "eicosapentaenoate", "folic acid", "phytosterols", "vitamin B12", "vitamin B6"]],
    ["Docosahexaenoate/Eicosapentaenoate/Omega-3 acid ethyl esters (USP) (Oral Pill)", true, ["docosahexaenoate", "eicosapentaenoate", "omega-3 acid ethyl esters (USP)"]],
    ["Docosanol (Topical)", false, ["docosanol"]],
    ["DOCTOR'S CHOICE (Oral Gel)", true, ["stannous fluoride"]],
    ["DOCULASE (Oral Pill)", true, ["docusate"]],
    ["Docusate (Oral Liquid)", true, ["docusate"]],
    ["Docusate (Oral Pill)", true, ["docusate"]],
    ["Docusate (Rectal)", false, ["docusate"]],
    ["Docusate/Sennosides, USP (Oral Pill)", true, ["docusate", "sennosides, USP"]],
    ["DOCUSOL (Rectal)", false, ["docusate"]],
    ["Dodecyl sulfate/Oxyquinoline (Vaginal)", false, ["dodecyl sulfate", "oxyquinoline"]],
    ["DODEX (Injectable)", false, ["vitamin B12"]],
    ["Dofetilide (Oral Pill)", true, ["dofetilide"]],
    ["DOJOLVI (Oral Liquid)", true, ["triheptanoin"]],
    ["DOK (Oral Pill)", true, ["docusate"]],
    ["Dolasetron (Oral Pill)", true, ["dolasetron"]],
    ["DOLISHALE 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["DOLOBID (Oral Pill)", true, ["diflunisal"]],
    ["DOLOPHINE (Oral Pill)", true, ["methadone"]],
    ["DOLORACIN WITH LIDOCAINE (Topical)", false, ["capsaicin", "lidocaine", "menthol", "methyl salicylate"]],
    ["Dolutegravir (Oral Pill)", true, ["dolutegravir"]],
    ["Dolutegravir (Oral Suspension Tablet)", true, ["dolutegravir"]],
    ["Dolutegravir/lamiVUDine (Oral Pill)", true, ["dolutegravir", "lamivudine"]],
    ["Dolutegravir/Rilpivirine (Oral Pill)", true, ["dolutegravir", "rilpivirine"]],
    ["DOMEBORO (Topical)", false, ["aluminum sulfate", "calcium acetate"]],
    ["Donanemab (Injectable)", false, ["donanemab"]],
    ["Donepezil (Oral Disintegrating)", true, ["donepezil"]],
    ["Donepezil (Oral Pill)", true, ["donepezil"]],
    ["Donepezil (Transdermal)", false, ["donepezil"]],
    ["Donepezil/Memantine (Pack)", true, ["donepezil", "memantine"]],
    ["Donepezil/Memantine XR (Oral Pill)", true, ["donepezil", "memantine"]],
    ["Donidalorsen (Injectable)", false, ["donidalorsen"]],
    ["Donislecel (Injectable)", false, ["donislecel"]],
    ["DONNATAL (Oral Liquid)", true, ["atropine", "hyoscyamine", "phenobarbital", "scopolamine"]],
    ["DONNATAL (Oral Pill)", true, ["atropine", "hyoscyamine", "phenobarbital", "scopolamine"]],
    ["DONNATAL XR (Oral Pill)", true, ["atropine", "hyoscyamine", "phenobarbital", "scopolamine"]],
    ["DOPamine (Injectable)", false, ["dopamine"]],
    ["DOPRAM (Injectable)", false, ["doxapram"]],
    ["DOPTELET (Oral Granules)", true, ["avatrombopag"]],
    ["DOPTELET (Oral Pill)", true, ["avatrombopag"]],
    ["DOPTELET 40 MG DAILY DOSE CARTON (Pack)", true, ["avatrombopag"]],
    ["DOPTELET 60 MG DAILY DOSE CARTON (Pack)", true, ["avatrombopag"]],
    ["DORAL (Oral Pill)", true, ["quazepam"]],
    ["Doravirine (Oral Pill)", true, ["doravirine"]],
    ["Doravirine/Islatravir (Oral Pill)", true, ["doravirine", "islatravir"]],
    ["Doravirine/lamiVUDine/Tenofovir disoproxil (Oral Pill)", true, ["doravirine", "lamivudine", "tenofovir disoproxil"]],
    ["Dordaviprone (Oral Pill)", true, ["dordaviprone"]],
    ["DORMIN (Oral Pill)", true, ["diphenhydramine"]],
    ["Dornase alfa (Inhalant)", false, ["dornase alfa"]],
    ["DORYX (Oral Pill)", true, ["doxycycline"]],
    ["Dorzolamide (Ophthalmic)", false, ["dorzolamide"]],
    ["Dorzolamide/Timolol (Ophthalmic)", false, ["dorzolamide", "timolol"]],
    ["Dostarlimab (Injectable)", false, ["dostarlimab"]],
    ["Dotatate (Injectable)", false, ["dotatate"]],
    ["DOTTI (Transdermal)", false, ["estradiol"]],
    ["DOVATO (Oral Pill)", true, ["dolutegravir", "lamivudine"]],
    ["DOVONEX (Topical)", false, ["calcipotriene"]],
    ["Doxapram (Injectable)", false, ["doxapram"]],
    ["Doxazosin (Oral Pill)", true, ["doxazosin"]],
    ["Doxazosin XR (Oral Pill)", true, ["doxazosin"]],
    ["Doxecitine/Doxribtimine (Oral Solution Powder)", true, ["doxecitine", "doxribtimine"]],
    ["Doxepin (Oral Liquid)", true, ["doxepin"]],
    ["Doxepin (Oral Pill)", true, ["doxepin"]],
    ["Doxepin (Topical)", false, ["doxepin"]],
    ["Doxercalciferol (Injectable)", false, ["doxercalciferol"]],
    ["Doxercalciferol (Oral Pill)", true, ["doxercalciferol"]],
    ["DOXIL (Injectable)", false, ["doxorubicin"]],
    ["DOXOrubicin (Injectable)", false, ["doxorubicin"]],
    ["DOXY (Injectable)", false, ["doxycycline"]],
    ["Doxycycline (Injectable)", false, ["doxycycline"]],
    ["Doxycycline (Oral Liquid)", true, ["doxycycline"]],
    ["Doxycycline (Oral Pill)", true, ["doxycycline"]],
    ["Doxycycline (Pack)", true, ["doxycycline"]],
    ["Doxycycline/Salicylic acid (Pack)", false, ["doxycycline", "salicylic acid"]],
    ["Doxylamine (Chewable)", true, ["doxylamine"]],
    ["Doxylamine (Oral Liquid)", true, ["doxylamine"]],
    ["Doxylamine (Oral Pill)", true, ["doxylamine"]],
    ["Doxylamine/Phenylephrine (Oral Pill)", true, ["doxylamine", "phenylephrine"]],
    ["Doxylamine/Pseudoephedrine (Oral Liquid)", true, ["doxylamine", "pseudoephedrine"]],
    ["Doxylamine/Pyridoxine (Oral Pill)", true, ["doxylamine", "pyridoxine"]],
    ["Doxylamine/Pyridoxine XR (Oral Pill)", true, ["doxylamine", "pyridoxine"]],
    ["DR. SMITH'S DIAPER RASH (Topical)", false, ["zinc oxide"]],
    ["DR. SMITH'S RASH-N-ALL (Topical)", false, ["lanolin", "petrolatum", "zinc oxide"]],
    ["DRAGON (Topical)", false, ["camphor", "menthol", "methyl salicylate"]],
    ["DRAMAMINE (Chewable)", true, ["dimenhydrinate"]],
    ["DRAMAMINE (Oral Pill)", true, ["dimenhydrinate"]],
    ["DRAMAMINE LESS DROWSY (Chewable)", true, ["meclizine"]],
    ["DRAMAMINE LESS DROWSY (Oral Pill)", true, ["meclizine"]],
    ["DRAMAMINE NAUSEA RELIEF (Oral Pill)", true, ["meclizine"]],
    ["DRIMINATE (Oral Pill)", true, ["dimenhydrinate"]],
    ["DRISDOL (Oral Liquid)", true, ["ergocalciferol"]],
    ["DRISDOL (Oral Pill)", true, ["ergocalciferol"]],
    ["DRISTAN 12-HOUR NASAL SPRAY (Nasal)", false, ["oxymetazoline"]],
    ["DRITHOCREME (Topical)", false, ["anthralin"]],
    ["DRIZALMA (Oral Pill)", true, ["duloxetine"]],
    ["droNABinol (Oral Liquid)", true, ["dronabinol"]],
    ["droNABinol (Oral Pill)", true, ["dronabinol"]],
    ["Dronedarone (Oral Pill)", true, ["dronedarone"]],
    ["droPERidol (Injectable)", false, ["droperidol"]],
    ["Drospirenone (Oral Pill)", true, ["drospirenone"]],
    ["Drospirenone (Pack)", true, ["drospirenone"]],
    ["Drospirenone/Estetrol (Oral Pill)", true, ["drospirenone", "estetrol"]],
    ["Drospirenone/Estetrol (Pack)", true, ["drospirenone", "estetrol"]],
    ["Drospirenone/Estradiol (Oral Pill)", true, ["drospirenone", "estradiol"]],
    ["Drospirenone/Estradiol (Pack)", true, ["drospirenone", "estradiol"]],
    ["Drospirenone/Ethinyl estradiol (Oral Pill)", true, ["drospirenone", "ethinyl estradiol"]],
    ["Drospirenone/Ethinyl estradiol (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["DROXIA (Oral Pill)", true, ["hydroxyurea"]],
    ["Droxidopa (Oral Pill)", true, ["droxidopa"]],
    ["DRYSOL (Topical)", false, ["aluminum chloride"]],
    ["DSUVIA (Sublingual)", false, ["sufentanil"]],
    ["DUAKLIR (Inhalant)", false, ["aclidinium", "formoterol"]],
    ["DUAVEE (Oral Pill)", true, ["bazedoxifene", "estrogens, conjugated (USP)"]],
    ["DUETACT (Oral Pill)", true, ["glimepiride", "pioglitazone"]],
    ["DUEXIS (Oral Pill)", true, ["famotidine", "ibuprofen"]],
    ["Dulaglutide (Injectable)", false, ["dulaglutide"]],
    ["DULCOLAX (Oral Pill)", true, ["bisacodyl"]],
    ["DULCOLAX (Rectal)", false, ["bisacodyl"]],
    ["DULERA (Inhalant)", false, ["formoterol", "mometasone"]],
    ["DULoxetine (Oral Pill)", true, ["duloxetine"]],
    ["DUO FUSION (Chewable)", true, ["calcium carbonate", "famotidine", "magnesium hydroxide"]],
    ["DUOBRII (Topical)", false, ["halobetasol", "tazarotene"]],
    ["DUODOTE (Injectable)", false, ["atropine", "pralidoxime"]],
    ["DUOFILM (Topical)", false, ["salicylic acid"]],
    ["DUOPA (Oral Liquid)", true, ["carbidopa", "levodopa"]],
    ["DUOPLANT (Topical)", false, ["salicylic acid"]],
    ["DUOVISC KIT 0.35/0.4 (Pack)", false, ["chondroitin sulfates", "hyaluronate"]],
    ["DUOVISC KIT 0.5/0.55 (Pack)", false, ["chondroitin sulfates", "hyaluronate"]],
    ["Dupilumab (Injectable)", false, ["dupilumab"]],
    ["DUPIXENT (Injectable)", false, ["dupilumab"]],
    ["DURACLON (Injectable)", false, ["clonidine"]],
    ["DURAFLOR (Mouthwash)", false, ["sodium fluoride"]],
    ["DURAMIST PLUS (Nasal)", false, ["oxymetazoline"]],
    ["DURAMORPH (Injectable)", false, ["morphine"]],
    ["DURAPREP (Topical)", false, ["iodine povacrylex", "isopropyl alcohol"]],
    ["DUREZOL (Ophthalmic)", false, ["difluprednate"]],
    ["DURLAZA XR (Oral Pill)", true, ["aspirin"]],
    ["Durlobactam/Sulbactam (Injectable)", false, ["durlobactam", "sulbactam"]],
    ["DUROLANE (Injectable)", false, ["hyaluronate"]],
    ["Durvalumab (Injectable)", false, ["durvalumab"]],
    ["DURYSTA (Implant)", false, ["bimatoprost"]],
    ["Dutasteride (Oral Pill)", true, ["dutasteride"]],
    ["Dutasteride/Tamsulosin (Oral Pill)", true, ["dutasteride", "tamsulosin"]],
    ["Duvelisib (Oral Pill)", true, ["duvelisib"]],
    ["DUVYZAT (Oral Liquid)", true, ["givinostat"]],
    ["DXEVO 11 DAY TAPER (Pack)", true, ["dexamethasone"]],
    ["DYANAVEL XR (Oral Liquid)", true, ["amphetamine"]],
    ["DYANAVEL XR (Oral Pill)", true, ["amphetamine"]],
    ["DYAZIDE (Oral Pill)", true, ["hydrochlorothiazide", "triamterene"]],
    ["Dyclonine (Mucosal)", false, ["dyclonine"]],
    ["Dyclonine (Oral Lozenge)", true, ["dyclonine"]],
    ["Dyclonine/Menthol (Oral Lozenge)", true, ["dyclonine", "menthol"]],
    ["Dyclonine/Menthol/Pectin (Oral Lozenge)", true, ["dyclonine", "menthol", "pectin"]],
    ["DYCLOPRO (Mucosal)", false, ["dyclonine"]],
    ["DYMISTA (Nasal)", false, ["azelastine", "fluticasone"]],
    ["DYNA-HEX (Soap)", false, ["chlorhexidine"]],
    ["DYNASHIELD ZO (Topical)", false, ["zinc oxide"]],
    ["DYRENIUM (Oral Pill)", true, ["triamterene"]],
    ["DYSPORT (Injectable)", false, ["botulinum toxin type A"]],
    ["E-R-O (Otic)", false, ["carbamide peroxide"]],
    ["E-Z-GAS II (Oral Solution Granules)", true, ["citric acid", "simethicone", "sodium bicarbonate"]],
    ["E.E.S. (Oral Liquid)", true, ["erythromycin ethylsuccinate"]],
    ["E.E.S. (Oral Pill)", true, ["erythromycin ethylsuccinate"]],
    ["EBANGA (Injectable)", false, ["ansuvimab"]],
    ["EBGLYSS (Injectable)", false, ["lebrikizumab"]],
    ["Ecallantide (Injectable)", false, ["ecallantide"]],
    ["Econazole (Topical)", false, ["econazole"]],
    ["ECONTRA (Oral Pill)", true, ["levonorgestrel"]],
    ["Ecothiopate (Ophthalmic)", false, ["ecothiopate"]],
    ["ECOTRIN (Oral Pill)", true, ["aspirin"]],
    ["ECOZA (Topical)", false, ["econazole"]],
    ["Eculizumab (Injectable)", false, ["eculizumab"]],
    ["ECZEMIN (Topical)", false, ["pramoxine"]],
    ["ED FLEX (Oral Pill)", true, ["acetaminophen", "phenyltoloxamine", "salicylamide"]],
    ["ED SPAZ (Oral Disintegrating)", true, ["hyoscyamine"]],
    ["Edaravone (Injectable)", false, ["edaravone"]],
    ["Edaravone (Oral Liquid)", true, ["edaravone"]],
    ["EDARBI (Oral Pill)", true, ["azilsartan"]],
    ["EDARBYCLOR (Oral Pill)", true, ["azilsartan", "chlorthalidone"]],
    ["EDECRIN (Injectable)", false, ["ethacrynate"]],
    ["EDECRIN (Oral Pill)", true, ["ethacrynate"]],
    ["Edetate calcium (Injectable)", false, ["edetate calcium"]],
    ["EDEX (Injectable)", false, ["alprostadil"]],
    ["EDLUAR (Sublingual)", false, ["zolpidem"]],
    ["Edoxaban (Oral Pill)", true, ["edoxaban"]],
    ["EDURANT (Oral Pill)", true, ["rilpivirine"]],
    ["EDURANT (Oral Suspension Tablet)", true, ["rilpivirine"]],
    ["Efavirenz (Oral Pill)", true, ["efavirenz"]],
    ["Efavirenz/Emtricitabine/Tenofovir disoproxil (Oral Pill)", true, ["efavirenz", "emtricitabine", "tenofovir disoproxil"]],
    ["Efavirenz/lamiVUDine/Tenofovir disoproxil (Oral Pill)", true, ["efavirenz", "lamivudine", "tenofovir disoproxil"]],
    ["Efbemalenograstim alfa (Injectable)", false, ["efbemalenograstim alfa"]],
    ["EFFER-K (Effervescent)", true, ["potassium bicarbonate"]],
    ["EFFEXOR XR (Oral Pill)", true, ["venlafaxine"]],
    ["EFFIENT (Oral Pill)", true, ["prasugrel"]],
    ["Efgartigimod alfa (Injectable)", false, ["efgartigimod alfa"]],
    ["Efgartigimod alfa/Hyaluronidase (Injectable)", false, ["efgartigimod alfa", "hyaluronidase"]],
    ["Efinaconazole (Topical)", false, ["efinaconazole"]],
    ["Eflapegrastim (Injectable)", false, ["eflapegrastim"]],
    ["Eflornithine (Oral Pill)", true, ["eflornithine"]],
    ["Efmoroctocog alfa (Injectable)", false, ["efmoroctocog alfa"]],
    ["EFUDEX (Topical)", false, ["fluorouracil"]],
    ["EGATEN (Oral Pill)", true, ["triclabendazole"]],
    ["EGRIFTA (Injectable)", false, ["tesamorelin"]],
    ["EKTERLY (Oral Pill)", true, ["sebetralstat"]],
    ["Elacestrant (Oral Pill)", true, ["elacestrant"]],
    ["Eladocagene exuparvovec (Injectable)", false, ["eladocagene exuparvovec"]],
    ["Elafibranor (Oral Pill)", true, ["elafibranor"]],
    ["Elagolix (Oral Pill)", true, ["elagolix"]],
    ["Elagolix/Estradiol/Norethindrone (Oral Pill)", true, ["elagolix", "estradiol", "norethindrone"]],
    ["Elagolix/Estradiol/Norethindrone (Pack)", true, ["elagolix", "estradiol", "norethindrone"]],
    ["ELAHERE (Injectable)", false, ["mirvetuximab soravtansine"]],
    ["Elamipretide (Injectable)", false, ["elamipretide"]],
    ["Elapegademase (Injectable)", false, ["elapegademase"]],
    ["ELAPRASE (Injectable)", false, ["idursulfase"]],
    ["ELAVIL (Oral Pill)", true, ["amitriptyline"]],
    ["Elbasvir/Grazoprevir (Oral Pill)", true, ["elbasvir", "grazoprevir"]],
    ["ELCYS (Injectable)", false, ["cysteine"]],
    ["ELDERTONIC (Oral Liquid)", true, ["dexpanthenol", "magnesium sulfate", "manganese sulfate", "niacinamide", "pyridoxine", "riboflavin", "thiamine", "vitamin B12", "zinc sulfate"]],
    ["ELELYSO (Injectable)", false, ["taliglucerase alfa"]],
    ["ELEPSIA XR (Oral Pill)", true, ["levetiracetam"]],
    ["ELESTRIN (Topical)", false, ["estradiol"]],
    ["Eletriptan (Oral Pill)", true, ["eletriptan"]],
    ["ELEVIDYS (Injectable)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 10.0 - 10.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 10.5 - 11.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 11.5 - 12.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 12.5 - 13.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 13.5 - 14.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 14.5 - 15.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 15.5 - 16.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 16.5 - 17.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 17.5 - 18.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 18.5 - 19.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 19.5 - 20.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 20.5 - 21.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 21.5 - 22.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 22.5 - 23.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 23.5 - 24.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 24.5 - 25.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 25.5 - 26.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 26.5 - 27.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 27.5 - 28.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 28.5 - 29.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 29.5 - 30.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 30.5 - 31.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 31.5 - 32.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 32.5 - 33.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 33.5 - 34.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 34.5 - 35.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 35.5 - 36.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 36.5 - 37.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 37.5 - 38.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 38.5 - 39.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 39.5 - 40.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 40.5 - 41.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 41.5 - 42.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 42.5 - 43.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 43.5 - 44.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 44.5 - 45.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 45.5 - 46.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 46.5 - 47.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 47.5 - 48.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 48.5 - 49.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 49.5 - 50.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 50.5 - 51.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 51.5 - 52.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 52.5 - 53.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 53.5 - 54.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 54.5 - 55.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 55.5 - 56.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 56.5 - 57.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 57.5 - 58.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 58.5 - 59.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 59.5 - 60.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 60.5 - 61.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 61.5 - 62.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 62.5 - 63.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 63.5 - 64.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 64.5 - 65.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 65.5 - 66.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 66.5 - 67.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 67.5 - 68.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT 68.5 - 69.4 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["ELEVIDYS KIT > 69.5 KG (Pack)", false, ["delandistrogene moxeparvovec"]],
    ["Elexacaftor/Ivacaftor/Tezacaftor (Oral Granules)", true, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["Elexacaftor/Ivacaftor/Tezacaftor (Oral Pill)", true, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["Elexacaftor/Ivacaftor/Tezacaftor (Pack)", false, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["ELFABRIO (Injectable)", false, ["pegunigalsidase alfa"]],
    ["ELIDEL (Topical)", false, ["pimecrolimus"]],
    ["ELIGARD (Injectable)", false, ["leuprolide"]],
    ["Eliglustat (Oral Pill)", true, ["eliglustat"]],
    ["ELIMITE (Topical)", false, ["permethrin"]],
    ["ELINEST 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestrel"]],
    ["Elinzanetant (Oral Pill)", true, ["elinzanetant"]],
    ["ELIQUIS (Oral Pill)", true, ["apixaban"]],
    ["ELIQUIS (Oral Suspension Powder)", true, ["apixaban"]],
    ["ELIQUIS (Oral Suspension Tablet)", true, ["apixaban"]],
    ["ELIQUIS 0.5 MG DOSE PACK (Pack)", false, ["apixaban"]],
    ["ELIQUIS 1.5 MG DOSE PACK (Pack)", false, ["apixaban"]],
    ["ELIQUIS 2 MG DOSE PACK (Pack)", false, ["apixaban"]],
    ["ELIQUIS 30-DAY STARTER PACK (Pack)", true, ["apixaban"]],
    ["ELITEK (Injectable)", false, ["rasburicase"]],
    ["Elivaldogene autotemcel (Injectable)", false, ["elivaldogene autotemcel"]],
    ["ELIXOPHYLLIN (Oral Liquid)", true, ["theophylline"]],
    ["ELIXSURE COUGH (Oral Liquid)", true, ["dextromethorphan"]],
    ["ELLA (Oral Pill)", true, ["ulipristal"]],
    ["ELLENCE (Injectable)", false, ["epirubicin"]],
    ["ELLIS TONIC (Oral Liquid)", true, ["dexpanthenol", "magnesium sulfate", "manganese sulfate", "niacinamide", "pyridoxine", "riboflavin", "thiamine", "vitamin B12", "zinc sulfate"]],
    ["ELMIRON (Oral Pill)", true, ["pentosan polysulfate"]],
    ["ELOCTATE (Injectable)", false, ["efmoroctocog alfa"]],
    ["ELON DUAL DEFENSE (Topical)", false, ["undecylenate"]],
    ["Elosulfase alfa (Injectable)", false, ["elosulfase alfa"]],
    ["Elotuzumab (Injectable)", false, ["elotuzumab"]],
    ["Elranatamab (Injectable)", false, ["elranatamab"]],
    ["ELREXFIO (Injectable)", false, ["elranatamab"]],
    ["Eltrombopag (Oral Pill)", true, ["eltrombopag"]],
    ["Eltrombopag (Oral Suspension Powder)", true, ["eltrombopag"]],
    ["ELURYNG (Vaginal)", false, ["ethinyl estradiol", "etonogestrel"]],
    ["Eluxadoline (Oral Pill)", true, ["eluxadoline"]],
    ["ELYXYB (Oral Liquid)", true, ["celecoxib"]],
    ["ELZONRIS (Injectable)", false, ["tagraxofusp"]],
    ["Emapalumab (Injectable)", false, ["emapalumab"]],
    ["EMBLAVEO (Injectable)", false, ["avibactam", "aztreonam"]],
    ["EMCIN CLEAR (Topical)", false, ["erythromycin"]],
    ["EMCYT (Oral Pill)", true, ["estramustine"]],
    ["EMEND (Oral Pill)", true, ["aprepitant"]],
    ["EMEND (Oral Suspension Powder)", true, ["aprepitant"]],
    ["EMEND INJECTION (Injectable)", false, ["fosaprepitant"]],
    ["EMEND TRI-FOLD PACK (Pack)", true, ["aprepitant"]],
    ["EMERPHED (Injectable)", false, ["ephedrine"]],
    ["EMETROL (Oral Liquid)", true, ["fructose", "glucose", "phosphoric acid"]],
    ["EMETROL CHEWABLES (Chewable)", true, ["sodium citrate"]],
    ["EMFLAZA (Oral Liquid)", true, ["deflazacort"]],
    ["EMFLAZA (Oral Pill)", true, ["deflazacort"]],
    ["EMGALITY (Injectable)", false, ["galcanezumab"]],
    ["EMGEL (Topical)", false, ["erythromycin"]],
    ["Emicizumab (Injectable)", false, ["emicizumab"]],
    ["Empagliflozin (Oral Pill)", true, ["empagliflozin"]],
    ["Empagliflozin/Linagliptin (Oral Pill)", true, ["empagliflozin", "linagliptin"]],
    ["Empagliflozin/Linagliptin/metFORMIN XR (Oral Pill)", true, ["empagliflozin", "linagliptin", "metformin"]],
    ["Empagliflozin/metFORMIN (Oral Pill)", true, ["empagliflozin", "metformin"]],
    ["Empagliflozin/metFORMIN XR (Oral Pill)", true, ["empagliflozin", "metformin"]],
    ["EMPAVELI (Injectable)", false, ["pegcetacoplan"]],
    ["EMPLICITI (Injectable)", false, ["elotuzumab"]],
    ["EMRELIS (Injectable)", false, ["telisotuzumab"]],
    ["EMROSI XR (Oral Pill)", true, ["minocycline"]],
    ["EMSAM (Transdermal)", false, ["selegiline"]],
    ["Emtricitabine (Oral Liquid)", true, ["emtricitabine"]],
    ["Emtricitabine (Oral Pill)", true, ["emtricitabine"]],
    ["Emtricitabine/Rilpivirine/Tenofovir alafenamide (Oral Pill)", true, ["emtricitabine", "rilpivirine", "tenofovir alafenamide"]],
    ["Emtricitabine/Rilpivirine/Tenofovir disoproxil (Oral Pill)", true, ["emtricitabine", "rilpivirine", "tenofovir disoproxil"]],
    ["Emtricitabine/Tenofovir alafenamide (Oral Pill)", true, ["emtricitabine", "tenofovir alafenamide"]],
    ["Emtricitabine/Tenofovir disoproxil (Oral Pill)", true, ["emtricitabine", "tenofovir disoproxil"]],
    ["EMTRIVA (Oral Liquid)", true, ["emtricitabine"]],
    ["EMTRIVA (Oral Pill)", true, ["emtricitabine"]],
    ["EMVERM (Chewable)", true, ["mebendazole"]],
    ["EMZAHH 28 DAY (Pack)", true, ["norethindrone"]],
    ["ENABLEX XR (Oral Pill)", true, ["darifenacin"]],
    ["Enalapril (Oral Liquid)", true, ["enalapril"]],
    ["Enalapril (Oral Pill)", true, ["enalapril"]],
    ["Enalapril/hydroCHLOROthiazide (Oral Pill)", true, ["enalapril", "hydrochlorothiazide"]],
    ["Enalaprilat (Injectable)", false, ["enalaprilat"]],
    ["Enasidenib (Oral Pill)", true, ["enasidenib"]],
    ["ENBREL (Injectable)", false, ["etanercept"]],
    ["ENBUMYST (Nasal)", false, ["bumetanide"]],
    ["ENCELTO (Implant)", false, ["revakinagene taroretcel"]],
    ["ENCORA (Pack)", false, ["calcium ascorbate", "calcium carbonate", "cholecalciferol", "folic acid", "linoleate", "omega-3 acid ethyl esters (USP)", "pyridoxine", "vitamin E"]],
    ["ENCORA AM TABLET (Oral Pill)", true, ["calcium ascorbate", "calcium carbonate", "cholecalciferol", "folic acid", "pyridoxine"]],
    ["ENCORA CAPSULE (Oral Pill)", true, ["linoleate", "omega-3 acid ethyl esters (USP)", "vitamin E"]],
    ["ENCORA PM TABLET (Oral Pill)", true, ["calcium ascorbate", "calcium carbonate", "cholecalciferol", "folic acid", "pyridoxine"]],
    ["Encorafenib (Oral Pill)", true, ["encorafenib"]],
    ["ENDARI (Oral Solution Powder)", true, ["glutamine"]],
    ["ENDOCET (Oral Pill)", true, ["acetaminophen", "oxycodone"]],
    ["ENDOMETRIN (Vaginal)", false, ["progesterone"]],
    ["ENDUR-ACIN XR (Oral Pill)", true, ["niacin"]],
    ["ENEMEEZ (Rectal)", false, ["docusate"]],
    ["ENEMEEZ PLUS (Rectal)", false, ["benzocaine", "docusate"]],
    ["ENFAMIL GLUCOSE (Oral Liquid)", true, ["glucose"]],
    ["ENFLONSIA (Injectable)", false, ["clesrovimab"]],
    ["Enfortumab (Injectable)", false, ["enfortumab"]],
    ["Enfuvirtide (Injectable)", false, ["enfuvirtide"]],
    ["ENGERIX-B (Injectable)", false, ["hepatitis B surface antigen vaccine"]],
    ["ENHERTU (Injectable)", false, ["trastuzumab"]],
    ["ENILLORING (Vaginal)", false, ["ethinyl estradiol", "etonogestrel"]],
    ["ENJAYMO (Injectable)", false, ["sutimlimab"]],
    ["Enlicitide (Oral Pill)", true, ["enlicitide"]],
    ["ENOBY (Injectable)", false, ["denosumab"]],
    ["Enoxaparin (Injectable)", false, ["enoxaparin"]],
    ["ENPRESSE 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["ENSACOVE (Oral Pill)", true, ["ensartinib"]],
    ["Ensartinib (Oral Pill)", true, ["ensartinib"]],
    ["Ensifentrine (Inhalant)", false, ["ensifentrine"]],
    ["Ensitrelvir (Oral Pill)", true, ["ensitrelvir"]],
    ["Ensitrelvir (Pack)", true, ["ensitrelvir"]],
    ["ENSKYCE 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["ENSPRYNG (Injectable)", false, ["satralizumab"]],
    ["ENSTILAR (Topical)", false, ["betamethasone", "calcipotriene"]],
    ["Entacapone (Oral Pill)", true, ["entacapone"]],
    ["ENTADFI (Oral Pill)", true, ["finasteride", "tadalafil"]],
    ["Entecavir (Oral Liquid)", true, ["entecavir"]],
    ["Entecavir (Oral Pill)", true, ["entecavir"]],
    ["ENTEREG (Oral Pill)", true, ["alvimopan"]],
    ["Entrectinib (Oral Pellet)", true, ["entrectinib"]],
    ["Entrectinib (Oral Pill)", true, ["entrectinib"]],
    ["ENTRESTO (Oral Pellet)", true, ["sacubitril", "valsartan"]],
    ["ENTRESTO (Oral Pill)", true, ["sacubitril", "valsartan"]],
    ["ENTSOL (Nasal)", false, ["sodium chloride"]],
    ["ENTYVIO (Injectable)", false, ["vedolizumab"]],
    ["ENULOSE (Oral Liquid)", true, ["lactulose"]],
    ["ENVARSUS XR (Oral Pill)", true, ["tacrolimus"]],
    ["Enzalutamide (Oral Pill)", true, ["enzalutamide"]],
    ["EOHILIA (Oral Liquid)", true, ["budesonide"]],
    ["EPANED (Oral Liquid)", true, ["enalapril"]],
    ["EPCLUSA (Oral Pellet)", true, ["sofosbuvir", "velpatasvir"]],
    ["EPCLUSA (Oral Pill)", true, ["sofosbuvir", "velpatasvir"]],
    ["Epcoritamab (Injectable)", false, ["epcoritamab"]],
    ["ePHEDrine (Injectable)", false, ["ephedrine"]],
    ["ePHEDrine (Oral Pill)", true, ["ephedrine"]],
    ["ePHEDrine/guaiFENesin (Oral Pill)", true, ["ephedrine", "guaifenesin"]],
    ["EPIDIOLEX (Oral Liquid)", true, ["cannabidiol"]],
    ["EPIDUO (Topical)", false, ["adapalene", "benzoyl peroxide"]],
    ["EPIFLUR (Chewable)", true, ["sodium fluoride"]],
    ["EPIFOAM (Topical)", false, ["hydrocortisone", "pramoxine"]],
    ["EPIMIDE 50 (Paste)", false, ["urea"]],
    ["Epinastine (Ophthalmic)", false, ["epinastine"]],
    ["EPINEPHrine (Inhalant)", false, ["epinephrine"]],
    ["EPINEPHrine (Injectable)", false, ["epinephrine"]],
    ["EPINEPHrine (Nasal)", false, ["epinephrine"]],
    ["EPINEPHrine/Lidocaine (Injectable)", false, ["epinephrine", "lidocaine"]],
    ["EPINEPHrine/Prilocaine (Injectable)", false, ["epinephrine", "prilocaine"]],
    ["EPIOXA (Ophthalmic)", false, ["riboflavin 5'-phosphate"]],
    ["EPIOXA CROSS-LINKING KIT (Pack)", false, ["riboflavin 5'-phosphate"]],
    ["EPIPEN (Injectable)", false, ["epinephrine"]],
    ["epiRUBicin (Injectable)", false, ["epirubicin"]],
    ["EPITOL (Oral Pill)", true, ["carbamazepine"]],
    ["EPIVIR (Oral Liquid)", true, ["lamivudine"]],
    ["EPIVIR (Oral Pill)", true, ["lamivudine"]],
    ["EPKINLY (Injectable)", false, ["epcoritamab"]],
    ["Eplerenone (Oral Pill)", true, ["eplerenone"]],
    ["Eplontersen (Injectable)", false, ["eplontersen"]],
    ["Epoetin alfa (Injectable)", false, ["epoetin alfa"]],
    ["EPOGEN (Injectable)", false, ["epoetin alfa"]],
    ["Epoprostenol (Injectable)", false, ["epoprostenol"]],
    ["EPRONTIA (Oral Liquid)", true, ["topiramate"]],
    ["EPSOLAY (Topical)", false, ["benzoyl peroxide"]],
    ["Eptifibatide (Injectable)", false, ["eptifibatide"]],
    ["Eptinezumab (Injectable)", false, ["eptinezumab"]],
    ["EPYSQLI (Injectable)", false, ["eculizumab"]],
    ["EPZICOM (Oral Pill)", true, ["abacavir", "lamivudine"]],
    ["EQUALACTIN (Chewable)", true, ["calcium polycarbophil"]],
    ["EQUETRO XR (Oral Pill)", true, ["carbamazepine"]],
    ["Eravacycline (Injectable)", false, ["eravacycline"]],
    ["ERAXIS (Injectable)", false, ["anidulafungin"]],
    ["ERBITUX (Injectable)", false, ["cetuximab"]],
    ["Erdafitinib (Oral Pill)", true, ["erdafitinib"]],
    ["Erenumab (Injectable)", false, ["erenumab"]],
    ["Erenumab (Pack)", false, ["erenumab"]],
    ["Ergocalciferol (Oral Liquid)", true, ["ergocalciferol"]],
    ["Ergocalciferol (Oral Pill)", true, ["ergocalciferol"]],
    ["Ergocalciferol/Vitamin A (Oral Pill)", true, ["ergocalciferol", "vitamin A"]],
    ["Ergoloid mesylates, USP (Oral Pill)", true, ["ergoloid mesylates, USP"]],
    ["ERGOMAR (Sublingual)", false, ["ergotamine"]],
    ["Ergotamine (Sublingual)", false, ["ergotamine"]],
    ["eriBULin (Injectable)", false, ["eribulin"]],
    ["ERIVEDGE (Oral Pill)", true, ["vismodegib"]],
    ["ERLEADA (Oral Pill)", true, ["apalutamide"]],
    ["Erlotinib (Oral Pill)", true, ["erlotinib"]],
    ["ERMEZA (Oral Liquid)", true, ["levothyroxine"]],
    ["ERRIN 28 DAY (Pack)", true, ["norethindrone"]],
    ["ERTACZO (Topical)", false, ["sertaconazole"]],
    ["Ertapenem (Injectable)", false, ["ertapenem"]],
    ["Ertugliflozin (Oral Pill)", true, ["ertugliflozin"]],
    ["Ertugliflozin/metFORMIN (Oral Pill)", true, ["ertugliflozin", "metformin"]],
    ["Ertugliflozin/SITagliptin (Oral Pill)", true, ["ertugliflozin", "sitagliptin"]],
    ["ERVEBO (Injectable)", false, ["Zaire ebolavirus envelope glycoprotein"]],
    ["ERWINAZE (Injectable)", false, ["asparaginase"]],
    ["ERY (Topical)", false, ["erythromycin"]],
    ["ERY-TAB (Oral Pill)", true, ["erythromycin"]],
    ["ERYGEL (Topical)", false, ["erythromycin"]],
    ["ERYPED (Oral Liquid)", true, ["erythromycin ethylsuccinate"]],
    ["ERYTHROCIN (Injectable)", false, ["erythromycin lactobionate"]],
    ["ERYTHROCIN STEARATE (Oral Pill)", true, ["erythromycin stearate"]],
    ["Erythromycin (Ophthalmic)", false, ["erythromycin"]],
    ["Erythromycin (Oral Pill)", true, ["erythromycin"]],
    ["Erythromycin (Topical)", false, ["erythromycin"]],
    ["Erythromycin ethylsuccinate (Oral Liquid)", true, ["erythromycin ethylsuccinate"]],
    ["Erythromycin ethylsuccinate (Oral Pill)", true, ["erythromycin ethylsuccinate"]],
    ["Erythromycin lactobionate (Injectable)", false, ["erythromycin lactobionate"]],
    ["Erythromycin stearate (Oral Pill)", true, ["erythromycin stearate"]],
    ["ERZOFRI (Injectable)", false, ["paliperidone"]],
    ["ESBRIET (Oral Pill)", true, ["pirfenidone"]],
    ["Escitalopram (Oral Liquid)", true, ["escitalopram"]],
    ["Escitalopram (Oral Pill)", true, ["escitalopram"]],
    ["ESGIC (Oral Pill)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["ESKATA (Topical)", false, ["hydrogen peroxide"]],
    ["Esketamine (Nasal)", false, ["esketamine"]],
    ["Esketamine (Pack)", false, ["esketamine"]],
    ["Eslicarbazepine (Oral Pill)", true, ["eslicarbazepine"]],
    ["Eslicarbazepine (Pack)", true, ["eslicarbazepine"]],
    ["Esmolol (Injectable)", false, ["esmolol"]],
    ["Esomeprazole (Injectable)", false, ["esomeprazole"]],
    ["Esomeprazole (Oral Pill)", true, ["esomeprazole"]],
    ["Esomeprazole (Oral Suspension Granules)", true, ["esomeprazole"]],
    ["Esomeprazole/Naproxen (Oral Pill)", true, ["esomeprazole", "naproxen"]],
    ["ESPEROCT (Injectable)", false, ["factor VIII"]],
    ["ESTARYLLA 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["Estazolam (Oral Pill)", true, ["estazolam"]],
    ["ESTRACE (Oral Pill)", true, ["estradiol"]],
    ["ESTRACE (Vaginal)", false, ["estradiol"]],
    ["Estradiol (Injectable)", false, ["estradiol"]],
    ["Estradiol (Oral Pill)", true, ["estradiol"]],
    ["Estradiol (Pack)", false, ["estradiol"]],
    ["Estradiol (Topical)", false, ["estradiol"]],
    ["Estradiol (Transdermal)", false, ["estradiol"]],
    ["Estradiol (Vaginal)", false, ["estradiol"]],
    ["Estradiol/Levonorgestrel (Transdermal)", false, ["estradiol", "levonorgestrel"]],
    ["Estradiol/Norethindrone (Oral Pill)", true, ["estradiol", "norethindrone"]],
    ["Estradiol/Norethindrone (Pack)", true, ["estradiol", "norethindrone"]],
    ["Estradiol/Norethindrone (Transdermal)", false, ["estradiol", "norethindrone"]],
    ["Estradiol/Norethindrone/Relugolix (Oral Pill)", true, ["estradiol", "norethindrone", "relugolix"]],
    ["Estradiol/Progesterone (Oral Pill)", true, ["estradiol", "progesterone"]],
    ["Estramustine (Oral Pill)", true, ["estramustine"]],
    ["ESTRATEST (Oral Pill)", true, ["estrogens, esterified (USP)", "methyltestosterone"]],
    ["ESTRING (Vaginal)", false, ["estradiol"]],
    ["ESTROGEL (Topical)", false, ["estradiol"]],
    ["Estrogens, conjugated (USP) (Injectable)", false, ["estrogens, conjugated (USP)"]],
    ["Estrogens, conjugated (USP) (Oral Pill)", true, ["estrogens, conjugated (USP)"]],
    ["Estrogens, conjugated (USP) (Vaginal)", false, ["estrogens, conjugated (USP)"]],
    ["Estrogens, conjugated (USP)/medroxyPROGESTERone (Oral Pill)", true, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["Estrogens, conjugated (USP)/medroxyPROGESTERone (Pack)", false, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["Estrogens, esterified (USP) (Oral Pill)", true, ["estrogens, esterified (USP)"]],
    ["Estrogens, esterified (USP)/methylTESTOSTERone (Oral Pill)", true, ["estrogens, esterified (USP)", "methyltestosterone"]],
    ["Estropipate (Oral Pill)", true, ["estropipate"]],
    ["Eszopiclone (Oral Pill)", true, ["eszopiclone"]],
    ["Etanercept (Injectable)", false, ["etanercept"]],
    ["ETCAMAH (Oral Pill)", true, ["camizestrant"]],
    ["Etelcalcetide (Injectable)", false, ["etelcalcetide"]],
    ["Eteplirsen (Injectable)", false, ["eteplirsen"]],
    ["Ethacrynate (Injectable)", false, ["ethacrynate"]],
    ["Ethacrynate (Oral Pill)", true, ["ethacrynate"]],
    ["Ethambutol (Oral Pill)", true, ["ethambutol"]],
    ["ETHAMOLIN (Injectable)", false, ["ethanolamine oleate"]],
    ["Ethanol (Injectable)", false, ["ethanol"]],
    ["Ethanol (Soap)", false, ["ethanol"]],
    ["Ethanol (Topical)", false, ["ethanol"]],
    ["Ethanol/Iodine/Sodium iodide (Topical)", false, ["ethanol", "iodine", "sodium iodide"]],
    ["Ethanolamine oleate (Injectable)", false, ["ethanolamine oleate"]],
    ["Ethinyl estradiol (Oral Pill)", true, ["ethinyl estradiol"]],
    ["Ethinyl estradiol/Ethynodiol (Oral Pill)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["Ethinyl estradiol/Ethynodiol (Pack)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["Ethinyl estradiol/Etonogestrel (Vaginal)", false, ["ethinyl estradiol", "etonogestrel"]],
    ["Ethinyl estradiol/Levonorgestrel (Chewable)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Ethinyl estradiol/Levonorgestrel (Oral Pill)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Ethinyl estradiol/Levonorgestrel (Pack)", false, ["ethinyl estradiol", "levonorgestrel"]],
    ["Ethinyl estradiol/Levonorgestrel (Transdermal)", false, ["ethinyl estradiol", "levonorgestrel"]],
    ["Ethinyl estradiol/Norelgestromin (Transdermal)", false, ["ethinyl estradiol", "norelgestromin"]],
    ["Ethinyl estradiol/Norethindrone (Chewable)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Ethinyl estradiol/Norethindrone (Oral Disintegrating)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Ethinyl estradiol/Norethindrone (Oral Pill)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Ethinyl estradiol/Norethindrone (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Ethinyl estradiol/Norgestimate (Oral Pill)", true, ["ethinyl estradiol", "norgestimate"]],
    ["Ethinyl estradiol/Norgestimate (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["Ethinyl estradiol/Norgestrel (Oral Pill)", true, ["ethinyl estradiol", "norgestrel"]],
    ["Ethinyl estradiol/Norgestrel (Pack)", true, ["ethinyl estradiol", "norgestrel"]],
    ["Ethinyl estradiol/Segesterone (Vaginal)", false, ["ethinyl estradiol", "segesterone"]],
    ["Ethionamide (Oral Pill)", true, ["ethionamide"]],
    ["Ethosuximide (Oral Liquid)", true, ["ethosuximide"]],
    ["Ethosuximide (Oral Pill)", true, ["ethosuximide"]],
    ["Ethyl chloride (Topical)", false, ["ethyl chloride"]],
    ["ETHYOL (Injectable)", false, ["amifostine"]],
    ["ETICOVO (Injectable)", false, ["etanercept"]],
    ["Etodolac (Oral Pill)", true, ["etodolac"]],
    ["Etodolac XR (Oral Pill)", true, ["etodolac"]],
    ["Etomidate (Injectable)", false, ["etomidate"]],
    ["Etonogestrel (Implant)", false, ["etonogestrel"]],
    ["ETOPOPHOS (Injectable)", false, ["etoposide"]],
    ["Etoposide (Injectable)", false, ["etoposide"]],
    ["Etoposide (Oral Pill)", true, ["etoposide"]],
    ["Etranacogene dezaparvovec (Injectable)", false, ["etranacogene dezaparvovec"]],
    ["Etranacogene dezaparvovec (Pack)", false, ["etranacogene dezaparvovec"]],
    ["Etrasimod (Oral Pill)", true, ["etrasimod"]],
    ["Etravirine (Oral Pill)", true, ["etravirine"]],
    ["Etripamil (Nasal)", false, ["etripamil"]],
    ["Etuvetidigene autotemcel (Injectable)", false, ["etuvetidigene autotemcel"]],
    ["ETYQA 0.5/0.1 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["ETYQA 1/0.5 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["Eucalyptol/Menthol/Methyl salicylate/Thymol (Mouthwash)", false, ["eucalyptol", "menthol", "methyl salicylate", "thymol"]],
    ["EUCERIN CALMING ITCH RELIEF (Topical)", false, ["menthol"]],
    ["EUCERIN ECZEMA RELIEF (Soap)", false, ["colloidal oatmeal"]],
    ["EUCERIN ECZEMA RELIEF (Topical)", false, ["colloidal oatmeal"]],
    ["EUCRISA (Topical)", false, ["crisaborole"]],
    ["EUFLEXXA (Injectable)", false, ["hyaluronate"]],
    ["Eugenol/Guaiacol (Oral Ointment)", true, ["eugenol", "guaiacol"]],
    ["EULEXIN (Oral Pill)", true, ["flutamide"]],
    ["EURAX (Topical)", false, ["crotamiton"]],
    ["European honey bee venom protein (Injectable)", false, ["European honey bee venom protein"]],
    ["EUTHYROX (Oral Pill)", true, ["levothyroxine"]],
    ["EVAC-U-GEN REFORMULATED JAN 2008 (Oral Pill)", true, ["bisacodyl"]],
    ["EVAMIST (Topical)", false, ["estradiol"]],
    ["EVARREST (Topical)", false, ["fibrinogen", "thrombin"]],
    ["EVDI (Injectable)", false, ["trabectedin"]],
    ["EVEKEO (Oral Disintegrating)", true, ["amphetamine"]],
    ["EVEKEO (Oral Pill)", true, ["amphetamine"]],
    ["Evening primrose oil (Oral Pill)", true, ["evening primrose oil"]],
    ["Evening primrose oil/Linoleate (Oral Pill)", true, ["evening primrose oil", "linoleate"]],
    ["EVENITY (Injectable)", false, ["romosozumab"]],
    ["EVENITY 210 MG DOSE (Pack)", false, ["romosozumab"]],
    ["Everolimus (Oral Pill)", true, ["everolimus"]],
    ["Everolimus (Oral Suspension Tablet)", true, ["everolimus"]],
    ["EVESSE (Topical)", false, ["hydrocortisone"]],
    ["EVEXITHROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["EVICEL (Topical)", false, ["fibrinogen", "thrombin"]],
    ["Evinacumab (Injectable)", false, ["evinacumab"]],
    ["EVISTA (Oral Pill)", true, ["raloxifene"]],
    ["EVIVO (Oral Suspension Powder)", true, ["Bifidobacterium infantis"]],
    ["EVKEEZA (Injectable)", false, ["evinacumab"]],
    ["Evolocumab (Injectable)", false, ["evolocumab"]],
    ["EVOMELA (Injectable)", false, ["melphalan"]],
    ["EVOTAZ (Oral Pill)", true, ["atazanavir", "cobicistat"]],
    ["EVOXAC (Oral Pill)", true, ["cevimeline"]],
    ["EVRYSDI (Oral Liquid)", true, ["risdiplam"]],
    ["EVRYSDI (Oral Pill)", true, ["risdiplam"]],
    ["EX-LAX CHOCOLATED (Chewable)", true, ["sennosides, USP"]],
    ["EX-LAX MAXIMUM RELIEF FORMULA (Oral Pill)", true, ["sennosides, USP"]],
    ["EX-LAX REGULAR STRENGTH PILLS (Oral Pill)", true, ["sennosides, USP"]],
    ["EX-LAX ULTRA (Oral Pill)", true, ["bisacodyl"]],
    ["Exagamglogene autotemcel (Injectable)", false, ["exagamglogene autotemcel"]],
    ["EXAPRIN (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine", "salicylamide"]],
    ["EXBLIFEP (Injectable)", false, ["cefepime", "enmetazobactam"]],
    ["EXCEDRIN (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine"]],
    ["EXCEDRIN MILD HEADACHE (Oral Pill)", true, ["acetaminophen", "caffeine"]],
    ["EXCEDRIN PM (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["EXCEDRIN PM TRIPLE ACTION (Oral Pill)", true, ["acetaminophen", "aspirin", "diphenhydramine"]],
    ["EXCEDRIN QUICK TAB (Oral Disintegrating)", true, ["acetaminophen", "caffeine"]],
    ["EXCEDRIN TENSION HEADACHE (Oral Pill)", true, ["acetaminophen", "caffeine"]],
    ["EXDENSUR (Injectable)", false, ["depemokimab"]],
    ["EXELDERM (Topical)", false, ["sulconazole"]],
    ["EXELON (Transdermal)", false, ["rivastigmine"]],
    ["Exemestane (Oral Pill)", true, ["exemestane"]],
    ["Exenatide (Injectable)", false, ["exenatide"]],
    ["EXFORGE (Oral Pill)", true, ["amlodipine", "valsartan"]],
    ["EXFORGE HCT (Oral Pill)", true, ["amlodipine", "hydrochlorothiazide", "valsartan"]],
    ["EXIDINE (Soap)", false, ["chlorhexidine"]],
    ["EXJADE (Oral Suspension Tablet)", true, ["deferasirox"]],
    ["EXKIVITY (Oral Pill)", true, ["mobocertinib"]],
    ["EXODERM (Topical)", false, ["salicylic acid", "thiosulfate"]],
    ["EXONDYS (Injectable)", false, ["eteplirsen"]],
    ["EXPAREL (Injectable)", false, ["bupivacaine"]],
    ["EXSERVAN (Oral Film)", true, ["riluzole"]],
    ["EXTAVIA (Injectable)", false, ["interferon beta-1b"]],
    ["EXTENCILLINE (Injectable)", false, ["penicillin G benzathine"]],
    ["EXTRANEAL (Injectable)", false, ["calcium chloride", "icodextrin", "lactate", "magnesium chloride", "sodium chloride"]],
    ["EXXUA TITRATION PACK (Pack)", true, ["gepirone"]],
    ["EXXUA XR (Oral Pill)", true, ["gepirone"]],
    ["EYDENZELT (Injectable)", false, ["aflibercept"]],
    ["EYE STREAM (Ophthalmic)", false, ["water"]],
    ["EYEMYCIN (Ophthalmic)", false, ["erythromycin"]],
    ["EYES ALIVE LUBRICATING (Ophthalmic)", false, ["carboxymethylcellulose"]],
    ["EYLEA (Injectable)", false, ["aflibercept"]],
    ["EYSUVIS (Ophthalmic)", false, ["loteprednol etabonate"]],
    ["EZALLOR (Oral Pill)", true, ["rosuvastatin"]],
    ["Ezetimibe (Oral Pill)", true, ["ezetimibe"]],
    ["Ezetimibe/Rosuvastatin (Oral Pill)", true, ["ezetimibe", "rosuvastatin"]],
    ["Ezetimibe/Simvastatin (Oral Pill)", true, ["ezetimibe", "simvastatin"]],
    ["EZFE (Oral Pill)", true, ["polysaccharide iron complex"]],
    ["FABHALTA (Oral Pill)", true, ["iptacopan"]],
    ["FABIOR (Topical)", false, ["tazarotene"]],
    ["FABRAZYME (Injectable)", false, ["agalsidase beta"]],
    ["Factor IX (Injectable)", false, ["factor IX"]],
    ["Factor IX complex (Injectable)", false, ["factor IX complex"]],
    ["Factor IX/Factor VII/Factor X/Protein C/Protein S/Prothrombin (Injectable)", false, ["factor IX", "factor VII", "factor X", "protein C", "protein S", "prothrombin"]],
    ["Factor VIIa (Injectable)", false, ["factor VIIa"]],
    ["Factor VIII (Injectable)", false, ["factor VIII"]],
    ["Factor VIII/Von Willebrand factor (Injectable)", false, ["factor VIII", "von Willebrand factor"]],
    ["Factor X (Injectable)", false, ["factor X"]],
    ["Factor XIII (Injectable)", false, ["factor XIII"]],
    ["FAKZYNJA (Oral Pill)", true, ["defactinib"]],
    ["FALMINA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Famciclovir (Oral Pill)", true, ["famciclovir"]],
    ["Famotidine (Chewable)", true, ["famotidine"]],
    ["Famotidine (Injectable)", false, ["famotidine"]],
    ["Famotidine (Oral Liquid)", true, ["famotidine"]],
    ["Famotidine (Oral Pill)", true, ["famotidine"]],
    ["Famotidine/Ibuprofen (Oral Pill)", true, ["famotidine", "ibuprofen"]],
    ["FANAPT (Oral Pill)", true, ["iloperidone"]],
    ["FANAPT TITRATION PACK (Pack)", true, ["iloperidone"]],
    ["FANAPT TITRATION PACK B (Pack)", true, ["iloperidone"]],
    ["FANAPT TITRATION PACK C (Pack)", true, ["iloperidone"]],
    ["FARESTON (Oral Pill)", true, ["toremifene"]],
    ["Faricimab (Injectable)", false, ["faricimab"]],
    ["FARXIGA (Oral Pill)", true, ["dapagliflozin"]],
    ["FARYDAK (Oral Pill)", true, ["panobinostat"]],
    ["FASENRA (Injectable)", false, ["benralizumab"]],
    ["FASLODEX (Injectable)", false, ["fulvestrant"]],
    ["FAST FREEZE (Topical)", false, ["camphor", "menthol"]],
    ["FAVLYXA (Injectable)", false, ["fluorouracil"]],
    ["FAYOSIM 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Fe heme polypeptide (Oral Pill)", true, ["Fe heme polypeptide"]],
    ["Fe heme polypeptide/Polysaccharide iron complex (Oral Pill)", true, ["Fe heme polypeptide", "polysaccharide iron complex"]],
    ["Febuxostat (Oral Pill)", true, ["febuxostat"]],
    ["Fecal microbiota spores, live (Oral Pill)", true, ["fecal microbiota spores, live"]],
    ["Fecal microbiota, live (Rectal)", false, ["fecal microbiota, live"]],
    ["Fedratinib (Oral Pill)", true, ["fedratinib"]],
    ["FEEN-A-MINT REFORMULATED JAN 2008 (Oral Pill)", true, ["bisacodyl"]],
    ["FEIBA (Injectable)", false, ["anti-inhibitor coagulant complex"]],
    ["FEIRZA 1.5/30 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["FEIRZA 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Felbamate (Oral Liquid)", true, ["felbamate"]],
    ["Felbamate (Oral Pill)", true, ["felbamate"]],
    ["FELBATOL (Oral Liquid)", true, ["felbamate"]],
    ["FELBATOL (Oral Pill)", true, ["felbamate"]],
    ["FELDENE (Oral Pill)", true, ["piroxicam"]],
    ["Felodipine XR (Oral Pill)", true, ["felodipine"]],
    ["FEM PH (Vaginal)", false, ["acetic acid", "oxyquinoline"]],
    ["FEMARA (Oral Pill)", true, ["letrozole"]],
    ["FEMLYV 24 ODT 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["FEMRING (Vaginal)", false, ["estradiol"]],
    ["FEMYNOR 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["Fenfluramine (Oral Liquid)", true, ["fenfluramine"]],
    ["Fenofibrate (Oral Pill)", true, ["fenofibrate"]],
    ["FENOGLIDE (Oral Pill)", true, ["fenofibrate"]],
    ["Fenoprofen (Oral Pill)", true, ["fenoprofen"]],
    ["FENOPRON (Oral Pill)", true, ["fenoprofen"]],
    ["FENSOLVI (Injectable)", false, ["leuprolide"]],
    ["fentaNYL (Buccal)", false, ["fentanyl"]],
    ["fentaNYL (Injectable)", false, ["fentanyl"]],
    ["fentaNYL (Mucosal)", false, ["fentanyl"]],
    ["fentaNYL (Oral Lozenge)", true, ["fentanyl"]],
    ["fentaNYL (Sublingual)", false, ["fentanyl"]],
    ["fentaNYL (Transdermal)", false, ["fentanyl"]],
    ["FENTORA (Buccal)", false, ["fentanyl"]],
    ["FEOSOL (Oral Pill)", true, ["ferrous sulfate"]],
    ["FEOSOL CAPLET (Oral Pill)", true, ["iron carbonyl"]],
    ["FER-IN-SOL (Oral Liquid)", true, ["ferrous sulfate"]],
    ["FERAHEME (Injectable)", false, ["ferumoxytol"]],
    ["FERATE (Oral Pill)", true, ["ferrous gluconate"]],
    ["FERGON (Oral Pill)", true, ["ferrous gluconate"]],
    ["FEROCON (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "liver stomach concentrate", "vitamin B12"]],
    ["FERRALET 90 (Oral Pill)", true, ["ascorbic acid", "docusate", "folic acid", "iron carbonyl", "vitamin B12"]],
    ["FERRAPLUS (Oral Pill)", true, ["ascorbic acid", "docusate", "folic acid", "iron carbonyl", "vitamin B12"]],
    ["FERRETTS IPS (Oral Liquid)", true, ["iron succinyl milk protein complex"]],
    ["FERREX 150 FORTE (Oral Pill)", true, ["folic acid", "polysaccharide iron complex", "vitamin B12"]],
    ["FERREX 150 FORTE PLUS (Oral Pill)", true, ["calcium ascorbate", "calcium threonate", "ferrous asparto glycinate", "folic acid", "polysaccharide iron complex", "succinic acid", "vitamin B12"]],
    ["FERREX 150 PLUS (Oral Pill)", true, ["ascorbic acid", "polysaccharide iron complex"]],
    ["FERREX-150 (Oral Pill)", true, ["polysaccharide iron complex"]],
    ["Ferric carboxymaltose (Injectable)", false, ["ferric carboxymaltose"]],
    ["Ferric citrate (Oral Pill)", true, ["ferric citrate"]],
    ["Ferric derisomaltose (Injectable)", false, ["ferric derisomaltose"]],
    ["Ferric maltol (Oral Pill)", true, ["ferric maltol"]],
    ["Ferric pyrophosphate (Injectable)", false, ["ferric pyrophosphate"]],
    ["Ferric subsulfate solution (Topical)", false, ["ferric subsulfate solution"]],
    ["FERRIMIN 150 (Oral Pill)", true, ["ferrous fumarate"]],
    ["FERRIPROX (Oral Liquid)", true, ["deferiprone"]],
    ["FERRIPROX (Oral Pill)", true, ["deferiprone"]],
    ["FERRLECIT (Injectable)", false, ["sodium ferric gluconate complex"]],
    ["FERROCITE (Oral Pill)", true, ["ferrous fumarate"]],
    ["Ferrous bisglycinate (Oral Pill)", true, ["ferrous bisglycinate"]],
    ["Ferrous fumarate (Chewable)", true, ["ferrous fumarate"]],
    ["Ferrous fumarate (Oral Pill)", true, ["ferrous fumarate"]],
    ["Ferrous fumarate/Folic acid (Oral Pill)", true, ["ferrous fumarate", "folic acid"]],
    ["Ferrous fumarate/Polysaccharide iron complex (Oral Pill)", true, ["ferrous fumarate", "polysaccharide iron complex"]],
    ["Ferrous gluconate (Oral Pill)", true, ["ferrous gluconate"]],
    ["Ferrous sulfate (Oral Liquid)", true, ["ferrous sulfate"]],
    ["Ferrous sulfate (Oral Pill)", true, ["ferrous sulfate"]],
    ["Ferrous sulfate XR (Oral Pill)", true, ["ferrous sulfate"]],
    ["Ferrous sulfate/Folic acid (Oral Pill)", true, ["ferrous sulfate", "folic acid"]],
    ["Ferumoxytol (Injectable)", false, ["ferumoxytol"]],
    ["FESILTY (Injectable)", false, ["fibrinogen"]],
    ["Fesoterodine XR (Oral Pill)", true, ["fesoterodine"]],
    ["FETROJA (Injectable)", false, ["cefiderocol"]],
    ["FETZIMA PACK (Pack)", true, ["levomilnacipran"]],
    ["FETZIMA TITRATION SAMPLE PACK (Pack)", true, ["levomilnacipran"]],
    ["FETZIMA XR (Oral Pill)", true, ["levomilnacipran"]],
    ["FEVERALL (Rectal)", false, ["acetaminophen"]],
    ["Fexinidazole (Oral Pill)", true, ["fexinidazole"]],
    ["Fexinidazole (Pack)", true, ["fexinidazole"]],
    ["FEXMID (Oral Pill)", true, ["cyclobenzaprine"]],
    ["Fexofenadine (Oral Disintegrating)", true, ["fexofenadine"]],
    ["Fexofenadine (Oral Liquid)", true, ["fexofenadine"]],
    ["Fexofenadine (Oral Pill)", true, ["fexofenadine"]],
    ["Fexofenadine/Pseudoephedrine XR (Oral Pill)", true, ["fexofenadine", "pseudoephedrine"]],
    ["Fezolinetant (Oral Pill)", true, ["fezolinetant"]],
    ["FIASP (Injectable)", false, ["insulin aspart, human"]],
    ["FIBER CHOICE (Chewable)", true, ["inulin"]],
    ["FIBER CHOICE WEIGHT MANAGEMENT (Chewable)", true, ["chromium picolinate", "inulin"]],
    ["FIBER TAB (Oral Pill)", true, ["calcium polycarbophil"]],
    ["FIBERCON (Oral Pill)", true, ["calcium polycarbophil"]],
    ["FIBRICOR (Oral Pill)", true, ["fenofibrate"]],
    ["Fibrinogen (Injectable)", false, ["fibrinogen"]],
    ["Fibrinogen/Thrombin (Injectable)", false, ["fibrinogen", "thrombin"]],
    ["Fibrinogen/Thrombin (Topical)", false, ["fibrinogen", "thrombin"]],
    ["FIBRYGA (Injectable)", false, ["fibrinogen"]],
    ["Fidanacogene elaparvovec (Injectable)", false, ["fidanacogene elaparvovec"]],
    ["Fidanacogene elaparvovec (Pack)", false, ["fidanacogene elaparvovec"]],
    ["Fidaxomicin (Oral Liquid)", true, ["fidaxomicin"]],
    ["Fidaxomicin (Oral Pill)", true, ["fidaxomicin"]],
    ["Filgrastim (Injectable)", false, ["filgrastim"]],
    ["FILKRI (Injectable)", false, ["filgrastim"]],
    ["FILSPARI (Oral Pill)", true, ["sparsentan"]],
    ["FILSUVEZ (Topical)", false, ["birch triterpenes"]],
    ["FINACEA (Topical)", false, ["azelate"]],
    ["Finafloxacin (Otic)", false, ["finafloxacin"]],
    ["Finasteride (Oral Pill)", true, ["finasteride"]],
    ["Finasteride/Tadalafil (Oral Pill)", true, ["finasteride", "tadalafil"]],
    ["Finerenone (Oral Pill)", true, ["finerenone"]],
    ["Fingolimod (Oral Disintegrating)", true, ["fingolimod"]],
    ["Fingolimod (Oral Pill)", true, ["fingolimod"]],
    ["FINTEPLA (Oral Liquid)", true, ["fenfluramine"]],
    ["FINZALA 24 FE CHEWABLE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["FIORICET (Oral Pill)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["FIORICET WITH CODEINE (Oral Pill)", true, ["acetaminophen", "butalbital", "caffeine", "codeine"]],
    ["FIRAZYR (Injectable)", false, ["icatibant"]],
    ["FIRDAPSE (Oral Pill)", true, ["amifampridine"]],
    ["FIRMAGON (Injectable)", false, ["degarelix"]],
    ["FIRVANQ (Oral Liquid)", true, ["vancomycin"]],
    ["Fish oil (containing omega-3 acids) (Injectable)", false, ["fish oil (containing omega-3 acids)"]],
    ["FISHERMAN'S FRIEND (Oral Lozenge)", true, ["menthol"]],
    ["Fitusiran (Injectable)", false, ["fitusiran"]],
    ["FLAC (Otic)", false, ["fluocinolone"]],
    ["FLAGYL (Oral Pill)", true, ["metronidazole"]],
    ["FLANDERS (Topical)", false, ["zinc oxide"]],
    ["FLAREX (Ophthalmic)", false, ["fluorometholone"]],
    ["FLAVALTA (Injectable)", false, ["epinephrine", "lidocaine"]],
    ["flavoxATE (Oral Pill)", true, ["flavoxate"]],
    ["FLEBOGAMMA (Injectable)", false, ["immunoglobulin G"]],
    ["Flecainide (Oral Pill)", true, ["flecainide"]],
    ["FLECTOR (Topical)", false, ["diclofenac"]],
    ["FLEQSUVY (Oral Liquid)", true, ["baclofen"]],
    ["FLETCHERS CASTORIA (Oral Liquid)", true, ["sennosides, USP"]],
    ["FLEXALL (Topical)", false, ["menthol"]],
    ["FLEXALL ULTRA PLUS (Topical)", false, ["camphor", "menthol", "methyl salicylate"]],
    ["FLEXBUMIN (Injectable)", false, ["albumin human, USP"]],
    ["Flibanserin (Oral Pill)", true, ["flibanserin"]],
    ["FLOLAN (Injectable)", false, ["epoprostenol"]],
    ["FLOLIPID (Oral Liquid)", true, ["simvastatin"]],
    ["FLOMAX (Oral Pill)", true, ["tamsulosin"]],
    ["FLONASE (Nasal)", false, ["fluticasone"]],
    ["FLONASE NIGHTTIME (Oral Pill)", true, ["triprolidine"]],
    ["FLONASE SENSIMIST (Nasal)", false, ["fluticasone"]],
    ["FLORAJEN3 (Oral Pill)", true, ["Bifidobacterium animalis", "Bifidobacterium longum", "Lactobacillus acidophilus"]],
    ["FLORASTOR (Oral Pill)", true, ["Saccharomyces boulardii"]],
    ["FLORASTOR (Oral Suspension Powder)", true, ["Saccharomyces boulardii"]],
    ["FLORICAL (Oral Pill)", true, ["calcium carbonate", "sodium fluoride"]],
    ["FLOVENT (Inhalant)", false, ["fluticasone"]],
    ["Floxuridine (Injectable)", false, ["floxuridine"]],
    ["FLUAD 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUAD 2026-2027 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUARIX 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUARIX 2026-2027 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUBLOK 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUBLOK 2026-2027 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUCAINE (Ophthalmic)", false, ["fluorescein", "proparacaine"]],
    ["FLUCELVAX 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUCELVAX 2026-2027 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["Fluconazole (Injectable)", false, ["fluconazole"]],
    ["Fluconazole (Oral Liquid)", true, ["fluconazole"]],
    ["Fluconazole (Oral Pill)", true, ["fluconazole"]],
    ["Flucytosine (Oral Pill)", true, ["flucytosine"]],
    ["Fludarabine (Injectable)", false, ["fludarabine"]],
    ["Fludrocortisone (Oral Pill)", true, ["fludrocortisone"]],
    ["FLULAVAL 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLULAVAL 2026-2027 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUMADINE (Oral Pill)", true, ["rimantadine"]],
    ["Flumazenil (Injectable)", false, ["flumazenil"]],
    ["FLUMIST 2025-2026 (Nasal)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUMIST 2026-2027 (Nasal)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["Flunisolide (Nasal)", false, ["flunisolide"]],
    ["Fluocinolone (Implant)", false, ["fluocinolone"]],
    ["Fluocinolone (Otic)", false, ["fluocinolone"]],
    ["Fluocinolone (Shampoo)", false, ["fluocinolone"]],
    ["Fluocinolone (Topical)", false, ["fluocinolone"]],
    ["Fluocinolone/Hydroquinone/Tretinoin (Topical)", false, ["fluocinolone", "hydroquinone", "tretinoin"]],
    ["Fluocinolone/Neomycin (Topical)", false, ["fluocinolone", "neomycin"]],
    ["Fluocinonide (Topical)", false, ["fluocinonide"]],
    ["FLUORABON (Chewable)", true, ["sodium fluoride"]],
    ["FLUORACAINE (Ophthalmic)", false, ["fluorescein", "proparacaine"]],
    ["Fluorescein/Proparacaine (Ophthalmic)", false, ["fluorescein", "proparacaine"]],
    ["FLUORIDEX (Toothpaste)", false, ["sodium fluoride"]],
    ["FLUORIDEX DAILY DEFENSE SENSITIVITY (Toothpaste)", false, ["potassium nitrate", "sodium fluoride"]],
    ["FLUORIMAX (Toothpaste)", false, ["sodium fluoride"]],
    ["FLUORIMAX SENSITIVE (Toothpaste)", false, ["potassium nitrate", "sodium fluoride"]],
    ["FLUORINSE (Mouthwash)", false, ["sodium fluoride"]],
    ["FLUORITAB (Chewable)", true, ["sodium fluoride"]],
    ["Fluorometholone (Ophthalmic)", false, ["fluorometholone"]],
    ["FLUOROPLEX (Topical)", false, ["fluorouracil"]],
    ["Fluorouracil (Injectable)", false, ["fluorouracil"]],
    ["Fluorouracil (Topical)", false, ["fluorouracil"]],
    ["FLUoxetine (Oral Liquid)", true, ["fluoxetine"]],
    ["FLUoxetine (Oral Pill)", true, ["fluoxetine"]],
    ["FLUoxetine/OLANZapine (Oral Pill)", true, ["fluoxetine", "olanzapine"]],
    ["fluPHENAZine (Injectable)", false, ["fluphenazine"]],
    ["fluPHENAZine (Oral Liquid)", true, ["fluphenazine"]],
    ["fluPHENAZine (Oral Pill)", true, ["fluphenazine"]],
    ["Flurandrenolide (Topical)", false, ["flurandrenolide"]],
    ["Flurazepam (Oral Pill)", true, ["flurazepam"]],
    ["Flurbiprofen (Ophthalmic)", false, ["flurbiprofen"]],
    ["Flurbiprofen (Oral Pill)", true, ["flurbiprofen"]],
    ["Flutamide (Oral Pill)", true, ["flutamide"]],
    ["FLUTICARE (Nasal)", false, ["fluticasone"]],
    ["Fluticasone (Inhalant)", false, ["fluticasone"]],
    ["Fluticasone (Nasal)", false, ["fluticasone"]],
    ["Fluticasone (Topical)", false, ["fluticasone"]],
    ["Fluticasone/Salmeterol (Inhalant)", false, ["fluticasone", "salmeterol"]],
    ["Fluticasone/Umeclidinium/Vilanterol (Inhalant)", false, ["fluticasone", "umeclidinium", "vilanterol"]],
    ["Fluticasone/Vilanterol (Inhalant)", false, ["fluticasone", "vilanterol"]],
    ["Fluvastatin (Oral Pill)", true, ["fluvastatin"]],
    ["Fluvastatin XR (Oral Pill)", true, ["fluvastatin"]],
    ["fluvoxaMINE (Oral Pill)", true, ["fluvoxamine"]],
    ["fluvoxaMINE XR (Oral Pill)", true, ["fluvoxamine"]],
    ["FLUZONE 2025 SOUTHERN HEMISPHERE (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUZONE 2025-2026 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUZONE 2026 SOUTHERN HEMISPHERE (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FLUZONE 2026-2027 (Injectable)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["FML (Ophthalmic)", false, ["fluorometholone"]],
    ["FML FORTE LIQUIFILM (Ophthalmic)", false, ["fluorometholone"]],
    ["FOCALIN (Oral Pill)", true, ["dexmethylphenidate"]],
    ["FOCALIN XR (Oral Pill)", true, ["dexmethylphenidate"]],
    ["FOCINVEZ (Injectable)", false, ["fosaprepitant"]],
    ["FOILLE (Topical)", false, ["benzocaine", "chloroxylenol"]],
    ["FOLACIN (Oral Pill)", true, ["folic acid"]],
    ["FOLBECAL XR (Oral Pill)", true, ["calcium carbonate", "folic acid", "pyridoxine", "vitamin B12"]],
    ["FOLBEE (Oral Pill)", true, ["folic acid", "vitamin B12", "vitamin B6"]],
    ["FOLBIC (Oral Pill)", true, ["folic acid", "vitamin B12", "vitamin B6"]],
    ["FOLDITAM (Oral Pill)", true, ["cholecalciferol", "folic acid"]],
    ["FOLGARD (Oral Pill)", true, ["folic acid", "vitamin B12", "vitamin B6"]],
    ["FOLGARD OS (Oral Pill)", true, ["boron", "calcium carbonate", "cholecalciferol", "folic acid", "magnesium oxide", "pyridoxine", "vitamin B12"]],
    ["Folic acid (Injectable)", false, ["folic acid"]],
    ["Folic acid (Oral Liquid)", true, ["folic acid"]],
    ["Folic acid (Oral Pill)", true, ["folic acid"]],
    ["Folic acid/Inositol (Oral Solution Powder)", true, ["folic acid", "inositol"]],
    ["Folic acid/Intrinsic factor/Vitamin B12 (Oral Pill)", true, ["folic acid", "intrinsic factor", "vitamin B12"]],
    ["Folic acid/Lacticaseibacillus casei (Oral Pill)", true, ["Lacticaseibacillus casei", "folic acid"]],
    ["Folic acid/Lacticaseibacillus casei (Oral Powder)", true, ["Lacticaseibacillus casei", "folic acid"]],
    ["Folic acid/Polysaccharide iron complex/Vitamin B12 (Oral Pill)", true, ["folic acid", "polysaccharide iron complex", "vitamin B12"]],
    ["Folic acid/Pyridoxine/Vitamin B12 (Oral Pill)", true, ["folic acid", "pyridoxine", "vitamin B12"]],
    ["Folic acid/Vitamin B12 (Oral Disintegrating)", true, ["folic acid", "vitamin B12"]],
    ["Folic acid/Vitamin B12 (Oral Pill)", true, ["folic acid", "vitamin B12"]],
    ["Folic acid/Vitamin B12 (Sublingual)", false, ["folic acid", "vitamin B12"]],
    ["Folic acid/Vitamin B12/Vitamin B6 (Oral Pill)", true, ["folic acid", "vitamin B12", "vitamin B6"]],
    ["FOLITAB XR (Oral Pill)", true, ["ascorbic acid", "ferrous sulfate", "folic acid"]],
    ["FOLIVANE-F (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "niacin", "polysaccharide iron complex"]],
    ["FOLIXATE (Oral Pill)", true, ["cholecalciferol", "levomefolate"]],
    ["Follicle stimulating hormone/Luteinizing hormone (Injectable)", false, ["follicle stimulating hormone", "luteinizing hormone"]],
    ["FOLLISTIM (Injectable)", false, ["follitropin beta"]],
    ["Follitropin alfa (Injectable)", false, ["follitropin alfa"]],
    ["Follitropin beta (Injectable)", false, ["follitropin beta"]],
    ["FOLOTYN (Injectable)", false, ["pralatrexate"]],
    ["FOLTABS (Oral Pill)", true, ["folic acid", "vitamin B12", "vitamin B6"]],
    ["FOLTRATE (Oral Pill)", true, ["folic acid", "vitamin B12"]],
    ["Fomepizole (Injectable)", false, ["fomepizole"]],
    ["Fondaparinux (Injectable)", false, ["fondaparinux"]],
    ["FORANE (Inhalant)", false, ["isoflurane"]],
    ["FORFIVO XR (Oral Pill)", true, ["bupropion"]],
    ["FORMA-RAY (Topical)", false, ["formaldehyde"]],
    ["FORMADON (Topical)", false, ["formaldehyde"]],
    ["Formaldehyde (Topical)", false, ["formaldehyde"]],
    ["Formoterol (Inhalant)", false, ["formoterol"]],
    ["Formoterol/Glycopyrronium (Inhalant)", false, ["formoterol", "glycopyrronium"]],
    ["Formoterol/Mometasone (Inhalant)", false, ["formoterol", "mometasone"]],
    ["FORTAZ (Injectable)", false, ["ceftazidime"]],
    ["FORTEO (Injectable)", false, ["teriparatide"]],
    ["FORTESTA (Topical)", false, ["testosterone"]],
    ["FORZINITY (Injectable)", false, ["elamipretide"]],
    ["FOSAMAX (Oral Pill)", true, ["alendronate"]],
    ["FOSAMAX PLUS D (Oral Pill)", true, ["alendronate", "cholecalciferol"]],
    ["Fosamprenavir (Oral Liquid)", true, ["fosamprenavir"]],
    ["Fosamprenavir (Oral Pill)", true, ["fosamprenavir"]],
    ["Fosaprepitant (Injectable)", false, ["fosaprepitant"]],
    ["Foscarnet (Injectable)", false, ["foscarnet"]],
    ["FOSCAVIR (Injectable)", false, ["foscarnet"]],
    ["Fosdenopterin (Injectable)", false, ["fosdenopterin"]],
    ["Fosfomycin (Injectable)", false, ["fosfomycin"]],
    ["Fosfomycin (Oral Solution Granules)", true, ["fosfomycin"]],
    ["Fosinopril (Oral Pill)", true, ["fosinopril"]],
    ["Fosinopril/hydroCHLOROthiazide (Oral Pill)", true, ["fosinopril", "hydrochlorothiazide"]],
    ["Fosphenytoin (Injectable)", false, ["fosphenytoin"]],
    ["FOSRENOL (Chewable)", true, ["lanthanum carbonate"]],
    ["FOSRENOL (Oral Powder)", true, ["lanthanum carbonate"]],
    ["Fostamatinib (Oral Pill)", true, ["fostamatinib"]],
    ["Fostemsavir XR (Oral Pill)", true, ["fostemsavir"]],
    ["FOTIVDA (Oral Pill)", true, ["tivozanib"]],
    ["FOUNDAYO (Oral Pill)", true, ["orforglipron"]],
    ["FRAGMIN (Injectable)", false, ["dalteparin"]],
    ["FREEZ EEZ (Oral Gel)", true, ["benzocaine"]],
    ["FREEZE IT (Topical)", false, ["camphor", "menthol"]],
    ["FREEZONE (Topical)", false, ["salicylic acid"]],
    ["Fremanezumab (Injectable)", false, ["fremanezumab"]],
    ["FRESHKOTE (Ophthalmic)", false, ["polyvinyl alcohol", "povidone"]],
    ["FRINDOVYX (Injectable)", false, ["cyclophosphamide"]],
    ["FROVA (Oral Pill)", true, ["frovatriptan"]],
    ["Frovatriptan (Oral Pill)", true, ["frovatriptan"]],
    ["Fructooligosaccharide (Chewable)", true, ["fructooligosaccharide"]],
    ["Fructooligosaccharide/Lactobacillus acidophilus (Chewable)", true, ["Lactobacillus acidophilus", "fructooligosaccharide"]],
    ["Fructose/Glucose/Phosphoric acid (Oral Liquid)", true, ["fructose", "glucose", "phosphoric acid"]],
    ["Fructose/Glucose/Sodium citrate (Chewable)", true, ["fructose", "glucose", "sodium citrate"]],
    ["Fruquintinib (Oral Pill)", true, ["fruquintinib"]],
    ["FRUZAQLA (Oral Pill)", true, ["fruquintinib"]],
    ["FULPHILA (Injectable)", false, ["pegfilgrastim"]],
    ["Fulvestrant (Injectable)", false, ["fulvestrant"]],
    ["FULVICIN P/G (Oral Pill)", true, ["griseofulvin"]],
    ["FUNGI-GUARD (Topical)", false, ["tolnaftate"]],
    ["FUNGI-NAIL (Topical)", false, ["undecylenate"]],
    ["FUNGICURE MAXIMUM STRENGTH (Topical)", false, ["undecylenate"]],
    ["FUNGICURE SOLUTION (Topical)", false, ["clotrimazole"]],
    ["FUNGIFOAM (Topical)", false, ["tolnaftate"]],
    ["FUNGIZYL (Topical)", false, ["dimethyl sulfoxide", "miconazole"]],
    ["FUNGOID (Topical)", false, ["miconazole"]],
    ["FURADANTIN (Oral Liquid)", true, ["nitrofurantoin"]],
    ["FUROSCIX (Injectable)", false, ["furosemide"]],
    ["Furosemide (Injectable)", false, ["furosemide"]],
    ["Furosemide (Oral Liquid)", true, ["furosemide"]],
    ["Furosemide (Oral Pill)", true, ["furosemide"]],
    ["FUSILEV (Injectable)", false, ["levoleucovorin"]],
    ["Futibatinib (Oral Pill)", true, ["futibatinib"]],
    ["Futibatinib (Pack)", true, ["futibatinib"]],
    ["FUZEON (Injectable)", false, ["enfuvirtide"]],
    ["FYARRO (Injectable)", false, ["sirolimus"]],
    ["FYAVOLV (Oral Pill)", true, ["ethinyl estradiol", "norethindrone"]],
    ["FYCOMPA (Oral Liquid)", true, ["perampanel"]],
    ["FYCOMPA (Oral Pill)", true, ["perampanel"]],
    ["FYCOMPA 2 MG 2-WEEK SAMPLE KIT (Pack)", true, ["perampanel"]],
    ["FYCOMPA 4/6 SAMPLE PACK (Pack)", true, ["perampanel"]],
    ["FYLNETRA (Injectable)", false, ["pegfilgrastim"]],
    ["FYREMADEL (Injectable)", false, ["ganirelix"]],
    ["Gabapentin (Oral Liquid)", true, ["gabapentin"]],
    ["Gabapentin (Oral Pill)", true, ["gabapentin"]],
    ["Gabapentin (Pack)", true, ["gabapentin"]],
    ["Gabapentin XR (Oral Pill)", true, ["gabapentin"]],
    ["GABARONE (Oral Pill)", true, ["gabapentin"]],
    ["GABITRIL (Oral Pill)", true, ["tiagabine"]],
    ["GABLOFEN (Injectable)", false, ["baclofen"]],
    ["GALAFOLD (Oral Pill)", true, ["migalastat"]],
    ["GALAFOLD 28 DAY WALLET (Pack)", true, ["migalastat"]],
    ["Galantamine (Oral Liquid)", true, ["galantamine"]],
    ["Galantamine (Oral Pill)", true, ["galantamine"]],
    ["Galantamine XR (Oral Pill)", true, ["galantamine"]],
    ["GALBRIELA 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Galcanezumab (Injectable)", false, ["galcanezumab"]],
    ["GALLIFREY (Oral Pill)", true, ["norethindrone"]],
    ["Galsulfase (Injectable)", false, ["galsulfase"]],
    ["GALZIN (Oral Pill)", true, ["zinc acetate"]],
    ["GAMASTAN (Injectable)", false, ["immunoglobulin G"]],
    ["GAMIFANT (Injectable)", false, ["emapalumab"]],
    ["GAMMAGARD (Injectable)", false, ["immunoglobulin G"]],
    ["GAMMAGARD ERC (Injectable)", false, ["immunoglobulin G"]],
    ["GAMMAKED (Injectable)", false, ["immunoglobulin G"]],
    ["GAMMAPLEX (Injectable)", false, ["immunoglobulin G"]],
    ["GAMUNEX (Injectable)", false, ["immunoglobulin G"]],
    ["Ganaxolone (Oral Liquid)", true, ["ganaxolone"]],
    ["Ganciclovir (Injectable)", false, ["ganciclovir"]],
    ["Ganciclovir (Ophthalmic)", false, ["ganciclovir"]],
    ["Ganirelix (Injectable)", false, ["ganirelix"]],
    ["Garadacimab (Injectable)", false, ["garadacimab"]],
    ["GARDASIL 9 (Injectable)", false, ["L1 protein, human papillomavirus type 11 vaccine", "L1 protein, human papillomavirus type 16 vaccine", "L1 protein, human papillomavirus type 18 vaccine", "L1 protein, human papillomavirus type 31 vaccine", "L1 protein, human papillomavirus type 33 vaccine", "L1 protein, human papillomavirus type 45 vaccine", "L1 protein, human papillomavirus type 52 vaccine", "L1 protein, human papillomavirus type 58 vaccine", "L1 protein, human papillomavirus type 6 vaccine"]],
    ["Garetosmab (Injectable)", false, ["garetosmab"]],
    ["GARZULYS (Injectable)", false, ["insulin aspart, human"]],
    ["GAS AIDE (Oral Pill)", true, ["simethicone"]],
    ["GAS-X (Chewable)", true, ["simethicone"]],
    ["GAS-X (Oral Film)", true, ["simethicone"]],
    ["GAS-X (Oral Pill)", true, ["simethicone"]],
    ["GAS-X PREVENTION (Oral Pill)", true, ["alpha-D-galactosidase enzyme"]],
    ["GAS-X TOTAL RELIEF (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["GAS-X WITH MAALOX (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["GASTROCROM (Oral Liquid)", true, ["cromolyn"]],
    ["Gatifloxacin (Ophthalmic)", false, ["gatifloxacin"]],
    ["GATTEX (Injectable)", false, ["teduglutide"]],
    ["GAVILAX (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["GAVILYTE-C (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride", "sodium sulfate"]],
    ["GAVILYTE-G (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride", "sodium sulfate"]],
    ["GAVILYTE-H (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride"]],
    ["GAVILYTE-N (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride"]],
    ["GAVISCON (Chewable)", true, ["aluminum hydroxide", "magnesium carbonate"]],
    ["GAVISCON (Oral Liquid)", true, ["aluminum hydroxide", "magnesium carbonate"]],
    ["GAVISCON CHEWABLE (Chewable)", true, ["aluminum hydroxide", "magnesium trisilicate"]],
    ["GAVRETO (Oral Pill)", true, ["pralsetinib"]],
    ["GAZYVA (Injectable)", false, ["obinutuzumab"]],
    ["Gedatolisib (Injectable)", false, ["gedatolisib"]],
    ["Gefitinib (Oral Pill)", true, ["gefitinib"]],
    ["GEL-KAM (Mouthwash)", false, ["stannous fluoride"]],
    ["GEL-KAM (Oral Gel)", true, ["stannous fluoride"]],
    ["GEL-ONE (Injectable)", false, ["hyaluronate"]],
    ["GEL-SYN (Injectable)", false, ["hyaluronate"]],
    ["Gelatin (Oral Pill)", true, ["gelatin"]],
    ["GELATO PERIO RINSE (Mouthwash)", false, ["stannous fluoride"]],
    ["GELATO SODIUM FLUORIDE (Oral Gel)", true, ["sodium fluoride"]],
    ["GELNIQUE (Topical)", false, ["oxybutynin"]],
    ["GELUSIL (Chewable)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["Gemcitabine (Implant)", false, ["gemcitabine"]],
    ["Gemcitabine (Injectable)", false, ["gemcitabine"]],
    ["Gemfibrozil (Oral Pill)", true, ["gemfibrozil"]],
    ["GEMMILY 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["GEMTESA (Oral Pill)", true, ["vibegron"]],
    ["Gemtuzumab ozogamicin (Injectable)", false, ["gemtuzumab ozogamicin"]],
    ["GENAHIST (Oral Pill)", true, ["diphenhydramine"]],
    ["GENAPHED (Oral Pill)", true, ["pseudoephedrine"]],
    ["GENERLAC (Oral Liquid)", true, ["lactulose"]],
    ["GENGLYCOS (Injectable)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 15 - < 21 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 21 - < 27 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 27 - < 33 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 33 - < 39 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 39 - < 45 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 45 - < 51 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 51 - < 57 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 57 - < 63 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 63 - < 69 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 69 - < 75 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 75 - < 81 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT 81 - < 87 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGLYCOS KIT > 87 KG (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["GENGRAF (Oral Liquid)", true, ["cyclosporine"]],
    ["GENGRAF (Oral Pill)", true, ["cyclosporine"]],
    ["GENOTROPIN (Injectable)", false, ["somatropin"]],
    ["GENPRIL (Oral Pill)", true, ["ibuprofen"]],
    ["GENTAK (Ophthalmic)", false, ["gentamicin"]],
    ["Gentamicin (Injectable)", false, ["gentamicin"]],
    ["Gentamicin (Ophthalmic)", false, ["gentamicin"]],
    ["Gentamicin (Topical)", false, ["gentamicin"]],
    ["GENTEAL (Ophthalmic)", false, ["hypromellose"]],
    ["Gentian violet (Topical)", false, ["gentian violet"]],
    ["GENTLELAX (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["GENVISC (Injectable)", false, ["hyaluronate"]],
    ["GENVOYA (Oral Pill)", true, ["cobicistat", "elvitegravir", "emtricitabine", "tenofovir alafenamide"]],
    ["GEODON (Injectable)", false, ["ziprasidone"]],
    ["GEODON (Oral Pill)", true, ["ziprasidone"]],
    ["Gepirone (Pack)", true, ["gepirone"]],
    ["Gepirone XR (Oral Pill)", true, ["gepirone"]],
    ["Gepotidacin (Oral Pill)", true, ["gepotidacin"]],
    ["GERI-HYDROLAC (Topical)", false, ["lactate"]],
    ["GIANVI 28-DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["GIAPREZA (Injectable)", false, ["angiotensin II"]],
    ["GILENYA (Oral Pill)", true, ["fingolimod"]],
    ["GILOTRIF (Oral Pill)", true, ["afatinib"]],
    ["Gilteritinib (Oral Pill)", true, ["gilteritinib"]],
    ["GIMOTI (Nasal)", false, ["metoclopramide"]],
    ["Ginger root (Oral Pill)", true, ["ginger root"]],
    ["GINGI MED (Mouthwash)", false, ["stannous fluoride"]],
    ["Givinostat (Oral Liquid)", true, ["givinostat"]],
    ["GIVLAARI (Injectable)", false, ["givosiran"]],
    ["Givosiran (Injectable)", false, ["givosiran"]],
    ["Glasdegib (Oral Pill)", true, ["glasdegib"]],
    ["GLASSIA (Injectable)", false, ["alpha 1-antitrypsin"]],
    ["Glatiramer (Injectable)", false, ["glatiramer"]],
    ["GLATOPA (Injectable)", false, ["glatiramer"]],
    ["Glecaprevir/Pibrentasvir (Oral Pellet)", true, ["glecaprevir", "pibrentasvir"]],
    ["Glecaprevir/Pibrentasvir (Oral Pill)", true, ["glecaprevir", "pibrentasvir"]],
    ["GLEEVEC (Oral Pill)", true, ["imatinib"]],
    ["GLEOSTINE (Oral Pill)", true, ["lomustine"]],
    ["GLIADEL (Implant)", false, ["carmustine"]],
    ["Glimepiride (Oral Pill)", true, ["glimepiride"]],
    ["Glimepiride/Pioglitazone (Oral Pill)", true, ["glimepiride", "pioglitazone"]],
    ["glipiZIDE (Oral Pill)", true, ["glipizide"]],
    ["glipiZIDE XR (Oral Pill)", true, ["glipizide"]],
    ["glipiZIDE/metFORMIN (Oral Pill)", true, ["glipizide", "metformin"]],
    ["Glofitamab (Injectable)", false, ["glofitamab"]],
    ["GLOPERBA (Oral Liquid)", true, ["colchicine"]],
    ["GLUCAGEN (Injectable)", false, ["glucagon"]],
    ["Glucagon (Injectable)", false, ["glucagon"]],
    ["Glucagon (Nasal)", false, ["glucagon"]],
    ["Glucarpidase (Injectable)", false, ["glucarpidase"]],
    ["GLUCOBURST (Oral Gel)", true, ["glucose"]],
    ["GLUCOPHAGE (Oral Pill)", true, ["metformin"]],
    ["GLUCOPHAGE XR (Oral Pill)", true, ["metformin"]],
    ["Glucosamine (Oral Pill)", true, ["glucosamine"]],
    ["Glucosamine/Hyaluronate/Methylsulfonylmethane (Oral Pill)", true, ["glucosamine", "hyaluronate", "methylsulfonylmethane"]],
    ["Glucosamine/Methylsulfonylmethane (Oral Liquid)", true, ["glucosamine", "methylsulfonylmethane"]],
    ["Glucosamine/Methylsulfonylmethane (Oral Pill)", true, ["glucosamine", "methylsulfonylmethane"]],
    ["Glucose (Chewable)", true, ["glucose"]],
    ["Glucose (Injectable)", false, ["glucose"]],
    ["Glucose (Oral Gel)", true, ["glucose"]],
    ["Glucose (Oral Liquid)", true, ["glucose"]],
    ["Glucose (Oral Solution Powder)", true, ["glucose"]],
    ["Glucose/Magnesium acetate/Potassium acetate/Sodium chloride (Injectable)", false, ["glucose", "magnesium acetate", "potassium acetate", "sodium chloride"]],
    ["Glucose/Potassium chloride (Injectable)", false, ["glucose", "potassium chloride"]],
    ["Glucose/Potassium chloride/Sodium chloride (Injectable)", false, ["glucose", "potassium chloride", "sodium chloride"]],
    ["Glucose/Sodium chloride (Injectable)", false, ["glucose", "sodium chloride"]],
    ["GLUCOTROL (Oral Pill)", true, ["glipizide"]],
    ["GLUCOTROL XR (Oral Pill)", true, ["glipizide"]],
    ["GLUMETZA XR (Oral Pill)", true, ["metformin"]],
    ["Glutamate (Oral Pill)", true, ["glutamate"]],
    ["GLUTAMIC-500 (Oral Pill)", true, ["glutamate"]],
    ["Glutamine (Oral Pill)", true, ["glutamine"]],
    ["Glutamine (Oral Solution Powder)", true, ["glutamine"]],
    ["GLUTOSE (Oral Gel)", true, ["glucose"]],
    ["GLY-OXIDE (Mucosal)", false, ["carbamide peroxide"]],
    ["glyBURIDE (Oral Pill)", true, ["glyburide"]],
    ["glyBURIDE/metFORMIN (Oral Pill)", true, ["glyburide", "metformin"]],
    ["GLYCATE (Oral Pill)", true, ["glycopyrronium"]],
    ["Glycerin (Mouthwash)", false, ["glycerin"]],
    ["Glycerin (Mucosal)", false, ["glycerin"]],
    ["Glycerin (Nasal)", false, ["glycerin"]],
    ["Glycerin (Ophthalmic)", false, ["glycerin"]],
    ["Glycerin (Oral Gel)", true, ["glycerin"]],
    ["Glycerin (Rectal)", false, ["glycerin"]],
    ["Glycerin (Topical)", false, ["glycerin"]],
    ["Glycerin/Hypromellose/Polyethylene glycol 400 (Ophthalmic)", false, ["glycerin", "hypromellose", "polyethylene glycol 400"]],
    ["Glycerin/Hypromellose/Polyethylene glycol 400/Tetrahydrozoline/Zinc sulfate (Ophthalmic)", false, ["glycerin", "hypromellose", "polyethylene glycol 400", "tetrahydrozoline", "zinc sulfate"]],
    ["Glycerin/Lanolin/Lidocaine/Zinc oxide (Topical)", false, ["glycerin", "lanolin", "lidocaine", "zinc oxide"]],
    ["Glycerin/Lidocaine (Topical)", false, ["glycerin", "lidocaine"]],
    ["Glycerin/Naphazoline (Ophthalmic)", false, ["glycerin", "naphazoline"]],
    ["Glycerin/Naphazoline/Zinc sulfate (Ophthalmic)", false, ["glycerin", "naphazoline", "zinc sulfate"]],
    ["Glycerin/Phenol (Mucosal)", false, ["glycerin", "phenol"]],
    ["Glycerin/Phenol (Otic)", false, ["glycerin", "phenol"]],
    ["Glycerin/Phenylephrine (Ophthalmic)", false, ["glycerin", "phenylephrine"]],
    ["Glycerin/Propylene glycol (Ophthalmic)", false, ["glycerin", "propylene glycol"]],
    ["Glycerin/Sodium chloride (Nasal)", false, ["glycerin", "sodium chloride"]],
    ["Glycerol phenylbutyrate (Oral Liquid)", true, ["glycerol phenylbutyrate"]],
    ["Glyceryl phosphate (Injectable)", false, ["glyceryl phosphate"]],
    ["Glycine (Irrigation)", false, ["glycine"]],
    ["Glycine/Isoleucine/Ubidecarenone XR (Oral Pill)", true, ["glycine", "isoleucine", "ubidecarenone"]],
    ["Glycolate (Soap)", false, ["glycolate"]],
    ["Glycolate (Topical)", false, ["glycolate"]],
    ["Glycolate/Lactate (Topical)", false, ["glycolate", "lactate"]],
    ["Glycolate/Pyruvate (Topical)", false, ["glycolate", "pyruvate"]],
    ["GLYCOPHOS (Injectable)", false, ["glyceryl phosphate"]],
    ["Glycopyrronium (Inhalant)", false, ["glycopyrronium"]],
    ["Glycopyrronium (Injectable)", false, ["glycopyrronium"]],
    ["Glycopyrronium (Oral Disintegrating)", true, ["glycopyrronium"]],
    ["Glycopyrronium (Oral Liquid)", true, ["glycopyrronium"]],
    ["Glycopyrronium (Oral Pill)", true, ["glycopyrronium"]],
    ["Glycopyrronium (Topical)", false, ["glycopyrronium"]],
    ["Glycopyrronium/Neostigmine (Injectable)", false, ["glycopyrronium", "neostigmine"]],
    ["GLYDO (Topical)", false, ["lidocaine"]],
    ["GLYNASE (Oral Pill)", true, ["glyburide"]],
    ["GLYRX (Injectable)", false, ["glycopyrronium"]],
    ["GLYXAMBI (Oral Pill)", true, ["empagliflozin", "linagliptin"]],
    ["GOBARDEN (Injectable)", false, ["bendamustine"]],
    ["GOCOVRI XR (Oral Pill)", true, ["amantadine"]],
    ["GOHIBIC (Injectable)", false, ["vilobelimab"]],
    ["Golimumab (Injectable)", false, ["golimumab"]],
    ["Golodirsen (Injectable)", false, ["golodirsen"]],
    ["GOLYTELY (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride", "sodium sulfate"]],
    ["GOMEKLI (Oral Pill)", true, ["mirdametinib"]],
    ["GOMEKLI (Oral Suspension Tablet)", true, ["mirdametinib"]],
    ["GONAL F (Injectable)", false, ["follitropin alfa"]],
    ["GONIOSOFT (Ophthalmic)", false, ["hypromellose"]],
    ["GONIOVISC (Ophthalmic)", false, ["hypromellose"]],
    ["GONITRO (Sublingual)", false, ["nitroglycerin"]],
    ["GOPRELTO (Nasal)", false, ["cocaine"]],
    ["GORDOFILM (Topical)", false, ["salicylic acid"]],
    ["GORDOGESIC (Topical)", false, ["methyl salicylate"]],
    ["GORMEL (Topical)", false, ["urea"]],
    ["GORMEL 10 (Topical)", false, ["urea"]],
    ["Goserelin (Implant)", false, ["goserelin"]],
    ["GRAFAPEX (Injectable)", false, ["treosulfan"]],
    ["GRALISE (Oral Pill)", true, ["gabapentin"]],
    ["GRALISE SAMPLE PACK (Pack)", true, ["gabapentin"]],
    ["Granisetron (Injectable)", false, ["granisetron"]],
    ["Granisetron (Oral Liquid)", true, ["granisetron"]],
    ["Granisetron (Oral Pill)", true, ["granisetron"]],
    ["Granisetron (Transdermal)", false, ["granisetron"]],
    ["GRANISOL (Oral Liquid)", true, ["granisetron"]],
    ["GRANIX (Injectable)", false, ["filgrastim"]],
    ["GRASTEK (Sublingual)", false, ["Timothy grass pollen extract"]],
    ["Griseofulvin (Oral Liquid)", true, ["griseofulvin"]],
    ["Griseofulvin (Oral Pill)", true, ["griseofulvin"]],
    ["Guaiacol/Methyl salicylate (Topical)", false, ["guaiacol", "methyl salicylate"]],
    ["guaiFENesin (Chewable)", true, ["guaifenesin"]],
    ["guaiFENesin (Oral Granules)", true, ["guaifenesin"]],
    ["guaiFENesin (Oral Liquid)", true, ["guaifenesin"]],
    ["guaiFENesin (Oral Pill)", true, ["guaifenesin"]],
    ["guaiFENesin XR (Oral Pill)", true, ["guaifenesin"]],
    ["guaiFENesin/HYDROcodone (Oral Liquid)", true, ["guaifenesin", "hydrocodone"]],
    ["guaiFENesin/Phenylephrine (Oral Liquid)", true, ["guaifenesin", "phenylephrine"]],
    ["guaiFENesin/Phenylephrine (Oral Pill)", true, ["guaifenesin", "phenylephrine"]],
    ["guaiFENesin/Phenylephrine XR (Oral Pill)", true, ["guaifenesin", "phenylephrine"]],
    ["guaiFENesin/Pseudoephedrine (Oral Liquid)", true, ["guaifenesin", "pseudoephedrine"]],
    ["guaiFENesin/Pseudoephedrine (Oral Pill)", true, ["guaifenesin", "pseudoephedrine"]],
    ["guaiFENesin/Pseudoephedrine XR (Oral Pill)", true, ["guaifenesin", "pseudoephedrine"]],
    ["guanFACINE (Oral Pill)", true, ["guanfacine"]],
    ["guanFACINE XR (Oral Pill)", true, ["guanfacine"]],
    ["Guselkumab (Injectable)", false, ["guselkumab"]],
    ["Guselkumab (Pack)", false, ["guselkumab"]],
    ["GVOKE (Injectable)", false, ["glucagon"]],
    ["GWYN LO (Transdermal)", false, ["ethinyl estradiol", "norelgestromin"]],
    ["GYNAZOLE-1 (Vaginal)", false, ["butoconazole"]],
    ["GYNECORT (Topical)", false, ["hydrocortisone"]],
    ["GYNOL II (Vaginal)", false, ["nonoxynol-9"]],
    ["HABITROL (Transdermal)", false, ["nicotine"]],
    ["HADLIMA (Injectable)", false, ["adalimumab"]],
    ["HAEGARDA (Injectable)", false, ["C1 esterase inhibitor"]],
    ["HAILEY 1.5/30 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["HAILEY 24 FE 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["HAILEY FE 1.5/30 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["HAILEY FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["HALAVEN (Injectable)", false, ["eribulin"]],
    ["Halcinonide (Topical)", false, ["halcinonide"]],
    ["HALCION (Oral Pill)", true, ["triazolam"]],
    ["HALDOL (Injectable)", false, ["haloperidol"]],
    ["HALLS (Oral Lozenge)", true, ["menthol"]],
    ["Halobetasol (Topical)", false, ["halobetasol"]],
    ["Halobetasol/Lactate (Pack)", false, ["halobetasol", "lactate"]],
    ["Halobetasol/Tazarotene (Topical)", false, ["halobetasol", "tazarotene"]],
    ["HALOETTE (Vaginal)", false, ["ethinyl estradiol", "etonogestrel"]],
    ["HALOG (Topical)", false, ["halcinonide"]],
    ["Haloperidol (Injectable)", false, ["haloperidol"]],
    ["Haloperidol (Oral Liquid)", true, ["haloperidol"]],
    ["Haloperidol (Oral Pill)", true, ["haloperidol"]],
    ["HARLIKU (Oral Pill)", true, ["nitisinone"]],
    ["HARVONI (Oral Pellet)", true, ["ledipasvir", "sofosbuvir"]],
    ["HARVONI (Oral Pill)", true, ["ledipasvir", "sofosbuvir"]],
    ["HAVRIX (Injectable)", false, ["hepatitis A vaccine (inactivated) strain HM175"]],
    ["HEAD & SHOULDERS (Shampoo)", false, ["zinc pyrithione"]],
    ["HEALON (Injectable)", false, ["hyaluronate"]],
    ["HEALON5 (Injectable)", false, ["hyaluronate"]],
    ["HEALTHY MAMA (Chewable)", true, ["calcium carbonate"]],
    ["HEALTHYLAX (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["HEATHER 28 DAY (Pack)", true, ["norethindrone"]],
    ["Heavy mineral oil (Oral Liquid)", true, ["heavy mineral oil"]],
    ["HECTOROL (Injectable)", false, ["doxercalciferol"]],
    ["HELIDAC THERAPY (Pack)", false, ["bismuth subsalicylate", "metronidazole", "tetracycline"]],
    ["Helium (Inhalant)", false, ["helium"]],
    ["Helium/Oxygen (Inhalant)", false, ["helium", "oxygen"]],
    ["HEMABATE (Injectable)", false, ["carboprost"]],
    ["HEMADY (Oral Pill)", true, ["dexamethasone"]],
    ["HEMANGEOL (Oral Liquid)", true, ["propranolol"]],
    ["HEMATEX (Oral Liquid)", true, ["polysaccharide iron complex"]],
    ["HEMATOGEN (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "vitamin B12"]],
    ["HEMAX XR (Oral Pill)", true, ["ascorbic acid", "biotin", "copper sulfate", "docusate", "folic acid", "iron carbonyl", "vitamin B12", "vitamin E"]],
    ["HEMGENIX (Injectable)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 101 - 105 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 106 - 110 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 111 - 115 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 116 - 120 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 121 - 125 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 126 - 130 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 131 - 135 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 136 - 140 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 141 - 145 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 146 - 150 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 151 - 155 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 156 - 160 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 161 - 165 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 166 - 170 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 171 - 175 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 176 - 180 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 181 - 185 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 186 - 190 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 191 - 195 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 196 - 200 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 201 - 205 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 206 - 210 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 211 - 215 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 216 - 220 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 221 - 225 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 226 - 230 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 231 - 235 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 236 - 240 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 46 - 50 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 51 - 55 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 56 - 60 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 61 - 65 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 66 - 70 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 71 - 75 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 76 - 80 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 81 - 85 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 86 - 90 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 91 - 95 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMGENIX KIT 96 - 100 KG (Pack)", false, ["etranacogene dezaparvovec"]],
    ["HEMICLOR (Oral Pill)", true, ["chlorthalidone"]],
    ["Hemin (Injectable)", false, ["hemin"]],
    ["HEMLIBRA (Injectable)", false, ["emicizumab"]],
    ["HEMMOREX (Rectal)", false, ["hydrocortisone"]],
    ["HEMOCYTE (Oral Pill)", true, ["ferrous fumarate"]],
    ["HEMOCYTE PLUS (Oral Pill)", true, ["copper sulfate", "ferrous fumarate", "folic acid", "magnesium sulfate", "manganese sulfate", "niacinamide", "pantothenic acid", "pyridoxine", "riboflavin", "sodium ascorbate", "thiamine", "vitamin B12", "zinc sulfate"]],
    ["HEMOCYTE-F (Oral Pill)", true, ["ferrous fumarate", "folic acid"]],
    ["HEMOFIL (Injectable)", false, ["factor VIII"]],
    ["HEMOX A (Topical)", false, ["aluminum chloride"]],
    ["HEMRIL (Rectal)", false, ["hydrocortisone"]],
    ["HEPAGAM B (Injectable)", false, ["hepatitis B immune globulin"]],
    ["Heparin (Injectable)", false, ["heparin"]],
    ["Heparin/Taurolidine (Injectable)", false, ["heparin", "taurolidine"]],
    ["Hepatitis A vaccine (inactivated) strain HM175 (Injectable)", false, ["hepatitis A vaccine (inactivated) strain HM175"]],
    ["Hepatitis A vaccine (inactivated) strain HM175/Hepatitis B surface antigen vaccine (Injectable)", false, ["hepatitis A vaccine (inactivated) strain HM175", "hepatitis B surface antigen vaccine"]],
    ["Hepatitis A virus strain CR 326F antigen, inactivated (Injectable)", false, ["hepatitis A virus strain CR 326F antigen, inactivated"]],
    ["Hepatitis B immune globulin (Injectable)", false, ["hepatitis B immune globulin"]],
    ["Hepatitis B surface antigen vaccine (Injectable)", false, ["hepatitis B surface antigen vaccine"]],
    ["HEPCLUDEX (Injectable)", false, ["bulevirtide"]],
    ["HEPLISAV-B (Injectable)", false, ["hepatitis B surface antigen vaccine"]],
    ["HEPSERA (Oral Pill)", true, ["adefovir"]],
    ["HEPZATO (Injectable)", false, ["melphalan"]],
    ["HER STYLE (Oral Pill)", true, ["levonorgestrel"]],
    ["HERCEPTIN (Injectable)", false, ["trastuzumab"]],
    ["HERCEPTIN HYLECTA (Injectable)", false, ["hyaluronidase", "trastuzumab"]],
    ["HERCESSI (Injectable)", false, ["trastuzumab"]],
    ["HERNEXEOS (Oral Pill)", true, ["zongertinib"]],
    ["Herpesvirus 1, human (Injectable)", false, ["herpesvirus 1, human"]],
    ["HERZUMA (Injectable)", false, ["trastuzumab"]],
    ["HESPAN (Injectable)", false, ["hetastarch"]],
    ["Hetastarch (Injectable)", false, ["hetastarch"]],
    ["HETLIOZ (Oral Liquid)", true, ["tasimelteon"]],
    ["HETLIOZ (Oral Pill)", true, ["tasimelteon"]],
    ["HEXATRIONE (Injectable)", false, ["triamcinolone"]],
    ["HEXTEND (Injectable)", false, ["hetastarch"]],
    ["Hexylresorcinol (Oral Lozenge)", true, ["hexylresorcinol"]],
    ["Hexylresorcinol (Topical)", false, ["hexylresorcinol"]],
    ["Hexylresorcinol/Menthol (Oral Lozenge)", true, ["hexylresorcinol", "menthol"]],
    ["HIBERIX (Injectable)", false, ["Haemophilus influenzae type b, capsular polysaccharide inactivated tetanus toxoid conjugate vaccine"]],
    ["HIBICLENS (Soap)", false, ["chlorhexidine"]],
    ["HIDEX 6-DAY TAPER (Pack)", true, ["dexamethasone"]],
    ["HIPREX (Oral Pill)", true, ["methenamine"]],
    ["Histamine (Topical)", false, ["histamine"]],
    ["Histamine/Menthol (Topical)", false, ["histamine", "menthol"]],
    ["Histrelin (Implant)", false, ["histrelin"]],
    ["HIZENTRA (Injectable)", false, ["immunoglobulin G"]],
    ["HOMATROPAIRE (Ophthalmic)", false, ["homatropine"]],
    ["Homatropine (Ophthalmic)", false, ["homatropine"]],
    ["Homatropine/HYDROcodone (Oral Liquid)", true, ["homatropine", "hydrocodone"]],
    ["Homatropine/HYDROcodone (Oral Pill)", true, ["homatropine", "hydrocodone"]],
    ["HORIZANT XR (Oral Pill)", true, ["gabapentin"]],
    ["Horse chestnut seed (Oral Pill)", true, ["horse chestnut seed"]],
    ["HULIO (Injectable)", false, ["adalimumab"]],
    ["HumaLOG (Injectable)", false, ["insulin lispro"]],
    ["HumaLOG MIX (Injectable)", false, ["insulin lispro", "insulin lispro protamine, human"]],
    ["HUMAN ALBUMIN GRIFOLS (Injectable)", false, ["albumin human, USP"]],
    ["Human vaccinia immune globulin (Injectable)", false, ["human vaccinia immune globulin"]],
    ["HUMATE-P (Injectable)", false, ["factor VIII", "von Willebrand factor"]],
    ["HUMATIN (Oral Pill)", true, ["paromomycin"]],
    ["HUMATROPE (Injectable)", false, ["somatropin"]],
    ["HUMIRA (Injectable)", false, ["adalimumab"]],
    ["HUMIRA PEDIATRIC CROHN'S DISEASE STARTER PACKAGE (3 COUNT) (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEDIATRIC CROHN'S DISEASE STARTER PACKAGE (6 COUNT) (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN - CROHN'S DISEASE STARTER PACK (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN - PSORIASIS STARTER PACK (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN 40 MG/0.4 ML STARTER PACK - CROHN'S DISEASE (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN 40 MG/0.4 ML STARTER PACK - PSORIASIS (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN 80 MG/0.8 ML - STARTER PACKAGE FOR CROHN'S DISEASE, ULCERATIVE COLITIS OR HIDRADENITIS SUPPURATIVA (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN 80 MG/0.8 ML - STARTER PACKAGE FOR PEDIATRIC ULCERATIVE COLITIS (Pack)", false, ["adalimumab"]],
    ["HUMIRA PEN 80 MG/0.8 ML AND 40 MG/0.4 ML - PSORIASIS/UVEITIS STARTER PACKAGE (Pack)", false, ["adalimumab"]],
    ["HUMIRA PREFILLED SYRINGE 80 MG/0.8 ML STARTER PACK - PEDIATRIC CROHN'S DISEASE (Pack)", false, ["adalimumab"]],
    ["HumuLIN (Injectable)", false, ["insulin isophane", "insulin, regular, human"]],
    ["HumuLIN N (Injectable)", false, ["insulin isophane"]],
    ["HumuLIN R (Injectable)", false, ["insulin, regular, human"]],
    ["HURRICAINE (Mucosal)", false, ["benzocaine"]],
    ["HURRICAINE (Oral Gel)", true, ["benzocaine"]],
    ["HURRICAINE (Topical)", false, ["benzocaine"]],
    ["HYALGAN (Injectable)", false, ["hyaluronate"]],
    ["Hyaluronate (Injectable)", false, ["hyaluronate"]],
    ["Hyaluronate (Mouthwash)", false, ["hyaluronate"]],
    ["Hyaluronate (Mucosal)", false, ["hyaluronate"]],
    ["Hyaluronate (Ophthalmic)", false, ["hyaluronate"]],
    ["Hyaluronate (Oral Gel)", true, ["hyaluronate"]],
    ["Hyaluronate (Topical)", false, ["hyaluronate"]],
    ["Hyaluronate (Vaginal)", false, ["hyaluronate"]],
    ["Hyaluronidase (Injectable)", false, ["hyaluronidase"]],
    ["Hyaluronidase/Immunoglobulin G (Pack)", false, ["hyaluronidase", "immunoglobulin G"]],
    ["Hyaluronidase/Nivolumab (Injectable)", false, ["hyaluronidase", "nivolumab"]],
    ["Hyaluronidase/Ocrelizumab (Injectable)", false, ["hyaluronidase", "ocrelizumab"]],
    ["Hyaluronidase/Pertuzumab/Trastuzumab (Injectable)", false, ["hyaluronidase", "pertuzumab", "trastuzumab"]],
    ["Hyaluronidase/riTUXimab (Injectable)", false, ["hyaluronidase", "rituximab"]],
    ["Hyaluronidase/Trastuzumab (Injectable)", false, ["hyaluronidase", "trastuzumab"]],
    ["HYBRISIL (Topical)", false, ["methylprednisolone"]],
    ["HYCAMTIN (Injectable)", false, ["topotecan"]],
    ["HYCAMTIN (Oral Pill)", true, ["topotecan"]],
    ["HYCET (Oral Liquid)", true, ["acetaminophen", "hydrocodone"]],
    ["HYCODAN (Oral Liquid)", true, ["homatropine", "hydrocodone"]],
    ["HYCODAN (Oral Pill)", true, ["homatropine", "hydrocodone"]],
    ["hydrALAZINE (Injectable)", false, ["hydralazine"]],
    ["hydrALAZINE (Oral Pill)", true, ["hydralazine"]],
    ["hydrALAZINE/Isosorbide dinitrate (Oral Pill)", true, ["hydralazine", "isosorbide dinitrate"]],
    ["HYDREA (Oral Pill)", true, ["hydroxyurea"]],
    ["HYDRO 35 (Topical)", false, ["urea"]],
    ["HYDRO 40 (Topical)", false, ["urea"]],
    ["hydroCHLOROthiazide (Oral Liquid)", true, ["hydrochlorothiazide"]],
    ["hydroCHLOROthiazide (Oral Pill)", true, ["hydrochlorothiazide"]],
    ["hydroCHLOROthiazide (Oral Suspension Powder)", true, ["hydrochlorothiazide"]],
    ["hydroCHLOROthiazide/Irbesartan (Oral Pill)", true, ["hydrochlorothiazide", "irbesartan"]],
    ["hydroCHLOROthiazide/Lisinopril (Oral Pill)", true, ["hydrochlorothiazide", "lisinopril"]],
    ["hydroCHLOROthiazide/Losartan (Oral Pill)", true, ["hydrochlorothiazide", "losartan"]],
    ["hydroCHLOROthiazide/Metoprolol (Oral Pill)", true, ["hydrochlorothiazide", "metoprolol"]],
    ["hydroCHLOROthiazide/Moexipril (Oral Pill)", true, ["hydrochlorothiazide", "moexipril"]],
    ["hydroCHLOROthiazide/Olmesartan (Oral Pill)", true, ["hydrochlorothiazide", "olmesartan"]],
    ["hydroCHLOROthiazide/Quinapril (Oral Pill)", true, ["hydrochlorothiazide", "quinapril"]],
    ["hydroCHLOROthiazide/Spironolactone (Oral Pill)", true, ["hydrochlorothiazide", "spironolactone"]],
    ["hydroCHLOROthiazide/Telmisartan (Oral Pill)", true, ["hydrochlorothiazide", "telmisartan"]],
    ["hydroCHLOROthiazide/Triamterene (Oral Pill)", true, ["hydrochlorothiazide", "triamterene"]],
    ["hydroCHLOROthiazide/Valsartan (Oral Pill)", true, ["hydrochlorothiazide", "valsartan"]],
    ["HYDROCIL (Oral Suspension Powder)", true, ["psyllium"]],
    ["HYDROcodone XR (Oral Pill)", true, ["hydrocodone"]],
    ["HYDROcodone/Ibuprofen (Oral Pill)", true, ["hydrocodone", "ibuprofen"]],
    ["Hydrocortisone (Injectable)", false, ["hydrocortisone"]],
    ["Hydrocortisone (Oral Granules)", true, ["hydrocortisone"]],
    ["Hydrocortisone (Oral Liquid)", true, ["hydrocortisone"]],
    ["Hydrocortisone (Oral Pill)", true, ["hydrocortisone"]],
    ["Hydrocortisone (Rectal)", false, ["hydrocortisone"]],
    ["Hydrocortisone (Topical)", false, ["hydrocortisone"]],
    ["Hydrocortisone (Vaginal)", false, ["hydrocortisone"]],
    ["Hydrocortisone/Iodoquinol (Topical)", false, ["hydrocortisone", "iodoquinol"]],
    ["Hydrocortisone/Lidocaine (Rectal)", false, ["hydrocortisone", "lidocaine"]],
    ["Hydrocortisone/Lidocaine (Topical)", false, ["hydrocortisone", "lidocaine"]],
    ["Hydrocortisone/Pramoxine (Rectal)", false, ["hydrocortisone", "pramoxine"]],
    ["Hydrocortisone/Pramoxine (Topical)", false, ["hydrocortisone", "pramoxine"]],
    ["Hydrocortisone/Tolnaftate (Topical)", false, ["hydrocortisone", "tolnaftate"]],
    ["Hydrofluoric acid/Phosphoric acid/Sodium fluoride (Oral Gel)", true, ["hydrofluoric acid", "phosphoric acid", "sodium fluoride"]],
    ["Hydrogen peroxide (Mouthwash)", false, ["hydrogen peroxide"]],
    ["Hydrogen peroxide (Mucosal)", false, ["hydrogen peroxide"]],
    ["Hydrogen peroxide (Oral Gel)", true, ["hydrogen peroxide"]],
    ["Hydrogen peroxide (Topical)", false, ["hydrogen peroxide"]],
    ["Hydrogen peroxide/Menthol (Mucosal)", false, ["hydrogen peroxide", "menthol"]],
    ["HYDROMET (Oral Liquid)", true, ["homatropine", "hydrocodone"]],
    ["HYDROmorphone (Injectable)", false, ["hydromorphone"]],
    ["HYDROmorphone (Oral Liquid)", true, ["hydromorphone"]],
    ["HYDROmorphone (Oral Pill)", true, ["hydromorphone"]],
    ["HYDROmorphone (Rectal)", false, ["hydromorphone"]],
    ["HYDROmorphone XR (Oral Pill)", true, ["hydromorphone"]],
    ["Hydroquinone (Topical)", false, ["hydroquinone"]],
    ["Hydroxocobalamin (Injectable)", false, ["hydroxocobalamin"]],
    ["Hydroxychloroquine (Oral Pill)", true, ["hydroxychloroquine"]],
    ["Hydroxyethyl starch 130-0.4 (Injectable)", false, ["hydroxyethyl starch 130-0.4"]],
    ["Hydroxypropylcellulose (Implant)", false, ["hydroxypropylcellulose"]],
    ["hydroxytryptophan (Oral Pill)", true, ["5-hydroxytryptophan"]],
    ["hydroxytryptophan XR (Oral Pill)", true, ["5-hydroxytryptophan"]],
    ["hydroxytryptophan/Magnesium oxide/Melatonin/Tryptophan/Vitamin B6 (Oral Pill)", true, ["5-hydroxytryptophan", "magnesium oxide", "melatonin", "tryptophan", "vitamin B6"]],
    ["hydroxytryptophan/Melatonin (Oral Pill)", true, ["5-hydroxytryptophan", "melatonin"]],
    ["Hydroxyurea (Oral Liquid)", true, ["hydroxyurea"]],
    ["Hydroxyurea (Oral Pill)", true, ["hydroxyurea"]],
    ["hydrOXYzine (Injectable)", false, ["hydroxyzine"]],
    ["hydrOXYzine (Oral Liquid)", true, ["hydroxyzine"]],
    ["hydrOXYzine (Oral Pill)", true, ["hydroxyzine"]],
    ["HYFTOR (Topical)", false, ["sirolimus"]],
    ["Hylan G-F 20 (Injectable)", false, ["hylan G-F 20"]],
    ["HYLENEX (Injectable)", false, ["hyaluronidase"]],
    ["HYMOVIS (Injectable)", false, ["hyaluronate"]],
    ["HYMPAVZI (Injectable)", false, ["marstacimab"]],
    ["HYOPHEN (Oral Pill)", true, ["benzoate", "hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate"]],
    ["Hyoscyamine (Injectable)", false, ["hyoscyamine"]],
    ["Hyoscyamine (Oral Disintegrating)", true, ["hyoscyamine"]],
    ["Hyoscyamine (Oral Liquid)", true, ["hyoscyamine"]],
    ["Hyoscyamine (Oral Pill)", true, ["hyoscyamine"]],
    ["Hyoscyamine (Sublingual)", false, ["hyoscyamine"]],
    ["Hyoscyamine XR (Oral Pill)", true, ["hyoscyamine"]],
    ["Hyoscyamine/Methenamine/Methylene blue/Phenyl salicylate/Sodium phosphate, monobasic (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["Hyoscyamine/Methenamine/Methylene blue/Sodium phosphate, monobasic (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "sodium phosphate, monobasic"]],
    ["Hyoscyamine/Phenyltoloxamine (Oral Pill)", true, ["hyoscyamine", "phenyltoloxamine"]],
    ["HYPER-SAL (Inhalant)", false, ["sodium chloride"]],
    ["HYPERHEP B (Injectable)", false, ["hepatitis B immune globulin"]],
    ["HYPERRAB (Injectable)", false, ["rabies immune globulin, human"]],
    ["HYPERRHO (Injectable)", false, ["Rho(D) immune globulin"]],
    ["HYPERTET (Injectable)", false, ["tetanus immune globulin"]],
    ["Hypochlorite (Irrigation)", false, ["hypochlorite"]],
    ["Hypochlorite (Topical)", false, ["hypochlorite"]],
    ["HYPOTEARS (Ophthalmic)", false, ["polyethylene glycols", "polyvinyl alcohol"]],
    ["Hypromellose (Injectable)", false, ["hypromellose"]],
    ["Hypromellose (Ophthalmic)", false, ["hypromellose"]],
    ["Hypromellose/Naphazoline (Ophthalmic)", false, ["hypromellose", "naphazoline"]],
    ["Hypromellose/Naphazoline/Polysorbate 80/Zinc sulfate (Ophthalmic)", false, ["hypromellose", "naphazoline", "polysorbate 80", "zinc sulfate"]],
    ["HYQVIA 10 G / 100 ML KIT (Pack)", false, ["hyaluronidase", "immunoglobulin G"]],
    ["HYQVIA 2.5 G / 25 ML KIT (Pack)", false, ["hyaluronidase", "immunoglobulin G"]],
    ["HYQVIA 20 G / 200 ML KIT (Pack)", false, ["hyaluronidase", "immunoglobulin G"]],
    ["HYQVIA 30 G / 300 ML KIT (Pack)", false, ["hyaluronidase", "immunoglobulin G"]],
    ["HYQVIA 5 G / 50 ML KIT (Pack)", false, ["hyaluronidase", "immunoglobulin G"]],
    ["HYRIMOZ (Injectable)", false, ["adalimumab"]],
    ["HYRIMOZ CROHN'S AND UC STARTER KIT (Pack)", false, ["adalimumab"]],
    ["HYRIMOZ PEDIATRIC CROHN'S STARTER KIT PATIENT WEIGHT < 40 KG (Pack)", false, ["adalimumab"]],
    ["HYRIMOZ PEDIATRIC CROHN'S STARTER KIT PATIENT WEIGHT > 40 KG (Pack)", false, ["adalimumab"]],
    ["HYRIMOZ PLAQUE PSORIASIS STARTER KIT (Pack)", false, ["adalimumab"]],
    ["HYRNUO (Oral Pill)", true, ["sevabertinib"]],
    ["HYSEPT (Topical)", false, ["hypochlorite"]],
    ["HYSINGLA XR (Oral Pill)", true, ["hydrocodone"]],
    ["HYZAAR (Oral Pill)", true, ["hydrochlorothiazide", "losartan"]],
    ["Ibalizumab (Injectable)", false, ["ibalizumab"]],
    ["Ibandronate (Injectable)", false, ["ibandronate"]],
    ["Ibandronate (Oral Pill)", true, ["ibandronate"]],
    ["Iberdomide (Oral Pill)", true, ["iberdomide"]],
    ["IBRANCE (Oral Pill)", true, ["palbociclib"]],
    ["Ibrexafungerp (Oral Pill)", true, ["ibrexafungerp"]],
    ["Ibrexafungerp (Pack)", true, ["ibrexafungerp"]],
    ["Ibrutinib (Oral Liquid)", true, ["ibrutinib"]],
    ["Ibrutinib (Oral Pill)", true, ["ibrutinib"]],
    ["IBSRELA (Oral Pill)", true, ["tenapanor"]],
    ["IBTROZI (Oral Pill)", true, ["taletrectinib"]],
    ["IBU (Oral Pill)", true, ["ibuprofen"]],
    ["IBUDONE (Oral Pill)", true, ["hydrocodone", "ibuprofen"]],
    ["Ibuprofen (Chewable)", true, ["ibuprofen"]],
    ["Ibuprofen (Injectable)", false, ["ibuprofen"]],
    ["Ibuprofen (Oral Liquid)", true, ["ibuprofen"]],
    ["Ibuprofen (Oral Pill)", true, ["ibuprofen"]],
    ["Ibuprofen/Phenylephrine (Oral Pill)", true, ["ibuprofen", "phenylephrine"]],
    ["Ibuprofen/Pseudoephedrine (Oral Pill)", true, ["ibuprofen", "pseudoephedrine"]],
    ["IBUPROHM (Oral Pill)", true, ["ibuprofen"]],
    ["Ibutilide (Injectable)", false, ["ibutilide"]],
    ["ICAR (Chewable)", true, ["iron carbonyl"]],
    ["ICAR (Oral Liquid)", true, ["iron carbonyl"]],
    ["ICAR C (Oral Pill)", true, ["ascorbic acid", "iron carbonyl"]],
    ["ICAR-C PLUS (Oral Pill)", true, ["ascorbic acid", "folic acid", "iron carbonyl", "vitamin B12"]],
    ["Icatibant (Injectable)", false, ["icatibant"]],
    ["Ichthammol (Topical)", false, ["ichthammol"]],
    ["ICLEVIA 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["ICLUSIG (Oral Pill)", true, ["ponatinib"]],
    ["Icosapent ethyl (Oral Pill)", true, ["icosapent ethyl"]],
    ["Icotrokinra (Oral Pill)", true, ["icotrokinra"]],
    ["ICOTYDE (Oral Pill)", true, ["icotrokinra"]],
    ["IDACIO (Injectable)", false, ["adalimumab"]],
    ["IDACIO PEN 40 MG/0.8 ML STARTER PACK - PLAQUE PSORIASIS (Pack)", false, ["adalimumab"]],
    ["IDACIO PEN 40 MG/0.8 ML STARTER PACKAGE FOR CROHN'S DISEASE OR ULCERATIVE COLITIS (Pack)", false, ["adalimumab"]],
    ["IDAMYCIN (Injectable)", false, ["idarubicin"]],
    ["IDArubicin (Injectable)", false, ["idarubicin"]],
    ["idaruCIZUmab (Injectable)", false, ["idarucizumab"]],
    ["Idecabtagene vicleucel (Injectable)", false, ["idecabtagene vicleucel"]],
    ["Idelalisib (Oral Pill)", true, ["idelalisib"]],
    ["IDELVION (Injectable)", false, ["factor IX"]],
    ["IDHIFA (Oral Pill)", true, ["enasidenib"]],
    ["IDOSE (Implant)", false, ["travoprost"]],
    ["Idursulfase (Injectable)", false, ["idursulfase"]],
    ["IDVYNSO (Oral Pill)", true, ["doravirine", "islatravir"]],
    ["IFEREX (Oral Pill)", true, ["polysaccharide iron complex"]],
    ["IFEREX 150 FORTE (Oral Pill)", true, ["folic acid", "polysaccharide iron complex", "vitamin B12"]],
    ["IFEX (Injectable)", false, ["ifosfamide"]],
    ["Ifosfamide (Injectable)", false, ["ifosfamide"]],
    ["IGALMI (Sublingual)", false, ["dexmedetomidine"]],
    ["IHEEZO (Ophthalmic)", false, ["chloroprocaine"]],
    ["ILARIS (Injectable)", false, ["canakinumab"]],
    ["ILEVRO (Ophthalmic)", false, ["nepafenac"]],
    ["ILEX SKIN (Topical)", false, ["petrolatum"]],
    ["Iloperidone (Oral Pill)", true, ["iloperidone"]],
    ["Iloperidone (Pack)", true, ["iloperidone"]],
    ["Iloprost (Inhalant)", false, ["iloprost"]],
    ["Iloprost (Injectable)", false, ["iloprost"]],
    ["ILUMYA (Injectable)", false, ["tildrakizumab"]],
    ["ILUVIEN (Implant)", false, ["fluocinolone"]],
    ["IMAAVY (Injectable)", false, ["nipocalimab"]],
    ["Imatinib (Oral Liquid)", true, ["imatinib"]],
    ["Imatinib (Oral Pill)", true, ["imatinib"]],
    ["IMBRUVICA (Oral Liquid)", true, ["ibrutinib"]],
    ["IMBRUVICA (Oral Pill)", true, ["ibrutinib"]],
    ["IMCIVREE (Injectable)", false, ["setmelanotide"]],
    ["IMDELLTRA (Injectable)", false, ["tarlatamab"]],
    ["Imetelstat (Injectable)", false, ["imetelstat"]],
    ["IMFINZI (Injectable)", false, ["durvalumab"]],
    ["Imiglucerase (Injectable)", false, ["imiglucerase"]],
    ["Imipramine (Oral Pill)", true, ["imipramine"]],
    ["Imiquimod (Topical)", false, ["imiquimod"]],
    ["IMITREX (Injectable)", false, ["sumatriptan"]],
    ["IMITREX (Nasal)", false, ["sumatriptan"]],
    ["IMITREX (Oral Pill)", true, ["sumatriptan"]],
    ["IMJUDO (Injectable)", false, ["tremelimumab"]],
    ["IMKELDI (Oral Liquid)", true, ["imatinib"]],
    ["Imlunestrant (Oral Pill)", true, ["imlunestrant"]],
    ["IMLYGIC (Injectable)", false, ["herpesvirus 1, human"]],
    ["IMMPHENTIV (Injectable)", false, ["phenylephrine"]],
    ["Immunoglobulin G (Injectable)", false, ["immunoglobulin G"]],
    ["IMODIUM (Oral Liquid)", true, ["loperamide"]],
    ["IMODIUM (Oral Pill)", true, ["loperamide"]],
    ["IMODIUM ADVANCED (Chewable)", true, ["loperamide", "simethicone"]],
    ["IMODIUM MULTI-SYMPTOM RELIEF (Oral Pill)", true, ["loperamide", "simethicone"]],
    ["IMOGAM (Injectable)", false, ["rabies immune globulin, human"]],
    ["IMOVAX (Injectable)", false, ["rabies virus vaccine wistar strain PM-1503-3M (human), inactivated"]],
    ["IMPAVIDO (Oral Pill)", true, ["miltefosine"]],
    ["IMPOYZ (Topical)", false, ["clobetasol"]],
    ["IMULDOSA (Injectable)", false, ["ustekinumab"]],
    ["IMURAN (Oral Pill)", true, ["azathioprine"]],
    ["IMVEXXY (Vaginal)", false, ["estradiol"]],
    ["IMVEXXY 10 MCG MAINTENANCE PACK (Pack)", false, ["estradiol"]],
    ["IMVEXXY 10 MCG STARTER PACK (Pack)", false, ["estradiol"]],
    ["IMVEXXY 4 MCG MAINTENANCE PACK (Pack)", false, ["estradiol"]],
    ["IMVEXXY 4 MCG STARTER PACK (Pack)", false, ["estradiol"]],
    ["Inavolisib (Oral Pill)", true, ["inavolisib"]],
    ["INBRIJA (Inhalant)", false, ["levodopa"]],
    ["INCASSIA 28 DAY (Pack)", true, ["norethindrone"]],
    ["Inclisiran (Injectable)", false, ["inclisiran"]],
    ["INCRELEX (Injectable)", false, ["mecasermin"]],
    ["INCRUSE (Inhalant)", false, ["umeclidinium"]],
    ["Indapamide (Oral Pill)", true, ["indapamide"]],
    ["INDERAL XR (Oral Pill)", true, ["propranolol"]],
    ["INDOCIN (Oral Liquid)", true, ["indomethacin"]],
    ["INDOCIN (Rectal)", false, ["indomethacin"]],
    ["Indomethacin (Injectable)", false, ["indomethacin"]],
    ["Indomethacin (Oral Liquid)", true, ["indomethacin"]],
    ["Indomethacin (Oral Pill)", true, ["indomethacin"]],
    ["Indomethacin (Rectal)", false, ["indomethacin"]],
    ["Indomethacin XR (Oral Pill)", true, ["indomethacin"]],
    ["Inebilizumab (Injectable)", false, ["inebilizumab"]],
    ["Inebilizumab (Pack)", false, ["inebilizumab"]],
    ["Inert ingredients (Chewable)", true, ["inert ingredients"]],
    ["Inert ingredients (Oral Disintegrating)", true, ["inert ingredients"]],
    ["Inert ingredients (Oral Pill)", true, ["inert ingredients"]],
    ["INFANRIX (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["INFASURF (Intratracheal)", false, ["calfactant"]],
    ["INFED (Injectable)", false, ["iron-dextran complex"]],
    ["Infigratinib (Oral Pill)", true, ["infigratinib"]],
    ["Infigratinib (Pack)", true, ["infigratinib"]],
    ["INFLECTRA (Injectable)", false, ["infliximab"]],
    ["inFLIXimab (Injectable)", false, ["infliximab"]],
    ["Influenza A virus (H1N1) antigen/Influenza A virus (H3N2) antigen/Influenza B virus antigen (Nasal)", false, ["influenza A virus (H1N1) antigen", "influenza A virus (H3N2) antigen", "influenza B virus antigen"]],
    ["Influenza A virus (H5N1) antigen (Injectable)", false, ["influenza A virus (H5N1) antigen"]],
    ["Influenza A virus (H5N8) antigen (Injectable)", false, ["influenza A virus (H5N8) antigen"]],
    ["Influenza vaccine, mRNA hemagglutinin glycoprotein (Injectable)", false, ["influenza vaccine, mRNA hemagglutinin glycoprotein"]],
    ["INFUGEM (Injectable)", false, ["gemcitabine"]],
    ["INFUMORPH (Injectable)", false, ["morphine"]],
    ["INFUVITE (Injectable)", false, ["alpha tocopherol", "ascorbic acid", "biotin", "cholecalciferol", "dexpanthenol", "folic acid", "niacinamide", "pyridoxine", "riboflavin", "thiamine", "vitamin A", "vitamin B12", "vitamin K1"]],
    ["INFUVITE PEDIATRIC (Injectable)", false, ["alpha tocopherol", "ascorbic acid", "biotin", "cholecalciferol", "dexpanthenol", "folic acid", "niacinamide", "pyridoxine", "riboflavin", "thiamine", "vitamin A", "vitamin B12", "vitamin K1"]],
    ["INGREZZA (Oral Pill)", true, ["valbenazine"]],
    ["INGREZZA (Pack)", true, ["valbenazine"]],
    ["INGREZZA 40/60 INITIATION PACK (Pack)", true, ["valbenazine"]],
    ["INJECTAFER (Injectable)", false, ["ferric carboxymaltose"]],
    ["INLEXZO (Implant)", false, ["gemcitabine"]],
    ["INLURIYO (Oral Pill)", true, ["imlunestrant"]],
    ["INLYTA (Oral Pill)", true, ["axitinib"]],
    ["INMAZEB (Injectable)", false, ["atoltivimab", "maftivimab", "odesivimab"]],
    ["INNOPRAN XR (Oral Pill)", true, ["propranolol"]],
    ["INOMAX (Inhalant)", false, ["nitric oxide", "nitrogen"]],
    ["Inositol (Oral Pill)", true, ["inositol"]],
    ["Inositol/Niacin (Oral Pill)", true, ["inositol", "niacin"]],
    ["Inotersen (Injectable)", false, ["inotersen"]],
    ["Inotuzumab ozogamicin (Injectable)", false, ["inotuzumab ozogamicin"]],
    ["INOVA (Topical)", false, ["benzoyl peroxide"]],
    ["INOVA 4/1 (Pack)", false, ["benzoyl peroxide", "salicylic acid"]],
    ["INOVA 8-2 (Topical)", false, ["benzoyl peroxide", "salicylic acid"]],
    ["INPEFA (Oral Pill)", true, ["sotagliflozin"]],
    ["INQOVI (Oral Pill)", true, ["cedazuridine", "decitabine"]],
    ["INQOVI 5 TABLET PACK (Pack)", true, ["cedazuridine", "decitabine"]],
    ["INREBIC (Oral Pill)", true, ["fedratinib"]],
    ["INSPRA (Oral Pill)", true, ["eplerenone"]],
    ["INSTA-CHAR (Oral Liquid)", true, ["activated charcoal"]],
    ["INSTA-GLUCOSE (Oral Gel)", true, ["glucose"]],
    ["INSTACORT (Topical)", false, ["hydrocortisone"]],
    ["Insulin analog, aspart (Injectable)", false, ["insulin aspart, human"]],
    ["Insulin analog, aspart mixed (Injectable)", false, ["insulin aspart protamine, human", "insulin aspart, human"]],
    ["Insulin analog, degludec (Injectable)", false, ["insulin degludec"]],
    ["Insulin analog, degludec/liraglutide (Injectable)", false, ["insulin degludec", "liraglutide"]],
    ["Insulin analog, detemir (Injectable)", false, ["insulin detemir"]],
    ["Insulin analog, glargine (Injectable)", false, ["insulin glargine"]],
    ["Insulin analog, glargine-aglr (Injectable)", false, ["insulin glargine"]],
    ["Insulin analog, glargine-aldy (Injectable)", false, ["insulin glargine"]],
    ["Insulin analog, glargine-yfgn (Injectable)", false, ["insulin glargine"]],
    ["Insulin analog, glargine/Lixisenatide (Injectable)", false, ["insulin glargine", "lixisenatide"]],
    ["Insulin analog, glulisine (Injectable)", false, ["insulin glulisine, human"]],
    ["Insulin analog, icodec (Injectable)", false, ["insulin icodec"]],
    ["Insulin analog, lispro (Injectable)", false, ["insulin lispro"]],
    ["Insulin analog, lispro mixed (Injectable)", false, ["insulin lispro", "insulin lispro protamine, human"]],
    ["Insulin analog, lispro-aabc (Injectable)", false, ["insulin lispro"]],
    ["Insulin aspart, human (Injectable)", false, ["insulin aspart, human"]],
    ["Insulin efsitora alfa (Injectable)", false, ["insulin efsitora alfa"]],
    ["Insulin, human isophane (Injectable)", false, ["insulin isophane"]],
    ["Insulin, human mixed (Injectable)", false, ["insulin isophane", "insulin, regular, human"]],
    ["Insulin, human regular (Inhalant pack)", false, ["insulin, regular, human"]],
    ["Insulin, human regular (Inhalant)", false, ["insulin, regular, human"]],
    ["Insulin, human regular (Injectable)", false, ["insulin, regular, human"]],
    ["Insulin, regular, human (Pack)", false, ["insulin, regular, human"]],
    ["INTEGRA F (Oral Pill)", true, ["ascorbic acid", "ferrous fumarate", "folic acid", "niacinamide", "polysaccharide iron complex"]],
    ["INTELENCE (Oral Pill)", true, ["etravirine"]],
    ["Interferon alfa-n3 (Injectable)", false, ["interferon alfa-n3"]],
    ["Interferon beta-1a (Injectable)", false, ["interferon beta-1a"]],
    ["Interferon beta-1a (Pack)", false, ["interferon beta-1a"]],
    ["Interferon beta-1b (Injectable)", false, ["interferon beta-1b"]],
    ["Interferon gamma-1b (Injectable)", false, ["interferon gamma-1b"]],
    ["INTESTINEX (Oral Pill)", true, ["Lactobacillus acidophilus"]],
    ["INTRALIPID (Injectable)", false, ["soybean oil"]],
    ["INTRAROSA (Vaginal)", false, ["prasterone"]],
    ["INTROVALE 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["INTUNIV XR (Oral Pill)", true, ["guanfacine"]],
    ["Inulin (Chewable)", true, ["inulin"]],
    ["Inulin/Lacticaseibacillus rhamnosus (Oral Pill)", true, ["Lacticaseibacillus rhamnosus", "inulin"]],
    ["INVANZ (Injectable)", false, ["ertapenem"]],
    ["INVEGA (Injectable)", false, ["paliperidone"]],
    ["INVEGA XR (Oral Pill)", true, ["paliperidone"]],
    ["INVELTYS (Ophthalmic)", false, ["loteprednol etabonate"]],
    ["INVOKAMET (Oral Pill)", true, ["canagliflozin", "metformin"]],
    ["INVOKAMET XR (Oral Pill)", true, ["canagliflozin", "metformin"]],
    ["INVOKANA (Oral Pill)", true, ["canagliflozin"]],
    ["INZIRQO (Oral Suspension Powder)", true, ["hydrochlorothiazide"]],
    ["INZO (Topical)", false, ["miconazole"]],
    ["Iodine (Topical)", false, ["iodine"]],
    ["Iodine povacrylex/Isopropyl alcohol (Topical)", false, ["iodine povacrylex", "isopropyl alcohol"]],
    ["Iodine/Potassium iodide (Oral Liquid)", true, ["iodine", "potassium iodide"]],
    ["Iodine/Potassium iodide (Topical)", false, ["iodine", "potassium iodide"]],
    ["Iodine/Sodium iodide (Topical)", false, ["iodine", "sodium iodide"]],
    ["iodobenzylguanidine (Injectable)", false, ["3-iodobenzylguanidine"]],
    ["IODOFLEX (Topical)", false, ["cadexomer iodine"]],
    ["IODOPEN (Injectable)", false, ["sodium iodide"]],
    ["IODOSORB (Topical)", false, ["cadexomer iodine"]],
    ["IONIL PLUS (Shampoo)", false, ["salicylic acid"]],
    ["IONIL T (Shampoo)", false, ["coal tar"]],
    ["IONOSOL-MB (Injectable)", false, ["glucose", "lactate", "magnesium chloride", "potassium chloride", "potassium phosphate", "sodium phosphate, monobasic"]],
    ["IONSYS (Transdermal)", false, ["fentanyl"]],
    ["IOPIDINE (Ophthalmic)", false, ["apraclonidine"]],
    ["IOSAT (Oral Pill)", true, ["potassium iodide"]],
    ["Ipilimumab (Injectable)", false, ["ipilimumab"]],
    ["IPM WOUND (Topical)", false, ["hyaluronate"]],
    ["IPOL (Injectable)", false, ["poliovirus vaccine inactivated, type 1 (Mahoney)", "poliovirus vaccine inactivated, type 2 (MEF-1)", "poliovirus vaccine inactivated, type 3 (Saukett)"]],
    ["Ipratropium (Inhalant)", false, ["ipratropium"]],
    ["Ipratropium (Nasal)", false, ["ipratropium"]],
    ["Iptacopan (Oral Pill)", true, ["iptacopan"]],
    ["IQIRVO (Oral Pill)", true, ["elafibranor"]],
    ["Irbesartan (Oral Pill)", true, ["irbesartan"]],
    ["IRENKA (Oral Pill)", true, ["duloxetine"]],
    ["IRESSA (Oral Pill)", true, ["gefitinib"]],
    ["Irinotecan (Injectable)", false, ["irinotecan"]],
    ["Iron carbonyl (Chewable)", true, ["iron carbonyl"]],
    ["Iron carbonyl (Oral Liquid)", true, ["iron carbonyl"]],
    ["Iron carbonyl (Oral Pill)", true, ["iron carbonyl"]],
    ["Iron succinyl milk protein complex (Oral Liquid)", true, ["iron succinyl milk protein complex"]],
    ["Iron sucrose (Injectable)", false, ["iron sucrose"]],
    ["Iron-dextran complex (Injectable)", false, ["iron-dextran complex"]],
    ["IROSPAN 24/6 KIT (Pack)", true, ["ascorbic acid", "biotin", "calcium carbonate", "ferrous bisglycinate", "folic acid", "formic acid", "iron-dextran complex", "niacin", "pantothenate", "pyridoxine", "riboflavin", "succinic acid", "thiamine", "vitamin B12"]],
    ["IROSPAN TABLET (Oral Pill)", true, ["ascorbic acid", "biotin", "ferrous bisglycinate", "folic acid", "formic acid", "iron-dextran complex", "niacin", "pantothenate", "pyridoxine", "riboflavin", "thiamine", "vitamin B12"]],
    ["Isatuximab (Injectable)", false, ["isatuximab"]],
    ["Isavuconazonium (Injectable)", false, ["isavuconazonium"]],
    ["Isavuconazonium (Oral Pill)", true, ["isavuconazonium"]],
    ["ISEMBYLD (Injectable)", false, ["apitegromab"]],
    ["ISENTRESS (Chewable)", true, ["raltegravir"]],
    ["ISENTRESS (Oral Pill)", true, ["raltegravir"]],
    ["ISENTRESS (Oral Suspension Granules)", true, ["raltegravir"]],
    ["ISIBLOOM 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Isocarboxazid (Oral Pill)", true, ["isocarboxazid"]],
    ["ISOCHRON XR (Oral Pill)", true, ["isosorbide dinitrate"]],
    ["ISODITRATE XR (Oral Pill)", true, ["isosorbide dinitrate"]],
    ["Isoflurane (Inhalant)", false, ["isoflurane"]],
    ["ISOLYTE P (Injectable)", false, ["dibasic potassium phosphate", "glucose", "magnesium chloride", "potassium chloride", "sodium acetate"]],
    ["ISOLYTE S (Injectable)", false, ["magnesium chloride", "potassium chloride", "potassium phosphate", "sodium acetate", "sodium chloride", "sodium gluconate", "sodium phosphate, dibasic"]],
    ["Isoniazid (Injectable)", false, ["isoniazid"]],
    ["Isoniazid (Oral Liquid)", true, ["isoniazid"]],
    ["Isoniazid (Oral Pill)", true, ["isoniazid"]],
    ["Isopropyl alcohol (Otic)", false, ["isopropyl alcohol"]],
    ["Isopropyl alcohol (Topical)", false, ["isopropyl alcohol"]],
    ["Isopropyl alcohol/Methyl salicylate (Topical)", false, ["isopropyl alcohol", "methyl salicylate"]],
    ["Isopropyl alcohol/Povidone-iodine (Topical)", false, ["isopropyl alcohol", "povidone-iodine"]],
    ["Isoproterenol (Injectable)", false, ["isoproterenol"]],
    ["ISOPTIN XR (Oral Pill)", true, ["verapamil"]],
    ["ISOPTO ALKALINE (Ophthalmic)", false, ["hypromellose"]],
    ["ISOPTO ATROPINE (Ophthalmic)", false, ["atropine"]],
    ["ISOPTO CARBACHOL (Ophthalmic)", false, ["carbachol"]],
    ["ISOPTOCARPINE (Ophthalmic)", false, ["pilocarpine"]],
    ["ISORDIL (Oral Pill)", true, ["isosorbide dinitrate"]],
    ["Isosorbide (Oral Pill)", true, ["isosorbide"]],
    ["Isosorbide dinitrate (Oral Pill)", true, ["isosorbide dinitrate"]],
    ["Isosorbide dinitrate (Sublingual)", false, ["isosorbide dinitrate"]],
    ["Isosorbide dinitrate XR (Oral Pill)", true, ["isosorbide dinitrate"]],
    ["Isosorbide XR (Oral Pill)", true, ["isosorbide"]],
    ["ISOtretinoin (Oral Pill)", true, ["isotretinoin"]],
    ["Isoxsuprine (Oral Pill)", true, ["isoxsuprine"]],
    ["Isradipine (Oral Pill)", true, ["isradipine"]],
    ["Isradipine XR (Oral Pill)", true, ["isradipine"]],
    ["ISTALOL (Ophthalmic)", false, ["timolol"]],
    ["ISTODAX (Injectable)", false, ["romidepsin"]],
    ["Istradefylline (Oral Pill)", true, ["istradefylline"]],
    ["ISTURISA (Oral Pill)", true, ["osilodrostat"]],
    ["ISUPREL (Injectable)", false, ["isoproterenol"]],
    ["ITCH-X (Topical)", false, ["benzyl alcohol", "pramoxine"]],
    ["ITOVEBI (Oral Pill)", true, ["inavolisib"]],
    ["Itraconazole (Oral Liquid)", true, ["itraconazole"]],
    ["Itraconazole (Oral Pill)", true, ["itraconazole"]],
    ["ITVISMA (Injectable)", false, ["onasemnogene abeparvovec"]],
    ["Ivabradine (Oral Liquid)", true, ["ivabradine"]],
    ["Ivabradine (Oral Pill)", true, ["ivabradine"]],
    ["Ivacaftor (Oral Granules)", true, ["ivacaftor"]],
    ["Ivacaftor (Oral Pill)", true, ["ivacaftor"]],
    ["Ivacaftor/Lumacaftor (Oral Granules)", true, ["ivacaftor", "lumacaftor"]],
    ["Ivacaftor/Lumacaftor (Oral Pill)", true, ["ivacaftor", "lumacaftor"]],
    ["Ivacaftor/Tezacaftor (Oral Pill)", true, ["ivacaftor", "tezacaftor"]],
    ["Ivacaftor/Tezacaftor (Pack)", true, ["ivacaftor", "tezacaftor"]],
    ["Ivermectin (Oral Pill)", true, ["ivermectin"]],
    ["Ivermectin (Topical)", false, ["ivermectin"]],
    ["IVIZIA (Ophthalmic)", false, ["povidone"]],
    ["Ivosidenib (Oral Pill)", true, ["ivosidenib"]],
    ["IVRA (Injectable)", false, ["melphalan"]],
    ["IVY DRY SUPER CONTINUOUS SPRAY (Topical)", false, ["benzyl alcohol", "camphor", "menthol"]],
    ["IVY-DRY CREAM (Topical)", false, ["benzyl alcohol", "camphor", "menthol"]],
    ["IWILFIN (Oral Pill)", true, ["eflornithine"]],
    ["Ixabepilone (Injectable)", false, ["ixabepilone"]],
    ["Ixazomib (Oral Pill)", true, ["ixazomib"]],
    ["IXCHIQ (Injectable)", false, ["chikungunya virus antigen, live attenuated LR2006 OPY1 strain"]],
    ["Ixekizumab (Injectable)", false, ["ixekizumab"]],
    ["IXEMPRA (Injectable)", false, ["ixabepilone"]],
    ["IXIARO (Injectable)", false, ["Japanese encephalitis virus vaccine, inactivated"]],
    ["IXINITY (Injectable)", false, ["factor IX"]],
    ["IYUZEH (Ophthalmic)", false, ["latanoprost"]],
    ["IZERVAY (Injectable)", false, ["avacincaptad pegol"]],
    ["JADENU (Oral Granules)", true, ["deferasirox"]],
    ["JADENU (Oral Pill)", true, ["deferasirox"]],
    ["JAIMIESS 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["JAKAFI (Oral Pill)", true, ["ruxolitinib"]],
    ["JAKAFI XR (Oral Pill)", true, ["ruxolitinib"]],
    ["JALYN (Oral Pill)", true, ["dutasteride", "tamsulosin"]],
    ["JANTOVEN (Oral Pill)", true, ["warfarin"]],
    ["JANUMET (Oral Pill)", true, ["metformin", "sitagliptin"]],
    ["JANUMET XR (Oral Pill)", true, ["metformin", "sitagliptin"]],
    ["JANUVIA (Oral Pill)", true, ["sitagliptin"]],
    ["Japanese encephalitis virus vaccine, inactivated (Injectable)", false, ["Japanese encephalitis virus vaccine, inactivated"]],
    ["JARDIANCE (Oral Pill)", true, ["empagliflozin"]],
    ["JASCAYD (Oral Pill)", true, ["nerandomilast"]],
    ["JASMIEL 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["JATENZO (Oral Pill)", true, ["testosterone"]],
    ["JAVADIN (Oral Liquid)", true, ["clonidine"]],
    ["JAVYGTOR (Oral Pill)", true, ["sapropterin"]],
    ["JAVYGTOR (Oral Solution Powder)", true, ["sapropterin"]],
    ["JAYPIRCA (Oral Pill)", true, ["pirtobrutinib"]],
    ["JAYTHARI (Oral Liquid)", true, ["deflazacort"]],
    ["JAYTHARI (Oral Pill)", true, ["deflazacort"]],
    ["JELMYTO (Pyelocalyceal Solution Powder)", false, ["mitomycin"]],
    ["JEMPERLI (Injectable)", false, ["dostarlimab"]],
    ["JENCYCLA 28 DAY (Pack)", true, ["norethindrone"]],
    ["JENTADUETO (Oral Pill)", true, ["linagliptin", "metformin"]],
    ["JENTADUETO XR (Oral Pill)", true, ["linagliptin", "metformin"]],
    ["JESDUVROQ (Oral Pill)", true, ["daprodustat"]],
    ["JET-ALERT (Oral Pill)", true, ["caffeine"]],
    ["JEUVEAU (Injectable)", false, ["botulinum toxin type A"]],
    ["JEVANTIQUE (Oral Pill)", true, ["ethinyl estradiol", "norethindrone"]],
    ["JEVTANA (Injectable)", false, ["cabazitaxel"]],
    ["JIDEYTRO (Oral Pill)", true, ["zidesamtinib"]],
    ["JINTELI (Oral Pill)", true, ["ethinyl estradiol", "norethindrone"]],
    ["JIVI (Injectable)", false, ["damoctocog alfa pegol"]],
    ["JOBEVNE (Injectable)", false, ["bevacizumab"]],
    ["JOENJA (Oral Pill)", true, ["leniolisib"]],
    ["JOLESSA 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["JORNAY XR (Oral Pill)", true, ["methylphenidate"]],
    ["JOURNAVX (Oral Pill)", true, ["suzetrigine"]],
    ["JOYEAUX 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["JUBBONTI (Injectable)", false, ["denosumab"]],
    ["JUBEREQ (Injectable)", false, ["denosumab"]],
    ["JUBLIA (Topical)", false, ["efinaconazole"]],
    ["JULEBER 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["JULIE (Oral Pill)", true, ["levonorgestrel"]],
    ["JULUCA (Oral Pill)", true, ["dolutegravir", "rilpivirine"]],
    ["JUNEL 1.5/30 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["JUNEL 1/20 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["JUNEL FE 1.5/30 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["JUNEL FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["JUNEL FE 24 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["JUVMO (Oral Pill)", true, ["tavapadon"]],
    ["JUVMO TITRATION PACK (Pack)", true, ["tavapadon"]],
    ["JUXTAPID (Oral Pill)", true, ["lomitapide"]],
    ["JYLAMVO (Oral Liquid)", true, ["methotrexate"]],
    ["JYNARQUE (Oral Pill)", true, ["tolvaptan"]],
    ["JYNARQUE 15/15 CARTON (Pack)", true, ["tolvaptan"]],
    ["JYNARQUE 30/15 CARTON (Pack)", true, ["tolvaptan"]],
    ["JYNARQUE 45/15 CARTON (Pack)", true, ["tolvaptan"]],
    ["JYNARQUE 60/30 CARTON (Pack)", true, ["tolvaptan"]],
    ["JYNARQUE 90/30 CARTON (Pack)", true, ["tolvaptan"]],
    ["JYNNEOS (Injectable)", false, ["vaccinia virus"]],
    ["K-PHOS (Oral Liquid)", true, ["potassium phosphate"]],
    ["K-PHOS NEUTRAL (Oral Pill)", true, ["potassium phosphate", "sodium phosphate, dibasic", "sodium phosphate, monobasic"]],
    ["K-PHOS NO 2 (Oral Pill)", true, ["potassium phosphate", "sodium phosphate, monobasic"]],
    ["KADCYLA (Injectable)", false, ["trastuzumab"]],
    ["KADIAN XR (Oral Pill)", true, ["morphine"]],
    ["KAITLIB FE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["KALBITOR (Injectable)", false, ["ecallantide"]],
    ["KALETRA (Oral Liquid)", true, ["lopinavir", "ritonavir"]],
    ["KALETRA (Oral Pill)", true, ["lopinavir", "ritonavir"]],
    ["KALLIGA 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["KALYDECO (Oral Granules)", true, ["ivacaftor"]],
    ["KALYDECO (Oral Pill)", true, ["ivacaftor"]],
    ["KANJINTI (Injectable)", false, ["trastuzumab"]],
    ["KANUMA (Injectable)", false, ["sebelipase alfa"]],
    ["KAOPECTATE REFORMULATED AUG 2006 (Chewable)", true, ["bismuth subsalicylate"]],
    ["KAOPECTATE REFORMULATED AUG 2006 (Oral Liquid)", true, ["bismuth subsalicylate"]],
    ["KAOPECTATE REFORMULATED AUG 2006 (Oral Pill)", true, ["bismuth subsalicylate"]],
    ["KAPSPARGO XR (Oral Pill)", true, ["metoprolol"]],
    ["KAPVAY XR (Oral Pill)", true, ["clonidine"]],
    ["KARBINAL XR (Oral Liquid)", true, ["carbinoxamine"]],
    ["KARIVA 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["KATERZIA (Oral Liquid)", true, ["amlodipine"]],
    ["KAZANO (Oral Pill)", true, ["alogliptin", "metformin"]],
    ["KCENTRA (Injectable)", false, ["factor IX", "factor VII", "factor X", "protein C", "protein S", "prothrombin"]],
    ["KEBILIDI (Injectable)", false, ["eladocagene exuparvovec"]],
    ["KEDBUMIN (Injectable)", false, ["albumin human, USP"]],
    ["KEDRAB (Injectable)", false, ["rabies immune globulin, human"]],
    ["KELNOR 1/35 28 DAY (Pack)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["KELNOR 1/50 28 DAY (Pack)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["KENALOG (Injectable)", false, ["triamcinolone"]],
    ["KENALOG (Topical)", false, ["triamcinolone"]],
    ["KENGREAL (Injectable)", false, ["cangrelor"]],
    ["KEPIVANCE (Injectable)", false, ["palifermin"]],
    ["KEPPRA (Injectable)", false, ["levetiracetam"]],
    ["KEPPRA (Oral Liquid)", true, ["levetiracetam"]],
    ["KEPPRA (Oral Pill)", true, ["levetiracetam"]],
    ["KEPPRA XR (Oral Pill)", true, ["levetiracetam"]],
    ["KERA NAIL (Topical)", false, ["urea"]],
    ["KERA-42 (Topical)", false, ["urea"]],
    ["KERALAC (Topical)", false, ["urea"]],
    ["KERALYT (Shampoo)", false, ["salicylic acid"]],
    ["KERALYT (Topical)", false, ["salicylic acid"]],
    ["KERALYT 5 (Topical)", false, ["salicylic acid"]],
    ["KERALYT SCALP (Pack)", false, ["salicylic acid"]],
    ["KERENDIA (Oral Pill)", true, ["finerenone"]],
    ["KERYDIN (Topical)", false, ["tavaborole"]],
    ["KESIMPTA (Injectable)", false, ["ofatumumab"]],
    ["KETALAR (Injectable)", false, ["ketamine"]],
    ["Ketamine (Injectable)", false, ["ketamine"]],
    ["Ketoconazole (Oral Pill)", true, ["ketoconazole"]],
    ["Ketoconazole (Shampoo)", false, ["ketoconazole"]],
    ["Ketoconazole (Topical)", false, ["ketoconazole"]],
    ["KETODAN (Topical)", false, ["ketoconazole"]],
    ["Ketoprofen (Oral Pill)", true, ["ketoprofen"]],
    ["Ketoprofen XR (Oral Pill)", true, ["ketoprofen"]],
    ["Ketorolac (Injectable)", false, ["ketorolac"]],
    ["Ketorolac (Nasal)", false, ["ketorolac"]],
    ["Ketorolac (Ophthalmic)", false, ["ketorolac"]],
    ["Ketorolac (Oral Pill)", true, ["ketorolac"]],
    ["Ketorolac/Phenylephrine (Ophthalmic)", false, ["ketorolac", "phenylephrine"]],
    ["Ketotifen (Ophthalmic)", false, ["ketotifen"]],
    ["KEVEYIS (Oral Pill)", true, ["dichlorphenamide"]],
    ["KEVZARA (Injectable)", false, ["sarilumab"]],
    ["KEYTRUDA (Injectable)", false, ["pembrolizumab"]],
    ["KEYTRUDA QLEX (Injectable)", false, ["berahyaluronidase alfa", "pembrolizumab"]],
    ["KHAPZORY (Injectable)", false, ["levoleucovorin"]],
    ["KHEDEZLA XR (Oral Pill)", true, ["desvenlafaxine"]],
    ["KHINDIVI (Oral Liquid)", true, ["hydrocortisone"]],
    ["KID'S CHOICE (Oral Gel)", true, ["stannous fluoride"]],
    ["KIMMTRAK (Injectable)", false, ["tebentafusp"]],
    ["KIMYRSA (Injectable)", false, ["oritavancin"]],
    ["KINERET (Injectable)", false, ["anakinra"]],
    ["KINEVAC (Injectable)", false, ["sincalide"]],
    ["KINRIX (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "poliovirus vaccine inactivated, type 1 (Mahoney)", "poliovirus vaccine inactivated, type 2 (MEF-1)", "poliovirus vaccine inactivated, type 3 (Saukett)", "tetanus toxoid vaccine, inactivated"]],
    ["KIONEX (Oral Liquid)", true, ["sodium polystyrene sulfonate"]],
    ["KIPROFEN (Oral Pill)", true, ["ketoprofen"]],
    ["KIRSTY (Injectable)", false, ["insulin aspart, human"]],
    ["KISQALI (Oral Pill)", true, ["ribociclib"]],
    ["KISQALI 200 MG DAILY DOSE CARTON (Pack)", true, ["ribociclib"]],
    ["KISQALI 400 MG DAILY DOSE CARTON (Pack)", true, ["ribociclib"]],
    ["KISQALI 600 MG DAILY DOSE CARTON (Pack)", true, ["ribociclib"]],
    ["KISQALI FEMARA CO-PACK 200 (Pack)", true, ["letrozole", "ribociclib"]],
    ["KISQALI FEMARA CO-PACK 400 (Pack)", true, ["letrozole", "ribociclib"]],
    ["KISQALI FEMARA CO-PACK 600 (Pack)", true, ["letrozole", "ribociclib"]],
    ["KISUNLA (Injectable)", false, ["donanemab"]],
    ["KITABIS (Inhalant)", false, ["tobramycin"]],
    ["KLARON (Topical)", false, ["sulfacetamide"]],
    ["KLISYRI (Topical)", false, ["tirbanibulin"]],
    ["KlonoPIN (Oral Pill)", true, ["clonazepam"]],
    ["KLOR-CON (Oral Solution Powder)", true, ["potassium chloride"]],
    ["KLOR-CON XR (Oral Pill)", true, ["potassium chloride"]],
    ["KLOR-CON/EF (Effervescent)", true, ["potassium bicarbonate"]],
    ["KLOXXADO (Nasal)", false, ["naloxone"]],
    ["KOATE (Injectable)", false, ["factor VIII"]],
    ["KODATEF (Oral Pill)", true, ["tafenoquine"]],
    ["KOGENATE (Injectable)", false, ["factor VIII"]],
    ["KOLDETS COUGH DROP (Oral Lozenge)", true, ["menthol"]],
    ["KOLORZ (Oral Foam)", true, ["sodium fluoride"]],
    ["KOLORZ (Oral Gel)", true, ["sodium fluoride"]],
    ["KOMBIGLYZE XR (Oral Pill)", true, ["metformin", "saxagliptin"]],
    ["KOMZIFTI (Oral Pill)", true, ["ziftomenib"]],
    ["KONDREMUL PLAIN (Oral Liquid)", true, ["mineral oil"]],
    ["KONSYL (Oral Suspension Powder)", true, ["psyllium"]],
    ["KONVOMEP (Oral Liquid)", true, ["omeprazole", "sodium bicarbonate"]],
    ["Korean ginseng root (Oral Pill)", true, ["Korean ginseng root"]],
    ["KORLYM (Oral Pill)", true, ["mifepristone"]],
    ["KORSUVA (Injectable)", false, ["difelikefalin"]],
    ["KOSELUGO (Oral Granules)", true, ["selumetinib"]],
    ["KOSELUGO (Oral Pill)", true, ["selumetinib"]],
    ["KOURZEQ (Oral Paste)", true, ["triamcinolone"]],
    ["KOVALTRY (Injectable)", false, ["factor VIII"]],
    ["KOVANAZE (Nasal)", false, ["oxymetazoline", "tetracaine"]],
    ["KRAZATI (Oral Pill)", true, ["adagrasib"]],
    ["KRESLADI (Injectable)", false, ["marnetegragene autotemcel"]],
    ["Krill oil (Oral Pill)", true, ["krill oil"]],
    ["KRINTAFEL (Oral Pill)", true, ["tafenoquine"]],
    ["KRISTALOSE (Oral Solution Powder)", true, ["lactulose"]],
    ["KRYSTEXXA (Injectable)", false, ["pegloticase"]],
    ["KURIC (Topical)", false, ["ketoconazole"]],
    ["KURVELO (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["KUVAN (Oral Pill)", true, ["sapropterin"]],
    ["KUVAN (Oral Solution Powder)", true, ["sapropterin"]],
    ["KYBELLA (Injectable)", false, ["deoxycholate"]],
    ["KYGEVVI (Oral Solution Powder)", true, ["doxecitine", "doxribtimine"]],
    ["KYLEENA (Intrauterine)", false, ["levonorgestrel"]],
    ["KYMBEE (Oral Liquid)", true, ["deflazacort"]],
    ["KYMBEE (Oral Pill)", true, ["deflazacort"]],
    ["KYMRIAH (Injectable)", false, ["tisagenlecleucel"]],
    ["KYPROLIS (Injectable)", false, ["carfilzomib"]],
    ["KYXATA (Injectable)", false, ["carboplatin"]],
    ["KYZATREX (Oral Pill)", true, ["testosterone"]],
    ["L-FORMULA (Oral Pill)", true, ["lysine"]],
    ["Labetalol (Injectable)", false, ["labetalol"]],
    ["Labetalol (Oral Pill)", true, ["labetalol"]],
    ["LAC-HYDRIN (Topical)", false, ["lactate"]],
    ["Lacosamide (Injectable)", false, ["lacosamide"]],
    ["Lacosamide (Oral Liquid)", true, ["lacosamide"]],
    ["Lacosamide (Oral Pill)", true, ["lacosamide"]],
    ["Lacosamide XR (Oral Pill)", true, ["lacosamide"]],
    ["LACRISERT (Implant)", false, ["hydroxypropylcellulose"]],
    ["LACTAID (Chewable)", true, ["lactase"]],
    ["LACTAID (Oral Pill)", true, ["lactase"]],
    ["Lactase (Chewable)", true, ["lactase"]],
    ["Lactase (Oral Pill)", true, ["lactase"]],
    ["Lactate (Topical)", false, ["lactate"]],
    ["Lactate/Urea (Topical)", false, ["lactate", "urea"]],
    ["LACTICARE (Topical)", false, ["lactate"]],
    ["Lacticaseibacillus rhamnosus (Chewable)", true, ["Lacticaseibacillus rhamnosus"]],
    ["Lacticaseibacillus rhamnosus (Oral Pill)", true, ["Lacticaseibacillus rhamnosus"]],
    ["Lacticaseibacillus rhamnosus (Oral Powder)", true, ["Lacticaseibacillus rhamnosus"]],
    ["LACTINOL (Topical)", false, ["lactate"]],
    ["Lactiplantibacillus plantarum (Oral Pill)", true, ["Lactiplantibacillus plantarum"]],
    ["Lactobacillus acidophilus (Oral Liquid)", true, ["Lactobacillus acidophilus"]],
    ["Lactobacillus acidophilus (Oral Pill)", true, ["Lactobacillus acidophilus"]],
    ["Lactobacillus acidophilus (Oral Wafer)", true, ["Lactobacillus acidophilus"]],
    ["Lactobacillus acidophilus/Lactobacillus delbrueckii subsp. bulgaricus (Oral Pill)", true, ["Lactobacillus acidophilus", "Lactobacillus delbrueckii subsp. bulgaricus"]],
    ["Lactobacillus acidophilus/Pectin (Oral Pill)", true, ["Lactobacillus acidophilus", "pectin"]],
    ["LACTOCAL (Oral Pill)", true, ["ascorbic acid", "calcium carbonate", "cholecalciferol", "copper sulfate", "ferrous fumarate", "folic acid", "magnesium oxide", "niacinamide", "potassium iodide", "pyridoxine", "riboflavin", "thiamine", "vitamin A", "vitamin B12", "vitamin E", "zinc sulfate"]],
    ["Lactulose (Oral Liquid)", true, ["lactulose"]],
    ["Lactulose (Oral Solution Powder)", true, ["lactulose"]],
    ["LAGEVRIO (Oral Pill)", true, ["molnupiravir"]],
    ["LAGICAM (Vaginal)", false, ["miconazole"]],
    ["LaMICtal (Oral Disintegrating)", true, ["lamotrigine"]],
    ["LaMICtal (Oral Pill)", true, ["lamotrigine"]],
    ["LaMICtal (Oral Suspension Tablet)", true, ["lamotrigine"]],
    ["LaMICtal BLUE (FOR PATIENTS TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LAMICTAL GREEN (FOR PATIENTS TAKING CARBAMAZEPINE, PHENYTOIN, PHENOBARBITAL, PRIMIDONE, OR RIFAMPIN AND NOT TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal ODT BLUE PATIENT TITRATION KIT (FOR PATIENTS TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal ODT GREEN TITRATION KIT (FOR PATIENTS TAKING ENZYME-INDUCING DRUGS AND NOT TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal ODT ORANGE PATIENT TITRATION KIT (FOR PATIENTS NOT TAKING ENZYME-INDUCING DRUGS OR VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal ORANGE (FOR PATIENTS NOT TAKING carBAMazepine, PHENYTOIN, PHENobarbital, PRIMIDONE, OR rifAMPin AND NOT TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal XR (Oral Pill)", true, ["lamotrigine"]],
    ["LaMICtal XR BLUE PATIENT TITRATION KIT (FOR PATIENTS TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal XR GREEN PATIENT TITRATION KIT (FOR PATIENTS TAKING carBAMazepine, PHENYTOIN, PHENobarbital, OR PRIMIDONE, AND NOT TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LaMICtal XR ORANGE PATIENT TITRATION KIT (FOR PATIENTS NOT TAKING carBAMazepine, PHENYTOIN, PHENobarbital, PRIMIDONE, OR VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["LamISIL (Topical)", false, ["terbinafine"]],
    ["LamISIL DEFENSE (Topical)", false, ["tolnaftate"]],
    ["lamiVUDine (Oral Liquid)", true, ["lamivudine"]],
    ["lamiVUDine (Oral Pill)", true, ["lamivudine"]],
    ["lamiVUDine/Tenofovir disoproxil (Oral Pill)", true, ["lamivudine", "tenofovir disoproxil"]],
    ["lamiVUDine/Zidovudine (Oral Pill)", true, ["lamivudine", "zidovudine"]],
    ["lamoTRIgine (Oral Disintegrating)", true, ["lamotrigine"]],
    ["lamoTRIgine (Oral Liquid)", true, ["lamotrigine"]],
    ["lamoTRIgine (Oral Pill)", true, ["lamotrigine"]],
    ["lamoTRIgine (Oral Suspension Tablet)", true, ["lamotrigine"]],
    ["lamoTRIgine (Pack)", true, ["lamotrigine"]],
    ["lamoTRIgine XR (Oral Pill)", true, ["lamotrigine"]],
    ["LAMPIT (Oral Pill)", true, ["nifurtimox"]],
    ["LAMPRENE (Oral Pill)", true, ["clofazimine"]],
    ["LAMZEDE (Injectable)", false, ["velmanase alfa"]],
    ["LANABIOTIC (Topical)", false, ["bacitracin", "neomycin", "polymyxin B", "pramoxine"]],
    ["LANACANE (Topical)", false, ["benzethonium", "benzocaine"]],
    ["Lanadelumab (Injectable)", false, ["lanadelumab"]],
    ["LANASHIELD (Topical)", false, ["lanolin"]],
    ["Landiolol (Injectable)", false, ["landiolol"]],
    ["LANGLARA (Injectable)", false, ["insulin glargine"]],
    ["Lanolin (Topical)", false, ["lanolin"]],
    ["Lanolin/Menthol/Petrolatum/Zinc oxide (Topical)", false, ["lanolin", "menthol", "petrolatum", "zinc oxide"]],
    ["Lanolin/Petrolatum (Topical)", false, ["lanolin", "petrolatum"]],
    ["Lanolin/Petrolatum/Zinc oxide (Topical)", false, ["lanolin", "petrolatum", "zinc oxide"]],
    ["LANOXIN (Injectable)", false, ["digoxin"]],
    ["LANOXIN (Oral Pill)", true, ["digoxin"]],
    ["Lanreotide (Injectable)", false, ["lanreotide"]],
    ["LANSINOH (Topical)", false, ["lanolin"]],
    ["Lansoprazole (Oral Disintegrating)", true, ["lansoprazole"]],
    ["Lansoprazole (Oral Pill)", true, ["lansoprazole"]],
    ["Lanthanum carbonate (Chewable)", true, ["lanthanum carbonate"]],
    ["Lanthanum carbonate (Oral Powder)", true, ["lanthanum carbonate"]],
    ["LANTIDRA (Injectable)", false, ["donislecel"]],
    ["LANTISEPTIC (Topical)", false, ["lanolin"]],
    ["LANTISEPTIC MULTI-PURPOSE (Topical)", false, ["calamine", "menthol", "zinc oxide"]],
    ["LANTUS (Injectable)", false, ["insulin glargine"]],
    ["Lapatinib (Oral Pill)", true, ["lapatinib"]],
    ["LARIN 1.5/30 (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["LARIN 1/20 (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["LARIN 24 FE 1/20 (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["LARIN FE 1.5/30 (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["LARIN FE 1/20 (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Laronidase (Injectable)", false, ["laronidase"]],
    ["Larotrectinib (Oral Liquid)", true, ["larotrectinib"]],
    ["Larotrectinib (Oral Pill)", true, ["larotrectinib"]],
    ["LASIX (Injectable)", false, ["furosemide"]],
    ["LASIX (Oral Pill)", true, ["furosemide"]],
    ["Lasmiditan (Oral Pill)", true, ["lasmiditan"]],
    ["LASOLEX (Topical)", false, ["miconazole"]],
    ["LASOLEX LIQUID (Topical)", false, ["clotrimazole"]],
    ["LASTACAFT (Ophthalmic)", false, ["alcaftadine"]],
    ["Latanoprost (Ophthalmic)", false, ["latanoprost"]],
    ["Latanoprost/Netarsudil (Ophthalmic)", false, ["latanoprost", "netarsudil"]],
    ["Latanoprostene bunod (Ophthalmic)", false, ["latanoprostene bunod"]],
    ["LATISSE (Topical)", false, ["bimatoprost"]],
    ["Latrodectus mactans antivenin (Injectable)", false, ["Latrodectus mactans antivenin"]],
    ["LATUDA (Oral Pill)", true, ["lurasidone"]],
    ["LAXACIN (Oral Pill)", true, ["docusate", "sennosides, USP"]],
    ["LAYOLIS FE 28 (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["LAZCLUZE (Oral Pill)", true, ["lazertinib"]],
    ["Lazertinib (Oral Pill)", true, ["lazertinib"]],
    ["Lebrikizumab (Injectable)", false, ["lebrikizumab"]],
    ["Lecanemab (Injectable)", false, ["lecanemab"]],
    ["Lecithin (Oral Liquid)", true, ["lecithin"]],
    ["Lecithin (Oral Pill)", true, ["lecithin"]],
    ["Ledipasvir/Sofosbuvir (Oral Pellet)", true, ["ledipasvir", "sofosbuvir"]],
    ["Ledipasvir/Sofosbuvir (Oral Pill)", true, ["ledipasvir", "sofosbuvir"]],
    ["LEENA 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Lefamulin (Injectable)", false, ["lefamulin"]],
    ["Lefamulin (Oral Pill)", true, ["lefamulin"]],
    ["Lefamulin (Pack)", true, ["lefamulin"]],
    ["Leflunomide (Oral Pill)", true, ["leflunomide"]],
    ["LEGATRIN PM (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["Lemborexant (Oral Pill)", true, ["lemborexant"]],
    ["LEMTRADA (Injectable)", false, ["alemtuzumab"]],
    ["Lenacapavir (Injectable)", false, ["lenacapavir"]],
    ["Lenacapavir (Oral Pill)", true, ["lenacapavir"]],
    ["Lenacapavir (Pack)", false, ["lenacapavir"]],
    ["Lenalidomide (Oral Pill)", true, ["lenalidomide"]],
    ["Leniolisib (Oral Pill)", true, ["leniolisib"]],
    ["LENMELDY (Injectable)", false, ["atidarsagene autotemcel"]],
    ["LENTOCILIN (Injectable)", false, ["penicillin G benzathine"]],
    ["Lenvatinib (Oral Pill)", true, ["lenvatinib"]],
    ["Lenvatinib (Pack)", true, ["lenvatinib"]],
    ["LENVIMA (Oral Pill)", true, ["lenvatinib"]],
    ["LENVIMA 10 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 12 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 14 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 18 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 20 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 24 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 4 (Pack)", true, ["lenvatinib"]],
    ["LENVIMA 8 (Pack)", true, ["lenvatinib"]],
    ["LENZAGEL (Topical)", false, ["lidocaine", "menthol"]],
    ["LENZAPATCH (Topical)", false, ["lidocaine", "menthol"]],
    ["LEQEMBI (Injectable)", false, ["lecanemab"]],
    ["LEQSELVI (Oral Pill)", true, ["deuruxolitinib"]],
    ["LEQVIO (Injectable)", false, ["inclisiran"]],
    ["LEROCHOL (Injectable)", false, ["lerodalcibep"]],
    ["Lerodalcibep (Injectable)", false, ["lerodalcibep"]],
    ["LESCOL (Oral Pill)", true, ["fluvastatin"]],
    ["LESCOL XR (Oral Pill)", true, ["fluvastatin"]],
    ["LESSINA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["LETAIRIS (Oral Pill)", true, ["ambrisentan"]],
    ["Letermovir (Injectable)", false, ["letermovir"]],
    ["Letermovir (Oral Pellet)", true, ["letermovir"]],
    ["Letermovir (Oral Pill)", true, ["letermovir"]],
    ["Letrozole (Oral Pill)", true, ["letrozole"]],
    ["Letrozole/Ribociclib (Pack)", true, ["letrozole", "ribociclib"]],
    ["LETYBO (Injectable)", false, ["botulinum toxin type A"]],
    ["Leucovorin (Injectable)", false, ["leucovorin"]],
    ["Leucovorin (Oral Pill)", true, ["leucovorin"]],
    ["LEUKERAN (Oral Pill)", true, ["chlorambucil"]],
    ["LEUKINE (Injectable)", false, ["sargramostim"]],
    ["Leuprolide (Injectable)", false, ["leuprolide"]],
    ["Levacetylleucine (Oral Suspension Granules)", true, ["levacetylleucine"]],
    ["Levalbuterol (Inhalant)", false, ["levalbuterol"]],
    ["Levamlodipine (Oral Pill)", true, ["levamlodipine"]],
    ["LEVBID XR (Oral Pill)", true, ["hyoscyamine"]],
    ["LEVEMIR (Injectable)", false, ["insulin detemir"]],
    ["levETIRAcetam (Injectable)", false, ["levetiracetam"]],
    ["levETIRAcetam (Oral Liquid)", true, ["levetiracetam"]],
    ["levETIRAcetam (Oral Pill)", true, ["levetiracetam"]],
    ["levETIRAcetam (Oral Suspension Tablet)", true, ["levetiracetam"]],
    ["levETIRAcetam XR (Oral Pill)", true, ["levetiracetam"]],
    ["LEVITRA (Oral Pill)", true, ["vardenafil"]],
    ["LEVO-T (Oral Pill)", true, ["levothyroxine"]],
    ["Levobunolol (Ophthalmic)", false, ["levobunolol"]],
    ["levOCARNitine (Injectable)", false, ["levocarnitine"]],
    ["levOCARNitine (Oral Liquid)", true, ["levocarnitine"]],
    ["levOCARNitine (Oral Pill)", true, ["levocarnitine"]],
    ["levOCARNitine/Ubidecarenone (Oral Pill)", true, ["levocarnitine", "ubidecarenone"]],
    ["levOCARNitine/Ubidecarenone/Vitamin E (Oral Pill)", true, ["levocarnitine", "ubidecarenone", "vitamin E"]],
    ["Levocetirizine (Oral Liquid)", true, ["levocetirizine"]],
    ["Levocetirizine (Oral Pill)", true, ["levocetirizine"]],
    ["Levodopa (Inhalant)", false, ["levodopa"]],
    ["levoFLOXacin (Injectable)", false, ["levofloxacin"]],
    ["levoFLOXacin (Ophthalmic)", false, ["levofloxacin"]],
    ["levoFLOXacin (Oral Liquid)", true, ["levofloxacin"]],
    ["levoFLOXacin (Oral Pill)", true, ["levofloxacin"]],
    ["LEVOleucovorin (Injectable)", false, ["levoleucovorin"]],
    ["Levomefolate (Oral Pill)", true, ["levomefolate"]],
    ["Levomilnacipran (Pack)", true, ["levomilnacipran"]],
    ["Levomilnacipran XR (Oral Pill)", true, ["levomilnacipran"]],
    ["LEVONEST 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Levonordefrin/Mepivacaine (Injectable)", false, ["levonordefrin", "mepivacaine"]],
    ["Levonorgestrel (Intrauterine)", false, ["levonorgestrel"]],
    ["Levonorgestrel (Oral Pill)", true, ["levonorgestrel"]],
    ["Levonorgestrel (Pack)", true, ["levonorgestrel"]],
    ["LEVOPHED (Injectable)", false, ["norepinephrine"]],
    ["LEVORA 0.15/30 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Levorphanol (Oral Pill)", true, ["levorphanol"]],
    ["Levothyroxine (Injectable)", false, ["levothyroxine"]],
    ["Levothyroxine (Oral Liquid)", true, ["levothyroxine"]],
    ["Levothyroxine (Oral Pill)", true, ["levothyroxine"]],
    ["Levothyroxine/Liothyronine (Oral Pill)", true, ["levothyroxine", "liothyronine"]],
    ["LEVOXYL (Oral Pill)", true, ["levothyroxine"]],
    ["LEVSIN (Oral Pill)", true, ["hyoscyamine"]],
    ["LEVSIN (Sublingual)", false, ["hyoscyamine"]],
    ["LEVULAN (Topical)", false, ["aminolevulinate"]],
    ["LEXAPRO (Oral Pill)", true, ["escitalopram"]],
    ["LEXETTE (Topical)", false, ["halobetasol"]],
    ["LEXINAL (Oral Pill)", true, ["biotin"]],
    ["LEXIVA (Oral Liquid)", true, ["fosamprenavir"]],
    ["LEXIVA (Oral Pill)", true, ["fosamprenavir"]],
    ["LIALDA (Oral Pill)", true, ["mesalamine"]],
    ["LIBERVANT (Buccal)", false, ["diazepam"]],
    ["LIBRAX (Oral Pill)", true, ["chlordiazepoxide", "clidinium"]],
    ["LIBTAYO (Injectable)", false, ["cemiplimab"]],
    ["LICART (Topical)", false, ["diclofenac"]],
    ["LIDO KING (Topical)", false, ["lidocaine"]],
    ["Lidocaine (Injectable)", false, ["lidocaine"]],
    ["Lidocaine (Mucosal)", false, ["lidocaine"]],
    ["Lidocaine (Ophthalmic)", false, ["lidocaine"]],
    ["Lidocaine (Otic)", false, ["lidocaine"]],
    ["Lidocaine (Rectal)", false, ["lidocaine"]],
    ["Lidocaine (Topical)", false, ["lidocaine"]],
    ["Lidocaine/Menthol (Topical)", false, ["lidocaine", "menthol"]],
    ["Lidocaine/Menthol/Methyl salicylate (Topical)", false, ["lidocaine", "menthol", "methyl salicylate"]],
    ["Lidocaine/Phenylephrine (Rectal)", false, ["lidocaine", "phenylephrine"]],
    ["Lidocaine/Phenylephrine (Topical)", false, ["lidocaine", "phenylephrine"]],
    ["Lidocaine/Prilocaine (Mucosal)", false, ["lidocaine", "prilocaine"]],
    ["Lidocaine/Prilocaine (Topical)", false, ["lidocaine", "prilocaine"]],
    ["Lidocaine/Tetracaine (Topical)", false, ["lidocaine", "tetracaine"]],
    ["LIDOCAN (Topical)", false, ["lidocaine"]],
    ["LIDOCREAM (Topical)", false, ["lidocaine"]],
    ["LIDODERM (Topical)", false, ["lidocaine"]],
    ["LIDOGUARD (Topical)", false, ["lidocaine"]],
    ["LIDOGUARD PAIN RELIEF (Topical)", false, ["lidocaine"]],
    ["LIDOPATCH (Topical)", false, ["lidocaine", "menthol"]],
    ["LIDOPRO (Topical)", false, ["capsaicin", "lidocaine", "menthol", "methyl salicylate"]],
    ["LIDOPRO PAIN RELIEVING PATCH (Topical)", false, ["lidocaine", "menthol"]],
    ["LIDOPRO PATCH (Topical)", false, ["lidocaine", "menthol", "methyl salicylate"]],
    ["LIDOTRAL (Topical)", false, ["lidocaine"]],
    ["LIDOTRAN (Topical)", false, ["lidocaine"]],
    ["LIDOZEN (Topical)", false, ["lidocaine", "menthol"]],
    ["Lifileucel (Injectable)", false, ["lifileucel"]],
    ["Lifitegrast (Ophthalmic)", false, ["lifitegrast"]],
    ["LIFYORLI (Oral Pill)", true, ["relacorilant"]],
    ["LIFYORLI 125 MG, 1-DOSE SUPPLY (Pack)", true, ["relacorilant"]],
    ["LIFYORLI 125 MG, 3-DOSE SUPPLY (Pack)", true, ["relacorilant"]],
    ["LIFYORLI 125 MG, 9-DOSE SUPPLY (Pack)", true, ["relacorilant"]],
    ["LIFYORLI 150 MG, 1-DOSE SUPPLY (Pack)", true, ["relacorilant"]],
    ["LIFYORLI 150 MG, 3-DOSE SUPPLY (Pack)", true, ["relacorilant"]],
    ["LIFYORLI 150 MG, 9-DOSE SUPPLY (Pack)", true, ["relacorilant"]],
    ["LIGNOSPAN (Injectable)", false, ["epinephrine", "lidocaine"]],
    ["LIKMEZ (Oral Liquid)", true, ["metronidazole"]],
    ["LILETTA (Intrauterine)", false, ["levonorgestrel"]],
    ["Limosilactobacillus reuteri (Chewable)", true, ["Limosilactobacillus reuteri"]],
    ["Linaclotide (Oral Pill)", true, ["linaclotide"]],
    ["Linagliptin (Oral Pill)", true, ["linagliptin"]],
    ["Linagliptin/metFORMIN (Oral Pill)", true, ["linagliptin", "metformin"]],
    ["Linagliptin/metFORMIN XR (Oral Pill)", true, ["linagliptin", "metformin"]],
    ["LINCOCIN (Injectable)", false, ["lincomycin"]],
    ["Lincomycin (Injectable)", false, ["lincomycin"]],
    ["Lindane (Shampoo)", false, ["lindane"]],
    ["Linerixibat (Oral Pill)", true, ["linerixibat"]],
    ["Linezolid (Injectable)", false, ["linezolid"]],
    ["Linezolid (Oral Liquid)", true, ["linezolid"]],
    ["Linezolid (Oral Pill)", true, ["linezolid"]],
    ["Linoleate/Omega-3 acid ethyl esters (USP)/Vitamin E (Oral Pill)", true, ["linoleate", "omega-3 acid ethyl esters (USP)", "vitamin E"]],
    ["Linoleic acids, conjugated (Oral Pill)", true, ["linoleic acids, conjugated"]],
    ["Linseed oil (Oral Pill)", true, ["linseed oil"]],
    ["Linvoseltamab (Injectable)", false, ["linvoseltamab"]],
    ["LINZESS (Oral Pill)", true, ["linaclotide"]],
    ["LIOMNY (Oral Pill)", true, ["liothyronine"]],
    ["LIORESAL (Injectable)", false, ["baclofen"]],
    ["Liothyronine (Injectable)", false, ["liothyronine"]],
    ["Liothyronine (Oral Pill)", true, ["liothyronine"]],
    ["LIPFENDRA (Oral Pill)", true, ["enlicitide"]],
    ["LIPITOR (Oral Pill)", true, ["atorvastatin"]],
    ["LIPOCAINE (Topical)", false, ["lidocaine"]],
    ["LIPOFEN (Oral Pill)", true, ["fenofibrate"]],
    ["LIQREV (Oral Liquid)", true, ["sildenafil"]],
    ["LIQSORB (Oral Liquid)", true, ["ubidecarenone"]],
    ["LIQUIBID (Oral Pill)", true, ["guaifenesin"]],
    ["LIQUIMAT (Topical)", false, ["sulfur"]],
    ["Liraglutide (Injectable)", false, ["liraglutide"]],
    ["Lisdexamfetamine (Chewable)", true, ["lisdexamfetamine"]],
    ["Lisdexamfetamine (Oral Liquid)", true, ["lisdexamfetamine"]],
    ["Lisdexamfetamine (Oral Pill)", true, ["lisdexamfetamine"]],
    ["Lisinopril (Oral Liquid)", true, ["lisinopril"]],
    ["Lisinopril (Oral Pill)", true, ["lisinopril"]],
    ["Lisocabtagene maraleucel (Injectable)", false, ["lisocabtagene maraleucel"]],
    ["LISRAYA (Oral Pill)", true, ["brepocitinib"]],
    ["LISTERINE (Mouthwash)", false, ["sodium fluoride"]],
    ["LISTERINE ANTISEPTIC (Mouthwash)", false, ["eucalyptol", "menthol", "methyl salicylate", "thymol"]],
    ["LISTERINE ULTRACLEAN (Mouthwash)", false, ["eucalyptol", "menthol", "methyl salicylate", "thymol"]],
    ["LITFULO (Oral Pill)", true, ["ritlecitinib"]],
    ["Lithium (Oral Pill)", true, ["lithium"]],
    ["Lithium carbonate (Oral Pill)", true, ["lithium carbonate"]],
    ["Lithium carbonate XR (Oral Pill)", true, ["lithium carbonate"]],
    ["Lithium citrate (Oral Liquid)", true, ["lithium citrate"]],
    ["LITHOBID XR (Oral Pill)", true, ["lithium carbonate"]],
    ["LITHOSTAT (Oral Pill)", true, ["acetohydroxamic acid"]],
    ["LITTLE NOSES (Nasal)", false, ["sodium chloride"]],
    ["LITTLE NOSES DECONGESTANT (Nasal)", false, ["phenylephrine"]],
    ["LITTLE TUMMYS (Oral Liquid)", true, ["simethicone"]],
    ["LIVALO (Oral Pill)", true, ["pitavastatin"]],
    ["LIVDELZI (Oral Pill)", true, ["seladelpar"]],
    ["Liver extract (Injectable)", false, ["liver extract"]],
    ["LIVMARLI (Oral Liquid)", true, ["maralixibat"]],
    ["LIVMARLI (Oral Pill)", true, ["maralixibat"]],
    ["LIVTENCITY (Oral Pill)", true, ["maribavir"]],
    ["LMX (Rectal)", false, ["lidocaine"]],
    ["LMX (Topical)", false, ["lidocaine"]],
    ["LO LOESTRIN FE 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["LO SIMPESSE 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["LO-ZUMANDIMINE 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["LOARGYS (Injectable)", false, ["pegzilarginase"]],
    ["LOCOID (Topical)", false, ["hydrocortisone"]],
    ["LODINE (Oral Pill)", true, ["etodolac"]],
    ["LODOCO (Oral Pill)", true, ["colchicine"]],
    ["LODOSYN (Oral Pill)", true, ["carbidopa"]],
    ["Lodoxamide (Ophthalmic)", false, ["lodoxamide"]],
    ["LOESTRIN 1.5/30 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["LOESTRIN 1/20 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["LOESTRIN FE 1.5/30 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["LOESTRIN FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["LOFENA (Oral Pill)", true, ["diclofenac"]],
    ["Lofexidine (Oral Pill)", true, ["lofexidine"]],
    ["LOJAIMIESS 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["LOKELMA (Oral Suspension Powder)", true, ["sodium zirconium cyclosilicate"]],
    ["LOLLICAINE (Oral Gel)", true, ["benzocaine"]],
    ["LOMAIRA (Oral Pill)", true, ["phentermine"]],
    ["LOMEDIA 24 FE (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Lomitapide (Oral Pill)", true, ["lomitapide"]],
    ["LOMOTIL (Oral Pill)", true, ["atropine", "diphenoxylate"]],
    ["Lomustine (Oral Pill)", true, ["lomustine"]],
    ["Lonafarnib (Oral Pill)", true, ["lonafarnib"]],
    ["Lonapegsomatropin (Injectable)", false, ["lonapegsomatropin"]],
    ["Loncastuximab tesirine (Injectable)", false, ["loncastuximab tesirine"]],
    ["LONHALA (Inhalant)", false, ["glycopyrronium"]],
    ["LONSURF (Oral Pill)", true, ["tipiracil", "trifluridine"]],
    ["Loperamide (Oral Liquid)", true, ["loperamide"]],
    ["Loperamide (Oral Pill)", true, ["loperamide"]],
    ["Loperamide/Simethicone (Chewable)", true, ["loperamide", "simethicone"]],
    ["Loperamide/Simethicone (Oral Pill)", true, ["loperamide", "simethicone"]],
    ["LOPID (Oral Pill)", true, ["gemfibrozil"]],
    ["Lopinavir/Ritonavir (Oral Liquid)", true, ["lopinavir", "ritonavir"]],
    ["Lopinavir/Ritonavir (Oral Pill)", true, ["lopinavir", "ritonavir"]],
    ["LOPREEZA 0.5/0.1 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["LOPREEZA 1/0.5 28 DAY (Pack)", true, ["estradiol", "norethindrone"]],
    ["LOPRESSOR (Oral Liquid)", true, ["metoprolol"]],
    ["LOPRESSOR (Oral Pill)", true, ["metoprolol"]],
    ["LOPRESSOR HCT (Oral Pill)", true, ["hydrochlorothiazide", "metoprolol"]],
    ["LOPROX (Topical)", false, ["ciclopirox"]],
    ["LOQTORZI (Injectable)", false, ["toripalimab"]],
    ["LORADAMED (Oral Pill)", true, ["loratadine"]],
    ["Loratadine (Chewable)", true, ["loratadine"]],
    ["Loratadine (Oral Disintegrating)", true, ["loratadine"]],
    ["Loratadine (Oral Liquid)", true, ["loratadine"]],
    ["Loratadine (Oral Pill)", true, ["loratadine"]],
    ["Loratadine/Pseudoephedrine XR (Oral Pill)", true, ["loratadine", "pseudoephedrine"]],
    ["LORazepam (Injectable)", false, ["lorazepam"]],
    ["LORazepam (Oral Liquid)", true, ["lorazepam"]],
    ["LORazepam (Oral Pill)", true, ["lorazepam"]],
    ["LORazepam XR (Oral Pill)", true, ["lorazepam"]],
    ["LORBRENA (Oral Pill)", true, ["lorlatinib"]],
    ["LOREEV XR (Oral Pill)", true, ["lorazepam"]],
    ["Lorlatinib (Oral Pill)", true, ["lorlatinib"]],
    ["LORTUSS EX (Oral Liquid)", true, ["codeine", "guaifenesin", "pseudoephedrine"]],
    ["LORYNA 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["LORZONE (Oral Pill)", true, ["chlorzoxazone"]],
    ["Losartan (Oral Liquid)", true, ["losartan"]],
    ["Losartan (Oral Pill)", true, ["losartan"]],
    ["LOTEMAX (Ophthalmic)", false, ["loteprednol etabonate"]],
    ["LOTENSIN (Oral Pill)", true, ["benazepril"]],
    ["LOTENSIN HCT (Oral Pill)", true, ["benazepril", "hydrochlorothiazide"]],
    ["Loteprednol etabonate (Ophthalmic)", false, ["loteprednol etabonate"]],
    ["Loteprednol etabonate/Tobramycin (Ophthalmic)", false, ["loteprednol etabonate", "tobramycin"]],
    ["Lotilaner (Ophthalmic)", false, ["lotilaner"]],
    ["LOTREL (Oral Pill)", true, ["amlodipine", "benazepril"]],
    ["LOTRIMIN (Topical)", false, ["clotrimazole"]],
    ["LOTRONEX (Oral Pill)", true, ["alosetron"]],
    ["Lovastatin (Oral Pill)", true, ["lovastatin"]],
    ["Lovastatin XR (Oral Pill)", true, ["lovastatin"]],
    ["LOVAZA (Oral Pill)", true, ["omega-3 acid ethyl esters (USP)"]],
    ["LOVENOX (Injectable)", false, ["enoxaparin"]],
    ["Lovotibeglogene autotemcel (Injectable)", false, ["lovotibeglogene autotemcel"]],
    ["LOW-OGESTREL 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestrel"]],
    ["Loxapine (Inhalant)", false, ["loxapine"]],
    ["Loxapine (Oral Pill)", true, ["loxapine"]],
    ["Lubiprostone (Oral Pill)", true, ["lubiprostone"]],
    ["LUBRIFRESH P.M. (Ophthalmic)", false, ["mineral oil", "petrolatum"]],
    ["LUCEMYRA (Oral Pill)", true, ["lofexidine"]],
    ["LUCENTIS (Injectable)", false, ["ranibizumab"]],
    ["LUDEN'S (Oral Lozenge)", true, ["menthol"]],
    ["LUDEN'S DROPS (Oral Lozenge)", true, ["pectin"]],
    ["LUDEN'S DUAL RELIEF (Oral Lozenge)", true, ["menthol", "pectin"]],
    ["LUDENT (Chewable)", true, ["sodium fluoride"]],
    ["LUIZZA 1.5/30 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["LUIZZA 1/20 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Luliconazole (Topical)", false, ["luliconazole"]],
    ["LUMAKRAS (Oral Pill)", true, ["sotorasib"]],
    ["Lumasiran (Injectable)", false, ["lumasiran"]],
    ["Lumateperone (Oral Pill)", true, ["lumateperone"]],
    ["LUMICAIN (Topical)", false, ["aluminum chloride"]],
    ["LUMIFY (Ophthalmic)", false, ["brimonidine"]],
    ["LUMIGAN (Ophthalmic)", false, ["bimatoprost"]],
    ["LUMIZYME (Injectable)", false, ["alglucosidase alfa"]],
    ["LUMOXITI (Injectable)", false, ["moxetumomab pasudotox"]],
    ["LUMRYZ (Oral Suspension Granules)", true, ["oxybate"]],
    ["LUMRYZ 28-DAY STARTER PACK (Pack)", false, ["oxybate"]],
    ["LUMVOA (Injectable)", false, ["veligrotug"]],
    ["LUNESTA (Oral Pill)", true, ["eszopiclone"]],
    ["Lunsotogene parvec (Injectable)", false, ["lunsotogene parvec"]],
    ["LUNSUMIO (Injectable)", false, ["mosunetuzumab"]],
    ["LUPKYNIS (Oral Pill)", true, ["voclosporin"]],
    ["LUPRON (Injectable)", false, ["leuprolide"]],
    ["Lurasidone (Oral Pill)", true, ["lurasidone"]],
    ["Lurbinectedin (Injectable)", false, ["lurbinectedin"]],
    ["LURBIPR (Oral Pill)", true, ["flurbiprofen"]],
    ["LURBIRO (Oral Pill)", true, ["flurbiprofen"]],
    ["Luspatercept (Injectable)", false, ["luspatercept"]],
    ["Lusutrombopag (Oral Pill)", true, ["lusutrombopag"]],
    ["LUTATHERA (Injectable)", false, ["dotatate"]],
    ["Lutein (Chewable)", true, ["lutein"]],
    ["Lutein (Oral Pill)", true, ["lutein"]],
    ["Lutein/Omega-3 acid ethyl esters (USP)/Zeaxanthin (Oral Pill)", true, ["lutein", "omega-3 acid ethyl esters (USP)", "zeaxanthin"]],
    ["Lutein/Zeaxanthin (Chewable)", true, ["lutein", "zeaxanthin"]],
    ["Lutein/Zeaxanthin (Oral Pill)", true, ["lutein", "zeaxanthin"]],
    ["LUTERA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["LUTRATE (Injectable)", false, ["leuprolide"]],
    ["LUXTURNA (Injectable)", false, ["voretigene neparvovec"]],
    ["LUZU (Topical)", false, ["luliconazole"]],
    ["LYBALVI (Oral Pill)", true, ["olanzapine", "samidorphan"]],
    ["Lycopene (Oral Pill)", true, ["lycopene"]],
    ["LYDEXA (Topical)", false, ["lidocaine"]],
    ["LYFGENIA (Injectable)", false, ["lovotibeglogene autotemcel"]],
    ["LYLEQ 28 DAY (Pack)", true, ["norethindrone"]],
    ["LYLLANA (Transdermal)", false, ["estradiol"]],
    ["LYMEPAK (Pack)", true, ["doxycycline"]],
    ["LYMPHIR (Injectable)", false, ["denileukin diftitox"]],
    ["Lymphocyte immune globulin, anti-thymocyte globulin (Injectable)", false, ["lymphocyte immune globulin, anti-thymocyte globulin"]],
    ["LYNAVOY (Oral Pill)", true, ["linerixibat"]],
    ["LYNKUET (Oral Pill)", true, ["elinzanetant"]],
    ["LYNOZYFIC (Injectable)", false, ["linvoseltamab"]],
    ["LYNPARZA (Oral Pill)", true, ["olaparib"]],
    ["LYRICA (Oral Liquid)", true, ["pregabalin"]],
    ["LYRICA (Oral Pill)", true, ["pregabalin"]],
    ["LYRICA XR (Oral Pill)", true, ["pregabalin"]],
    ["Lysine (Oral Pill)", true, ["lysine"]],
    ["LYSINE PLUS (Topical)", false, ["menthol"]],
    ["Lysine/Proline (Oral Pill)", true, ["lysine", "proline"]],
    ["LYSODREN (Oral Pill)", true, ["mitotane"]],
    ["LYSTEDA (Oral Pill)", true, ["tranexamic acid"]],
    ["LYTENAVA (Injectable)", false, ["bevacizumab"]],
    ["LYTGOBI (Oral Pill)", true, ["futibatinib"]],
    ["LYTGOBI 12 MG DAILY DOSE (Pack)", true, ["futibatinib"]],
    ["LYTGOBI 16 MG DAILY DOSE (Pack)", true, ["futibatinib"]],
    ["LYTGOBI 16 MG DAILY DOSE - 16 MG (7) (Pack)", true, ["futibatinib"]],
    ["LYTGOBI 20 MG DAILY DOSE (Pack)", true, ["futibatinib"]],
    ["LYTGOBI 20 MG DAILY DOSE - 4 MG (7), 16 MG (7) (Pack)", true, ["futibatinib"]],
    ["LYUMJEV (Injectable)", false, ["insulin lispro"]],
    ["LYVISPAH (Oral Granules)", true, ["baclofen"]],
    ["LYZA (Pack)", true, ["norethindrone"]],
    ["M-CLEAR WC (Oral Pill)", true, ["codeine", "guaifenesin"]],
    ["M-END MAX D (Oral Liquid)", true, ["codeine", "dexbrompheniramine", "pseudoephedrine"]],
    ["M-END PE (Oral Liquid)", true, ["brompheniramine", "codeine", "phenylephrine"]],
    ["M-M-R II (Injectable)", false, ["measles virus vaccine live, Enders' attenuated Edmonston strain", "mumps virus vaccine live, Jeryl Lynn strain", "rubella virus vaccine live (Wistar RA 27-3 strain)"]],
    ["MAALOX MAX (Oral Liquid)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["MAALOX MAX QUICK DISSOLVE (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["MAALOX PLUS (Oral Liquid)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["Macitentan (Oral Pill)", true, ["macitentan"]],
    ["Macitentan/Tadalafil (Oral Pill)", true, ["macitentan", "tadalafil"]],
    ["MACROBID (Oral Pill)", true, ["nitrofurantoin"]],
    ["MACRODANTIN (Oral Pill)", true, ["nitrofurantoin"]],
    ["MACUVITE WITH LUTEIN (Oral Pill)", true, ["ascorbic acid", "beta carotene", "copper sulfate", "lutein", "selenite", "vitamin E", "zinc oxide"]],
    ["Mafenide (Topical)", false, ["mafenide"]],
    ["MAG 64 (Oral Pill)", true, ["magnesium chloride"]],
    ["MAG-G (Oral Pill)", true, ["magnesium gluconate"]],
    ["MAG-OX 400 (Oral Pill)", true, ["magnesium oxide"]],
    ["MAG-TAB XR (Oral Pill)", true, ["magnesium lactate"]],
    ["Magaldrate/Simethicone (Oral Liquid)", true, ["magaldrate", "simethicone"]],
    ["MAGINEX (Oral Pill)", true, ["magnesium aspartate"]],
    ["MAGNEBIND (Oral Pill)", true, ["calcium carbonate", "magnesium carbonate"]],
    ["Magnesium amino acid chelate (Oral Pill)", true, ["magnesium amino acid chelate"]],
    ["Magnesium aspartate (Oral Pill)", true, ["magnesium aspartate"]],
    ["Magnesium aspartate/Potassium aspartate (Oral Pill)", true, ["magnesium aspartate", "potassium aspartate"]],
    ["Magnesium carbonate (Oral Liquid)", true, ["magnesium carbonate"]],
    ["Magnesium chloride (Injectable)", false, ["magnesium chloride"]],
    ["Magnesium chloride (Oral Pill)", true, ["magnesium chloride"]],
    ["Magnesium chloride/Potassium chloride/Sodium acetate/Sodium chloride/Sodium gluconate (Injectable)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["Magnesium chloride/Potassium chloride/Sodium acetate/Sodium chloride/Sodium gluconate (Irrigation)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["Magnesium citrate (Chewable)", true, ["magnesium citrate"]],
    ["Magnesium citrate (Oral Liquid)", true, ["magnesium citrate"]],
    ["Magnesium citrate (Oral Pill)", true, ["magnesium citrate"]],
    ["Magnesium citrate/Magnesium oxide/Potassium citrate/Pyridoxine XR (Oral Pill)", true, ["magnesium citrate", "magnesium oxide", "potassium citrate", "pyridoxine"]],
    ["Magnesium citrate/Potassium citrate (Oral Pill)", true, ["magnesium citrate", "potassium citrate"]],
    ["Magnesium gluconate (Oral Pill)", true, ["magnesium gluconate"]],
    ["Magnesium glycinate (Oral Pill)", true, ["magnesium glycinate"]],
    ["Magnesium hydroxide (Chewable)", true, ["magnesium hydroxide"]],
    ["Magnesium hydroxide (Oral Liquid)", true, ["magnesium hydroxide"]],
    ["Magnesium hydroxide/Malic acid (Oral Pill)", true, ["magnesium hydroxide", "malic acid"]],
    ["Magnesium lactate XR (Oral Pill)", true, ["magnesium lactate"]],
    ["Magnesium oxide (Oral Pill)", true, ["magnesium oxide"]],
    ["Magnesium oxide/Pyridoxine (Oral Pill)", true, ["magnesium oxide", "pyridoxine"]],
    ["Magnesium salicylate (Oral Pill)", true, ["magnesium salicylate"]],
    ["Magnesium salicylate/Phenyltoloxamine (Oral Pill)", true, ["magnesium salicylate", "phenyltoloxamine"]],
    ["Magnesium sulfate (Injectable)", false, ["magnesium sulfate"]],
    ["Magnesium sulfate (Oral Pill)", true, ["magnesium sulfate"]],
    ["Magnesium sulfate (Oral Solution Granules)", true, ["magnesium sulfate"]],
    ["Magnesium sulfate/Polyethylene glycol 3350/Potassium chloride/Sodium chloride/Sodium sulfate (Pack)", false, ["magnesium sulfate", "polyethylene glycol 3350", "potassium chloride", "sodium chloride", "sodium sulfate"]],
    ["Magnesium sulfate/Potassium chloride/Sodium sulfate (Oral Pill)", true, ["magnesium sulfate", "potassium chloride", "sodium sulfate"]],
    ["Magnesium sulfate/Potassium sulfate/Sodium sulfate (Oral Liquid)", true, ["magnesium sulfate", "potassium sulfate", "sodium sulfate"]],
    ["Magnesium sulfate/Potassium sulfate/Sodium sulfate (Pack)", false, ["magnesium sulfate", "potassium sulfate", "sodium sulfate"]],
    ["Magnesium, chelated (Oral Pill)", true, ["magnesium, chelated"]],
    ["MAGONATE REFORMULATED MAY 2022 (Oral Liquid)", true, ["magnesium carbonate"]],
    ["MAGTRATE (Oral Pill)", true, ["magnesium gluconate"]],
    ["MALARONE (Oral Pill)", true, ["atovaquone", "proguanil"]],
    ["Malathion (Topical)", false, ["malathion"]],
    ["Manganese chloride (Injectable)", false, ["manganese chloride"]],
    ["Manganese gluconate (Oral Pill)", true, ["manganese gluconate"]],
    ["Mannitol (Inhalant)", false, ["mannitol"]],
    ["Mannitol (Injectable)", false, ["mannitol"]],
    ["Mannitol/Sorbitol (Irrigation)", false, ["mannitol", "sorbitol"]],
    ["Mannose (Chewable)", true, ["mannose"]],
    ["Mannose (Oral Pill)", true, ["mannose"]],
    ["MAPAP (Chewable)", true, ["acetaminophen"]],
    ["MAPAP (Oral Liquid)", true, ["acetaminophen"]],
    ["MAPAP (Oral Pill)", true, ["acetaminophen"]],
    ["MAPAP XR (Oral Pill)", true, ["acetaminophen"]],
    ["MAR-COF CG (Oral Liquid)", true, ["codeine", "guaifenesin"]],
    ["Maralixibat (Oral Liquid)", true, ["maralixibat"]],
    ["Maralixibat (Oral Pill)", true, ["maralixibat"]],
    ["Maraviroc (Oral Liquid)", true, ["maraviroc"]],
    ["Maraviroc (Oral Pill)", true, ["maraviroc"]],
    ["MARCAINE (Injectable)", false, ["bupivacaine"]],
    ["MARCAINE WITH EPINEPHrine (Injectable)", false, ["bupivacaine", "epinephrine"]],
    ["MARGENZA (Injectable)", false, ["margetuximab"]],
    ["Margetuximab (Injectable)", false, ["margetuximab"]],
    ["Maribavir (Oral Pill)", true, ["maribavir"]],
    ["MARINOL (Oral Pill)", true, ["dronabinol"]],
    ["MARLISSA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Marnetegragene autotemcel (Injectable)", false, ["marnetegragene autotemcel"]],
    ["MARPLAN (Oral Pill)", true, ["isocarboxazid"]],
    ["MARQIBO (Injectable)", false, ["vincristine"]],
    ["Marstacimab (Injectable)", false, ["marstacimab"]],
    ["MARTEN-TAB (Oral Pill)", true, ["acetaminophen", "butalbital"]],
    ["MATULANE (Oral Pill)", true, ["procarbazine"]],
    ["MATZIM XR (Oral Pill)", true, ["diltiazem"]],
    ["Mavacamten (Oral Pill)", true, ["mavacamten"]],
    ["MAVENCLAD (Oral Pill)", true, ["cladribine"]],
    ["MAVENCLAD 10 TABLET PACK (Pack)", true, ["cladribine"]],
    ["MAVENCLAD 4 TABLET PACK (Pack)", true, ["cladribine"]],
    ["MAVENCLAD 5 TABLET PACK (Pack)", true, ["cladribine"]],
    ["MAVENCLAD 6 TABLET PACK (Pack)", true, ["cladribine"]],
    ["MAVENCLAD 7 TABLET PACK (Pack)", true, ["cladribine"]],
    ["MAVENCLAD 8 TABLET PACK (Pack)", true, ["cladribine"]],
    ["MAVENCLAD 9 TABLET PACK (Pack)", true, ["cladribine"]],
    ["Mavorixafor (Oral Pill)", true, ["mavorixafor"]],
    ["MAVYRET (Oral Pellet)", true, ["glecaprevir", "pibrentasvir"]],
    ["MAVYRET (Oral Pill)", true, ["glecaprevir", "pibrentasvir"]],
    ["MAXALT (Oral Disintegrating)", true, ["rizatriptan"]],
    ["MAXALT (Oral Pill)", true, ["rizatriptan"]],
    ["MAXIDEX (Ophthalmic)", false, ["dexamethasone"]],
    ["MAXIMUM D3 (Oral Pill)", true, ["cholecalciferol"]],
    ["MAXITROL (Ophthalmic)", false, ["dexamethasone", "neomycin", "polymyxin B"]],
    ["MAXZIDE (Oral Pill)", true, ["hydrochlorothiazide", "triamterene"]],
    ["MAYZENT (Oral Pill)", true, ["siponimod"]],
    ["MAYZENT 1 MG STARTER PACK (Pack)", true, ["siponimod"]],
    ["MAYZENT 2 MG STARTER PACK (Pack)", true, ["siponimod"]],
    ["Mebendazole (Chewable)", true, ["mebendazole"]],
    ["Mecamylamine (Oral Pill)", true, ["mecamylamine"]],
    ["Mecasermin (Injectable)", false, ["mecasermin"]],
    ["Mechlorethamine (Topical)", false, ["mechlorethamine"]],
    ["Meclizine (Chewable)", true, ["meclizine"]],
    ["Meclizine (Oral Disintegrating)", true, ["meclizine"]],
    ["Meclizine (Oral Pill)", true, ["meclizine"]],
    ["Meclofenamate (Oral Pill)", true, ["meclofenamate"]],
    ["Mecobalamin (Chewable)", true, ["mecobalamin"]],
    ["Mecobalamin (Oral Disintegrating)", true, ["mecobalamin"]],
    ["Mecobalamin (Oral Lozenge)", true, ["mecobalamin"]],
    ["Mecobalamin (Oral Pill)", true, ["mecobalamin"]],
    ["Mecobalamin (Sublingual)", false, ["mecobalamin"]],
    ["Mecobalamin/Vitamin B12 (Sublingual)", false, ["mecobalamin", "vitamin B12"]],
    ["MEDERMA ADVANCED SCAR (Topical)", false, ["allantoin"]],
    ["MEDERMA FOR KIDS (Topical)", false, ["allantoin"]],
    ["MEDERMA PM (Topical)", false, ["dimethicone"]],
    ["MEDERMA STRETCH MARK THERAPY (Topical)", false, ["dimethicone"]],
    ["MEDI-DERM (Topical)", false, ["capsaicin", "menthol", "methyl salicylate"]],
    ["MEDI-DERM WITH LIDOCAINE (Topical)", false, ["capsaicin", "lidocaine", "menthol", "methyl salicylate"]],
    ["MEDI-LYTE (Oral Pill)", true, ["calcium phosphate", "magnesium carbonate", "potassium chloride"]],
    ["MEDICAINE STING (Topical)", false, ["benzocaine", "menthol"]],
    ["MEDICASP (Shampoo)", false, ["coal tar"]],
    ["MEDICONE (Rectal)", false, ["benzocaine"]],
    ["MEDICONE HEMORRHOIDAL (Rectal)", false, ["phenylephrine"]],
    ["MEDIPLAST (Topical)", false, ["salicylic acid"]],
    ["MEDROL (Oral Pill)", true, ["methylprednisolone"]],
    ["MEDROL DOSEPAK (Pack)", true, ["methylprednisolone"]],
    ["MEDROX (Topical)", false, ["capsaicin", "menthol", "methyl salicylate"]],
    ["medroxyPROGESTERone (Injectable)", false, ["medroxyprogesterone"]],
    ["medroxyPROGESTERone (Oral Pill)", true, ["medroxyprogesterone"]],
    ["Mefenamate (Oral Pill)", true, ["mefenamate"]],
    ["Mefloquine (Oral Pill)", true, ["mefloquine"]],
    ["Megestrol (Oral Liquid)", true, ["megestrol"]],
    ["Megestrol (Oral Pill)", true, ["megestrol"]],
    ["MEKINIST (Oral Liquid)", true, ["trametinib"]],
    ["MEKINIST (Oral Pill)", true, ["trametinib"]],
    ["MEKTOVI (Oral Pill)", true, ["binimetinib"]],
    ["MELATONEX XR (Oral Pill)", true, ["melatonin", "pyridoxine"]],
    ["Melatonin (Chewable)", true, ["melatonin"]],
    ["Melatonin (Oral Disintegrating)", true, ["melatonin"]],
    ["Melatonin (Oral Liquid)", true, ["melatonin"]],
    ["Melatonin (Oral Pill)", true, ["melatonin"]],
    ["Melatonin (Sublingual)", false, ["melatonin"]],
    ["Melatonin XR (Oral Pill)", true, ["melatonin"]],
    ["Melatonin/Pyridoxine (Oral Pill)", true, ["melatonin", "pyridoxine"]],
    ["Melatonin/Pyridoxine XR (Oral Pill)", true, ["melatonin", "pyridoxine"]],
    ["Melatonin/Threonine (Chewable)", true, ["melatonin", "threonine"]],
    ["Melatonin/Tryptophan (Oral Pill)", true, ["melatonin", "tryptophan"]],
    ["Melatonin/Vitamin B6 (Oral Pill)", true, ["melatonin", "vitamin B6"]],
    ["Melatonin/Vitamin B6 (Sublingual)", false, ["melatonin", "vitamin B6"]],
    ["Melatonin/Vitamin B6 XR (Oral Pill)", true, ["melatonin", "vitamin B6"]],
    ["MELEYA 28 DAY (Pack)", true, ["norethindrone"]],
    ["MELFIAT XR (Oral Pill)", true, ["phendimetrazine"]],
    ["MELODETTA 24 FE CHEWABLE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Meloxicam (Injectable)", false, ["meloxicam"]],
    ["Meloxicam (Oral Disintegrating)", true, ["meloxicam"]],
    ["Meloxicam (Oral Liquid)", true, ["meloxicam"]],
    ["Meloxicam (Oral Pill)", true, ["meloxicam"]],
    ["Meloxicam/Rizatriptan (Oral Pill)", true, ["meloxicam", "rizatriptan"]],
    ["Melphalan (Injectable)", false, ["melphalan"]],
    ["Melphalan (Oral Pill)", true, ["melphalan"]],
    ["Memantine (Oral Liquid)", true, ["memantine"]],
    ["Memantine (Oral Pill)", true, ["memantine"]],
    ["Memantine (Pack)", true, ["memantine"]],
    ["Memantine XR (Oral Pill)", true, ["memantine"]],
    ["MENACTRA (Injectable)", false, ["Neisseria meningitidis serogroup A capsular polysaccharide diphtheria toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup C capsular polysaccharide diphtheria toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup W-135 capsular polysaccharide diphtheria toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup Y capsular polysaccharide diphtheria toxoid protein conjugate vaccine"]],
    ["Menatetrenone (Oral Pill)", true, ["menatetrenone"]],
    ["MENEST (Oral Pill)", true, ["estrogens, esterified (USP)"]],
    ["Meningococcal group B vaccine (Injectable)", false, ["meningococcal group B vaccine"]],
    ["MENOPUR (Injectable)", false, ["follicle stimulating hormone", "luteinizing hormone"]],
    ["MENOSTAR (Transdermal)", false, ["estradiol"]],
    ["MENQUADFI (Injectable)", false, ["Neisseria meningitidis serogroup A capsular polysaccharide tetanus toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup C capsular polysaccharide tetanus toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup W-135 capsular polysaccharide tetanus toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup Y capsular polysaccharide tetanus toxoid protein conjugate vaccine"]],
    ["MENTHAC ARTHRITIS CREAM WITH CAPSAICIN (Topical)", false, ["capsaicin"]],
    ["Menthol (Oral Lozenge)", true, ["menthol"]],
    ["Menthol (Topical)", false, ["menthol"]],
    ["Menthol/Methyl salicylate (Topical)", false, ["menthol", "methyl salicylate"]],
    ["Menthol/Pectin (Oral Lozenge)", true, ["menthol", "pectin"]],
    ["Menthol/Pramoxine (Topical)", false, ["menthol", "pramoxine"]],
    ["Menthol/Selenium sulfide (Shampoo)", false, ["menthol", "selenium sulfide"]],
    ["Menthol/Zinc oxide (Paste)", false, ["menthol", "zinc oxide"]],
    ["Menthol/Zinc oxide (Rectal)", false, ["menthol", "zinc oxide"]],
    ["Menthol/Zinc oxide (Topical)", false, ["menthol", "zinc oxide"]],
    ["MENTHOLATUM (Topical)", false, ["camphor", "menthol"]],
    ["MENVEO (Injectable)", false, ["Neisseria meningitidis serogroup A oligosaccharide diphtheria CRM197 protein conjugate vaccine", "Neisseria meningitidis serogroup C oligosaccharide diphtheria CRM197 protein conjugate vaccine", "Neisseria meningitidis serogroup W-135 oligosaccharide diphtheria CRM197 protein conjugate vaccine", "Neisseria meningitidis serogroup Y oligosaccharide diphtheria CRM197 protein conjugate vaccine"]],
    ["Meperidine (Injectable)", false, ["meperidine"]],
    ["Meperidine (Oral Liquid)", true, ["meperidine"]],
    ["Meperidine (Oral Pill)", true, ["meperidine"]],
    ["MEPHYTON (Oral Pill)", true, ["vitamin K1"]],
    ["Mepivacaine (Injectable)", false, ["mepivacaine"]],
    ["Mepolizumab (Injectable)", false, ["mepolizumab"]],
    ["Meprobamate (Oral Pill)", true, ["meprobamate"]],
    ["MEPRON (Oral Liquid)", true, ["atovaquone"]],
    ["MEPSEVII (Injectable)", false, ["vestronidase alfa"]],
    ["Merbromin (Topical)", false, ["merbromin"]],
    ["Mercaptopurine (Oral Liquid)", true, ["mercaptopurine"]],
    ["Mercaptopurine (Oral Pill)", true, ["mercaptopurine"]],
    ["MERILOG (Injectable)", false, ["insulin aspart, human"]],
    ["Meropenem (Injectable)", false, ["meropenem"]],
    ["Meropenem/Vaborbactam (Injectable)", false, ["meropenem", "vaborbactam"]],
    ["MERZEE 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Mesalamine (Oral Pill)", true, ["mesalamine"]],
    ["Mesalamine (Rectal)", false, ["mesalamine"]],
    ["Mesalamine XR (Oral Pill)", true, ["mesalamine"]],
    ["Mesna (Injectable)", false, ["mesna"]],
    ["Mesna (Oral Pill)", true, ["mesna"]],
    ["MESNEX (Injectable)", false, ["mesna"]],
    ["MESNEX (Oral Pill)", true, ["mesna"]],
    ["MESTINON (Oral Liquid)", true, ["pyridostigmine"]],
    ["MESTINON (Oral Pill)", true, ["pyridostigmine"]],
    ["MESTINON XR (Oral Pill)", true, ["pyridostigmine"]],
    ["METADATE XR (Oral Pill)", true, ["methylphenidate"]],
    ["METAMUCIL (Oral Pill)", true, ["psyllium"]],
    ["METAMUCIL (Oral Suspension Powder)", true, ["psyllium"]],
    ["METAMUCIL (Oral Wafer)", true, ["psyllium"]],
    ["Metaproterenol (Inhalant)", false, ["metaproterenol"]],
    ["Metaproterenol (Oral Liquid)", true, ["metaproterenol"]],
    ["Metaproterenol (Oral Pill)", true, ["metaproterenol"]],
    ["Metaxalone (Oral Pill)", true, ["metaxalone"]],
    ["metFORMIN (Oral Liquid)", true, ["metformin"]],
    ["metFORMIN (Oral Pill)", true, ["metformin"]],
    ["metFORMIN XR (Oral Pill)", true, ["metformin"]],
    ["metFORMIN/Pioglitazone (Oral Pill)", true, ["metformin", "pioglitazone"]],
    ["metFORMIN/Rosiglitazone (Oral Pill)", true, ["metformin", "rosiglitazone"]],
    ["metFORMIN/sAXagliptin XR (Oral Pill)", true, ["metformin", "saxagliptin"]],
    ["metFORMIN/SITagliptin (Oral Pill)", true, ["metformin", "sitagliptin"]],
    ["metFORMIN/SITagliptin XR (Oral Pill)", true, ["metformin", "sitagliptin"]],
    ["Methacholine/Methyl salicylate (Topical)", false, ["methacholine", "methyl salicylate"]],
    ["Methadone (Injectable)", false, ["methadone"]],
    ["Methadone (Oral Liquid)", true, ["methadone"]],
    ["Methadone (Oral Pill)", true, ["methadone"]],
    ["Methadone (Oral Suspension Tablet)", true, ["methadone"]],
    ["METHADOSE (Oral Liquid)", true, ["methadone"]],
    ["METHADOSE (Oral Suspension Tablet)", true, ["methadone"]],
    ["METHAGUAL (Topical)", false, ["guaiacol", "methyl salicylate"]],
    ["Methamphetamine (Oral Pill)", true, ["methamphetamine"]],
    ["methazolAMIDE (Oral Pill)", true, ["methazolamide"]],
    ["Methenamine (Oral Liquid)", true, ["methenamine"]],
    ["Methenamine (Oral Pill)", true, ["methenamine"]],
    ["Methenamine/Salicylic acid (Oral Pill)", true, ["methenamine", "salicylic acid"]],
    ["Methenamine/Sodium phosphate, monobasic (Oral Pill)", true, ["methenamine", "sodium phosphate, monobasic"]],
    ["METHERGINE (Oral Pill)", true, ["methylergonovine"]],
    ["methIMAzole (Oral Pill)", true, ["methimazole"]],
    ["METHITEST (Oral Pill)", true, ["methyltestosterone"]],
    ["Methocarbamol (Injectable)", false, ["methocarbamol"]],
    ["Methocarbamol (Oral Liquid)", true, ["methocarbamol"]],
    ["Methocarbamol (Oral Pill)", true, ["methocarbamol"]],
    ["Methohexital (Injectable)", false, ["methohexital"]],
    ["Methotrexate (Injectable)", false, ["methotrexate"]],
    ["Methotrexate (Oral Liquid)", true, ["methotrexate"]],
    ["Methotrexate (Oral Pill)", true, ["methotrexate"]],
    ["Methoxsalen (Injectable)", false, ["methoxsalen"]],
    ["Methoxsalen (Oral Pill)", true, ["methoxsalen"]],
    ["Methoxy polyethylene glycol-epoetin beta (Injectable)", false, ["methoxy polyethylene glycol-epoetin beta"]],
    ["Methscopolamine (Oral Pill)", true, ["methscopolamine"]],
    ["Methsuximide (Oral Pill)", true, ["methsuximide"]],
    ["Methyl 5-aminolevulinate (Topical)", false, ["methyl 5-aminolevulinate"]],
    ["Methyl salicylate (Topical)", false, ["methyl salicylate"]],
    ["Methylcellulose (Oral Pill)", true, ["methylcellulose"]],
    ["Methylcellulose (Oral Suspension Powder)", true, ["methylcellulose"]],
    ["Methyldopa (Oral Pill)", true, ["methyldopa"]],
    ["Methylene blue (Injectable)", false, ["methylene blue"]],
    ["Methylene blue (Topical)", false, ["methylene blue"]],
    ["Methylergonovine (Injectable)", false, ["methylergonovine"]],
    ["Methylergonovine (Oral Pill)", true, ["methylergonovine"]],
    ["METHYLIN (Oral Liquid)", true, ["methylphenidate"]],
    ["Methylnaltrexone (Injectable)", false, ["methylnaltrexone"]],
    ["Methylnaltrexone (Oral Pill)", true, ["methylnaltrexone"]],
    ["Methylphenidate (Chewable)", true, ["methylphenidate"]],
    ["Methylphenidate (Oral Disintegrating)", true, ["methylphenidate"]],
    ["Methylphenidate (Oral Liquid)", true, ["methylphenidate"]],
    ["Methylphenidate (Oral Pill)", true, ["methylphenidate"]],
    ["Methylphenidate (Transdermal)", false, ["methylphenidate"]],
    ["Methylphenidate XR (Chewable)", true, ["methylphenidate"]],
    ["Methylphenidate XR (Oral Liquid)", true, ["methylphenidate"]],
    ["Methylphenidate XR (Oral Pill)", true, ["methylphenidate"]],
    ["methylPREDNISolone (Injectable)", false, ["methylprednisolone"]],
    ["methylPREDNISolone (Oral Pill)", true, ["methylprednisolone"]],
    ["methylPREDNISolone (Pack)", true, ["methylprednisolone"]],
    ["methylPREDNISolone (Topical)", false, ["methylprednisolone"]],
    ["Methylsulfonylmethane (Oral Pill)", true, ["methylsulfonylmethane"]],
    ["methylTESTOSTERone (Oral Pill)", true, ["methyltestosterone"]],
    ["Metoclopramide (Injectable)", false, ["metoclopramide"]],
    ["Metoclopramide (Nasal)", false, ["metoclopramide"]],
    ["Metoclopramide (Oral Disintegrating)", true, ["metoclopramide"]],
    ["Metoclopramide (Oral Liquid)", true, ["metoclopramide"]],
    ["Metoclopramide (Oral Pill)", true, ["metoclopramide"]],
    ["metOLazone (Oral Pill)", true, ["metolazone"]],
    ["METOPIRONE (Oral Pill)", true, ["metyrapone"]],
    ["Metoprolol (Injectable)", false, ["metoprolol"]],
    ["Metoprolol (Oral Liquid)", true, ["metoprolol"]],
    ["Metoprolol (Oral Pill)", true, ["metoprolol"]],
    ["Metoprolol XR (Oral Pill)", true, ["metoprolol"]],
    ["METOZOLV (Oral Disintegrating)", true, ["metoclopramide"]],
    ["Metreleptin (Injectable)", false, ["metreleptin"]],
    ["METROCREAM (Topical)", false, ["metronidazole"]],
    ["METROGEL (Topical)", false, ["metronidazole"]],
    ["METROLOTION (Topical)", false, ["metronidazole"]],
    ["metroNIDAZOLE (Injectable)", false, ["metronidazole"]],
    ["metroNIDAZOLE (Oral Liquid)", true, ["metronidazole"]],
    ["metroNIDAZOLE (Oral Pill)", true, ["metronidazole"]],
    ["metroNIDAZOLE (Topical)", false, ["metronidazole"]],
    ["metroNIDAZOLE (Vaginal)", false, ["metronidazole"]],
    ["metroNIDAZOLE XR (Oral Pill)", true, ["metronidazole"]],
    ["METVIXIA (Topical)", false, ["methyl 5-aminolevulinate"]],
    ["metyraPONE (Oral Pill)", true, ["metyrapone"]],
    ["metyroSINE (Oral Pill)", true, ["metyrosine"]],
    ["Mexiletine (Oral Pill)", true, ["mexiletine"]],
    ["MEXSANA (Topical)", false, ["corn starch"]],
    ["MFLUSIVA 2026-2027 (Injectable)", false, ["influenza vaccine, mRNA hemagglutinin glycoprotein"]],
    ["MG 217 PSORIASIS (Topical)", false, ["coal tar"]],
    ["MG PLUS PROTEIN (Oral Pill)", true, ["magnesium amino acid chelate"]],
    ["MG217 PSORIASIS SALICYLIC ACID (Shampoo)", false, ["salicylic acid"]],
    ["MI-ACID GAS RELIEF (Chewable)", true, ["simethicone"]],
    ["MIACALCIN (Injectable)", false, ["salmon calcitonin"]],
    ["MIBELAS 24 FE CHEWABLE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["MICADERM (Topical)", false, ["miconazole"]],
    ["Micafungin (Injectable)", false, ["micafungin"]],
    ["MICANOL (Topical)", false, ["anthralin"]],
    ["MICARDIS (Oral Pill)", true, ["telmisartan"]],
    ["MICARDIS-HCT (Oral Pill)", true, ["hydrochlorothiazide", "telmisartan"]],
    ["MICATIN (Topical)", false, ["miconazole"]],
    ["Miconazole (Buccal)", false, ["miconazole"]],
    ["Miconazole (Pack)", false, ["miconazole"]],
    ["Miconazole (Topical)", false, ["miconazole"]],
    ["Miconazole (Vaginal)", false, ["miconazole"]],
    ["Miconazole/Petrolatum/Zinc oxide (Topical)", false, ["miconazole", "petrolatum", "zinc oxide"]],
    ["MICORT-HC (Topical)", false, ["hydrocortisone"]],
    ["MICRHOGAM (Injectable)", false, ["Rho(D) immune globulin"]],
    ["MICRO-GUARD (Topical)", false, ["miconazole"]],
    ["MICROGESTIN 1.5/30 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["MICROGESTIN 1/20 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["MICROGESTIN 24 FE 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["MICROGESTIN FE 1.5/30 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["MICROGESTIN FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Midazolam (Injectable)", false, ["midazolam"]],
    ["Midazolam (Nasal)", false, ["midazolam"]],
    ["Midazolam (Oral Liquid)", true, ["midazolam"]],
    ["Midodrine (Oral Pill)", true, ["midodrine"]],
    ["Midostaurin (Oral Pill)", true, ["midostaurin"]],
    ["MIEBO (Ophthalmic)", false, ["perfluorohexyloctane"]],
    ["MIFEPREX (Oral Pill)", true, ["mifepristone"]],
    ["miFEPRIStone (Oral Pill)", true, ["mifepristone"]],
    ["migALAstat (Oral Pill)", true, ["migalastat"]],
    ["migALAstat (Pack)", true, ["migalastat"]],
    ["MIGERGOT (Rectal)", false, ["caffeine", "ergotamine"]],
    ["Miglitol (Oral Pill)", true, ["miglitol"]],
    ["migLUstat (Oral Pill)", true, ["miglustat"]],
    ["MIGRANAL (Nasal)", false, ["dihydroergotamine"]],
    ["MILI 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["MILLIPRED (Oral Pill)", true, ["prednisolone"]],
    ["MILLIPRED DP 12 DAY (Pack)", true, ["prednisolone"]],
    ["MILLIPRED DP 6 DAY (Pack)", true, ["prednisolone"]],
    ["Milnacipran (Oral Pill)", true, ["milnacipran"]],
    ["Milnacipran (Pack)", true, ["milnacipran"]],
    ["MILOPHENE (Oral Pill)", true, ["clomiphene"]],
    ["Milrinone (Injectable)", false, ["milrinone"]],
    ["Milsaperidone (Oral Pill)", true, ["milsaperidone"]],
    ["Milsaperidone (Pack)", true, ["milsaperidone"]],
    ["Miltefosine (Oral Pill)", true, ["miltefosine"]],
    ["MIMRYLO (Injectable)", false, ["rusfertide"]],
    ["MIMVEY (Pack)", true, ["estradiol", "norethindrone"]],
    ["MINASTRIN 24 FE CHEWABLE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["MINERAL ICE (Topical)", false, ["menthol"]],
    ["Mineral oil (Oral Liquid)", true, ["mineral oil"]],
    ["Mineral oil (Rectal)", false, ["mineral oil"]],
    ["Mineral oil (Topical)", false, ["mineral oil"]],
    ["Mineral oil/Mineral oil, light (Ophthalmic)", false, ["mineral oil", "mineral oil, light"]],
    ["Mineral oil/Petrolatum (Ophthalmic)", false, ["mineral oil", "petrolatum"]],
    ["Mineral oil/Petrolatum (Topical)", false, ["mineral oil", "petrolatum"]],
    ["MINIDROPS (Ophthalmic)", false, ["polyvinyl alcohol", "povidone"]],
    ["MINIPRESS (Oral Pill)", true, ["prazosin"]],
    ["MINIPRIN (Oral Pill)", true, ["aspirin"]],
    ["MINIVELLE (Transdermal)", false, ["estradiol"]],
    ["MINOCIN (Injectable)", false, ["minocycline"]],
    ["MINOCIN (Oral Liquid)", true, ["minocycline"]],
    ["MINOCIN (Oral Pill)", true, ["minocycline"]],
    ["Minocycline (Injectable)", false, ["minocycline"]],
    ["Minocycline (Oral Liquid)", true, ["minocycline"]],
    ["Minocycline (Oral Pill)", true, ["minocycline"]],
    ["Minocycline (Oral Powder)", true, ["minocycline"]],
    ["Minocycline (Topical)", false, ["minocycline"]],
    ["Minocycline XR (Oral Pill)", true, ["minocycline"]],
    ["MINOLIRA XR (Oral Pill)", true, ["minocycline"]],
    ["Minoxidil (Oral Pill)", true, ["minoxidil"]],
    ["Minoxidil (Topical)", false, ["minoxidil"]],
    ["MINTOX PLUS (Chewable)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["MINTOX PLUS (Oral Liquid)", true, ["aluminum hydroxide", "magnesium hydroxide", "simethicone"]],
    ["MINZOYA 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous bisglycinate", "levonorgestrel"]],
    ["MIOCHOL (Ophthalmic)", false, ["acetylcholine"]],
    ["MIOSTAT (Injectable)", false, ["carbachol"]],
    ["MIPLYFFA (Oral Pill)", true, ["arimoclomol"]],
    ["Mipomersen (Injectable)", false, ["mipomersen"]],
    ["Mirabegron XR (Oral Liquid)", true, ["mirabegron"]],
    ["Mirabegron XR (Oral Pill)", true, ["mirabegron"]],
    ["MIRAFAST (Chewable)", true, ["magnesium hydroxide"]],
    ["MIRALAX (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["MIRAPEX (Oral Pill)", true, ["pramipexole"]],
    ["MIRAPEX XR (Oral Pill)", true, ["pramipexole"]],
    ["MIRCERA (Injectable)", false, ["methoxy polyethylene glycol-epoetin beta"]],
    ["Mirdametinib (Oral Pill)", true, ["mirdametinib"]],
    ["Mirdametinib (Oral Suspension Tablet)", true, ["mirdametinib"]],
    ["MIRENA (Intrauterine)", false, ["levonorgestrel"]],
    ["Mirikizumab (Injectable)", false, ["mirikizumab"]],
    ["Mirikizumab (Pack)", false, ["mirikizumab"]],
    ["Mirtazapine (Oral Disintegrating)", true, ["mirtazapine"]],
    ["Mirtazapine (Oral Pill)", true, ["mirtazapine"]],
    ["MIRVASO (Topical)", false, ["brimonidine"]],
    ["Mirvetuximab soravtansine (Injectable)", false, ["mirvetuximab soravtansine"]],
    ["miSOPROStol (Oral Pill)", true, ["misoprostol"]],
    ["Mitapivat (Oral Pill)", true, ["mitapivat"]],
    ["Mitapivat (Pack)", true, ["mitapivat"]],
    ["MITIGARE (Oral Pill)", true, ["colchicine"]],
    ["MITIGO (Injectable)", false, ["morphine"]],
    ["mitoMYcin (Injectable)", false, ["mitomycin"]],
    ["mitoMYcin (Intravesical)", false, ["mitomycin"]],
    ["mitoMYcin (Ophthalmic)", false, ["mitomycin"]],
    ["mitoMYcin (Pyelocalyceal Solution Powder)", false, ["mitomycin"]],
    ["MITOSOL (Ophthalmic)", false, ["mitomycin"]],
    ["Mitotane (Oral Pill)", true, ["mitotane"]],
    ["mitoXANTRONE (Injectable)", false, ["mitoxantrone"]],
    ["MIUDELLA (Implant)", false, ["copper"]],
    ["MNEXSPIKE 2025-2026 (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["MNEXSPIKE 2026-2027 (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["MOBIC (Oral Pill)", true, ["meloxicam"]],
    ["MOBISYL (Topical)", false, ["trolamine salicylate"]],
    ["Mobocertinib (Oral Pill)", true, ["mobocertinib"]],
    ["Modafinil (Oral Pill)", true, ["modafinil"]],
    ["MODEYSO (Oral Pill)", true, ["dordaviprone"]],
    ["Moexipril (Oral Pill)", true, ["moexipril"]],
    ["Mogamulizumab (Injectable)", false, ["mogamulizumab"]],
    ["MOISTUREL THERAPEUTIC (Topical)", false, ["dimethicone"]],
    ["Molindone (Oral Pill)", true, ["molindone"]],
    ["MOLLIFENE (Otic)", false, ["carbamide peroxide"]],
    ["Molnupiravir (Oral Pill)", true, ["molnupiravir"]],
    ["Molybdenum (Oral Pill)", true, ["molybdenum"]],
    ["Momelotinib (Oral Pill)", true, ["momelotinib"]],
    ["Mometasone (Implant)", false, ["mometasone"]],
    ["Mometasone (Inhalant)", false, ["mometasone"]],
    ["Mometasone (Nasal)", false, ["mometasone"]],
    ["Mometasone (Topical)", false, ["mometasone"]],
    ["Mometasone/Olopatadine (Nasal)", false, ["mometasone", "olopatadine"]],
    ["MONDOXYNE (Oral Pill)", true, ["doxycycline"]],
    ["MONISTAT (Vaginal)", false, ["miconazole"]],
    ["MONISTAT 1 DAY OVULE COMBINATION PACK (Pack)", false, ["miconazole"]],
    ["MONISTAT 3 DAY OVULE COMBINATION PACK (Pack)", false, ["miconazole"]],
    ["MONISTAT 3 VAGINAL CREAM COMBINATION PACK WITH VAGINAL CREAMS (Pack)", false, ["miconazole"]],
    ["MONISTAT 7 VAGINAL CREAM COMBINATION PACK (Pack)", false, ["miconazole"]],
    ["MONISTAT 7 VAGINAL CREAM COMBINATION PACK WITH VAGINAL CREAMS (Pack)", false, ["miconazole"]],
    ["MONISTAT CARE (Topical)", false, ["benzocaine"]],
    ["MONISTAT ITCH RELIEF (Vaginal)", false, ["hydrocortisone"]],
    ["MONISTAT SIMPLE THERAPY (Vaginal)", false, ["tioconazole"]],
    ["MONISTAT SOOTHING CARE (Topical)", false, ["dimethicone"]],
    ["MONJUVI (Injectable)", false, ["tafasitamab"]],
    ["MONO-LINYAH 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["MONOCAL (Oral Pill)", true, ["calcium carbonate", "monofluorophosphate"]],
    ["MONOFERRIC (Injectable)", false, ["ferric derisomaltose"]],
    ["Monofluorophosphate (Toothpaste)", false, ["monofluorophosphate"]],
    ["Monomethyl fumarate (Oral Pill)", true, ["monomethyl fumarate"]],
    ["MONOVISC (Injectable)", false, ["hyaluronate"]],
    ["Montelukast (Chewable)", true, ["montelukast"]],
    ["Montelukast (Oral Granules)", true, ["montelukast"]],
    ["Montelukast (Oral Pill)", true, ["montelukast"]],
    ["MORGIDOX (Oral Pill)", true, ["doxycycline"]],
    ["MORNING AFTER (Oral Pill)", true, ["levonorgestrel"]],
    ["Morphine (Injectable)", false, ["morphine"]],
    ["Morphine (Oral Liquid)", true, ["morphine"]],
    ["Morphine (Oral Pill)", true, ["morphine"]],
    ["Morphine (Rectal)", false, ["morphine"]],
    ["Morphine XR (Oral Pill)", true, ["morphine"]],
    ["MOSCO CORN & CALLUS REMOVER (Topical)", false, ["salicylic acid"]],
    ["Mosunetuzumab (Injectable)", false, ["mosunetuzumab"]],
    ["MOTEGRITY (Oral Pill)", true, ["prucalopride"]],
    ["Motixafortide (Injectable)", false, ["motixafortide"]],
    ["MOTOFEN (Oral Pill)", true, ["atropine", "difenoxin"]],
    ["MOTPOLY XR (Oral Pill)", true, ["lacosamide"]],
    ["MOTRIN (Chewable)", true, ["ibuprofen"]],
    ["MOTRIN (Oral Liquid)", true, ["ibuprofen"]],
    ["MOTRIN (Oral Pill)", true, ["ibuprofen"]],
    ["MOTRIN PM (Oral Pill)", true, ["diphenhydramine", "ibuprofen"]],
    ["MOUNJARO (Injectable)", false, ["tirzepatide"]],
    ["MOVANTIK (Oral Pill)", true, ["naloxegol"]],
    ["MOVIPREP (Oral Solution Powder)", true, ["ascorbic acid", "polyethylene glycol 3350", "potassium chloride", "sodium ascorbate", "sodium chloride", "sodium sulfate"]],
    ["MOXATAG XR (Oral Pill)", true, ["amoxicillin"]],
    ["Moxetumomab pasudotox (Injectable)", false, ["moxetumomab pasudotox"]],
    ["Moxidectin (Oral Pill)", true, ["moxidectin"]],
    ["Moxifloxacin (Injectable)", false, ["moxifloxacin"]],
    ["Moxifloxacin (Ophthalmic)", false, ["moxifloxacin"]],
    ["Moxifloxacin (Oral Pill)", true, ["moxifloxacin"]],
    ["MOZOBIL (Injectable)", false, ["plerixafor"]],
    ["MRESVIA (Injectable)", false, ["respiratory syncytial virus pre-fusion F glycoprotein mRNA"]],
    ["MS CONTIN XR (Oral Pill)", true, ["morphine"]],
    ["MST 600 (Oral Pill)", true, ["magnesium salicylate"]],
    ["MTX SUPPORT (Oral Pill)", true, ["folic acid", "vitamin B12"]],
    ["MUCILIN (Oral Suspension Powder)", true, ["psyllium"]],
    ["MUCINEX (Oral Granules)", true, ["guaifenesin"]],
    ["MUCINEX (Oral Liquid)", true, ["guaifenesin"]],
    ["MUCINEX XR (Oral Pill)", true, ["guaifenesin"]],
    ["MULPLETA (Oral Pill)", true, ["lusutrombopag"]],
    ["MULTAQ (Oral Pill)", true, ["dronedarone"]],
    ["MULTI-DELYN (Oral Liquid)", true, ["ascorbic acid", "cholecalciferol", "niacinamide", "pyridoxine", "riboflavin", "thiamine", "vitamin A", "vitamin B12", "vitamin E"]],
    ["MULTIGEN (Oral Pill)", true, ["calcium ascorbate", "calcium threonate", "ferrous asparto glycinate", "liver stomach concentrate", "succinic acid", "vitamin B12"]],
    ["MULTIGEN PLUS (Oral Pill)", true, ["calcium ascorbate", "calcium threonate", "ferrous asparto glycinate", "ferrous fumarate", "folic acid", "succinic acid", "vitamin B12"]],
    ["MULTITRACE-4 (Injectable)", false, ["chromic chloride", "copper sulfate", "manganese sulfate", "zinc sulfate"]],
    ["MULTITRACE-5 (Injectable)", false, ["chromic chloride", "copper sulfate", "manganese sulfate", "selenious acid", "zinc sulfate"]],
    ["MULTRYS (Injectable)", false, ["copper sulfate", "manganese sulfate", "selenious acid", "zinc sulfate"]],
    ["Mupirocin (Topical)", false, ["mupirocin"]],
    ["MURINE DRY EYES (Ophthalmic)", false, ["polyvinyl alcohol", "povidone"]],
    ["MURINE EAR (Otic)", false, ["carbamide peroxide"]],
    ["MURO 128 (Ophthalmic)", false, ["sodium chloride"]],
    ["MUSE (Urethral)", false, ["alprostadil"]],
    ["MUTAMYCIN (Injectable)", false, ["mitomycin"]],
    ["MVASI (Injectable)", false, ["bevacizumab"]],
    ["MVC-FLUORIDE (Chewable)", true, ["ascorbic acid", "cholecalciferol", "folic acid", "niacin", "riboflavin", "sodium fluoride", "thiamine", "vitamin A", "vitamin B12", "vitamin B6", "vitamin E"]],
    ["MY CHOICE (Oral Pill)", true, ["levonorgestrel"]],
    ["MY WAY (Oral Pill)", true, ["levonorgestrel"]],
    ["MYALEPT (Injectable)", false, ["metreleptin"]],
    ["MYAMBUTOL (Oral Pill)", true, ["ethambutol"]],
    ["MYCAMINE (Injectable)", false, ["micafungin"]],
    ["MYCAPSSA (Oral Pill)", true, ["octreotide"]],
    ["MYCINAIRE (Nasal)", false, ["sodium chloride"]],
    ["MYCINETTE SORE THROAT SPRAY (Mucosal)", false, ["phenol"]],
    ["MYCITRACIN PLUS PAIN RELIEVER (Topical)", false, ["bacitracin", "neomycin", "polymyxin B", "pramoxine"]],
    ["MYCOBUTIN (Oral Pill)", true, ["rifabutin"]],
    ["MYCOCIDE NS (Topical)", false, ["tolnaftate"]],
    ["Mycophenolate mofetil (Injectable)", false, ["mycophenolate mofetil"]],
    ["Mycophenolate mofetil (Oral Liquid)", true, ["mycophenolate mofetil"]],
    ["Mycophenolate mofetil (Oral Pill)", true, ["mycophenolate mofetil"]],
    ["Mycophenolic acid (Oral Pill)", true, ["mycophenolic acid"]],
    ["MYDAYIS XR (Oral Pill)", true, ["amphetamine", "dextroamphetamine"]],
    ["MYDCOMBI (Ophthalmic)", false, ["phenylephrine", "tropicamide"]],
    ["MYDRIACYL (Ophthalmic)", false, ["tropicamide"]],
    ["MYFEMBREE (Oral Pill)", true, ["estradiol", "norethindrone", "relugolix"]],
    ["MYFORTIC (Oral Pill)", true, ["mycophenolic acid"]],
    ["MYHIBBIN (Oral Liquid)", true, ["mycophenolate mofetil"]],
    ["MYLERAN (Oral Pill)", true, ["busulfan"]],
    ["MYLICON (Oral Liquid)", true, ["simethicone"]],
    ["MYLICON CHILDREN'S (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["MYLICON CHILDREN'S (Oral Liquid)", true, ["calcium carbonate", "simethicone"]],
    ["MYLOTARG (Injectable)", false, ["gemtuzumab ozogamicin"]],
    ["MYOBLOC (Injectable)", false, ["botulinum toxin type B"]],
    ["MYOFLEX (Topical)", false, ["trolamine salicylate"]],
    ["MYORISAN (Oral Pill)", true, ["isotretinoin"]],
    ["MYQORZO (Oral Pill)", true, ["aficamten"]],
    ["MYRBETRIQ XR (Oral Liquid)", true, ["mirabegron"]],
    ["MYRBETRIQ XR (Oral Pill)", true, ["mirabegron"]],
    ["MYSOLINE (Oral Pill)", true, ["primidone"]],
    ["MYTESI (Oral Pill)", true, ["crofelemer"]],
    ["MYXREDLIN (Injectable)", false, ["insulin, regular, human"]],
    ["N ICE WITH VITAMIN C (Chewable)", true, ["ascorbic acid"]],
    ["N'ICE (Oral Lozenge)", true, ["menthol"]],
    ["NA-ZONE (Nasal)", false, ["sodium chloride"]],
    ["NABI-HB (Injectable)", false, ["hepatitis B immune globulin"]],
    ["Nabilone (Oral Pill)", true, ["nabilone"]],
    ["Nabumetone (Oral Pill)", true, ["nabumetone"]],
    ["Nadofaragene firadenovec (Intravesical)", false, ["nadofaragene firadenovec"]],
    ["Nadolol (Oral Pill)", true, ["nadolol"]],
    ["Nafarelin (Nasal)", false, ["nafarelin"]],
    ["Nafcillin (Injectable)", false, ["nafcillin"]],
    ["NAFRINSE (Chewable)", true, ["sodium fluoride"]],
    ["NAFRINSE (Mouthwash)", false, ["sodium fluoride"]],
    ["NAFRINSE (Oral Pill)", true, ["sodium fluoride"]],
    ["Naftifine (Topical)", false, ["naftifine"]],
    ["NAFTIN (Topical)", false, ["naftifine"]],
    ["NAGLAZYME (Injectable)", false, ["galsulfase"]],
    ["Nalbuphine (Injectable)", false, ["nalbuphine"]],
    ["Naldemedine (Oral Pill)", true, ["naldemedine"]],
    ["NALFON (Oral Pill)", true, ["fenoprofen"]],
    ["Nalmefene (Injectable)", false, ["nalmefene"]],
    ["Nalmefene (Nasal)", false, ["nalmefene"]],
    ["NALOCET (Oral Pill)", true, ["acetaminophen", "oxycodone"]],
    ["Naloxegol (Oral Pill)", true, ["naloxegol"]],
    ["Naloxone (Injectable)", false, ["naloxone"]],
    ["Naloxone (Nasal)", false, ["naloxone"]],
    ["Naloxone/Pentazocine (Oral Pill)", true, ["naloxone", "pentazocine"]],
    ["Naltrexone (Injectable)", false, ["naltrexone"]],
    ["Naltrexone (Oral Pill)", true, ["naltrexone"]],
    ["NAMENDA (Oral Pill)", true, ["memantine"]],
    ["NAMENDA 28 TITRATION PACK (Pack)", true, ["memantine"]],
    ["NAMENDA XR (Oral Pill)", true, ["memantine"]],
    ["NAMZARIC TITRATION PACK (Pack)", true, ["donepezil", "memantine"]],
    ["NAMZARIC XR (Oral Pill)", true, ["donepezil", "memantine"]],
    ["Naphazoline (Nasal)", false, ["naphazoline"]],
    ["Naphazoline (Ophthalmic)", false, ["naphazoline"]],
    ["Naphazoline/Pheniramine (Ophthalmic)", false, ["naphazoline", "pheniramine"]],
    ["Naphazoline/Polyethylene glycol 300 (Ophthalmic)", false, ["naphazoline", "polyethylene glycol 300"]],
    ["NAPHCON A (Ophthalmic)", false, ["naphazoline", "pheniramine"]],
    ["NAPRELAN XR (Oral Pill)", true, ["naproxen"]],
    ["NAPROSYN (Oral Liquid)", true, ["naproxen"]],
    ["NAPROSYN (Oral Pill)", true, ["naproxen"]],
    ["Naproxen (Oral Liquid)", true, ["naproxen"]],
    ["Naproxen (Oral Pill)", true, ["naproxen"]],
    ["Naproxen XR (Oral Pill)", true, ["naproxen"]],
    ["Naproxen/Pseudoephedrine XR (Oral Pill)", true, ["naproxen", "pseudoephedrine"]],
    ["Naproxen/SUMAtriptan (Oral Pill)", true, ["naproxen", "sumatriptan"]],
    ["Naratriptan (Oral Pill)", true, ["naratriptan"]],
    ["NARCAN (Nasal)", false, ["naloxone"]],
    ["NARDIL (Oral Pill)", true, ["phenelzine"]],
    ["NAROPIN (Injectable)", false, ["ropivacaine"]],
    ["Narsoplimab (Injectable)", false, ["narsoplimab"]],
    ["NASACORT (Nasal)", false, ["triamcinolone"]],
    ["NASALCROM (Nasal)", false, ["cromolyn"]],
    ["NASCOBAL (Nasal)", false, ["vitamin B12"]],
    ["NASONEX (Nasal)", false, ["mometasone"]],
    ["NASOPEN PE (Oral Liquid)", true, ["phenylephrine", "thonzylamine"]],
    ["NATACYN (Ophthalmic)", false, ["natamycin"]],
    ["Natalizumab (Injectable)", false, ["natalizumab"]],
    ["Natamycin (Ophthalmic)", false, ["natamycin"]],
    ["NATAZIA 28 DAY (Pack)", true, ["dienogest", "estradiol"]],
    ["Nateglinide (Oral Pill)", true, ["nateglinide"]],
    ["NATESTO (Nasal)", false, ["testosterone"]],
    ["NATPARA (Injectable)", false, ["parathyroid hormone"]],
    ["NATROBA (Shampoo)", false, ["spinosad"]],
    ["Nattokinase (Oral Pill)", true, ["nattokinase"]],
    ["NATURE-THROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["NAVELBINE (Injectable)", false, ["vinorelbine"]],
    ["Navepegritide (Injectable)", false, ["navepegritide"]],
    ["NAVITRUX (Injectable)", false, ["fosaprepitant"]],
    ["Naxitamab (Injectable)", false, ["naxitamab"]],
    ["NAYZILAM (Nasal)", false, ["midazolam"]],
    ["Nebivolol (Oral Pill)", true, ["nebivolol"]],
    ["Nebivolol/Valsartan (Oral Pill)", true, ["nebivolol", "valsartan"]],
    ["NEBUPENT (Inhalant)", false, ["pentamidine"]],
    ["NEBUSAL (Inhalant)", false, ["sodium chloride"]],
    ["Necitumumab (Injectable)", false, ["necitumumab"]],
    ["NECON 0.5/35 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["NECON 7/7/7 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Nedocromil (Ophthalmic)", false, ["nedocromil"]],
    ["Nedosiran (Injectable)", false, ["nedosiran"]],
    ["Nefazodone (Oral Pill)", true, ["nefazodone"]],
    ["NEFFY (Nasal)", false, ["epinephrine"]],
    ["Nelarabine (Injectable)", false, ["nelarabine"]],
    ["Nelfinavir (Oral Pill)", true, ["nelfinavir"]],
    ["NEMBUTAL (Injectable)", false, ["pentobarbital"]],
    ["NEMLUVIO (Injectable)", false, ["nemolizumab"]],
    ["Nemolizumab (Injectable)", false, ["nemolizumab"]],
    ["NEO-POLYCIN (Ophthalmic)", false, ["bacitracin", "neomycin", "polymyxin B"]],
    ["NEO-POLYCIN HC (Ophthalmic)", false, ["bacitracin", "hydrocortisone", "neomycin", "polymyxin B"]],
    ["NEO-SYNALAR (Topical)", false, ["fluocinolone", "neomycin"]],
    ["NEO-SYNEPHRINE (Nasal)", false, ["phenylephrine"]],
    ["NEO-SYNEPHRINE 12 HOUR (Nasal)", false, ["oxymetazoline"]],
    ["NEOBENZ MICRO (Topical)", false, ["benzoyl peroxide"]],
    ["NEOBENZ MICRO WASH (Soap)", false, ["benzoyl peroxide"]],
    ["Neomycin (Oral Pill)", true, ["neomycin"]],
    ["Neomycin (Topical)", false, ["neomycin"]],
    ["Neomycin/Polymyxin B (Irrigation)", false, ["neomycin", "polymyxin B"]],
    ["NEOPROFEN (Injectable)", false, ["ibuprofen"]],
    ["NEOQ10 (Oral Pill)", true, ["ubidecarenone", "vitamin E"]],
    ["NEORAL (Oral Liquid)", true, ["cyclosporine"]],
    ["NEORAL (Oral Pill)", true, ["cyclosporine"]],
    ["Neostigmine (Injectable)", false, ["neostigmine"]],
    ["Nepafenac (Ophthalmic)", false, ["nepafenac"]],
    ["Nerandomilast (Oral Pill)", true, ["nerandomilast"]],
    ["Neratinib (Oral Pill)", true, ["neratinib"]],
    ["NEREUS (Oral Pill)", true, ["tradipitant"]],
    ["NERLYNX (Oral Pill)", true, ["neratinib"]],
    ["NESACAINE (Injectable)", false, ["chloroprocaine"]],
    ["NESINA (Oral Pill)", true, ["alogliptin"]],
    ["Netarsudil (Ophthalmic)", false, ["netarsudil"]],
    ["Netupitant/Palonosetron (Injectable)", false, ["netupitant", "palonosetron"]],
    ["Netupitant/Palonosetron (Oral Pill)", true, ["netupitant", "palonosetron"]],
    ["NEUAC (Topical)", false, ["benzoyl peroxide", "clindamycin"]],
    ["NEULASTA (Injectable)", false, ["pegfilgrastim"]],
    ["NEUPOGEN (Injectable)", false, ["filgrastim"]],
    ["NEUPRO (Transdermal)", false, ["rotigotine"]],
    ["NEUPRO KIT (Pack)", false, ["rotigotine"]],
    ["NEURONTIN (Oral Liquid)", true, ["gabapentin"]],
    ["NEURONTIN (Oral Pill)", true, ["gabapentin"]],
    ["NEUTRACARE (Oral Gel)", true, ["sodium fluoride"]],
    ["NEUTRAGARD (Toothpaste)", false, ["sodium fluoride"]],
    ["NEUTRAMAXX (Toothpaste)", false, ["sodium fluoride"]],
    ["NEUTRAPHOR (Topical)", false, ["dimethicone"]],
    ["NEVANAC (Ophthalmic)", false, ["nepafenac"]],
    ["Nevirapine (Oral Liquid)", true, ["nevirapine"]],
    ["Nevirapine (Oral Pill)", true, ["nevirapine"]],
    ["Nevirapine XR (Oral Pill)", true, ["nevirapine"]],
    ["NEW DAY (Oral Pill)", true, ["levonorgestrel"]],
    ["NEW-SKIN LIQUID BANDAGE (Topical)", false, ["benzethonium"]],
    ["NEXAFED (Oral Pill)", true, ["pseudoephedrine"]],
    ["NexAVAR (Oral Pill)", true, ["sorafenib"]],
    ["NEXAVIR (Injectable)", false, ["liver extract"]],
    ["NEXESTA FE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["NEXICLON XR (Oral Pill)", true, ["clonidine"]],
    ["NexIUM (Injectable)", false, ["esomeprazole"]],
    ["NexIUM (Oral Pill)", true, ["esomeprazole"]],
    ["NexIUM (Oral Suspension Granules)", true, ["esomeprazole"]],
    ["NEXLETOL (Oral Pill)", true, ["bempedoic acid"]],
    ["NEXLIZET (Oral Pill)", true, ["bempedoic acid", "ezetimibe"]],
    ["NEXOBRID (Topical)", false, ["anacaulase"]],
    ["NEXPLANON (Implant)", false, ["etonogestrel"]],
    ["NEXT CHOICE ONE DOSE (Oral Pill)", true, ["levonorgestrel"]],
    ["NEXTERONE (Injectable)", false, ["amiodarone"]],
    ["NEXTSTELLIS 28 DAY (Pack)", true, ["drospirenone", "estetrol"]],
    ["NEXVIAZYME (Injectable)", false, ["avalglucosidase alfa"]],
    ["NGENLA (Injectable)", false, ["somatrogon"]],
    ["Niacin (Oral Pill)", true, ["niacin"]],
    ["Niacin XR (Oral Pill)", true, ["niacin"]],
    ["Niacin/Pantethine XR (Oral Pill)", true, ["niacin", "pantethine"]],
    ["Niacin/Riboflavin/Thiamine (Oral Pill)", true, ["niacin", "riboflavin", "thiamine"]],
    ["Niacinamide (Oral Pill)", true, ["niacinamide"]],
    ["Niacinamide (Topical)", false, ["niacinamide"]],
    ["Niacinamide XR (Oral Pill)", true, ["niacinamide"]],
    ["NIACOR (Oral Pill)", true, ["niacin"]],
    ["NIASPAN XR (Oral Pill)", true, ["niacin"]],
    ["niCARdipine (Injectable)", false, ["nicardipine"]],
    ["niCARdipine (Oral Pill)", true, ["nicardipine"]],
    ["NICAZEL (Oral Pill)", true, ["azelate", "cupric oxide", "folic acid", "niacinamide", "pyridoxine", "zinc oxide"]],
    ["NICODERM C-Q (Transdermal)", false, ["nicotine"]],
    ["NICOMIDE (Oral Pill)", true, ["cupric oxide", "folic acid", "niacinamide", "zinc oxide"]],
    ["NICORELIEF (Chewable)", true, ["nicotine"]],
    ["NICORETTE (Chewable)", true, ["nicotine"]],
    ["NICORETTE (Oral Lozenge)", true, ["nicotine"]],
    ["Nicotine (Chewable)", true, ["nicotine"]],
    ["Nicotine (Inhalant)", false, ["nicotine"]],
    ["Nicotine (Nasal)", false, ["nicotine"]],
    ["Nicotine (Oral Lozenge)", true, ["nicotine"]],
    ["Nicotine (Pack)", false, ["nicotine"]],
    ["Nicotine (Transdermal)", false, ["nicotine"]],
    ["NICOTROL (Inhalant)", false, ["nicotine"]],
    ["NICOTROL (Nasal)", false, ["nicotine"]],
    ["NIFEdipine (Oral Pill)", true, ["nifedipine"]],
    ["NIFEdipine XR (Oral Pill)", true, ["nifedipine"]],
    ["Nifurtimox (Oral Pill)", true, ["nifurtimox"]],
    ["NIKITA (Oral Pill)", true, ["pitavastatin"]],
    ["NIKKI 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["NIKTIMVO (Injectable)", false, ["axatilimab"]],
    ["NILANDRON (Oral Pill)", true, ["nilutamide"]],
    ["Nilotinib (Oral Disintegrating)", true, ["nilotinib"]],
    ["Nilotinib (Oral Pill)", true, ["nilotinib"]],
    ["Nilutamide (Oral Pill)", true, ["nilutamide"]],
    ["NIMBEX (Injectable)", false, ["cisatracurium"]],
    ["niMODipine (Oral Liquid)", true, ["nimodipine"]],
    ["niMODipine (Oral Pill)", true, ["nimodipine"]],
    ["NIMOTOP (Oral Pill)", true, ["nimodipine"]],
    ["NINJACOF (Oral Liquid)", true, ["chlophedianol", "pyrilamine"]],
    ["NINJACOF A (Oral Liquid)", true, ["acetaminophen", "chlophedianol", "pyrilamine"]],
    ["NINJACOF XG (Oral Liquid)", true, ["codeine", "guaifenesin"]],
    ["NINLARO (Oral Pill)", true, ["ixazomib"]],
    ["Nintedanib (Oral Pill)", true, ["nintedanib"]],
    ["NIPENT (Injectable)", false, ["pentostatin"]],
    ["Nipocalimab (Injectable)", false, ["nipocalimab"]],
    ["NIPRIDE (Injectable)", false, ["nitroprusside"]],
    ["Niraparib (Oral Pill)", true, ["niraparib"]],
    ["Nirmatrelvir (Oral Pill)", true, ["nirmatrelvir"]],
    ["Nirmatrelvir/Ritonavir (Pack)", true, ["nirmatrelvir", "ritonavir"]],
    ["Nirogacestat (Oral Pill)", true, ["nirogacestat"]],
    ["Nirogacestat (Pack)", true, ["nirogacestat"]],
    ["Nirsevimab (Injectable)", false, ["nirsevimab"]],
    ["Nisoldipine XR (Oral Pill)", true, ["nisoldipine"]],
    ["Nitazoxanide (Oral Liquid)", true, ["nitazoxanide"]],
    ["Nitazoxanide (Oral Pill)", true, ["nitazoxanide"]],
    ["NITHIODOTE (Pack)", false, ["sodium nitrite", "thiosulfate"]],
    ["Nitisinone (Oral Liquid)", true, ["nitisinone"]],
    ["Nitisinone (Oral Pill)", true, ["nitisinone"]],
    ["Nitric oxide/Nitrogen (Inhalant)", false, ["nitric oxide", "nitrogen"]],
    ["NITRO-BID (Topical)", false, ["nitroglycerin"]],
    ["NITRO-DUR (Transdermal)", false, ["nitroglycerin"]],
    ["Nitrofurantoin (Oral Liquid)", true, ["nitrofurantoin"]],
    ["Nitrofurantoin (Oral Pill)", true, ["nitrofurantoin"]],
    ["Nitrogen (Inhalant)", false, ["nitrogen"]],
    ["Nitrogen (Topical)", false, ["nitrogen"]],
    ["Nitrogen/Oxygen (Inhalant)", false, ["nitrogen", "oxygen"]],
    ["Nitroglycerin (Injectable)", false, ["nitroglycerin"]],
    ["Nitroglycerin (Mucosal)", false, ["nitroglycerin"]],
    ["Nitroglycerin (Rectal)", false, ["nitroglycerin"]],
    ["Nitroglycerin (Sublingual)", false, ["nitroglycerin"]],
    ["Nitroglycerin (Topical)", false, ["nitroglycerin"]],
    ["Nitroglycerin (Transdermal)", false, ["nitroglycerin"]],
    ["Nitroglycerin XR (Oral Pill)", true, ["nitroglycerin"]],
    ["NITROLINGUAL (Mucosal)", false, ["nitroglycerin"]],
    ["NITROMIST (Mucosal)", false, ["nitroglycerin"]],
    ["Nitroprusside (Injectable)", false, ["nitroprusside"]],
    ["NITROSTAT (Sublingual)", false, ["nitroglycerin"]],
    ["Nitrous oxide (Inhalant)", false, ["nitrous oxide"]],
    ["NITYR (Oral Pill)", true, ["nitisinone"]],
    ["NIVA THYROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["NIVESTYM (Injectable)", false, ["filgrastim"]],
    ["Nivolumab (Injectable)", false, ["nivolumab"]],
    ["Nivolumab/Relatlimab (Injectable)", false, ["nivolumab", "relatlimab"]],
    ["NIX CREAM RINSE (Shampoo)", false, ["permethrin"]],
    ["Nizatidine (Oral Liquid)", true, ["nizatidine"]],
    ["Nizatidine (Oral Pill)", true, ["nizatidine"]],
    ["NIZORAL (Shampoo)", false, ["ketoconazole"]],
    ["NIZORAL PSORIASIS (Shampoo)", false, ["salicylic acid"]],
    ["NIZORAL PSORIASIS (Topical)", false, ["salicylic acid"]],
    ["NO DOZ (Oral Pill)", true, ["caffeine"]],
    ["NOCDURNA (Sublingual)", false, ["desmopressin"]],
    ["NOCTIVA (Nasal)", false, ["desmopressin"]],
    ["Nogapendekin alfa inbakicept (Intravesical)", false, ["nogapendekin alfa inbakicept"]],
    ["Nonoxynol-9 (Vaginal)", false, ["nonoxynol-9"]],
    ["NORA-BE 28 DAY (Pack)", true, ["norethindrone"]],
    ["NORCO (Oral Pill)", true, ["acetaminophen", "hydrocodone"]],
    ["NORDITROPIN (Injectable)", false, ["somatropin"]],
    ["Norepinephrine (Injectable)", false, ["norepinephrine"]],
    ["Norethindrone (Oral Pill)", true, ["norethindrone"]],
    ["Norethindrone (Pack)", true, ["norethindrone"]],
    ["NORGESIC (Oral Pill)", true, ["aspirin", "caffeine", "orphenadrine"]],
    ["Norgestrel (Oral Pill)", true, ["norgestrel"]],
    ["Norgestrel (Pack)", true, ["norgestrel"]],
    ["NORISC (Topical)", false, ["benzethonium"]],
    ["NORITATE (Topical)", false, ["metronidazole"]],
    ["NORLIQVA (Oral Liquid)", true, ["amlodipine"]],
    ["NORLYDA 28 DAY (Pack)", true, ["norethindrone"]],
    ["NORLYROC 28 DAY (Pack)", true, ["norethindrone"]],
    ["NORMLSHIELD (Topical)", false, ["dimethicone"]],
    ["NORMOSOL-M (Injectable)", false, ["glucose", "magnesium acetate", "potassium acetate", "sodium chloride"]],
    ["NORMOSOL-R (Injectable)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["NORMOSOL-R IN 5 % DEXTROSE (Injectable)", false, ["glucose", "magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["NORPACE (Oral Pill)", true, ["disopyramide"]],
    ["NORPACE XR (Oral Pill)", true, ["disopyramide"]],
    ["NORPRAMIN (Oral Pill)", true, ["desipramine"]],
    ["North American coral snake antivenin (Injectable)", false, ["North American coral snake antivenin"]],
    ["NORTHERA (Oral Pill)", true, ["droxidopa"]],
    ["NORTREL 0.5/35 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["NORTREL 1/35 21 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["NORTREL 1/35 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["NORTREL 7/7/7 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["Nortriptyline (Oral Liquid)", true, ["nortriptyline"]],
    ["Nortriptyline (Oral Pill)", true, ["nortriptyline"]],
    ["NORVASC (Oral Pill)", true, ["amlodipine"]],
    ["NORVIR (Oral Pill)", true, ["ritonavir"]],
    ["NORVIR (Oral Powder)", true, ["ritonavir"]],
    ["NOSTRILLA (Nasal)", false, ["oxymetazoline"]],
    ["NOURESS (Injectable)", false, ["cysteine"]],
    ["NOURIANZ (Oral Pill)", true, ["istradefylline"]],
    ["NOVACORT (Topical)", false, ["hydrocortisone", "pramoxine"]],
    ["NOVAREL (Injectable)", false, ["chorionic gonadotropin"]],
    ["NOVOEIGHT (Injectable)", false, ["factor VIII"]],
    ["NovoLIN (Injectable)", false, ["insulin isophane", "insulin, regular, human"]],
    ["NovoLIN N (Injectable)", false, ["insulin isophane"]],
    ["NovoLIN R (Injectable)", false, ["insulin, regular, human"]],
    ["NovoLOG (Injectable)", false, ["insulin aspart, human"]],
    ["NovoLOG MIX (Injectable)", false, ["insulin aspart protamine, human", "insulin aspart, human"]],
    ["NOVOSEVEN (Injectable)", false, ["factor VIIa"]],
    ["NOXAFIL (Injectable)", false, ["posaconazole"]],
    ["NOXAFIL (Oral Liquid)", true, ["posaconazole"]],
    ["NOXAFIL (Oral Pill)", true, ["posaconazole"]],
    ["NOXAFIL (Oral Suspension Powder)", true, ["posaconazole"]],
    ["NOXIVENT (Inhalant)", false, ["nitric oxide", "nitrogen"]],
    ["NOXZEMA CLEAN (Topical)", false, ["salicylic acid"]],
    ["NP THYROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["NPLATE (Injectable)", false, ["romiplostim"]],
    ["NU-IRON 150 (Oral Pill)", true, ["polysaccharide iron complex"]],
    ["NUBEQA (Oral Pill)", true, ["darolutamide"]],
    ["NUCALA (Injectable)", false, ["mepolizumab"]],
    ["NUCORT (Topical)", false, ["hydrocortisone"]],
    ["NUCYNTA (Oral Pill)", true, ["tapentadol"]],
    ["NUCYNTA XR (Oral Pill)", true, ["tapentadol"]],
    ["NUEDEXTA (Oral Pill)", true, ["dextromethorphan", "quinidine"]],
    ["NUFYMCO (Injectable)", false, ["ranibizumab"]],
    ["NULEV (Oral Disintegrating)", true, ["hyoscyamine"]],
    ["NULIBRY (Injectable)", false, ["fosdenopterin"]],
    ["NULOJIX (Injectable)", false, ["belatacept"]],
    ["NUMBRINO (Nasal)", false, ["cocaine"]],
    ["NUMOTIZINE (Topical)", false, ["menthol"]],
    ["NUOX (Topical)", false, ["benzoyl peroxide", "sulfur"]],
    ["NUPERCAINAL (Rectal)", false, ["dibucaine"]],
    ["NUPLAZID (Oral Pill)", true, ["pimavanserin"]],
    ["NUPRIN BACKACHE (Oral Pill)", true, ["magnesium salicylate"]],
    ["NUPRO CHLORHEXIDINE (Mouthwash)", false, ["chlorhexidine"]],
    ["NURTEC (Oral Disintegrating)", true, ["rimegepant"]],
    ["Nusinersen (Injectable)", false, ["nusinersen"]],
    ["NUTRALOX (Chewable)", true, ["calcium carbonate"]],
    ["NUTRAPLUS (Topical)", false, ["urea"]],
    ["NUTRILIPID (Injectable)", false, ["soybean oil"]],
    ["NUTRILYTE (Injectable)", false, ["calcium acetate", "magnesium acetate", "potassium acetate", "potassium chloride", "sodium acetate", "sodium gluconate"]],
    ["NUTROPIN (Injectable)", false, ["somatropin"]],
    ["NUVARING (Vaginal)", false, ["ethinyl estradiol", "etonogestrel"]],
    ["NUVAXOVID 2026-2027 (Injectable)", false, ["SARS-COV-2 (COVID-19) vaccine, subunit, recombinant spike protein"]],
    ["NUVESSA (Vaginal)", false, ["metronidazole"]],
    ["NUVIGIL (Oral Pill)", true, ["armodafinil"]],
    ["NUWIQ (Injectable)", false, ["factor VIII"]],
    ["NUZOLVENCE (Oral Suspension Granules)", true, ["zoliflodacin"]],
    ["NUZYRA (Injectable)", false, ["omadacycline"]],
    ["NUZYRA (Oral Pill)", true, ["omadacycline"]],
    ["NYAMYC (Topical)", false, ["nystatin"]],
    ["NYDAMAX (Topical)", false, ["metronidazole"]],
    ["NYLIA 1/35 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["NYLIA 7/7/7 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["NYMALIZE (Oral Liquid)", true, ["nimodipine"]],
    ["NYMYO 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["NYPOZI (Injectable)", false, ["filgrastim"]],
    ["Nystatin (Oral Liquid)", true, ["nystatin"]],
    ["Nystatin (Oral Pill)", true, ["nystatin"]],
    ["Nystatin (Topical)", false, ["nystatin"]],
    ["Nystatin/Triamcinolone (Topical)", false, ["nystatin", "triamcinolone"]],
    ["NYSTOP (Topical)", false, ["nystatin"]],
    ["NYTOL (Oral Pill)", true, ["diphenhydramine"]],
    ["NYVEPRIA (Injectable)", false, ["pegfilgrastim"]],
    ["O-palmitoylascorbic acid/Alpha tocopherol/levOCARNitine/Ubidecarenone (Oral Pill)", true, ["6-O-palmitoylascorbic acid", "alpha tocopherol", "levocarnitine", "ubidecarenone"]],
    ["OASIS TEARS (Ophthalmic)", false, ["glycerin"]],
    ["Obecabtagene autoleucel (Injectable)", false, ["obecabtagene autoleucel"]],
    ["Obecabtagene autoleucel (Pack)", false, ["obecabtagene autoleucel"]],
    ["Obeticholic acid (Oral Pill)", true, ["obeticholic acid"]],
    ["Obiltoxaximab (Injectable)", false, ["obiltoxaximab"]],
    ["Obinutuzumab (Injectable)", false, ["obinutuzumab"]],
    ["OBIZUR (Injectable)", false, ["factor VIII"]],
    ["OBREDON (Oral Liquid)", true, ["guaifenesin", "hydrocodone"]],
    ["OCALIVA (Oral Pill)", true, ["obeticholic acid"]],
    ["OCEAN BLUE NUTRITIONALS OMEGA-3 1450 (Oral Pill)", true, ["docosahexaenoate", "eicosapentaenoate", "omega-3 acid ethyl esters (USP)"]],
    ["OCELLA 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["Ocrelizumab (Injectable)", false, ["ocrelizumab"]],
    ["OCREVUS (Injectable)", false, ["ocrelizumab"]],
    ["OCREVUS ZUNOVO (Injectable)", false, ["hyaluronidase", "ocrelizumab"]],
    ["OCTAGAM (Injectable)", false, ["immunoglobulin G"]],
    ["Octreotide (Injectable)", false, ["octreotide"]],
    ["Octreotide (Oral Pill)", true, ["octreotide"]],
    ["OCUFEN (Ophthalmic)", false, ["flurbiprofen"]],
    ["OCUFLOX (Ophthalmic)", false, ["ofloxacin"]],
    ["OCUVITE (Oral Pill)", true, ["ascorbic acid", "beta carotene", "cuprous oxide", "lutein", "sodium selenate", "vitamin E", "zinc oxide"]],
    ["OCUVITE LUTEIN (Oral Pill)", true, ["ascorbic acid", "cuprous oxide", "lutein", "vitamin E", "zinc oxide"]],
    ["ODACTRA (Sublingual)", false, ["American house dust mite allergenic extract", "European house dust mite allergenic extract"]],
    ["ODEFSEY (Oral Pill)", true, ["emtricitabine", "rilpivirine", "tenofovir alafenamide"]],
    ["Odevixibat (Oral Pellet)", true, ["odevixibat"]],
    ["Odevixibat (Oral Pill)", true, ["odevixibat"]],
    ["ODOMZO (Oral Pill)", true, ["sonidegib"]],
    ["Ofatumumab (Injectable)", false, ["ofatumumab"]],
    ["OFEV (Oral Pill)", true, ["nintedanib"]],
    ["Ofloxacin (Ophthalmic)", false, ["ofloxacin"]],
    ["Ofloxacin (Oral Pill)", true, ["ofloxacin"]],
    ["Ofloxacin (Otic)", false, ["ofloxacin"]],
    ["OGIVRI (Injectable)", false, ["trastuzumab"]],
    ["OGSIVEO (Oral Pill)", true, ["nirogacestat"]],
    ["OGSIVEO 100 MG 7-DAY (Pack)", true, ["nirogacestat"]],
    ["OGSIVEO 150 MG 7-DAY (Pack)", true, ["nirogacestat"]],
    ["OHTUVAYRE (Inhalant)", false, ["ensifentrine"]],
    ["OJEMDA (Oral Pill)", true, ["tovorafenib"]],
    ["OJEMDA (Oral Suspension Powder)", true, ["tovorafenib"]],
    ["OJEMDA 400 MG ONCE WEEKLY CARTON (Pack)", true, ["tovorafenib"]],
    ["OJEMDA 500 MG ONCE WEEKLY CARTON (Pack)", true, ["tovorafenib"]],
    ["OJEMDA 600 MG ONCE WEEKLY CARTON (Pack)", true, ["tovorafenib"]],
    ["OJJAARA (Oral Pill)", true, ["momelotinib"]],
    ["OLANZapine (Injectable)", false, ["olanzapine"]],
    ["OLANZapine (Oral Disintegrating)", true, ["olanzapine"]],
    ["OLANZapine (Oral Pill)", true, ["olanzapine"]],
    ["OLANZapine/Samidorphan (Oral Pill)", true, ["olanzapine", "samidorphan"]],
    ["Olaparib (Oral Pill)", true, ["olaparib"]],
    ["Olezarsen (Injectable)", false, ["olezarsen"]],
    ["Oliceridine (Injectable)", false, ["oliceridine"]],
    ["OLINVYK (Injectable)", false, ["oliceridine"]],
    ["Olipudase alfa (Injectable)", false, ["olipudase alfa"]],
    ["Olive oil/Soybean oil (Injectable)", false, ["olive oil", "soybean oil"]],
    ["Olmesartan (Oral Pill)", true, ["olmesartan"]],
    ["Olodaterol (Inhalant)", false, ["olodaterol"]],
    ["Olodaterol/Tiotropium (Inhalant)", false, ["olodaterol", "tiotropium"]],
    ["Olopatadine (Nasal)", false, ["olopatadine"]],
    ["Olopatadine (Ophthalmic)", false, ["olopatadine"]],
    ["OLPRUVA (Oral Suspension Granules)", true, ["phenylbutyrate"]],
    ["OLPRUVA 2 GM PACK (Pack)", false, ["phenylbutyrate"]],
    ["OLPRUVA 3 GM PACK (Pack)", false, ["phenylbutyrate"]],
    ["OLPRUVA 4 GM PACK (Pack)", false, ["phenylbutyrate"]],
    ["OLPRUVA 5 GM PACK (Pack)", false, ["phenylbutyrate"]],
    ["OLPRUVA 6 GM PACK (Pack)", false, ["phenylbutyrate"]],
    ["OLPRUVA 6.67 GM PACK (Pack)", false, ["phenylbutyrate"]],
    ["Olsalazine (Oral Pill)", true, ["olsalazine"]],
    ["OLUMIANT (Oral Pill)", true, ["baricitinib"]],
    ["Olutasidenib (Oral Pill)", true, ["olutasidenib"]],
    ["OLUX (Topical)", false, ["clobetasol"]],
    ["Omacetaxine mepesuccinate (Injectable)", false, ["omacetaxine mepesuccinate"]],
    ["Omadacycline (Injectable)", false, ["omadacycline"]],
    ["Omadacycline (Oral Pill)", true, ["omadacycline"]],
    ["Omalizumab (Injectable)", false, ["omalizumab"]],
    ["Omaveloxolone (Oral Pill)", true, ["omaveloxolone"]],
    ["OMECLAMOX (Pack)", true, ["amoxicillin", "clarithromycin", "omeprazole"]],
    ["Omega-3 acid ethyl esters (USP) (Oral Pill)", true, ["omega-3 acid ethyl esters (USP)"]],
    ["OMEGAVEN (Injectable)", false, ["fish oil (containing omega-3 acids)"]],
    ["Omeprazole (Oral Disintegrating)", true, ["omeprazole"]],
    ["Omeprazole (Oral Pill)", true, ["omeprazole"]],
    ["Omeprazole (Oral Suspension Granules)", true, ["omeprazole"]],
    ["Omeprazole/Sodium bicarbonate (Oral Liquid)", true, ["omeprazole", "sodium bicarbonate"]],
    ["Omeprazole/Sodium bicarbonate (Oral Pill)", true, ["omeprazole", "sodium bicarbonate"]],
    ["Omeprazole/Sodium bicarbonate (Oral Suspension Powder)", true, ["omeprazole", "sodium bicarbonate"]],
    ["Omidenepag (Ophthalmic)", false, ["omidenepag"]],
    ["OMIDRIA (Ophthalmic)", false, ["ketorolac", "phenylephrine"]],
    ["Omidubicel (Injectable)", false, ["omidubicel"]],
    ["Omidubicel (Pack)", false, ["omidubicel"]],
    ["OMISIRGE (Pack)", false, ["omidubicel"]],
    ["OMLONTI (Ophthalmic)", false, ["omidenepag"]],
    ["OMLYCLO (Injectable)", false, ["omalizumab"]],
    ["OMNARIS (Nasal)", false, ["ciclesonide"]],
    ["OMNI GEL (Oral Gel)", true, ["stannous fluoride"]],
    ["OMNITROPE (Injectable)", false, ["somatropin"]],
    ["OMVOH (Injectable)", false, ["mirikizumab"]],
    ["OMVOH PREFILLED PEN 300 MG DOSE CARTON (Pack)", false, ["mirikizumab"]],
    ["OMVOH PREFILLED SYRINGE 300 MG DOSE CARTON (Pack)", false, ["mirikizumab"]],
    ["ONAPGO (Injectable)", false, ["apomorphine"]],
    ["Onasemnogene abeparvovec (Injectable)", false, ["onasemnogene abeparvovec"]],
    ["Onasemnogene abeparvovec (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ONCASPAR (Injectable)", false, ["pegaspargase"]],
    ["Ondansetron (Injectable)", false, ["ondansetron"]],
    ["Ondansetron (Oral Disintegrating)", true, ["ondansetron"]],
    ["Ondansetron (Oral Liquid)", true, ["ondansetron"]],
    ["Ondansetron (Oral Pill)", true, ["ondansetron"]],
    ["ONEXTON (Topical)", false, ["benzoyl peroxide", "clindamycin"]],
    ["ONFI (Oral Liquid)", true, ["clobazam"]],
    ["ONFI (Oral Pill)", true, ["clobazam"]],
    ["ONGENTYS (Oral Pill)", true, ["opicapone"]],
    ["ONGLYZA (Oral Pill)", true, ["saxagliptin"]],
    ["ONIVYDE (Injectable)", false, ["irinotecan"]],
    ["ONPATTRO (Injectable)", false, ["patisiran"]],
    ["ONSWIK (Injectable)", false, ["insulin efsitora alfa"]],
    ["ONTRALFY (Oral Liquid)", true, ["tizanidine"]],
    ["ONTRUZANT (Injectable)", false, ["trastuzumab"]],
    ["ONUREG (Oral Pill)", true, ["azacitidine"]],
    ["ONYDA XR (Oral Liquid)", true, ["clonidine"]],
    ["ONZETRA (Nasal)", false, ["sumatriptan"]],
    ["OPCICON ONE-STEP (Oral Pill)", true, ["levonorgestrel"]],
    ["OPCON-A (Ophthalmic)", false, ["naphazoline", "pheniramine"]],
    ["OPDIVO (Injectable)", false, ["nivolumab"]],
    ["OPDIVO QVANTIG (Injectable)", false, ["hyaluronidase", "nivolumab"]],
    ["OPDUALAG (Injectable)", false, ["nivolumab", "relatlimab"]],
    ["OPFOLDA (Oral Pill)", true, ["miglustat"]],
    ["Opicapone (Oral Pill)", true, ["opicapone"]],
    ["OPILL 28 DAY (Pack)", true, ["norgestrel"]],
    ["OPIPZA (Oral Film)", true, ["aripiprazole"]],
    ["Opium (Oral Liquid)", true, ["opium"]],
    ["Oprelvekin (Injectable)", false, ["oprelvekin"]],
    ["OPSUMIT (Oral Pill)", true, ["macitentan"]],
    ["OPSYNVI (Oral Pill)", true, ["macitentan", "tadalafil"]],
    ["OPTIFLEX-C (Oral Pill)", true, ["chondroitin sulfates"]],
    ["OPTIFLEX-G (Oral Pill)", true, ["glucosamine"]],
    ["OPTIGENE (Ophthalmic)", false, ["tetrahydrozoline"]],
    ["OPTION 2 (Oral Pill)", true, ["levonorgestrel"]],
    ["OPUVIZ (Injectable)", false, ["aflibercept"]],
    ["OPVEE (Nasal)", false, ["nalmefene"]],
    ["OPZELURA (Topical)", false, ["ruxolitinib"]],
    ["ORA RELIEF (Mucosal)", false, ["phenol"]],
    ["ORABASE (Oral Paste)", true, ["benzocaine"]],
    ["ORABASE (Topical)", false, ["benzocaine"]],
    ["ORABLOC (Injectable)", false, ["articaine", "epinephrine"]],
    ["ORACEA (Oral Pill)", true, ["doxycycline"]],
    ["ORACIT (Oral Liquid)", true, ["citric acid", "sodium citrate"]],
    ["ORAJEL (Mucosal)", false, ["benzocaine"]],
    ["ORAJEL (Oral Gel)", true, ["benzocaine"]],
    ["ORAJEL (Oral Paste)", true, ["benzocaine"]],
    ["ORAJEL (Topical)", false, ["benzocaine"]],
    ["ORALAIR 100 (Sublingual)", false, ["Kentucky bluegrass pollen extract", "Timothy grass pollen extract", "orchard grass pollen extract", "perennial rye grass pollen extract", "sweet vernal grass pollen extract"]],
    ["ORALAIR 300 (Sublingual)", false, ["Kentucky bluegrass pollen extract", "Timothy grass pollen extract", "orchard grass pollen extract", "perennial rye grass pollen extract", "sweet vernal grass pollen extract"]],
    ["ORALAIR CHILDREN AND ADOLESCENTS SAMPLE KIT (Pack)", false, ["Kentucky bluegrass pollen extract", "Timothy grass pollen extract", "orchard grass pollen extract", "perennial rye grass pollen extract", "sweet vernal grass pollen extract"]],
    ["ORALONE (Oral Paste)", true, ["triamcinolone"]],
    ["ORAMAGIC PLUS (Oral Liquid)", true, ["benzocaine"]],
    ["ORAPRED (Oral Disintegrating)", true, ["prednisolone"]],
    ["ORAQIX (Mucosal)", false, ["lidocaine", "prilocaine"]],
    ["ORASEP REFORMULATED DEC 2013 (Mucosal)", false, ["benzocaine", "cetylpyridinium", "menthol"]],
    ["ORAVERSE (Injectable)", false, ["phentolamine"]],
    ["ORAVIG (Buccal)", false, ["miconazole"]],
    ["ORAZINC (Oral Pill)", true, ["zinc sulfate"]],
    ["ORBACTIV (Injectable)", false, ["oritavancin"]],
    ["ORENCIA (Injectable)", false, ["abatacept"]],
    ["ORENITRAM MONTH 1 TITRATION KIT (Pack)", true, ["treprostinil"]],
    ["ORENITRAM MONTH 2 TITRATION KIT (Pack)", true, ["treprostinil"]],
    ["ORENITRAM MONTH 3 TITRATION KIT (Pack)", true, ["treprostinil"]],
    ["ORENITRAM XR (Oral Pill)", true, ["treprostinil"]],
    ["ORFADIN (Oral Liquid)", true, ["nitisinone"]],
    ["ORFADIN (Oral Pill)", true, ["nitisinone"]],
    ["Orforglipron (Oral Pill)", true, ["orforglipron"]],
    ["ORGOVYX (Oral Pill)", true, ["relugolix"]],
    ["ORIAHNN 28 DAY KIT (Pack)", true, ["elagolix", "estradiol", "norethindrone"]],
    ["ORILISSA (Oral Pill)", true, ["elagolix"]],
    ["Oritavancin (Injectable)", false, ["oritavancin"]],
    ["ORKAMBI (Oral Granules)", true, ["ivacaftor", "lumacaftor"]],
    ["ORKAMBI (Oral Pill)", true, ["ivacaftor", "lumacaftor"]],
    ["ORLADEYO (Oral Pellet)", true, ["berotralstat"]],
    ["ORLADEYO (Oral Pill)", true, ["berotralstat"]],
    ["Orlistat (Oral Pill)", true, ["orlistat"]],
    ["ORLYNVAH (Oral Pill)", true, ["probenecid", "sulopenem"]],
    ["ORMALVI (Oral Pill)", true, ["dichlorphenamide"]],
    ["ORO CLENSE (Mouthwash)", false, ["chlorhexidine"]],
    ["Orphenadrine (Injectable)", false, ["orphenadrine"]],
    ["Orphenadrine XR (Oral Pill)", true, ["orphenadrine"]],
    ["ORPHENGESIC (Oral Pill)", true, ["aspirin", "caffeine", "orphenadrine"]],
    ["ORQUIDEA 28 DAY (Pack)", true, ["norethindrone"]],
    ["ORSERDU (Oral Pill)", true, ["elacestrant"]],
    ["ORSYTHIA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["ORTHO MICRONOR 28 DAY (Pack)", true, ["norethindrone"]],
    ["ORTHO TRI-CYCLEN 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["ORTHO-NESIC (Topical)", false, ["camphor", "menthol"]],
    ["ORTHO-NOVUM 7/7/7 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["ORTHOVISC (Injectable)", false, ["hyaluronate"]],
    ["ORTIKOS XR (Oral Pill)", true, ["budesonide"]],
    ["ORUDIS (Oral Pill)", true, ["ketoprofen"]],
    ["OS-CAL 500 WITH D (Chewable)", true, ["calcium carbonate", "cholecalciferol"]],
    ["OS-CAL 500 WITH D (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["OSCAL 500 (Oral Pill)", true, ["calcium carbonate"]],
    ["OSCIMIN (Oral Disintegrating)", true, ["hyoscyamine"]],
    ["OSCIMIN (Oral Pill)", true, ["hyoscyamine"]],
    ["OSCIMIN (Sublingual)", false, ["hyoscyamine"]],
    ["OSCIMIN XR (Oral Pill)", true, ["hyoscyamine"]],
    ["Oseltamivir (Oral Liquid)", true, ["oseltamivir"]],
    ["Oseltamivir (Oral Pill)", true, ["oseltamivir"]],
    ["OSENI (Oral Pill)", true, ["alogliptin", "pioglitazone"]],
    ["OSENVELT (Injectable)", false, ["denosumab"]],
    ["Osilodrostat (Oral Pill)", true, ["osilodrostat"]],
    ["Osimertinib (Oral Pill)", true, ["osimertinib"]],
    ["OSMITROL (Injectable)", false, ["mannitol"]],
    ["OSMOLEX 322 MG DAILY DOSING (Pack)", true, ["amantadine"]],
    ["OSMOLEX XR (Oral Pill)", true, ["amantadine"]],
    ["Ospemifene (Oral Pill)", true, ["ospemifene"]],
    ["OSPHENA (Oral Pill)", true, ["ospemifene"]],
    ["OSPOMYV (Injectable)", false, ["denosumab"]],
    ["OSTEO-PORETICAL (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["OSVYRTI (Injectable)", false, ["denosumab"]],
    ["OTARMENI (Injectable)", false, ["lunsotogene parvec"]],
    ["Oteseconazole (Oral Pill)", true, ["oteseconazole"]],
    ["Oteseconazole (Pack)", true, ["oteseconazole"]],
    ["OTEZLA (Oral Pill)", true, ["apremilast"]],
    ["OTEZLA 14-DAY 10/20 STARTER PACK (Pack)", true, ["apremilast"]],
    ["OTEZLA 14-DAY 10/20/30 STARTER PACK (Pack)", true, ["apremilast"]],
    ["OTEZLA 28-DAY 10/20 STARTER PACK (Pack)", true, ["apremilast"]],
    ["OTEZLA 28-DAY 10/20/30 STARTER PACK (Pack)", true, ["apremilast"]],
    ["OTEZLA 28-DAY 10/20/30/75 STARTER PACK (Pack)", true, ["apremilast"]],
    ["OTEZLA XR (Oral Pill)", true, ["apremilast"]],
    ["OTICIN HC (Otic)", false, ["hydrocortisone", "neomycin", "polymyxin B"]],
    ["OTOVEL (Otic)", false, ["ciprofloxacin", "fluocinolone"]],
    ["OTREXUP (Injectable)", false, ["methotrexate"]],
    ["OTULFI (Injectable)", false, ["ustekinumab"]],
    ["OUTGRO PAIN RELIEF (Topical)", false, ["benzocaine"]],
    ["OVACE (Shampoo)", false, ["sulfacetamide"]],
    ["OVACE (Soap)", false, ["sulfacetamide"]],
    ["OVACE (Topical)", false, ["sulfacetamide"]],
    ["OVIDE (Topical)", false, ["malathion"]],
    ["OVIDREL (Injectable)", false, ["chorionic gonadotropin"]],
    ["Oxacillin (Injectable)", false, ["oxacillin"]],
    ["Oxaliplatin (Injectable)", false, ["oxaliplatin"]],
    ["Oxandrolone (Oral Pill)", true, ["oxandrolone"]],
    ["Oxaprozin (Oral Pill)", true, ["oxaprozin"]],
    ["OXAYDO (Oral Pill)", true, ["oxycodone"]],
    ["Oxazepam (Oral Pill)", true, ["oxazepam"]],
    ["OXcarbazepine (Oral Liquid)", true, ["oxcarbazepine"]],
    ["OXcarbazepine (Oral Pill)", true, ["oxcarbazepine"]],
    ["OXcarbazepine XR (Oral Pill)", true, ["oxcarbazepine"]],
    ["OXERVATE (Ophthalmic)", false, ["cenegermin"]],
    ["Oxiconazole (Topical)", false, ["oxiconazole"]],
    ["OXIPOR VHC (Topical)", false, ["coal tar"]],
    ["OXISTAT (Topical)", false, ["oxiconazole"]],
    ["OXLUMO (Injectable)", false, ["lumasiran"]],
    ["OXTELLAR XR (Oral Pill)", true, ["oxcarbazepine"]],
    ["Oxybate (Oral Liquid)", true, ["oxybate"]],
    ["Oxybate (Oral Suspension Granules)", true, ["oxybate"]],
    ["Oxybate (Pack)", false, ["oxybate"]],
    ["oxyBUTYnin (Oral Liquid)", true, ["oxybutynin"]],
    ["oxyBUTYnin (Oral Pill)", true, ["oxybutynin"]],
    ["oxyBUTYnin (Topical)", false, ["oxybutynin"]],
    ["oxyBUTYnin (Transdermal)", false, ["oxybutynin"]],
    ["oxyBUTYnin XR (Oral Pill)", true, ["oxybutynin"]],
    ["Oxychlorosene (Topical)", false, ["oxychlorosene"]],
    ["oxyCODONE (Oral Liquid)", true, ["oxycodone"]],
    ["oxyCODONE (Oral Pill)", true, ["oxycodone"]],
    ["oxyCODONE XR (Oral Pill)", true, ["oxycodone"]],
    ["OxyCONTIN XR (Oral Pill)", true, ["oxycodone"]],
    ["Oxygen (Inhalant)", false, ["oxygen"]],
    ["Oxymetazoline (Nasal)", false, ["oxymetazoline"]],
    ["Oxymetazoline (Ophthalmic)", false, ["oxymetazoline"]],
    ["Oxymetazoline (Topical)", false, ["oxymetazoline"]],
    ["Oxymetazoline/Tetracaine (Nasal)", false, ["oxymetazoline", "tetracaine"]],
    ["oxyMORphone (Oral Pill)", true, ["oxymorphone"]],
    ["oxyMORphone XR (Oral Pill)", true, ["oxymorphone"]],
    ["Oxytocin (Injectable)", false, ["oxytocin"]],
    ["OXYTROL (Transdermal)", false, ["oxybutynin"]],
    ["OYSCO 500 WITH D (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["OYSCO D (Oral Pill)", true, ["calcium carbonate", "cholecalciferol"]],
    ["Ozanimod (Oral Pill)", true, ["ozanimod"]],
    ["Ozanimod (Pack)", true, ["ozanimod"]],
    ["OZEMPIC (Injectable)", false, ["semaglutide"]],
    ["OZEMPIC (Oral Pill)", true, ["semaglutide"]],
    ["Ozenoxacin (Topical)", false, ["ozenoxacin"]],
    ["OZILTUS (Injectable)", false, ["denosumab"]],
    ["OZOBAX (Oral Liquid)", true, ["baclofen"]],
    ["OZURDEX (Implant)", false, ["dexamethasone"]],
    ["P & S (Shampoo)", false, ["salicylic acid"]],
    ["P-hydroxyamphetamine/Tropicamide (Ophthalmic)", false, ["p-hydroxyamphetamine", "tropicamide"]],
    ["PACERONE (Oral Pill)", true, ["amiodarone"]],
    ["PACLitaxel (Injectable)", false, ["paclitaxel"]],
    ["PACNEX (Soap)", false, ["benzoyl peroxide"]],
    ["PACNEX (Topical)", false, ["benzoyl peroxide"]],
    ["Pacritinib (Oral Pill)", true, ["pacritinib"]],
    ["PADCEV (Injectable)", false, ["enfortumab"]],
    ["Palbociclib (Oral Pill)", true, ["palbociclib"]],
    ["PALFORZIA (Oral Powder)", true, ["peanut allergenic extract"]],
    ["PALFORZIA 1 MG (LEVEL 0) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 12 MG (LEVEL 3) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 120 MG (LEVEL 7) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 160 MG (LEVEL 8) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 20 MG (LEVEL 4) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 200 MG (LEVEL 9) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 240 MG (LEVEL 10) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 3 MG (LEVEL 1) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 300 MG (LEVEL 11) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 40 MG (LEVEL 5) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 6 MG (LEVEL 2) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA 80 MG (LEVEL 6) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA INITIAL DOSE ESCALATION (1 - 3 YEARS) (Pack)", false, ["peanut allergenic extract"]],
    ["PALFORZIA INITIAL DOSE ESCALATION (Pack)", false, ["peanut allergenic extract"]],
    ["Palifermin (Injectable)", false, ["palifermin"]],
    ["Paliperidone (Injectable)", false, ["paliperidone"]],
    ["Paliperidone XR (Oral Pill)", true, ["paliperidone"]],
    ["Palivizumab (Injectable)", false, ["palivizumab"]],
    ["Palonosetron (Injectable)", false, ["palonosetron"]],
    ["Palovarotene (Oral Pill)", true, ["palovarotene"]],
    ["PALSONIFY (Oral Pill)", true, ["paltusotine"]],
    ["Paltusotine (Oral Pill)", true, ["paltusotine"]],
    ["PALYNZIQ (Injectable)", false, ["pegvaliase"]],
    ["Pamabrom (Oral Pill)", true, ["pamabrom"]],
    ["PAMELOR (Oral Pill)", true, ["nortriptyline"]],
    ["Pamidronate (Injectable)", false, ["pamidronate"]],
    ["PAMINE (Oral Pill)", true, ["methscopolamine"]],
    ["PAMPRIN CRAMP FORMULA (Oral Pill)", true, ["acetaminophen", "magnesium salicylate", "pamabrom"]],
    ["PAMPRIN MAX FORMULA (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine"]],
    ["PAMPRIN MULTI-SYMPTOM (Oral Pill)", true, ["acetaminophen", "pamabrom", "pyrilamine"]],
    ["PANADOL (Oral Liquid)", true, ["acetaminophen"]],
    ["PANADOL (Oral Pill)", true, ["acetaminophen"]],
    ["PANADOL EXTRA (Oral Pill)", true, ["acetaminophen", "caffeine"]],
    ["PANADOL PM (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["PANCREAZE (Oral Pill)", true, ["amylase", "lipase", "protease"]],
    ["Pancuronium (Injectable)", false, ["pancuronium"]],
    ["PANDEL (Topical)", false, ["hydrocortisone"]],
    ["PANHEMATIN (Injectable)", false, ["hemin"]],
    ["Panitumumab (Injectable)", false, ["panitumumab"]],
    ["Panobinostat (Oral Pill)", true, ["panobinostat"]],
    ["PANRETIN (Topical)", false, ["alitretinoin"]],
    ["Pantethine XR (Oral Pill)", true, ["pantethine"]],
    ["Pantoprazole (Injectable)", false, ["pantoprazole"]],
    ["Pantoprazole (Oral Granules)", true, ["pantoprazole"]],
    ["Pantoprazole (Oral Pill)", true, ["pantoprazole"]],
    ["Pantothenate (Oral Pill)", true, ["pantothenate"]],
    ["PANZYGA (Injectable)", false, ["immunoglobulin G"]],
    ["Papain (Oral Pill)", true, ["papain"]],
    ["Papain/Urea (Topical)", false, ["papain", "urea"]],
    ["Papaverine (Injectable)", false, ["papaverine"]],
    ["PAPZIMEOS (Injectable)", false, ["zopapogene imadenovec"]],
    ["PARAGARD (Implant)", false, ["copper"]],
    ["PARAPLATIN (Injectable)", false, ["carboplatin"]],
    ["Parathyroid hormone (Injectable)", false, ["parathyroid hormone"]],
    ["PAREMYD (Ophthalmic)", false, ["p-hydroxyamphetamine", "tropicamide"]],
    ["Paricalcitol (Injectable)", false, ["paricalcitol"]],
    ["Paricalcitol (Oral Pill)", true, ["paricalcitol"]],
    ["Pariglasgene brecaparvovec (Injectable)", false, ["pariglasgene brecaparvovec"]],
    ["Pariglasgene brecaparvovec (Pack)", false, ["pariglasgene brecaparvovec"]],
    ["PARLODEL (Oral Pill)", true, ["bromocriptine"]],
    ["PARNATE (Oral Pill)", true, ["tranylcypromine"]],
    ["PAROEX (Mouthwash)", false, ["chlorhexidine"]],
    ["Paromomycin (Oral Pill)", true, ["paromomycin"]],
    ["PARoxetine (Oral Liquid)", true, ["paroxetine"]],
    ["PARoxetine (Oral Pill)", true, ["paroxetine"]],
    ["PARoxetine XR (Oral Pill)", true, ["paroxetine"]],
    ["PARSABIV (Injectable)", false, ["etelcalcetide"]],
    ["PASATRU (Injectable)", false, ["garetosmab"]],
    ["PASER D/R (Oral Granules)", true, ["aminosalicylic acid"]],
    ["Pasireotide (Injectable)", false, ["pasireotide"]],
    ["PATADAY (Ophthalmic)", false, ["olopatadine"]],
    ["PATANASE (Nasal)", false, ["olopatadine"]],
    ["Patiromer (Oral Suspension Powder)", true, ["patiromer"]],
    ["Patisiran (Injectable)", false, ["patisiran"]],
    ["PAVBLU (Injectable)", false, ["aflibercept"]],
    ["PAXIL (Oral Liquid)", true, ["paroxetine"]],
    ["PAXIL (Oral Pill)", true, ["paroxetine"]],
    ["PAXIL XR (Oral Pill)", true, ["paroxetine"]],
    ["PAXLOVID 150 MG /100 MG DOSE PACK (Pack)", true, ["nirmatrelvir", "ritonavir"]],
    ["PAXLOVID 300 MG /100 MG ; 150 MG / 100 MG DOSE PACK (Pack)", true, ["nirmatrelvir", "ritonavir"]],
    ["PAXLOVID 5-DAY (Pack)", true, ["nirmatrelvir", "ritonavir"]],
    ["PAZOPanib (Oral Pill)", true, ["pazopanib"]],
    ["PCXX NEUTRAL FOAM (Oral Foam)", true, ["sodium fluoride"]],
    ["PCXX NEUTRAL RINSE (Mouthwash)", false, ["sodium fluoride"]],
    ["Peanut allergenic extract (Oral Powder)", true, ["peanut allergenic extract"]],
    ["Peanut allergenic extract (Pack)", false, ["peanut allergenic extract"]],
    ["Pectin (Oral Lozenge)", true, ["pectin"]],
    ["Pectin (Oral Pill)", true, ["pectin"]],
    ["PEDIA-LAX (Oral Film)", true, ["sennosides, USP"]],
    ["PEDIA-LAX CHEWABLE (Chewable)", true, ["magnesium hydroxide"]],
    ["PEDIA-LAX LIQUID (Oral Liquid)", true, ["docusate"]],
    ["PEDIA-LAX LIQUID GLYCERIN SUPPOSITORIES (Rectal)", false, ["glycerin"]],
    ["PEDIACLEAR (Oral Liquid)", true, ["pyrilamine"]],
    ["PEDIACLEAR CHILDRENS (Oral Liquid)", true, ["triprolidine"]],
    ["PEDIACLEAR COUGH (Oral Liquid)", true, ["diphenhydramine"]],
    ["PEDIAPRED (Oral Liquid)", true, ["prednisolone"]],
    ["PEDIARIX (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "hepatitis B surface antigen vaccine", "poliovirus vaccine inactivated, type 1 (Mahoney)", "poliovirus vaccine inactivated, type 2 (MEF-1)", "poliovirus vaccine inactivated, type 3 (Saukett)", "tetanus toxoid vaccine, inactivated"]],
    ["PEDMARK (Injectable)", false, ["thiosulfate"]],
    ["PEDVAXHIB (Injectable)", false, ["Haemophilus influenzae b (Ross strain) capsular polysaccharide meningococcal protein conjugate vaccine"]],
    ["Pegaspargase (Injectable)", false, ["pegaspargase"]],
    ["PEGASYS (Injectable)", false, ["peginterferon alfa-2a"]],
    ["Pegcetacoplan (Injectable)", false, ["pegcetacoplan"]],
    ["Pegfilgrastim (Injectable)", false, ["pegfilgrastim"]],
    ["Peginterferon alfa-2a (Injectable)", false, ["peginterferon alfa-2a"]],
    ["Peginterferon beta-1a (Injectable)", false, ["peginterferon beta-1a"]],
    ["Peginterferon beta-1a (Pack)", false, ["peginterferon beta-1a"]],
    ["Pegloticase (Injectable)", false, ["pegloticase"]],
    ["Pegunigalsidase alfa (Injectable)", false, ["pegunigalsidase alfa"]],
    ["Pegvaliase (Injectable)", false, ["pegvaliase"]],
    ["Pegvisomant (Injectable)", false, ["pegvisomant"]],
    ["Pegzilarginase (Injectable)", false, ["pegzilarginase"]],
    ["PELLIX (Topical)", false, ["calcipotriene"]],
    ["PEMAZYRE (Oral Pill)", true, ["pemigatinib"]],
    ["Pembrolizumab (Injectable)", false, ["pembrolizumab"]],
    ["PEMEtrexed (Injectable)", false, ["pemetrexed"]],
    ["PEMFEXY (Injectable)", false, ["pemetrexed"]],
    ["PEMGARDA (Injectable)", false, ["pemivibart"]],
    ["Pemigatinib (Oral Pill)", true, ["pemigatinib"]],
    ["Pemirolast (Ophthalmic)", false, ["pemirolast"]],
    ["Pemivibart (Injectable)", false, ["pemivibart"]],
    ["PEMRYDI RTU (Injectable)", false, ["pemetrexed"]],
    ["PENBRAYA (Injectable)", false, ["Neisseria meningitidis serogroup A capsular polysaccharide tetanus toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup C capsular polysaccharide tetanus toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup W-135 capsular polysaccharide tetanus toxoid protein conjugate vaccine", "Neisseria meningitidis serogroup Y capsular polysaccharide tetanus toxoid protein conjugate vaccine", "meningococcal group B vaccine"]],
    ["Penciclovir (Topical)", false, ["penciclovir"]],
    ["penicillAMINE (Oral Pill)", true, ["penicillamine"]],
    ["Penicillin G benzathine (Injectable)", false, ["penicillin G benzathine"]],
    ["Penicillin G benzathine/Penicillin G procaine (Injectable)", false, ["penicillin G benzathine", "penicillin G procaine"]],
    ["Penicillin G potassium (Injectable)", false, ["penicillin G potassium"]],
    ["Penicillin G sodium (Injectable)", false, ["penicillin G sodium"]],
    ["Penicillin V potassium (Oral Liquid)", true, ["penicillin V potassium"]],
    ["Penicillin V potassium (Oral Pill)", true, ["penicillin V potassium"]],
    ["PENMENVY (Injectable)", false, ["Neisseria meningitidis serogroup A oligosaccharide diphtheria CRM197 protein conjugate vaccine", "Neisseria meningitidis serogroup C oligosaccharide diphtheria CRM197 protein conjugate vaccine", "Neisseria meningitidis serogroup W-135 oligosaccharide diphtheria CRM197 protein conjugate vaccine", "Neisseria meningitidis serogroup Y oligosaccharide diphtheria CRM197 protein conjugate vaccine", "meningococcal group B vaccine"]],
    ["PENNSAID (Topical)", false, ["diclofenac"]],
    ["Penpulimab (Injectable)", false, ["penpulimab"]],
    ["PENTACEL (Injectable)", false, ["Haemophilus influenzae type b, capsular polysaccharide inactivated tetanus toxoid conjugate vaccine", "acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "poliovirus vaccine inactivated, type 1 (Mahoney)", "poliovirus vaccine inactivated, type 2 (MEF-1)", "poliovirus vaccine inactivated, type 3 (Saukett)", "tetanus toxoid vaccine, inactivated"]],
    ["PENTAM (Injectable)", false, ["pentamidine"]],
    ["Pentamidine (Inhalant)", false, ["pentamidine"]],
    ["Pentamidine (Injectable)", false, ["pentamidine"]],
    ["PENTASA XR (Oral Pill)", true, ["mesalamine"]],
    ["Pentetate calcium (Injectable)", false, ["pentetate calcium"]],
    ["PENTobarbital (Injectable)", false, ["pentobarbital"]],
    ["Pentosan polysulfate (Oral Pill)", true, ["pentosan polysulfate"]],
    ["Pentostatin (Injectable)", false, ["pentostatin"]],
    ["Pentoxifylline XR (Oral Pill)", true, ["pentoxifylline"]],
    ["PEP-BACK (Oral Pill)", true, ["caffeine"]],
    ["PEPCID (Oral Pill)", true, ["famotidine"]],
    ["PEPCID COMPLETE (Chewable)", true, ["calcium carbonate", "famotidine", "magnesium hydroxide"]],
    ["PEPTO NAUSEA (Oral Pill)", true, ["meclizine"]],
    ["PEPTO-BISMOL (Chewable)", true, ["bismuth subsalicylate"]],
    ["PEPTO-BISMOL (Oral Liquid)", true, ["bismuth subsalicylate"]],
    ["PEPTO-BISMOL (Oral Pill)", true, ["bismuth subsalicylate"]],
    ["PEPTO-BISMOL CHILDREN'S (Chewable)", true, ["calcium carbonate"]],
    ["Peramivir (Injectable)", false, ["peramivir"]],
    ["Perampanel (Oral Liquid)", true, ["perampanel"]],
    ["Perampanel (Oral Pill)", true, ["perampanel"]],
    ["Perampanel (Pack)", true, ["perampanel"]],
    ["PERCOCET (Oral Pill)", true, ["acetaminophen", "oxycodone"]],
    ["PERCOGESIC BACKACHE (Oral Pill)", true, ["magnesium salicylate"]],
    ["PERCOGESIC REFORMULATED JAN 2011 (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["PERCY MEDICINE (Oral Liquid)", true, ["bismuth subsalicylate"]],
    ["PERDIEM OVERNIGHT (Oral Pill)", true, ["sennosides, USP"]],
    ["PERFECT CHOICE (Oral Gel)", true, ["stannous fluoride"]],
    ["Perfluorohexyloctane (Ophthalmic)", false, ["perfluorohexyloctane"]],
    ["PERFORM (Topical)", false, ["menthol"]],
    ["PERFOROMIST (Inhalant)", false, ["formoterol"]],
    ["PERIDEX (Mouthwash)", false, ["chlorhexidine"]],
    ["PERIGIENE (Soap)", false, ["chloroxylenol"]],
    ["PERIGUARD (Topical)", false, ["zinc oxide"]],
    ["PERIGUARD OINTMENT (Topical)", false, ["petrolatum"]],
    ["Perindopril (Oral Pill)", true, ["perindopril"]],
    ["PERIO MED (Mouthwash)", false, ["stannous fluoride"]],
    ["PERIOCHIP (Implant)", false, ["chlorhexidine"]],
    ["PERIOGARD (Mouthwash)", false, ["chlorhexidine"]],
    ["PERIOSTAT (Oral Pill)", true, ["doxycycline"]],
    ["PERJETA (Injectable)", false, ["pertuzumab"]],
    ["Permethrin (Shampoo)", false, ["permethrin"]],
    ["Permethrin (Topical)", false, ["permethrin"]],
    ["PERNOX SCRUB CLEANSER (Soap)", false, ["salicylic acid", "sulfur"]],
    ["PEROXYL (Mouthwash)", false, ["hydrogen peroxide"]],
    ["PEROXYL (Mucosal)", false, ["hydrogen peroxide"]],
    ["PEROXYL (Oral Gel)", true, ["hydrogen peroxide"]],
    ["Perphenazine (Oral Pill)", true, ["perphenazine"]],
    ["PERSA-GEL (Topical)", false, ["benzoyl peroxide"]],
    ["PERSERIS (Injectable)", false, ["risperidone"]],
    ["Pertuzumab (Injectable)", false, ["pertuzumab"]],
    ["PERTZYE (Oral Pill)", true, ["amylase", "lipase", "protease"]],
    ["Petrolatum (Paste)", false, ["petrolatum"]],
    ["Petrolatum (Topical)", false, ["petrolatum"]],
    ["Petrolatum/Resorcinol (Topical)", false, ["petrolatum", "resorcinol"]],
    ["Petrolatum/Zinc oxide (Paste)", false, ["petrolatum", "zinc oxide"]],
    ["Petrolatum/Zinc oxide (Topical)", false, ["petrolatum", "zinc oxide"]],
    ["Pexidartinib (Oral Pill)", true, ["pexidartinib"]],
    ["PFIZERPEN (Injectable)", false, ["penicillin G potassium"]],
    ["PHARBETOL (Oral Pill)", true, ["acetaminophen"]],
    ["PHAZYME (Oral Pill)", true, ["simethicone"]],
    ["PHAZYME GAS & ACID (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["PHEBURANE (Oral Pellet)", true, ["phenylbutyrate"]],
    ["PHENADOZ (Rectal)", false, ["promethazine"]],
    ["Phenazopyridine (Oral Pill)", true, ["phenazopyridine"]],
    ["Phendimetrazine (Oral Pill)", true, ["phendimetrazine"]],
    ["Phendimetrazine XR (Oral Pill)", true, ["phendimetrazine"]],
    ["Phenelzine (Oral Pill)", true, ["phenelzine"]],
    ["PHENERGAN (Injectable)", false, ["promethazine"]],
    ["PHENERGAN (Rectal)", false, ["promethazine"]],
    ["Pheniramine/Phenylephrine (Oral Pill)", true, ["pheniramine", "phenylephrine"]],
    ["PHENobarbital (Injectable)", false, ["phenobarbital"]],
    ["PHENobarbital (Oral Liquid)", true, ["phenobarbital"]],
    ["PHENobarbital (Oral Pill)", true, ["phenobarbital"]],
    ["PHENOHYTRO (Oral Liquid)", true, ["atropine", "hyoscyamine", "phenobarbital", "scopolamine"]],
    ["PHENOHYTRO (Oral Pill)", true, ["atropine", "hyoscyamine", "phenobarbital", "scopolamine"]],
    ["Phenol (Mouthwash)", false, ["phenol"]],
    ["Phenol (Mucosal)", false, ["phenol"]],
    ["Phenol (Topical)", false, ["phenol"]],
    ["Phenoxybenzamine (Oral Pill)", true, ["phenoxybenzamine"]],
    ["Phentermine (Oral Pill)", true, ["phentermine"]],
    ["Phentermine/Topiramate XR (Oral Pill)", true, ["phentermine", "topiramate"]],
    ["Phentolamine (Injectable)", false, ["phentolamine"]],
    ["Phentolamine (Ophthalmic)", false, ["phentolamine"]],
    ["Phenylalanine (Oral Pill)", true, ["phenylalanine"]],
    ["Phenylbutyrate (Oral Pellet)", true, ["phenylbutyrate"]],
    ["Phenylbutyrate (Oral Pill)", true, ["phenylbutyrate"]],
    ["Phenylbutyrate (Oral Powder)", true, ["phenylbutyrate"]],
    ["Phenylbutyrate (Oral Suspension Granules)", true, ["phenylbutyrate"]],
    ["Phenylbutyrate (Pack)", false, ["phenylbutyrate"]],
    ["Phenylephrine (Injectable)", false, ["phenylephrine"]],
    ["Phenylephrine (Nasal)", false, ["phenylephrine"]],
    ["Phenylephrine (Ophthalmic)", false, ["phenylephrine"]],
    ["Phenylephrine (Oral Film)", true, ["phenylephrine"]],
    ["Phenylephrine (Oral Liquid)", true, ["phenylephrine"]],
    ["Phenylephrine (Oral Pill)", true, ["phenylephrine"]],
    ["Phenylephrine (Rectal)", false, ["phenylephrine"]],
    ["Phenylephrine/Pramoxine (Rectal)", false, ["phenylephrine", "pramoxine"]],
    ["Phenylephrine/Promethazine (Oral Liquid)", true, ["phenylephrine", "promethazine"]],
    ["Phenylephrine/Pyrilamine (Oral Liquid)", true, ["phenylephrine", "pyrilamine"]],
    ["Phenylephrine/Thonzylamine (Oral Liquid)", true, ["phenylephrine", "thonzylamine"]],
    ["Phenylephrine/Triprolidine (Oral Liquid)", true, ["phenylephrine", "triprolidine"]],
    ["Phenylephrine/Triprolidine (Oral Pill)", true, ["phenylephrine", "triprolidine"]],
    ["Phenylephrine/Tropicamide (Ophthalmic)", false, ["phenylephrine", "tropicamide"]],
    ["Phenylephrine/Witch hazel (Rectal)", false, ["phenylephrine", "witch hazel"]],
    ["PHENYTEK XR (Oral Pill)", true, ["phenytoin"]],
    ["Phenytoin (Chewable)", true, ["phenytoin"]],
    ["Phenytoin (Injectable)", false, ["phenytoin"]],
    ["Phenytoin (Oral Liquid)", true, ["phenytoin"]],
    ["Phenytoin XR (Oral Pill)", true, ["phenytoin"]],
    ["PHESGO (Injectable)", false, ["hyaluronidase", "pertuzumab", "trastuzumab"]],
    ["PHEXX (Vaginal)", false, ["citric acid", "lactate", "potassium bitartrate"]],
    ["PHEXXI (Vaginal)", false, ["citric acid", "lactate", "potassium bitartrate"]],
    ["PHILITH 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["PHILLIPS MILK OF MAGNESIA (Oral Liquid)", true, ["magnesium hydroxide"]],
    ["PHILLIPS STOOL SOFTENER (Oral Pill)", true, ["docusate"]],
    ["PHILLIPS' CRAMP-FREE (Oral Pill)", true, ["magnesium oxide"]],
    ["PHOS-FLUR (Mouthwash)", false, ["sodium fluoride"]],
    ["PHOS-FLUR (Toothpaste)", false, ["sodium fluoride"]],
    ["PHOSLO (Oral Pill)", true, ["calcium acetate"]],
    ["PHOSLYRA (Oral Liquid)", true, ["calcium acetate"]],
    ["PHOSPHA 250 NEUTRAL (Oral Pill)", true, ["potassium phosphate", "sodium phosphate, dibasic", "sodium phosphate, monobasic"]],
    ["PHOSPHASAL (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["PHOSPHOLINE IODIDE (Ophthalmic)", false, ["ecothiopate"]],
    ["PHOTOFRIN (Injectable)", false, ["dihematoporphyrin ether"]],
    ["PHOTREXA (Ophthalmic)", false, ["riboflavin 5'-phosphate"]],
    ["PHYRAGO (Oral Pill)", true, ["dasatinib"]],
    ["PHYSIOLYTE (Irrigation)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["PHYSIOSOL (Irrigation)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["PHYSostigmine (Injectable)", false, ["physostigmine"]],
    ["Phytosterols (Oral Pill)", true, ["phytosterols"]],
    ["PIASKY (Injectable)", false, ["crovalimab"]],
    ["PIFELTRO (Oral Pill)", true, ["doravirine"]],
    ["PILOCAR (Ophthalmic)", false, ["pilocarpine"]],
    ["Pilocarpine (Ophthalmic)", false, ["pilocarpine"]],
    ["Pilocarpine (Oral Pill)", true, ["pilocarpine"]],
    ["Pimavanserin (Oral Pill)", true, ["pimavanserin"]],
    ["Pimecrolimus (Topical)", false, ["pimecrolimus"]],
    ["Pimozide (Oral Pill)", true, ["pimozide"]],
    ["PIMTREA PACK (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Pindolol (Oral Pill)", true, ["pindolol"]],
    ["Pioglitazone (Oral Pill)", true, ["pioglitazone"]],
    ["Piperacillin/Tazobactam (Injectable)", false, ["piperacillin", "tazobactam"]],
    ["Piperonyl butoxide/Pyrethrins (Shampoo)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["Piperonyl butoxide/Pyrethrins (Topical)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["PIQRAY (Oral Pill)", true, ["alpelisib"]],
    ["PIQRAY 200 MG DAILY DOSE (Pack)", true, ["alpelisib"]],
    ["PIQRAY 250 MG DAILY DOSE (Pack)", true, ["alpelisib"]],
    ["PIQRAY 300 MG DAILY DOSE (Pack)", true, ["alpelisib"]],
    ["Pirfenidone (Oral Pill)", true, ["pirfenidone"]],
    ["Pirfenidone (Pack)", true, ["pirfenidone"]],
    ["PIRMELLA 1/35 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["PIRMELLA 7/7/7 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["PIRNUO (Topical)", false, ["mupirocin"]],
    ["Piroxicam (Oral Pill)", true, ["piroxicam"]],
    ["Pirtobrutinib (Oral Pill)", true, ["pirtobrutinib"]],
    ["Pitavastatin (Oral Pill)", true, ["pitavastatin"]],
    ["PITOCIN (Injectable)", false, ["oxytocin"]],
    ["Pitolisant (Oral Pill)", true, ["pitolisant"]],
    ["Pivekimab sunirine (Injectable)", false, ["pivekimab sunirine"]],
    ["PIVYA (Oral Pill)", true, ["amdinocillin pivoxil"]],
    ["PLAN B ONE-STEP (Oral Pill)", true, ["levonorgestrel"]],
    ["Plant stanol ester (Oral Pill)", true, ["plant stanol ester"]],
    ["PLAQUENIL (Oral Pill)", true, ["hydroxychloroquine"]],
    ["PLASBUMIN (Injectable)", false, ["albumin human, USP"]],
    ["Plasma protein fraction (Injectable)", false, ["plasma protein fraction"]],
    ["PLASMA-LYTE 148 (Injectable)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["PLASMALYTE A (Injectable)", false, ["magnesium chloride", "potassium chloride", "sodium acetate", "sodium chloride", "sodium gluconate"]],
    ["PLASMANATE (Injectable)", false, ["plasma protein fraction"]],
    ["Plasminogen (Injectable)", false, ["plasminogen"]],
    ["PLAVIX (Oral Pill)", true, ["clopidogrel"]],
    ["Plazomicin (Injectable)", false, ["plazomicin"]],
    ["Plecanatide (Oral Pill)", true, ["plecanatide"]],
    ["PLEGRIDY (Injectable)", false, ["peginterferon beta-1a"]],
    ["PLEGRIDY PEN STARTER PACK (Pack)", false, ["peginterferon beta-1a"]],
    ["PLEGRIDY STARTER PACK (Pack)", false, ["peginterferon beta-1a"]],
    ["PLENAMINE (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["PLENVU (Pack)", false, ["ascorbic acid", "polyethylene glycol 3350", "potassium chloride", "sodium ascorbate", "sodium chloride", "sodium sulfate"]],
    ["Plerixafor (Injectable)", false, ["plerixafor"]],
    ["PLEXION (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["PLEXION (Topical)", false, ["sulfacetamide", "sulfur"]],
    ["PLIAGLIS (Topical)", false, ["lidocaine", "tetracaine"]],
    ["Plozasiran (Injectable)", false, ["plozasiran"]],
    ["PLUVICTO (Injectable)", false, ["vipivotide tetraxetan"]],
    ["PNEUMOVAX 23 (Injectable)", false, ["Streptococcus pneumoniae type 1 capsular polysaccharide antigen", "Streptococcus pneumoniae type 10A capsular polysaccharide antigen", "Streptococcus pneumoniae type 11A capsular polysaccharide antigen", "Streptococcus pneumoniae type 12F capsular polysaccharide antigen", "Streptococcus pneumoniae type 14 capsular polysaccharide antigen", "Streptococcus pneumoniae type 15B capsular polysaccharide antigen", "Streptococcus pneumoniae type 17F capsular polysaccharide antigen", "Streptococcus pneumoniae type 18C capsular polysaccharide antigen", "Streptococcus pneumoniae type 19A capsular polysaccharide antigen", "Streptococcus pneumoniae type 19F capsular polysaccharide antigen", "Streptococcus pneumoniae type 2 capsular polysaccharide antigen", "Streptococcus pneumoniae type 20 capsular polysaccharide antigen", "Streptococcus pneumoniae type 22F capsular polysaccharide antigen", "Streptococcus pneumoniae type 23F capsular polysaccharide antigen", "Streptococcus pneumoniae type 3 capsular polysaccharide antigen", "Streptococcus pneumoniae type 33F capsular polysaccharide antigen", "Streptococcus pneumoniae type 4 capsular polysaccharide antigen", "Streptococcus pneumoniae type 5 capsular polysaccharide antigen", "Streptococcus pneumoniae type 6B capsular polysaccharide antigen", "Streptococcus pneumoniae type 7F capsular polysaccharide antigen", "Streptococcus pneumoniae type 8 capsular polysaccharide antigen", "Streptococcus pneumoniae type 9N capsular polysaccharide antigen", "Streptococcus pneumoniae type 9V capsular polysaccharide antigen"]],
    ["PODOCON (Topical)", false, ["podophyllin"]],
    ["Podofilox (Topical)", false, ["podofilox"]],
    ["Podophyllin (Topical)", false, ["podophyllin"]],
    ["POKONZA (Oral Liquid)", true, ["potassium chloride"]],
    ["POKONZA (Oral Solution Powder)", true, ["potassium chloride"]],
    ["POLAR FREEZE (Topical)", false, ["camphor", "menthol"]],
    ["POLAR FROST (Topical)", false, ["menthol"]],
    ["Polatuzumab vedotin (Injectable)", false, ["polatuzumab vedotin"]],
    ["Policosanol (Oral Pill)", true, ["policosanol"]],
    ["Polidocanol (Injectable)", false, ["polidocanol"]],
    ["POLIVY (Injectable)", false, ["polatuzumab vedotin"]],
    ["POLOCAINE (Injectable)", false, ["mepivacaine"]],
    ["Poloxamer 407/Simethicone (Oral Gel)", true, ["poloxamer 407", "simethicone"]],
    ["POLY HIST PD (Oral Liquid)", true, ["chlorpheniramine", "phenylephrine", "pyrilamine"]],
    ["POLY IRON 150 FORTE (Oral Pill)", true, ["folic acid", "polysaccharide iron complex", "vitamin B12"]],
    ["POLY-DEX (Ophthalmic)", false, ["dexamethasone", "neomycin", "polymyxin B"]],
    ["POLY-VI-SOL (Oral Liquid)", true, ["ascorbic acid", "cholecalciferol", "niacin", "riboflavin", "thiamine", "vitamin A", "vitamin B12", "vitamin B6", "vitamin E"]],
    ["POLYCIN (Ophthalmic)", false, ["bacitracin", "polymyxin B"]],
    ["Polyethylene glycol 3350 (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["Polyethylene glycol 3350/Potassium chloride/Sodium chloride/Sodium sulfate (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium chloride", "sodium sulfate"]],
    ["Polyethylene glycol 400 (Ophthalmic)", false, ["polyethylene glycol 400"]],
    ["Polyethylene glycol 400/Propylene glycol (Ophthalmic)", false, ["polyethylene glycol 400", "propylene glycol"]],
    ["Polyethylene glycol 400/Propylene glycol (Pack)", false, ["polyethylene glycol 400", "propylene glycol"]],
    ["Polyethylene glycol 400/Tetrahydrozoline (Ophthalmic)", false, ["polyethylene glycol 400", "tetrahydrozoline"]],
    ["Polyethylene glycol 400/Tetrahydrozoline/Zinc sulfate (Ophthalmic)", false, ["polyethylene glycol 400", "tetrahydrozoline", "zinc sulfate"]],
    ["Polyethylene glycols/Polyvinyl alcohol (Ophthalmic)", false, ["polyethylene glycols", "polyvinyl alcohol"]],
    ["Polyethylene glycols/Propylene glycol (Nasal)", false, ["polyethylene glycols", "propylene glycol"]],
    ["Polymyxin B (Injectable)", false, ["polymyxin B"]],
    ["Polymyxin B/Trimethoprim (Ophthalmic)", false, ["polymyxin B", "trimethoprim"]],
    ["Polypodium leucotomos (Oral Pill)", true, ["Polypodium leucotomos"]],
    ["Polysaccharide iron complex (Oral Liquid)", true, ["polysaccharide iron complex"]],
    ["Polysaccharide iron complex (Oral Pill)", true, ["polysaccharide iron complex"]],
    ["Polysorbate 80 (Ophthalmic)", false, ["polysorbate 80"]],
    ["POLYSPORIN (Topical)", false, ["bacitracin", "polymyxin B"]],
    ["Polyvinyl alcohol (Ophthalmic)", false, ["polyvinyl alcohol"]],
    ["Polyvinyl alcohol/Povidone (Ophthalmic)", false, ["polyvinyl alcohol", "povidone"]],
    ["Polyvinyl alcohol/Povidone/Tetrahydrozoline (Ophthalmic)", false, ["polyvinyl alcohol", "povidone", "tetrahydrozoline"]],
    ["Pomalidomide (Oral Pill)", true, ["pomalidomide"]],
    ["POMALYST (Oral Pill)", true, ["pomalidomide"]],
    ["POMBILITI (Injectable)", false, ["cipaglucosidase alfa"]],
    ["PONATinib (Oral Pill)", true, ["ponatinib"]],
    ["Ponesimod (Oral Pill)", true, ["ponesimod"]],
    ["Ponesimod (Pack)", true, ["ponesimod"]],
    ["PONTOCAINE (Topical)", false, ["tetracaine"]],
    ["PONVORY (Oral Pill)", true, ["ponesimod"]],
    ["PONVORY 14 DAY (Pack)", true, ["ponesimod"]],
    ["Poractant alfa (Intratracheal)", false, ["poractant alfa"]],
    ["PORTIA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["PORTRAZZA (Injectable)", false, ["necitumumab"]],
    ["Posaconazole (Injectable)", false, ["posaconazole"]],
    ["Posaconazole (Oral Liquid)", true, ["posaconazole"]],
    ["Posaconazole (Oral Pill)", true, ["posaconazole"]],
    ["Posaconazole (Oral Suspension Powder)", true, ["posaconazole"]],
    ["POSFREA (Injectable)", false, ["palonosetron"]],
    ["POSIMIR (Injectable)", false, ["bupivacaine"]],
    ["POTABA (Oral Pill)", true, ["4-aminobenzoate"]],
    ["Potassium (Oral Pill)", true, ["potassium"]],
    ["Potassium acetate (Injectable)", false, ["potassium acetate"]],
    ["Potassium bicarbonate (Effervescent)", true, ["potassium bicarbonate"]],
    ["Potassium bitartrate/Sodium bicarbonate (Rectal)", false, ["potassium bitartrate", "sodium bicarbonate"]],
    ["Potassium chloride (Effervescent)", true, ["potassium chloride"]],
    ["Potassium chloride (Injectable)", false, ["potassium chloride"]],
    ["Potassium chloride (Oral Liquid)", true, ["potassium chloride"]],
    ["Potassium chloride (Oral Pill)", true, ["potassium chloride"]],
    ["Potassium chloride (Oral Solution Powder)", true, ["potassium chloride"]],
    ["Potassium chloride XR (Oral Pill)", true, ["potassium chloride"]],
    ["Potassium chloride/Sodium chloride (Injectable)", false, ["potassium chloride", "sodium chloride"]],
    ["Potassium chloride/Sodium chloride (Oral Pill)", true, ["potassium chloride", "sodium chloride"]],
    ["Potassium citrate (Oral Pill)", true, ["potassium citrate"]],
    ["Potassium citrate XR (Oral Pill)", true, ["potassium citrate"]],
    ["Potassium gluconate (Oral Pill)", true, ["potassium gluconate"]],
    ["Potassium iodide (Oral Liquid)", true, ["potassium iodide"]],
    ["Potassium iodide (Oral Pill)", true, ["potassium iodide"]],
    ["Potassium nitrate (Toothpaste)", false, ["potassium nitrate"]],
    ["Potassium nitrate/Silver nitrate (Topical)", false, ["potassium nitrate", "silver nitrate"]],
    ["Potassium nitrate/Sodium fluoride (Toothpaste)", false, ["potassium nitrate", "sodium fluoride"]],
    ["Potassium phosphate (Oral Liquid)", true, ["potassium phosphate"]],
    ["Potassium phosphate/Sodium phosphate, dibasic/Sodium phosphate, monobasic (Oral Pill)", true, ["potassium phosphate", "sodium phosphate, dibasic", "sodium phosphate, monobasic"]],
    ["Potassium phosphate/Sodium phosphate, monobasic (Oral Pill)", true, ["potassium phosphate", "sodium phosphate, monobasic"]],
    ["Potassium,chelated (Oral Pill)", true, ["potassium,chelated"]],
    ["POTELIGEO (Injectable)", false, ["mogamulizumab"]],
    ["Povidone (Ophthalmic)", false, ["povidone"]],
    ["Povidone-iodine (Mouthwash)", false, ["povidone-iodine"]],
    ["Povidone-iodine (Ophthalmic)", false, ["povidone-iodine"]],
    ["Povidone-iodine (Soap)", false, ["povidone-iodine"]],
    ["Povidone-iodine (Topical)", false, ["povidone-iodine"]],
    ["Povidone-iodine (Vaginal)", false, ["povidone-iodine"]],
    ["Povidone/Propylene glycol (Ophthalmic)", false, ["povidone", "propylene glycol"]],
    ["Pozelimab (Injectable)", false, ["pozelimab"]],
    ["PRADAXA (Oral Pellet)", true, ["dabigatran etexilate"]],
    ["PRADAXA (Oral Pill)", true, ["dabigatran etexilate"]],
    ["Prademagene zamikeracel (Topical)", false, ["prademagene zamikeracel"]],
    ["PRALAtrexate (Injectable)", false, ["pralatrexate"]],
    ["Pralidoxime (Injectable)", false, ["pralidoxime"]],
    ["Pralsetinib (Oral Pill)", true, ["pralsetinib"]],
    ["PRALUENT (Injectable)", false, ["alirocumab"]],
    ["PRAMEGEL REFORMULATED APR 2012 (Topical)", false, ["menthol", "pramoxine"]],
    ["Pramipexole (Oral Pill)", true, ["pramipexole"]],
    ["Pramipexole XR (Oral Pill)", true, ["pramipexole"]],
    ["Pramlintide (Injectable)", false, ["pramlintide"]],
    ["PRAMOSONE (Topical)", false, ["hydrocortisone", "pramoxine"]],
    ["Pramoxine (Rectal)", false, ["pramoxine"]],
    ["Pramoxine (Soap)", false, ["pramoxine"]],
    ["Pramoxine (Topical)", false, ["pramoxine"]],
    ["Pramoxine/Zinc acetate (Topical)", false, ["pramoxine", "zinc acetate"]],
    ["Pramoxine/Zinc oxide (Rectal)", false, ["pramoxine", "zinc oxide"]],
    ["Prasterone (Oral Pill)", true, ["prasterone"]],
    ["Prasterone (Vaginal)", false, ["prasterone"]],
    ["Prasugrel (Oral Pill)", true, ["prasugrel"]],
    ["PRAVACHOL (Oral Pill)", true, ["pravastatin"]],
    ["Pravastatin (Oral Pill)", true, ["pravastatin"]],
    ["PRAX (Topical)", false, ["pramoxine"]],
    ["PRAXBIND (Injectable)", false, ["idarucizumab"]],
    ["Praziquantel (Oral Pill)", true, ["praziquantel"]],
    ["Prazosin (Oral Pill)", true, ["prazosin"]],
    ["PRECEDEX (Injectable)", false, ["dexmedetomidine"]],
    ["PRECOSE (Oral Pill)", true, ["acarbose"]],
    ["PRED FORTE (Ophthalmic)", false, ["prednisolone"]],
    ["PRED MILD (Ophthalmic)", false, ["prednisolone"]],
    ["Prednicarbate (Topical)", false, ["prednicarbate"]],
    ["prednisoLONE (Ophthalmic)", false, ["prednisolone"]],
    ["prednisoLONE (Oral Disintegrating)", true, ["prednisolone"]],
    ["prednisoLONE (Oral Liquid)", true, ["prednisolone"]],
    ["prednisoLONE (Oral Pill)", true, ["prednisolone"]],
    ["prednisoLONE (Pack)", true, ["prednisolone"]],
    ["prednisoLONE/Sulfacetamide (Ophthalmic)", false, ["prednisolone", "sulfacetamide"]],
    ["predniSONE (Oral Liquid)", true, ["prednisone"]],
    ["predniSONE (Oral Pill)", true, ["prednisone"]],
    ["predniSONE (Pack)", true, ["prednisone"]],
    ["Pregabalin (Oral Liquid)", true, ["pregabalin"]],
    ["Pregabalin (Oral Pill)", true, ["pregabalin"]],
    ["Pregabalin XR (Oral Pill)", true, ["pregabalin"]],
    ["PREGNITUDE (Oral Solution Powder)", true, ["folic acid", "inositol"]],
    ["PREGNYL (Injectable)", false, ["chorionic gonadotropin"]],
    ["PREHEVBRIO (Injectable)", false, ["hepatitis B surface antigen vaccine"]],
    ["PRELIEF (Oral Pill)", true, ["calcium glycerophosphate"]],
    ["PREMARIN (Injectable)", false, ["estrogens, conjugated (USP)"]],
    ["PREMARIN (Oral Pill)", true, ["estrogens, conjugated (USP)"]],
    ["PREMARIN (Vaginal)", false, ["estrogens, conjugated (USP)"]],
    ["PREMASOL (Injectable)", false, ["alanine", "arginine", "aspartate", "cysteine", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "taurine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["PREMPHASE 28 DAY (Pack)", false, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["PREMPRO 0.3/1.5 28 DAY (Pack)", false, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["PREMPRO 0.45/1.5 28 DAY (Pack)", false, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["PREMPRO 0.625/2.5 28 DAY (Pack)", false, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["PREMPRO 0.625/5 28 DAY (Pack)", false, ["estrogens, conjugated (USP)", "medroxyprogesterone"]],
    ["PREMSYN PMS (Oral Pill)", true, ["acetaminophen", "pamabrom", "pyrilamine"]],
    ["PREPIDIL (Vaginal)", false, ["dinoprostone"]],
    ["PRESERVISION (Oral Pill)", true, ["ascorbic acid", "beta carotene", "cuprous oxide", "vitamin E", "zinc oxide"]],
    ["PRESERVISION WITH LUTEIN (Oral Pill)", true, ["ascorbic acid", "cuprous oxide", "lutein", "vitamin E", "zinc oxide"]],
    ["PRESTALIA (Oral Pill)", true, ["amlodipine", "perindopril"]],
    ["Pretomanid (Oral Pill)", true, ["pretomanid"]],
    ["PRETZ (Nasal)", false, ["glycerin", "sodium chloride"]],
    ["PREVACID (Oral Disintegrating)", true, ["lansoprazole"]],
    ["PREVACID (Oral Pill)", true, ["lansoprazole"]],
    ["PREVALITE (Oral Suspension Powder)", true, ["cholestyramine resin"]],
    ["PREVDUO (Injectable)", false, ["glycopyrronium", "neostigmine"]],
    ["PREVENTEZA (Oral Pill)", true, ["levonorgestrel"]],
    ["PREVIDENT (Toothpaste)", false, ["sodium fluoride"]],
    ["PREVIDENT 5000 SENSITIVE (Toothpaste)", false, ["potassium nitrate", "sodium fluoride"]],
    ["PREVIDENT DENTAL RINSE (Mouthwash)", false, ["sodium fluoride"]],
    ["PREVIFEM 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["PREVNAR 13 (Injectable)", false, ["Streptococcus pneumoniae serotype 1 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 14 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 18C capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 23F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 3 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 4 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 5 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6B capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 7F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 9V capsular antigen diphtheria CRM197 protein conjugate vaccine"]],
    ["PREVNAR 20 (Injectable)", false, ["Streptococcus pneumoniae serotype 1 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 10A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 11A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 12F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 14 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 15B capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 18C capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 22F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 23F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 3 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 33F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 4 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 5 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6B capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 7F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 8 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 9V capsular antigen diphtheria CRM197 protein conjugate vaccine"]],
    ["PREVYMIS (Injectable)", false, ["letermovir"]],
    ["PREVYMIS (Oral Pellet)", true, ["letermovir"]],
    ["PREVYMIS (Oral Pill)", true, ["letermovir"]],
    ["PREZCOBIX (Oral Pill)", true, ["cobicistat", "darunavir"]],
    ["PREZCOBIX (Oral Suspension Tablet)", true, ["cobicistat", "darunavir"]],
    ["PREZISTA (Oral Liquid)", true, ["darunavir"]],
    ["PREZISTA (Oral Pill)", true, ["darunavir"]],
    ["PRIALT (Injectable)", false, ["ziconotide"]],
    ["PRIFTIN (Oral Pill)", true, ["rifapentine"]],
    ["Prilocaine (Injectable)", false, ["prilocaine"]],
    ["PriLOSEC (Oral Pill)", true, ["omeprazole"]],
    ["PriLOSEC (Oral Suspension Granules)", true, ["omeprazole"]],
    ["Primaquine (Oral Pill)", true, ["primaquine"]],
    ["PRIMATENE MIST INHALER (Inhalant)", false, ["epinephrine"]],
    ["PRIMATENE WITH ePHEDrine & guaiFENesin (Oral Pill)", true, ["ephedrine", "guaifenesin"]],
    ["PRIMATENE WITH ePHEDrine (Oral Pill)", true, ["ephedrine"]],
    ["PRIMAXIN (Injectable)", false, ["cilastatin", "imipenem"]],
    ["Primidone (Oral Pill)", true, ["primidone"]],
    ["PRIMLEV (Oral Pill)", true, ["acetaminophen", "oxycodone"]],
    ["PRIMSOL (Oral Liquid)", true, ["trimethoprim"]],
    ["PRINIVIL (Oral Pill)", true, ["lisinopril"]],
    ["PRIORIX (Injectable)", false, ["measles virus vaccine live, attenuated Schwarz strain", "mumps virus vaccine live, Jeryl Lynn strain", "rubella virus vaccine live (Wistar RA 27-3 strain)"]],
    ["PRISTIQ XR (Oral Pill)", true, ["desvenlafaxine"]],
    ["PRIVIGEN (Injectable)", false, ["immunoglobulin G"]],
    ["PRIVINE (Nasal)", false, ["naphazoline"]],
    ["PROAIR (Inhalant)", false, ["albuterol"]],
    ["PROBANTHINE (Oral Pill)", true, ["propantheline"]],
    ["Probenecid (Oral Pill)", true, ["probenecid"]],
    ["Probenecid/Sulopenem (Oral Pill)", true, ["probenecid", "sulopenem"]],
    ["Procainamide (Injectable)", false, ["procainamide"]],
    ["Procarbazine (Oral Pill)", true, ["procarbazine"]],
    ["PROCARDIA XR (Oral Pill)", true, ["nifedipine"]],
    ["PROCENTRA (Oral Liquid)", true, ["dextroamphetamine"]],
    ["Prochlorperazine (Injectable)", false, ["prochlorperazine"]],
    ["Prochlorperazine (Oral Pill)", true, ["prochlorperazine"]],
    ["Prochlorperazine (Rectal)", false, ["prochlorperazine"]],
    ["PROCLEARZ (Topical)", false, ["tolnaftate"]],
    ["PROCORT 1.85/1.15 (Rectal)", false, ["hydrocortisone", "pramoxine"]],
    ["PROCRIT (Injectable)", false, ["epoetin alfa"]],
    ["PROCTO-KIT (Rectal)", false, ["hydrocortisone"]],
    ["PROCTO-MED (Topical)", false, ["hydrocortisone"]],
    ["PROCTO-PAK (Topical)", false, ["hydrocortisone"]],
    ["PROCTOCORT (Rectal)", false, ["hydrocortisone"]],
    ["PROCTOCORT (Topical)", false, ["hydrocortisone"]],
    ["PROCTOFOAM (Rectal)", false, ["pramoxine"]],
    ["PROCTOFOAM-HC (Rectal)", false, ["hydrocortisone", "pramoxine"]],
    ["PROCTOSOL (Rectal)", false, ["hydrocortisone"]],
    ["PROCTOSOL (Topical)", false, ["hydrocortisone"]],
    ["PROCTOZONE HC (Topical)", false, ["hydrocortisone"]],
    ["PROCYSBI (Oral Granules)", true, ["cysteamine"]],
    ["PROCYSBI (Oral Pill)", true, ["cysteamine"]],
    ["PRODENRX RINSE (Mouthwash)", false, ["sodium fluoride"]],
    ["PROFERRIN (Oral Pill)", true, ["Fe heme polypeptide"]],
    ["PROFILNINE (Injectable)", false, ["factor IX complex"]],
    ["Progesterone (Injectable)", false, ["progesterone"]],
    ["Progesterone (Oral Pill)", true, ["progesterone"]],
    ["Progesterone (Vaginal)", false, ["progesterone"]],
    ["PROGLYCEM (Oral Liquid)", true, ["diazoxide"]],
    ["PROGRAF (Injectable)", false, ["tacrolimus"]],
    ["PROGRAF (Oral Pill)", true, ["tacrolimus"]],
    ["PROGRAF (Oral Suspension Granules)", true, ["tacrolimus"]],
    ["PROLASTIN (Injectable)", false, ["alpha 1-antitrypsin"]],
    ["PROLATE (Oral Liquid)", true, ["acetaminophen", "oxycodone"]],
    ["PROLATE (Oral Pill)", true, ["acetaminophen", "oxycodone"]],
    ["PROLAXA (Oral Pill)", true, ["docusate"]],
    ["PROLENSA (Ophthalmic)", false, ["bromfenac"]],
    ["PROLEUKIN (Injectable)", false, ["aldesleukin"]],
    ["PROLIA (Injectable)", false, ["denosumab"]],
    ["PROMACTA (Oral Pill)", true, ["eltrombopag"]],
    ["PROMACTA (Oral Suspension Powder)", true, ["eltrombopag"]],
    ["Promethazine (Injectable)", false, ["promethazine"]],
    ["Promethazine (Oral Liquid)", true, ["promethazine"]],
    ["Promethazine (Oral Pill)", true, ["promethazine"]],
    ["Promethazine (Rectal)", false, ["promethazine"]],
    ["PROMETHEGAN (Rectal)", false, ["promethazine"]],
    ["PROMETRIUM (Oral Pill)", true, ["progesterone"]],
    ["PROMOLAXIN (Oral Pill)", true, ["docusate"]],
    ["PRONTO (Shampoo)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["PRONTO PLUS (Shampoo)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["PRONTO PLUS COMPLETE LICE REMOVER SYSTEM (Pack)", false, ["benzalkonium", "piperonyl butoxide", "pyrethrins"]],
    ["PRONTO PLUS LICE EGG REMOVER (Topical)", false, ["benzalkonium"]],
    ["PROPA P.H. (Soap)", false, ["salicylic acid"]],
    ["PROPA P.H. ACNE MASK (Topical)", false, ["salicylic acid"]],
    ["Propafenone (Oral Pill)", true, ["propafenone"]],
    ["Propafenone XR (Oral Pill)", true, ["propafenone"]],
    ["Propantheline (Oral Pill)", true, ["propantheline"]],
    ["Proparacaine (Ophthalmic)", false, ["proparacaine"]],
    ["PROPECIA (Oral Pill)", true, ["finasteride"]],
    ["PROPEL (Implant)", false, ["mometasone"]],
    ["Propofol (Injectable)", false, ["propofol"]],
    ["Propolis (Oral Pill)", true, ["propolis"]],
    ["Propranolol (Injectable)", false, ["propranolol"]],
    ["Propranolol (Oral Liquid)", true, ["propranolol"]],
    ["Propranolol (Oral Pill)", true, ["propranolol"]],
    ["Propranolol XR (Oral Pill)", true, ["propranolol"]],
    ["PROPRINAL (Oral Pill)", true, ["ibuprofen"]],
    ["Propylene glycol (Ophthalmic)", false, ["propylene glycol"]],
    ["Propylhexedrine (Nasal)", false, ["propylhexedrine"]],
    ["Propylthiouracil (Oral Pill)", true, ["propylthiouracil"]],
    ["PROQUAD (Injectable)", false, ["measles virus vaccine live, Enders' attenuated Edmonston strain", "mumps virus vaccine live, Jeryl Lynn strain", "rubella virus vaccine live (Wistar RA 27-3 strain)", "varicella-zoster virus vaccine live (Oka-Merck) strain"]],
    ["PROSCAR (Oral Pill)", true, ["finasteride"]],
    ["PROSOL (Injectable)", false, ["alanine", "arginine", "aspartate", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["PROSTIN VR (Injectable)", false, ["alprostadil"]],
    ["Protamine sulfate (USP) (Injectable)", false, ["protamine sulfate (USP)"]],
    ["Protein C (Injectable)", false, ["protein C"]],
    ["PROTONIX (Injectable)", false, ["pantoprazole"]],
    ["PROTONIX (Oral Granules)", true, ["pantoprazole"]],
    ["PROTONIX (Oral Pill)", true, ["pantoprazole"]],
    ["PROTOPAM (Injectable)", false, ["pralidoxime"]],
    ["Protriptyline (Oral Pill)", true, ["protriptyline"]],
    ["PROVAYBLUE (Injectable)", false, ["methylene blue"]],
    ["PROVENGE (Injectable)", false, ["sipuleucel-T"]],
    ["PROVENTIL (Inhalant)", false, ["albuterol"]],
    ["PROVERA (Oral Pill)", true, ["medroxyprogesterone"]],
    ["PROVIGIL (Oral Pill)", true, ["modafinil"]],
    ["PROVISC (Injectable)", false, ["hyaluronate"]],
    ["PROzac (Oral Pill)", true, ["fluoxetine"]],
    ["Prucalopride (Oral Pill)", true, ["prucalopride"]],
    ["PRUDOXIN (Topical)", false, ["doxepin"]],
    ["Prussian blue insoluble (Oral Pill)", true, ["prussian blue insoluble"]],
    ["Pseudoephedrine (Oral Liquid)", true, ["pseudoephedrine"]],
    ["Pseudoephedrine (Oral Pill)", true, ["pseudoephedrine"]],
    ["Pseudoephedrine XR (Oral Pill)", true, ["pseudoephedrine"]],
    ["Pseudoephedrine/Pyrilamine (Oral Pill)", true, ["pseudoephedrine", "pyrilamine"]],
    ["Pseudoephedrine/Triprolidine (Oral Liquid)", true, ["pseudoephedrine", "triprolidine"]],
    ["Pseudoephedrine/Triprolidine (Oral Pill)", true, ["pseudoephedrine", "triprolidine"]],
    ["PSORCON (Topical)", false, ["diflorasone"]],
    ["PSORIASIN (Topical)", false, ["coal tar"]],
    ["PSORIASIN WASH (Soap)", false, ["salicylic acid"]],
    ["Psyllium (Oral Pill)", true, ["psyllium"]],
    ["Psyllium (Oral Suspension Powder)", true, ["psyllium"]],
    ["Psyllium (Oral Wafer)", true, ["psyllium"]],
    ["PULMICORT (Inhalant)", false, ["budesonide"]],
    ["PULMOSAL (Inhalant)", false, ["sodium chloride"]],
    ["PULMOZYME (Inhalant)", false, ["dornase alfa"]],
    ["PURELAX (Oral Solution Powder)", true, ["polyethylene glycol 3350"]],
    ["Purified protein derivative of tuberculin (Injectable)", false, ["purified protein derivative of tuberculin"]],
    ["PURIXAN (Oral Liquid)", true, ["mercaptopurine"]],
    ["PYLERA (Oral Pill)", true, ["bismuth subcitrate", "metronidazole", "tetracycline"]],
    ["PYQUVI (Oral Liquid)", true, ["deflazacort"]],
    ["Pyrantel (Chewable)", true, ["pyrantel"]],
    ["Pyrantel (Oral Liquid)", true, ["pyrantel"]],
    ["Pyrantel (Oral Pill)", true, ["pyrantel"]],
    ["Pyrazinamide (Oral Pill)", true, ["pyrazinamide"]],
    ["PYRIDIUM (Oral Pill)", true, ["phenazopyridine"]],
    ["pyRIDostigmine (Injectable)", false, ["pyridostigmine"]],
    ["pyRIDostigmine (Oral Liquid)", true, ["pyridostigmine"]],
    ["pyRIDostigmine (Oral Pill)", true, ["pyridostigmine"]],
    ["pyRIDostigmine XR (Oral Pill)", true, ["pyridostigmine"]],
    ["Pyridoxine (Injectable)", false, ["pyridoxine"]],
    ["Pyridoxine (Oral Pill)", true, ["pyridoxine"]],
    ["Pyridoxine/Thiamine/Vitamin B12 (Oral Pill)", true, ["pyridoxine", "thiamine", "vitamin B12"]],
    ["Pyrilamine (Oral Liquid)", true, ["pyrilamine"]],
    ["Pyrimethamine (Oral Pill)", true, ["pyrimethamine"]],
    ["Pyrogallol (Topical)", false, ["pyrogallol"]],
    ["PYRUKYND (Oral Pill)", true, ["mitapivat"]],
    ["PYRUKYND 20 MG / 50 MG TAPER (Pack)", true, ["mitapivat"]],
    ["PYRUKYND 20 MG 4-WEEK (Pack)", true, ["mitapivat"]],
    ["PYRUKYND 5 MG / 20 MG TAPER (Pack)", true, ["mitapivat"]],
    ["PYRUKYND 5 MG 4-WEEK (Pack)", true, ["mitapivat"]],
    ["PYRUKYND 5 MG TAPER (Pack)", true, ["mitapivat"]],
    ["PYRUKYND 50 MG 4-WEEK (Pack)", true, ["mitapivat"]],
    ["PYZCHIVA (Injectable)", false, ["ustekinumab"]],
    ["Q-SORB CO Q-10 (Oral Pill)", true, ["ubidecarenone"]],
    ["QALSODY (Injectable)", false, ["tofersen"]],
    ["QAMZOVA (Injectable)", false, ["meloxicam"]],
    ["QBRELIS (Oral Liquid)", true, ["lisinopril"]],
    ["QBREXZA (Topical)", false, ["glycopyrronium"]],
    ["QDOLO (Oral Liquid)", true, ["tramadol"]],
    ["QELBREE XR (Oral Pill)", true, ["viloxazine"]],
    ["QFITLIA (Injectable)", false, ["fitusiran"]],
    ["QINLOCK (Oral Pill)", true, ["ripretinib"]],
    ["QIVIGY (Injectable)", false, ["immunoglobulin G"]],
    ["QLEARQUIL NASAL DECONGESTANT (Nasal)", false, ["oxymetazoline"]],
    ["QLONILIK (Oral Liquid)", true, ["clonidine"]],
    ["QLOSI (Ophthalmic)", false, ["pilocarpine"]],
    ["QMIIZ (Oral Disintegrating)", true, ["meloxicam"]],
    ["QNASL (Nasal)", false, ["beclomethasone"]],
    ["QSYMIA XR (Oral Pill)", true, ["phentermine", "topiramate"]],
    ["QTERN (Oral Pill)", true, ["dapagliflozin", "saxagliptin"]],
    ["QUADRACEL (Injectable)", false, ["acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "poliovirus vaccine inactivated, type 1 (Mahoney)", "poliovirus vaccine inactivated, type 2 (MEF-1)", "poliovirus vaccine inactivated, type 3 (Saukett)", "tetanus toxoid vaccine, inactivated"]],
    ["QUADRAMET (Injectable)", false, ["samarium"]],
    ["QUALAQUIN (Oral Pill)", true, ["quinine"]],
    ["QUARTETTE 91 DAY PACK (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Quazepam (Oral Pill)", true, ["quazepam"]],
    ["QUDEXY XR (Oral Pill)", true, ["topiramate"]],
    ["QUELICIN (Injectable)", false, ["succinylcholine"]],
    ["Quercetin (Oral Pill)", true, ["quercetin"]],
    ["QUESTRAN (Oral Suspension Powder)", true, ["cholestyramine resin"]],
    ["QUEtiapine (Oral Pill)", true, ["quetiapine"]],
    ["QUEtiapine (Pack)", true, ["quetiapine"]],
    ["QUEtiapine XR (Oral Pill)", true, ["quetiapine"]],
    ["QUILLICHEW XR (Chewable)", true, ["methylphenidate"]],
    ["QUILLIVANT XR (Oral Liquid)", true, ["methylphenidate"]],
    ["Quinapril (Oral Pill)", true, ["quinapril"]],
    ["quiNIDine (Oral Pill)", true, ["quinidine"]],
    ["quiNIDine XR (Oral Pill)", true, ["quinidine"]],
    ["quiNINE (Oral Pill)", true, ["quinine"]],
    ["QUINJA (Topical)", false, ["aloe polysaccharide", "iodoquinol"]],
    ["QUINZYME (Oral Disintegrating)", true, ["ubidecarenone"]],
    ["QUIOFIC (Oral Liquid)", true, ["folic acid"]],
    ["Quizartinib (Oral Pill)", true, ["quizartinib"]],
    ["QULIPTA (Oral Pill)", true, ["atogepant"]],
    ["QUTENZA (Topical)", false, ["capsaicin"]],
    ["QUVIVIQ (Oral Pill)", true, ["daridorexant"]],
    ["QUZYTTIR (Injectable)", false, ["cetirizine"]],
    ["QVAR (Inhalant)", false, ["beclomethasone"]],
    ["R A ACNE (Topical)", false, ["resorcinol"]],
    ["RABAVERT (Injectable)", false, ["rabies virus vaccine flury-lep strain"]],
    ["RABEprazole (Oral Granules)", true, ["rabeprazole"]],
    ["RABEprazole (Oral Pill)", true, ["rabeprazole"]],
    ["Rabies immune globulin, human (Injectable)", false, ["rabies immune globulin, human"]],
    ["Rabies virus vaccine flury-lep strain (Injectable)", false, ["rabies virus vaccine flury-lep strain"]],
    ["Rabies virus vaccine wistar strain PM-1503-3M (human), inactivated (Injectable)", false, ["rabies virus vaccine wistar strain PM-1503-3M (human), inactivated"]],
    ["Racepinephrine (Inhalant)", false, ["racepinephrine"]],
    ["RADIAGUARD (Topical)", false, ["lidocaine"]],
    ["RADICAVA (Injectable)", false, ["edaravone"]],
    ["RADICAVA (Oral Liquid)", true, ["edaravone"]],
    ["RADIOGARDASE (Oral Pill)", true, ["prussian blue insoluble"]],
    ["Radium (Injectable)", false, ["radium"]],
    ["RAGWITEK (Sublingual)", false, ["short ragweed pollen extract"]],
    ["RALDESY (Oral Liquid)", true, ["trazodone"]],
    ["Raloxifene (Oral Pill)", true, ["raloxifene"]],
    ["Raltegravir (Chewable)", true, ["raltegravir"]],
    ["Raltegravir (Oral Pill)", true, ["raltegravir"]],
    ["Raltegravir (Oral Suspension Granules)", true, ["raltegravir"]],
    ["Ramelteon (Oral Pill)", true, ["ramelteon"]],
    ["Ramipril (Oral Liquid)", true, ["ramipril"]],
    ["Ramipril (Oral Pill)", true, ["ramipril"]],
    ["Ramucirumab (Injectable)", false, ["ramucirumab"]],
    ["RANEXA XR (Oral Pill)", true, ["ranolazine"]],
    ["Ranibizumab (Injectable)", false, ["ranibizumab"]],
    ["Ranitidine (Oral Pill)", true, ["ranitidine"]],
    ["Ranolazine (Oral Granules)", true, ["ranolazine"]],
    ["Ranolazine XR (Oral Pill)", true, ["ranolazine"]],
    ["RAPAFLO (Oral Pill)", true, ["silodosin"]],
    ["RAPAMUNE (Oral Liquid)", true, ["sirolimus"]],
    ["RAPAMUNE (Oral Pill)", true, ["sirolimus"]],
    ["RAPIBLYK (Injectable)", false, ["landiolol"]],
    ["RAPIVAB (Injectable)", false, ["peramivir"]],
    ["Rasagiline (Oral Pill)", true, ["rasagiline"]],
    ["Rasburicase (Injectable)", false, ["rasburicase"]],
    ["RASH RELIEF ANTIBACTERIAL (Topical)", false, ["bacitracin", "dimethicone", "zinc oxide"]],
    ["RASH RELIEF ANTIFUNGAL (Topical)", false, ["dimethicone", "miconazole", "zinc oxide"]],
    ["RASH RELIEF CLEAR (Topical)", false, ["dimethicone", "petrolatum"]],
    ["RASH RELIEF WITH ZINC OXIDE (Topical)", false, ["dimethicone", "zinc oxide"]],
    ["RASONQUE (Oral Pill)", true, ["daraxonrasib"]],
    ["RASUVO (Injectable)", false, ["methotrexate"]],
    ["RAVICTI (Oral Liquid)", true, ["glycerol phenylbutyrate"]],
    ["Ravulizumab (Injectable)", false, ["ravulizumab"]],
    ["Raxibacumab (Injectable)", false, ["raxibacumab"]],
    ["RAYALDEE XR (Oral Pill)", true, ["calcifediol"]],
    ["RAYASAL (Topical)", false, ["salicylic acid"]],
    ["RAYOS (Oral Pill)", true, ["prednisone"]],
    ["REA-LO (Topical)", false, ["urea"]],
    ["REACT (Oral Pill)", true, ["levonorgestrel"]],
    ["REBIF (Injectable)", false, ["interferon beta-1a"]],
    ["REBIF REBIDOSE (Pack)", false, ["interferon beta-1a"]],
    ["REBIF TITRATION (Pack)", false, ["interferon beta-1a"]],
    ["REBINYN (Injectable)", false, ["factor IX"]],
    ["REBLOZYL (Injectable)", false, ["luspatercept"]],
    ["REBYOTA (Rectal)", false, ["fecal microbiota, live"]],
    ["RECARBRIO (Injectable)", false, ["cilastatin", "imipenem", "relebactam"]],
    ["RECLAST (Injectable)", false, ["zoledronic acid"]],
    ["RECLIPSEN 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["RECOMBINATE (Injectable)", false, ["factor VIII"]],
    ["RECOMBIVAX (Injectable)", false, ["hepatitis B surface antigen vaccine"]],
    ["RECORLEV (Oral Pill)", true, ["ketoconazole"]],
    ["RECORT PLUS (Rectal)", false, ["hydrocortisone"]],
    ["RECOTHROM (Topical)", false, ["thrombin"]],
    ["RECTICARE (Rectal)", false, ["lidocaine"]],
    ["RECTICARE ADVANCE CREAM (Topical)", false, ["lidocaine", "mineral oil", "petrolatum", "phenylephrine"]],
    ["RECTICARE WIPES (Topical)", false, ["glycerin", "lidocaine"]],
    ["RECTIV (Rectal)", false, ["nitroglycerin"]],
    ["RED CROSS CANKER SORE (Oral Ointment)", true, ["benzocaine"]],
    ["Red yeast rice (Oral Pill)", true, ["red yeast rice"]],
    ["Red yeast rice/Ubidecarenone (Oral Pill)", true, ["red yeast rice", "ubidecarenone"]],
    ["REDEMPLO (Injectable)", false, ["plozasiran"]],
    ["REDITREX (Injectable)", false, ["methotrexate"]],
    ["REDUTEMP (Oral Liquid)", true, ["acetaminophen"]],
    ["REFENESEN (Oral Pill)", true, ["guaifenesin"]],
    ["REFISSA (Topical)", false, ["tretinoin"]],
    ["REGENECARE (Topical)", false, ["lidocaine"]],
    ["REGENER-EYES (Ophthalmic)", false, ["glycerin"]],
    ["REGIOCIT (Injectable)", false, ["sodium chloride", "sodium citrate"]],
    ["REGLAN (Oral Pill)", true, ["metoclopramide"]],
    ["REGONOL (Injectable)", false, ["pyridostigmine"]],
    ["Regorafenib (Oral Pill)", true, ["regorafenib"]],
    ["REGOXIDINE (Topical)", false, ["minoxidil"]],
    ["REGRANEX (Topical)", false, ["becaplermin"]],
    ["REGULOID (Oral Pill)", true, ["psyllium"]],
    ["REGULOID (Oral Suspension Powder)", true, ["psyllium"]],
    ["Relacorilant (Oral Pill)", true, ["relacorilant"]],
    ["Relacorilant (Pack)", true, ["relacorilant"]],
    ["RELADOR (Topical)", false, ["lidocaine", "prilocaine"]],
    ["RELAFEN (Oral Pill)", true, ["nabumetone"]],
    ["RELAGARD (Vaginal)", false, ["acetic acid", "oxyquinoline"]],
    ["RELAGESIC (Oral Pill)", true, ["acetaminophen", "phenyltoloxamine"]],
    ["RELENZA (Inhalant)", false, ["zanamivir"]],
    ["RELEUKO (Injectable)", false, ["filgrastim"]],
    ["RELEXXII XR (Oral Pill)", true, ["methylphenidate"]],
    ["RELGAABI (Oral Pill)", true, ["gabapentin"]],
    ["RELION GLUCOSE (Oral Liquid)", true, ["cholecalciferol", "glucose"]],
    ["RELISTOR (Injectable)", false, ["methylnaltrexone"]],
    ["RELISTOR (Oral Pill)", true, ["methylnaltrexone"]],
    ["RELPAX (Oral Pill)", true, ["eletriptan"]],
    ["RELTONE (Oral Pill)", true, ["ursodeoxycholate"]],
    ["Relugolix (Oral Pill)", true, ["relugolix"]],
    ["Remdesivir (Injectable)", false, ["remdesivir"]],
    ["REMERON (Oral Disintegrating)", true, ["mirtazapine"]],
    ["REMERON (Oral Pill)", true, ["mirtazapine"]],
    ["Remestemcel-L (Injectable)", false, ["remestemcel-L"]],
    ["Remestemcel-L (Pack)", false, ["remestemcel-L"]],
    ["Remibrutinib (Oral Pill)", true, ["remibrutinib"]],
    ["REMICADE (Injectable)", false, ["infliximab"]],
    ["Remifentanil (Injectable)", false, ["remifentanil"]],
    ["Remimazolam (Injectable)", false, ["remimazolam"]],
    ["REMODULIN (Injectable)", false, ["treprostinil"]],
    ["RENA-VITE (Oral Pill)", true, ["D-biotin", "ascorbic acid", "folic acid", "niacinamide", "pantothenate", "pyridoxine", "riboflavin", "thiamine", "vitamin B12"]],
    ["RENACIDIN (Irrigation)", false, ["citric acid", "gluconolactone", "magnesium carbonate"]],
    ["RENAGEL (Oral Pill)", true, ["sevelamer"]],
    ["RENFLEXIS (Injectable)", false, ["infliximab"]],
    ["RENOVA (Topical)", false, ["tretinoin"]],
    ["RENTHYROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["RENVELA (Oral Pill)", true, ["sevelamer"]],
    ["RENVELA (Oral Suspension Powder)", true, ["sevelamer"]],
    ["Repaglinide (Oral Pill)", true, ["repaglinide"]],
    ["REPAN (Oral Pill)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["REPATHA (Injectable)", false, ["evolocumab"]],
    ["REPLESTA NX (Oral Wafer)", true, ["cholecalciferol", "vitamin E"]],
    ["Repotrectinib (Oral Pill)", true, ["repotrectinib"]],
    ["REPREXAIN (Oral Pill)", true, ["hydrocodone", "ibuprofen"]],
    ["RESINOL (Topical)", false, ["petrolatum", "resorcinol"]],
    ["Reslizumab (Injectable)", false, ["reslizumab"]],
    ["Resmetirom (Oral Pill)", true, ["resmetirom"]],
    ["Resorcinol (Topical)", false, ["resorcinol"]],
    ["Resorcinol/Sulfur (Topical)", false, ["resorcinol", "sulfur"]],
    ["RESPA-BR XR (Oral Pill)", true, ["brompheniramine"]],
    ["Respiratory syncytial virus pre-fusion F glycoprotein mRNA (Injectable)", false, ["respiratory syncytial virus pre-fusion F glycoprotein mRNA"]],
    ["Respiratory syncytial virus pre-fusion F protein (Injectable)", false, ["respiratory syncytial virus pre-fusion F protein"]],
    ["RESTASIS (Ophthalmic)", false, ["cyclosporine"]],
    ["RESTORIL (Oral Pill)", true, ["temazepam"]],
    ["Resveratrol (Oral Pill)", true, ["resveratrol"]],
    ["RETACRIT (Injectable)", false, ["epoetin alfa"]],
    ["Retapamulin (Topical)", false, ["retapamulin"]],
    ["RETAVASE (Injectable)", false, ["reteplase"]],
    ["Reteplase (Injectable)", false, ["reteplase"]],
    ["RETEVMO (Oral Pill)", true, ["selpercatinib"]],
    ["RETHYMIC (Implant)", false, ["allogeneic processed thymus tissue"]],
    ["Retifanlimab (Injectable)", false, ["retifanlimab"]],
    ["RETIN-A (Topical)", false, ["tretinoin"]],
    ["RETISERT (Implant)", false, ["fluocinolone"]],
    ["RETROVIR (Injectable)", false, ["zidovudine"]],
    ["RETROVIR (Oral Liquid)", true, ["zidovudine"]],
    ["RETROVIR (Oral Pill)", true, ["zidovudine"]],
    ["Revakinagene taroretcel (Implant)", false, ["revakinagene taroretcel"]],
    ["REVATIO (Injectable)", false, ["sildenafil"]],
    ["REVATIO (Oral Liquid)", true, ["sildenafil"]],
    ["REVATIO (Oral Pill)", true, ["sildenafil"]],
    ["REVCOVI (Injectable)", false, ["elapegademase"]],
    ["Revefenacin (Inhalant)", false, ["revefenacin"]],
    ["REVIA (Oral Pill)", true, ["naltrexone"]],
    ["REVITADERM WOUND CARE (Topical)", false, ["benzalkonium"]],
    ["REVLIMID (Oral Pill)", true, ["lenalidomide"]],
    ["REVONTO (Injectable)", false, ["dantrolene"]],
    ["REVTORPYK (Injectable)", false, ["gedatolisib"]],
    ["REVUFORJ (Oral Pill)", true, ["revumenib"]],
    ["Revumenib (Oral Pill)", true, ["revumenib"]],
    ["REXTOVY (Nasal)", false, ["naloxone"]],
    ["REXULTI (Oral Pill)", true, ["brexpiprazole"]],
    ["REYATAZ (Oral Pill)", true, ["atazanavir"]],
    ["REYATAZ (Oral Powder)", true, ["atazanavir"]],
    ["REYVOW (Oral Pill)", true, ["lasmiditan"]],
    ["Rezafungin (Injectable)", false, ["rezafungin"]],
    ["REZAMID (Topical)", false, ["resorcinol", "sulfur"]],
    ["REZDIFFRA (Oral Pill)", true, ["resmetirom"]],
    ["REZENOPY (Nasal)", false, ["naloxone"]],
    ["REZIPRES (Injectable)", false, ["ephedrine"]],
    ["REZLIDHIA (Oral Pill)", true, ["olutasidenib"]],
    ["REZUROCK (Oral Pill)", true, ["belumosudil"]],
    ["REZVOGLAR (Injectable)", false, ["insulin glargine"]],
    ["REZZAYO (Injectable)", false, ["rezafungin"]],
    ["RHAPSIDO (Oral Pill)", true, ["remibrutinib"]],
    ["RHINALL (Nasal)", false, ["phenylephrine"]],
    ["RHINARIS (Nasal)", false, ["sodium chloride"]],
    ["RHINOCORT (Nasal)", false, ["budesonide"]],
    ["Rho(D) immune globulin (Injectable)", false, ["Rho(D) immune globulin"]],
    ["RHOFADE (Topical)", false, ["oxymetazoline"]],
    ["RHOGAM (Injectable)", false, ["Rho(D) immune globulin"]],
    ["RHOPHYLAC (Injectable)", false, ["Rho(D) immune globulin"]],
    ["RHOPRESSA (Ophthalmic)", false, ["netarsudil"]],
    ["RHULI (Topical)", false, ["camphor", "menthol"]],
    ["RHUZDAH 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["RI-MAG PLUS (Oral Liquid)", true, ["magaldrate", "simethicone"]],
    ["RIABNI (Injectable)", false, ["rituximab"]],
    ["RIASTAP (Injectable)", false, ["fibrinogen"]],
    ["Ribavirin (Inhalant)", false, ["ribavirin"]],
    ["Ribavirin (Oral Pill)", true, ["ribavirin"]],
    ["Ribavirin (Pack)", true, ["ribavirin"]],
    ["Ribociclib (Oral Pill)", true, ["ribociclib"]],
    ["Ribociclib (Pack)", true, ["ribociclib"]],
    ["Riboflavin (Oral Pill)", true, ["riboflavin"]],
    ["Riboflavin 5'-phosphate (Ophthalmic)", false, ["riboflavin 5'-phosphate"]],
    ["Riboflavin 5'-phosphate (Pack)", false, ["riboflavin 5'-phosphate"]],
    ["RICOLA (Oral Lozenge)", true, ["menthol"]],
    ["RID (Shampoo)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["RIDAURA (Oral Pill)", true, ["auranofin"]],
    ["Rifabutin (Oral Pill)", true, ["rifabutin"]],
    ["RIFADIN (Injectable)", false, ["rifampin"]],
    ["RIFADIN (Oral Pill)", true, ["rifampin"]],
    ["rifAMPin (Injectable)", false, ["rifampin"]],
    ["rifAMPin (Oral Pill)", true, ["rifampin"]],
    ["Rifamycin SV (Oral Pill)", true, ["rifamycin SV"]],
    ["Rifapentine (Oral Pill)", true, ["rifapentine"]],
    ["rifAXIMin (Oral Pill)", true, ["rifaximin"]],
    ["Rilonacept (Injectable)", false, ["rilonacept"]],
    ["Rilpivirine (Injectable)", false, ["rilpivirine"]],
    ["Rilpivirine (Oral Pill)", true, ["rilpivirine"]],
    ["Rilpivirine (Oral Suspension Tablet)", true, ["rilpivirine"]],
    ["RILUTEK (Oral Pill)", true, ["riluzole"]],
    ["Riluzole (Oral Film)", true, ["riluzole"]],
    ["Riluzole (Oral Liquid)", true, ["riluzole"]],
    ["Riluzole (Oral Pill)", true, ["riluzole"]],
    ["Rilzabrutinib (Oral Pill)", true, ["rilzabrutinib"]],
    ["riMANTAdine (Oral Pill)", true, ["rimantadine"]],
    ["Rimegepant (Oral Disintegrating)", true, ["rimegepant"]],
    ["RIMSO-50 (Irrigation)", false, ["dimethyl sulfoxide"]],
    ["RINVOQ (Oral Liquid)", true, ["upadacitinib"]],
    ["RINVOQ XR (Oral Pill)", true, ["upadacitinib"]],
    ["Riociguat (Oral Pill)", true, ["riociguat"]],
    ["RIOMET (Oral Liquid)", true, ["metformin"]],
    ["Ripretinib (Oral Pill)", true, ["ripretinib"]],
    ["RISAMINE (Topical)", false, ["menthol", "zinc oxide"]],
    ["Risankizumab (Injectable)", false, ["risankizumab"]],
    ["Risdiplam (Oral Liquid)", true, ["risdiplam"]],
    ["Risdiplam (Oral Pill)", true, ["risdiplam"]],
    ["Risedronate (Oral Pill)", true, ["risedronate"]],
    ["Risedronate (Pack)", true, ["risedronate"]],
    ["RisperDAL (Injectable)", false, ["risperidone"]],
    ["RisperDAL (Oral Liquid)", true, ["risperidone"]],
    ["RisperDAL (Oral Pill)", true, ["risperidone"]],
    ["risperiDONE (Injectable)", false, ["risperidone"]],
    ["risperiDONE (Oral Disintegrating)", true, ["risperidone"]],
    ["risperiDONE (Oral Liquid)", true, ["risperidone"]],
    ["risperiDONE (Oral Pill)", true, ["risperidone"]],
    ["RITALIN (Oral Pill)", true, ["methylphenidate"]],
    ["RITALIN XR (Oral Pill)", true, ["methylphenidate"]],
    ["Ritlecitinib (Oral Pill)", true, ["ritlecitinib"]],
    ["Ritonavir (Oral Pill)", true, ["ritonavir"]],
    ["Ritonavir (Oral Powder)", true, ["ritonavir"]],
    ["RITUXAN (Injectable)", false, ["rituximab"]],
    ["RITUXAN HYCELA (Injectable)", false, ["hyaluronidase", "rituximab"]],
    ["riTUXimab (Injectable)", false, ["rituximab"]],
    ["Rivaroxaban (Oral Liquid)", true, ["rivaroxaban"]],
    ["Rivaroxaban (Oral Pill)", true, ["rivaroxaban"]],
    ["Rivaroxaban (Pack)", true, ["rivaroxaban"]],
    ["Rivastigmine (Oral Pill)", true, ["rivastigmine"]],
    ["Rivastigmine (Transdermal)", false, ["rivastigmine"]],
    ["RIVELSA 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["RIVFLOZA (Injectable)", false, ["nedosiran"]],
    ["RIXUBIS (Injectable)", false, ["factor IX"]],
    ["RIZAFILM (Oral Film)", true, ["rizatriptan"]],
    ["Rizatriptan (Oral Disintegrating)", true, ["rizatriptan"]],
    ["Rizatriptan (Oral Film)", true, ["rizatriptan"]],
    ["Rizatriptan (Oral Pill)", true, ["rizatriptan"]],
    ["ROBAFEN (Oral Liquid)", true, ["guaifenesin"]],
    ["ROBAFEN COUGH (Oral Pill)", true, ["dextromethorphan"]],
    ["ROBAXIN (Injectable)", false, ["methocarbamol"]],
    ["ROBINUL (Oral Pill)", true, ["glycopyrronium"]],
    ["ROCALTROL (Oral Liquid)", true, ["calcitriol"]],
    ["ROCALTROL (Oral Pill)", true, ["calcitriol"]],
    ["ROCKLATAN (Ophthalmic)", false, ["latanoprost", "netarsudil"]],
    ["ROCTAVIAN (Injectable)", false, ["valoctocogene roxaparvovec"]],
    ["Rocuronium (Injectable)", false, ["rocuronium"]],
    ["Roflumilast (Oral Pill)", true, ["roflumilast"]],
    ["Roflumilast (Topical)", false, ["roflumilast"]],
    ["ROGAINE (Topical)", false, ["minoxidil"]],
    ["ROLAIDS REFORMULATED AUG 2006 (Chewable)", true, ["calcium carbonate", "magnesium hydroxide"]],
    ["Rolapitant (Oral Pill)", true, ["rolapitant"]],
    ["ROLVEDON (Injectable)", false, ["eflapegrastim"]],
    ["romiDEPsin (Injectable)", false, ["romidepsin"]],
    ["romiPLOStim (Injectable)", false, ["romiplostim"]],
    ["Romosozumab (Injectable)", false, ["romosozumab"]],
    ["Romosozumab (Pack)", false, ["romosozumab"]],
    ["ROMVIMZA (Oral Pill)", true, ["vimseltinib"]],
    ["Ropeginterferon alfa-2b (Injectable)", false, ["ropeginterferon alfa-2b"]],
    ["rOPINIRole (Oral Pill)", true, ["ropinirole"]],
    ["rOPINIRole XR (Oral Pill)", true, ["ropinirole"]],
    ["ROPivacaine (Injectable)", false, ["ropivacaine"]],
    ["ROSADAN (Topical)", false, ["metronidazole"]],
    ["ROSANIL (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["ROSULA (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["ROSULA (Topical)", false, ["sulfacetamide", "sulfur"]],
    ["Rosuvastatin (Oral Pill)", true, ["rosuvastatin"]],
    ["ROSYRAH 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["ROSZET (Oral Pill)", true, ["ezetimibe", "rosuvastatin"]],
    ["ROTARIX (Oral Liquid)", true, ["rotavirus vaccine, live attenuated, G1P[8] human 89-12 strain"]],
    ["ROTATEQ (Oral Liquid)", true, ["human-bovine reassortant rotavirus strain G1 vaccine", "human-bovine reassortant rotavirus strain G2 vaccine", "human-bovine reassortant rotavirus strain G3 vaccine", "human-bovine reassortant rotavirus strain G4 vaccine", "human-bovine reassortant rotavirus strain P1A[8] vaccine"]],
    ["Rotavirus vaccine, live attenuated, G1P[8] human 89-12 strain (Oral Liquid)", true, ["rotavirus vaccine, live attenuated, G1P[8] human 89-12 strain"]],
    ["Rotigotine (Pack)", false, ["rotigotine"]],
    ["Rotigotine (Transdermal)", false, ["rotigotine"]],
    ["ROWASA (Rectal)", false, ["mesalamine"]],
    ["ROWEEPRA (Oral Pill)", true, ["levetiracetam"]],
    ["ROWEEPRA XR (Oral Pill)", true, ["levetiracetam"]],
    ["ROXICODONE (Oral Pill)", true, ["oxycodone"]],
    ["ROXYBOND (Oral Pill)", true, ["oxycodone"]],
    ["Royal jelly (Oral Pill)", true, ["royal jelly"]],
    ["Rozanolixizumab (Injectable)", false, ["rozanolixizumab"]],
    ["ROZEREM (Oral Pill)", true, ["ramelteon"]],
    ["ROZLYTREK (Oral Pellet)", true, ["entrectinib"]],
    ["ROZLYTREK (Oral Pill)", true, ["entrectinib"]],
    ["RUBRACA (Oral Pill)", true, ["rucaparib"]],
    ["Rucaparib (Oral Pill)", true, ["rucaparib"]],
    ["RUCONEST (Injectable)", false, ["C1 esterase inhibitor"]],
    ["Rufinamide (Oral Liquid)", true, ["rufinamide"]],
    ["Rufinamide (Oral Pill)", true, ["rufinamide"]],
    ["RUKOBIA XR (Oral Pill)", true, ["fostemsavir"]],
    ["Rusfertide (Injectable)", false, ["rusfertide"]],
    ["Rutin (Oral Pill)", true, ["rutin"]],
    ["RUXIENCE (Injectable)", false, ["rituximab"]],
    ["Ruxolitinib (Oral Pill)", true, ["ruxolitinib"]],
    ["Ruxolitinib (Topical)", false, ["ruxolitinib"]],
    ["Ruxolitinib XR (Oral Pill)", true, ["ruxolitinib"]],
    ["RYALTRIS (Nasal)", false, ["mometasone", "olopatadine"]],
    ["RYANODEX (Injectable)", false, ["dantrolene"]],
    ["RYBELSUS (Oral Pill)", true, ["semaglutide"]],
    ["RYBREVANT (Injectable)", false, ["amivantamab"]],
    ["RYBREVANT FASPRO (Injectable)", false, ["amivantamab", "hyaluronidase"]],
    ["RYCLORA (Oral Liquid)", true, ["dexchlorpheniramine"]],
    ["RYDAPT (Oral Pill)", true, ["midostaurin"]],
    ["RYKINDO (Injectable)", false, ["risperidone"]],
    ["RYLAZE (Injectable)", false, ["asparaginase"]],
    ["RYONCIL (Injectable)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 100 - < 112.5 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 112.5 - < 125 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 12.5 - < 25 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 125 - < 137.5 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 137.5 - < 150 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 25 - < 37.5 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 37.5 - < 50 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 50 - < 62.5 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 62.5 - < 75 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 75 - < 87.5 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT 87.5 - < 100 KG (Pack)", false, ["remestemcel-L"]],
    ["RYONCIL KIT < 12.5 KG (Pack)", false, ["remestemcel-L"]],
    ["RYPLAZIM (Injectable)", false, ["plasminogen"]],
    ["RYSTIGGO (Injectable)", false, ["rozanolixizumab"]],
    ["RYTARY XR (Oral Pill)", true, ["carbidopa", "levodopa"]],
    ["RYTELO (Injectable)", false, ["imetelstat"]],
    ["RYTHMOL XR (Oral Pill)", true, ["propafenone"]],
    ["RYVENT (Oral Pill)", true, ["carbinoxamine"]],
    ["RYZNEUTA (Injectable)", false, ["efbemalenograstim alfa"]],
    ["RYZUMVI (Ophthalmic)", false, ["phentolamine"]],
    ["S-2 (Inhalant)", false, ["racepinephrine"]],
    ["S-adenosylmethionine (Oral Pill)", true, ["S-adenosylmethionine"]],
    ["SABRIL (Oral Pill)", true, ["vigabatrin"]],
    ["SABRIL (Oral Solution Powder)", true, ["vigabatrin"]],
    ["Saccharomyces boulardii (Oral Pill)", true, ["Saccharomyces boulardii"]],
    ["Saccharomyces boulardii (Oral Suspension Powder)", true, ["Saccharomyces boulardii"]],
    ["Saccharomyces cerevisiae (Oral Pill)", true, ["Saccharomyces cerevisiae"]],
    ["Sacituzumab (Injectable)", false, ["sacituzumab"]],
    ["Sacrosidase (Oral Liquid)", true, ["sacrosidase"]],
    ["Sacubitril/Valsartan (Oral Pellet)", true, ["sacubitril", "valsartan"]],
    ["Sacubitril/Valsartan (Oral Pill)", true, ["sacubitril", "valsartan"]],
    ["Safinamide (Oral Pill)", true, ["safinamide"]],
    ["SAFYRAL 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol", "levomefolate"]],
    ["SAIZEN (Injectable)", false, ["somatropin"]],
    ["SAJAZIR (Injectable)", false, ["icatibant"]],
    ["SALAGEN (Oral Pill)", true, ["pilocarpine"]],
    ["SALETO (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine", "salicylamide"]],
    ["SALICOR (Topical)", false, ["trolamine salicylate"]],
    ["Salicylic acid (Pack)", false, ["salicylic acid"]],
    ["Salicylic acid (Paste)", false, ["salicylic acid"]],
    ["Salicylic acid (Shampoo)", false, ["salicylic acid"]],
    ["Salicylic acid (Soap)", false, ["salicylic acid"]],
    ["Salicylic acid (Topical)", false, ["salicylic acid"]],
    ["Salicylic acid/Sulfur (Shampoo)", false, ["salicylic acid", "sulfur"]],
    ["Salicylic acid/Sulfur (Soap)", false, ["salicylic acid", "sulfur"]],
    ["Salicylic acid/Thiosulfate (Topical)", false, ["salicylic acid", "thiosulfate"]],
    ["Salicylic acid/Urea (Pack)", false, ["salicylic acid", "urea"]],
    ["Salicylic acid/Urea (Topical)", false, ["salicylic acid", "urea"]],
    ["Salicylic acid/Zinc pyrithione (Shampoo)", false, ["salicylic acid", "zinc pyrithione"]],
    ["SALINOCAINE (Topical)", false, ["benzocaine", "salicylic acid"]],
    ["SALJET (Irrigation)", false, ["sodium chloride"]],
    ["Salmeterol (Inhalant)", false, ["salmeterol"]],
    ["Salmon calcitonin (Injectable)", false, ["salmon calcitonin"]],
    ["Salmon calcitonin (Nasal)", false, ["salmon calcitonin"]],
    ["Salmon oil (Oral Pill)", true, ["salmon oil"]],
    ["Salmonella typhi Ty21a live antigen (Oral Pill)", true, ["Salmonella typhi Ty21a live antigen"]],
    ["Salsalate (Oral Pill)", true, ["salsalate"]],
    ["SALTAIRE (Nasal)", false, ["sodium chloride"]],
    ["SALVAX (Topical)", false, ["salicylic acid"]],
    ["SALVAX DUO PLUS (Pack)", false, ["salicylic acid", "urea"]],
    ["SALYCIM (Topical)", false, ["salicylic acid"]],
    ["SALYNTRA (Topical)", false, ["salicylic acid"]],
    ["Samarium (Injectable)", false, ["samarium"]],
    ["SAMSCA (Oral Pill)", true, ["tolvaptan"]],
    ["SAMSON 8 (Oral Pill)", true, ["ibuprofen"]],
    ["SANCUSO (Transdermal)", false, ["granisetron"]],
    ["SandIMMUNE (Injectable)", false, ["cyclosporine"]],
    ["SandIMMUNE (Oral Liquid)", true, ["cyclosporine"]],
    ["SandIMMUNE (Oral Pill)", true, ["cyclosporine"]],
    ["SandoSTATIN (Injectable)", false, ["octreotide"]],
    ["SANTYL (Topical)", false, ["collagenase"]],
    ["SAPHNELO (Injectable)", false, ["anifrolumab"]],
    ["SAPHRIS (Sublingual)", false, ["asenapine"]],
    ["Sapropterin (Oral Pill)", true, ["sapropterin"]],
    ["Sapropterin (Oral Solution Powder)", true, ["sapropterin"]],
    ["SARCLISA (Injectable)", false, ["isatuximab"]],
    ["Sarecycline (Oral Pill)", true, ["sarecycline"]],
    ["Sargramostim (Injectable)", false, ["sargramostim"]],
    ["Sarilumab (Injectable)", false, ["sarilumab"]],
    ["SARNOL-HC (Topical)", false, ["hydrocortisone"]],
    ["Sarracenia purpurea preparation (Injectable)", false, ["Sarracenia purpurea preparation"]],
    ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["SARS-COV-2 (COVID-19) vaccine, subunit, recombinant spike protein (Injectable)", false, ["SARS-COV-2 (COVID-19) vaccine, subunit, recombinant spike protein"]],
    ["Satralizumab (Injectable)", false, ["satralizumab"]],
    ["SAVAYSA (Oral Pill)", true, ["edoxaban"]],
    ["SAVELLA (Oral Pill)", true, ["milnacipran"]],
    ["SAVELLA 4-WEEK TITRATION (Pack)", true, ["milnacipran"]],
    ["sAXagliptin (Oral Pill)", true, ["saxagliptin"]],
    ["SAXENDA (Injectable)", false, ["liraglutide"]],
    ["SCALACORT (Topical)", false, ["hydrocortisone"]],
    ["SCALACORT DK (Pack)", false, ["hydrocortisone", "salicylic acid", "sulfur"]],
    ["SCALPICIN ITCH RELIEF (Topical)", false, ["hydrocortisone"]],
    ["SCALPICIN SCALP RELIEF (Topical)", false, ["salicylic acid"]],
    ["SCANDONEST (Injectable)", false, ["mepivacaine"]],
    ["SCEMBLIX (Oral Pill)", true, ["asciminib"]],
    ["SCENESSE (Implant)", false, ["afamelanotide"]],
    ["SCHIFF (Oral Pill)", true, ["chondroitin sulfates", "glucosamine"]],
    ["SCLEROSOL (Topical)", false, ["talc"]],
    ["Scopolamine (Transdermal)", false, ["scopolamine"]],
    ["SCOT-TUSSIN (Oral Liquid)", true, ["guaifenesin"]],
    ["SCOT-TUSSIN DIABETIC CF (Oral Liquid)", true, ["dextromethorphan"]],
    ["SCOT-TUSSIN DM COUGH CHASERS (Oral Lozenge)", true, ["dextromethorphan"]],
    ["SCYTERA (Topical)", false, ["coal tar"]],
    ["SDAMLO (Oral Solution Powder)", true, ["amlodipine"]],
    ["SEA SOFT (Nasal)", false, ["sodium chloride"]],
    ["SEBASORB (Topical)", false, ["salicylic acid"]],
    ["Sebelipase alfa (Injectable)", false, ["sebelipase alfa"]],
    ["Sebetralstat (Oral Pill)", true, ["sebetralstat"]],
    ["SEBEX (Shampoo)", false, ["salicylic acid", "sulfur"]],
    ["SEBULEX (Shampoo)", false, ["salicylic acid", "sulfur"]],
    ["Secnidazole (Oral Granules)", true, ["secnidazole"]],
    ["Secretin human, synthetic (Injectable)", false, ["secretin human, synthetic"]],
    ["SECUADO (Transdermal)", false, ["asenapine"]],
    ["Secukinumab (Injectable)", false, ["secukinumab"]],
    ["SEGLENTIS (Oral Pill)", true, ["celecoxib", "tramadol"]],
    ["SEGLUROMET (Oral Pill)", true, ["ertugliflozin", "metformin"]],
    ["Seladelpar (Oral Pill)", true, ["seladelpar"]],
    ["SELARSDI (Injectable)", false, ["ustekinumab"]],
    ["Selegiline (Oral Disintegrating)", true, ["selegiline"]],
    ["Selegiline (Oral Pill)", true, ["selegiline"]],
    ["Selegiline (Transdermal)", false, ["selegiline"]],
    ["Selenious acid (Injectable)", false, ["selenious acid"]],
    ["Selenium sulfide (Shampoo)", false, ["selenium sulfide"]],
    ["Selenium sulfide (Topical)", false, ["selenium sulfide"]],
    ["Selenomethionine (Oral Pill)", true, ["selenomethionine"]],
    ["Selexipag (Injectable)", false, ["selexipag"]],
    ["Selexipag (Oral Pill)", true, ["selexipag"]],
    ["Selexipag (Pack)", true, ["selexipag"]],
    ["Selinexor (Oral Pill)", true, ["selinexor"]],
    ["Selinexor (Pack)", true, ["selinexor"]],
    ["Selpercatinib (Oral Pill)", true, ["selpercatinib"]],
    ["SELRX (Shampoo)", false, ["selenium sulfide"]],
    ["SELSUN BLUE (Shampoo)", false, ["selenium sulfide"]],
    ["SELSUN BLUE NATURALS (Shampoo)", false, ["salicylic acid"]],
    ["SELSUN BLUE SENSITIVE SCALP (Shampoo)", false, ["zinc pyrithione"]],
    ["Selumetinib (Oral Granules)", true, ["selumetinib"]],
    ["Selumetinib (Oral Pill)", true, ["selumetinib"]],
    ["SELZENTRY (Oral Liquid)", true, ["maraviroc"]],
    ["SELZENTRY (Oral Pill)", true, ["maraviroc"]],
    ["Semaglutide (Injectable)", false, ["semaglutide"]],
    ["Semaglutide (Oral Pill)", true, ["semaglutide"]],
    ["SEMGLEE (Injectable)", false, ["insulin glargine"]],
    ["SENEXON (Oral Liquid)", true, ["sennosides, USP"]],
    ["SENEXON S (Oral Pill)", true, ["docusate", "sennosides, USP"]],
    ["SENNA-TIME (Oral Pill)", true, ["sennosides, USP"]],
    ["Sennosides, USP (Chewable)", true, ["sennosides, USP"]],
    ["Sennosides, USP (Oral Film)", true, ["sennosides, USP"]],
    ["Sennosides, USP (Oral Liquid)", true, ["sennosides, USP"]],
    ["Sennosides, USP (Oral Pill)", true, ["sennosides, USP"]],
    ["SENOKOT (Oral Pill)", true, ["sennosides, USP"]],
    ["SENOKOT-S (Oral Pill)", true, ["docusate", "sennosides, USP"]],
    ["SENOSOL (Oral Pill)", true, ["sennosides, USP"]],
    ["SENOSOL-SS (Oral Pill)", true, ["docusate", "sennosides, USP"]],
    ["SENSIPAR (Oral Pill)", true, ["cinacalcet"]],
    ["SENSORCAINE (Injectable)", false, ["bupivacaine"]],
    ["SENSORCAINE WITH EPINEPHrine (Injectable)", false, ["bupivacaine", "epinephrine"]],
    ["SEPHIENCE (Oral Powder)", true, ["sepiapterin"]],
    ["Sepiapterin (Oral Powder)", true, ["sepiapterin"]],
    ["SEPTOCAINE (Injectable)", false, ["articaine", "epinephrine"]],
    ["SEREVENT (Inhalant)", false, ["salmeterol"]],
    ["SERNIVO (Topical)", false, ["betamethasone"]],
    ["SEROMYCIN (Oral Pill)", true, ["cycloserine"]],
    ["SEROQUEL (Oral Pill)", true, ["quetiapine"]],
    ["SEROQUEL XR (Oral Pill)", true, ["quetiapine"]],
    ["SEROQUEL XR 14-DAY SAMPLE KIT (Pack)", true, ["quetiapine"]],
    ["SEROSTIM (Injectable)", false, ["somatropin"]],
    ["Sertaconazole (Topical)", false, ["sertaconazole"]],
    ["Sertraline (Oral Liquid)", true, ["sertraline"]],
    ["Sertraline (Oral Pill)", true, ["sertraline"]],
    ["SETLAKIN 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Setmelanotide (Injectable)", false, ["setmelanotide"]],
    ["Sevabertinib (Oral Pill)", true, ["sevabertinib"]],
    ["Sevelamer (Oral Pill)", true, ["sevelamer"]],
    ["Sevelamer (Oral Suspension Powder)", true, ["sevelamer"]],
    ["SEVENFACT (Injectable)", false, ["factor VIIa"]],
    ["Sevoflurane (Inhalant)", false, ["sevoflurane"]],
    ["SEYSARA (Oral Pill)", true, ["sarecycline"]],
    ["SEZABY (Injectable)", false, ["phenobarbital"]],
    ["Shark liver oil (Oral Pill)", true, ["shark liver oil"]],
    ["SHAROBEL 28 DAY (Pack)", true, ["norethindrone"]],
    ["SHEWISE (Oral Pill)", true, ["levonorgestrel"]],
    ["SHINGRIX (Injectable)", false, ["varicella zoster virus glycoprotein E"]],
    ["Short ragweed pollen extract (Sublingual)", false, ["short ragweed pollen extract"]],
    ["Sibeprenlimab (Injectable)", false, ["sibeprenlimab"]],
    ["SIGNIFOR (Injectable)", false, ["pasireotide"]],
    ["SIKLOS (Oral Pill)", true, ["hydroxyurea"]],
    ["SILADRYL (Oral Liquid)", true, ["diphenhydramine"]],
    ["Sildenafil (Injectable)", false, ["sildenafil"]],
    ["Sildenafil (Oral Film)", true, ["sildenafil"]],
    ["Sildenafil (Oral Liquid)", true, ["sildenafil"]],
    ["Sildenafil (Oral Pill)", true, ["sildenafil"]],
    ["SILENOR (Oral Pill)", true, ["doxepin"]],
    ["Silicon dioxide (Oral Pill)", true, ["silicon dioxide"]],
    ["SILIQ (Injectable)", false, ["brodalumab"]],
    ["SILKA CREAM (Topical)", false, ["terbinafine"]],
    ["Silodosin (Oral Pill)", true, ["silodosin"]],
    ["SILTUSSIN (Oral Liquid)", true, ["guaifenesin"]],
    ["Siltuximab (Injectable)", false, ["siltuximab"]],
    ["SILVADENE (Topical)", false, ["silver sulfadiazine"]],
    ["Silver nitrate (Topical)", false, ["silver nitrate"]],
    ["silver sulfADIAZINE (Topical)", false, ["silver sulfadiazine"]],
    ["SIMBRINZA (Ophthalmic)", false, ["brimonidine", "brinzolamide"]],
    ["Simethicone (Chewable)", true, ["simethicone"]],
    ["Simethicone (Oral Film)", true, ["simethicone"]],
    ["Simethicone (Oral Liquid)", true, ["simethicone"]],
    ["Simethicone (Oral Pill)", true, ["simethicone"]],
    ["SIMLANDI (Injectable)", false, ["adalimumab"]],
    ["SIMLIYA 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["SIMPESSE 91 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["SIMPLY SALINE (Nasal)", false, ["sodium chloride"]],
    ["SIMPLY SLEEP (Oral Pill)", true, ["diphenhydramine"]],
    ["SIMPONI (Injectable)", false, ["golimumab"]],
    ["SIMULECT (Injectable)", false, ["basiliximab"]],
    ["Simvastatin (Oral Liquid)", true, ["simvastatin"]],
    ["Simvastatin (Oral Pill)", true, ["simvastatin"]],
    ["Sincalide (Injectable)", false, ["sincalide"]],
    ["Sinecatechins (Topical)", false, ["sinecatechins"]],
    ["SINEMET (Oral Pill)", true, ["carbidopa", "levodopa"]],
    ["SINEX LONG-ACTING (Nasal)", false, ["oxymetazoline"]],
    ["SINGULAIR (Chewable)", true, ["montelukast"]],
    ["SINGULAIR (Oral Granules)", true, ["montelukast"]],
    ["SINGULAIR (Oral Pill)", true, ["montelukast"]],
    ["SINUVA (Implant)", false, ["mometasone"]],
    ["Siponimod (Oral Pill)", true, ["siponimod"]],
    ["Siponimod (Pack)", true, ["siponimod"]],
    ["Sipuleucel-T (Injectable)", false, ["sipuleucel-T"]],
    ["Sirolimus (Injectable)", false, ["sirolimus"]],
    ["Sirolimus (Oral Liquid)", true, ["sirolimus"]],
    ["Sirolimus (Oral Pill)", true, ["sirolimus"]],
    ["Sirolimus (Topical)", false, ["sirolimus"]],
    ["SIRTURO (Oral Pill)", true, ["bedaquiline"]],
    ["SITagliptin (Oral Liquid)", true, ["sitagliptin"]],
    ["SITagliptin (Oral Pill)", true, ["sitagliptin"]],
    ["SITAVIG (Buccal)", false, ["acyclovir"]],
    ["SIVEXTRO (Injectable)", false, ["tedizolid"]],
    ["SIVEXTRO (Oral Pill)", true, ["tedizolid"]],
    ["SKELAXIN (Oral Pill)", true, ["metaxalone"]],
    ["SKLICE (Topical)", false, ["ivermectin"]],
    ["SKYCLARYS (Oral Pill)", true, ["omaveloxolone"]],
    ["SKYLA (Intrauterine)", false, ["levonorgestrel"]],
    ["SKYRIZI (Injectable)", false, ["risankizumab"]],
    ["SKYSONA (Injectable)", false, ["elivaldogene autotemcel"]],
    ["SKYTROFA (Injectable)", false, ["lonapegsomatropin"]],
    ["SLEEPINAL (Oral Pill)", true, ["diphenhydramine"]],
    ["SLO-NIACIN XR (Oral Pill)", true, ["niacin"]],
    ["SLOAN'S LINIMENT (Topical)", false, ["capsaicin", "turpentine"]],
    ["SLOW-FE XR (Oral Pill)", true, ["ferrous sulfate"]],
    ["SLOW-MAG REFORMULATED FEB 2012 (Oral Pill)", true, ["calcium carbonate", "magnesium chloride"]],
    ["SLYND (Pack)", true, ["drospirenone"]],
    ["Smallpox vaccine live, New York City Board of Health vaccinia strain (Injectable)", false, ["smallpox vaccine live, New York City Board of Health vaccinia strain"]],
    ["SOAANZ (Oral Pill)", true, ["torsemide"]],
    ["Sodium acetate (Injectable)", false, ["sodium acetate"]],
    ["Sodium bicarbonate (Injectable)", false, ["sodium bicarbonate"]],
    ["Sodium bicarbonate (Oral Pill)", true, ["sodium bicarbonate"]],
    ["Sodium bicarbonate/Sodium chloride (Nasal Solution Powder)", false, ["sodium bicarbonate", "sodium chloride"]],
    ["Sodium chloride (Inhalant)", false, ["sodium chloride"]],
    ["Sodium chloride (Injectable)", false, ["sodium chloride"]],
    ["Sodium chloride (Irrigation)", false, ["sodium chloride"]],
    ["Sodium chloride (Nasal)", false, ["sodium chloride"]],
    ["Sodium chloride (Ophthalmic)", false, ["sodium chloride"]],
    ["Sodium chloride (Oral Liquid)", true, ["sodium chloride"]],
    ["Sodium chloride (Oral Pill)", true, ["sodium chloride"]],
    ["Sodium chloride (Topical)", false, ["sodium chloride"]],
    ["Sodium chloride/Sodium citrate (Injectable)", false, ["sodium chloride", "sodium citrate"]],
    ["Sodium citrate (Chewable)", true, ["sodium citrate"]],
    ["Sodium ferric gluconate complex (Injectable)", false, ["sodium ferric gluconate complex"]],
    ["Sodium fluoride (Chewable)", true, ["sodium fluoride"]],
    ["Sodium fluoride (Mouthwash)", false, ["sodium fluoride"]],
    ["Sodium fluoride (Oral Foam)", true, ["sodium fluoride"]],
    ["Sodium fluoride (Oral Gel)", true, ["sodium fluoride"]],
    ["Sodium fluoride (Oral Liquid)", true, ["sodium fluoride"]],
    ["Sodium fluoride (Oral Pill)", true, ["sodium fluoride"]],
    ["Sodium fluoride (Toothpaste)", false, ["sodium fluoride"]],
    ["Sodium hydroxide (Topical)", false, ["sodium hydroxide"]],
    ["Sodium iodide (Injectable)", false, ["sodium iodide"]],
    ["Sodium nitrite (Injectable)", false, ["sodium nitrite"]],
    ["Sodium nitrite/Thiosulfate (Pack)", false, ["sodium nitrite", "thiosulfate"]],
    ["Sodium phosphate, dibasic/Sodium phosphate, monobasic (Injectable)", false, ["sodium phosphate, dibasic", "sodium phosphate, monobasic"]],
    ["Sodium phosphate, dibasic/Sodium phosphate, monobasic (Oral Liquid)", true, ["sodium phosphate, dibasic", "sodium phosphate, monobasic"]],
    ["Sodium phosphate, dibasic/Sodium phosphate, monobasic (Rectal)", false, ["sodium phosphate, dibasic", "sodium phosphate, monobasic"]],
    ["Sodium polystyrene sulfonate (Oral Liquid)", true, ["sodium polystyrene sulfonate"]],
    ["Sodium polystyrene sulfonate (Oral Suspension Powder)", true, ["sodium polystyrene sulfonate"]],
    ["Sodium tetradecyl sulfate (Injectable)", false, ["sodium tetradecyl sulfate"]],
    ["Sodium zirconium cyclosilicate (Oral Suspension Powder)", true, ["sodium zirconium cyclosilicate"]],
    ["SOFDRA (Topical)", false, ["sofpironium"]],
    ["Sofosbuvir (Oral Pellet)", true, ["sofosbuvir"]],
    ["Sofosbuvir (Oral Pill)", true, ["sofosbuvir"]],
    ["Sofosbuvir/Velpatasvir (Oral Pellet)", true, ["sofosbuvir", "velpatasvir"]],
    ["Sofosbuvir/Velpatasvir (Oral Pill)", true, ["sofosbuvir", "velpatasvir"]],
    ["Sofosbuvir/Velpatasvir/Voxilaprevir (Oral Pill)", true, ["sofosbuvir", "velpatasvir", "voxilaprevir"]],
    ["Sofpironium (Topical)", false, ["sofpironium"]],
    ["SOGROYA (Injectable)", false, ["somapacitan"]],
    ["SOHONOS (Oral Pill)", true, ["palovarotene"]],
    ["SOJOURN (Inhalant)", false, ["sevoflurane"]],
    ["SOLARCAINE (Topical)", false, ["lidocaine"]],
    ["SOLARCAINE PLUS ALOE (Topical)", false, ["benzocaine"]],
    ["Solifenacin (Oral Liquid)", true, ["solifenacin"]],
    ["Solifenacin (Oral Pill)", true, ["solifenacin"]],
    ["SOLIQUA (Injectable)", false, ["insulin glargine", "lixisenatide"]],
    ["SOLIRIS (Injectable)", false, ["eculizumab"]],
    ["SOLODYN XR (Oral Pill)", true, ["minocycline"]],
    ["SOLOSEC (Oral Granules)", true, ["secnidazole"]],
    ["Solriamfetol (Oral Pill)", true, ["solriamfetol"]],
    ["SOLTAMOX (Oral Liquid)", true, ["tamoxifen"]],
    ["Solu-CORTEF (Injectable)", false, ["hydrocortisone"]],
    ["SOLU-Medrol (Injectable)", false, ["methylprednisolone"]],
    ["SOLUCLENZ (Topical)", false, ["benzoyl peroxide"]],
    ["SOMA (Oral Pill)", true, ["carisoprodol"]],
    ["Somapacitan (Injectable)", false, ["somapacitan"]],
    ["Somatrogon (Injectable)", false, ["somatrogon"]],
    ["Somatropin (Injectable)", false, ["somatropin"]],
    ["SOMATULINE (Injectable)", false, ["lanreotide"]],
    ["SOMAVERT (Injectable)", false, ["pegvisomant"]],
    ["SOMBRA WARM PAIN RELIEVING GEL (Topical)", false, ["camphor", "menthol"]],
    ["SOMINEX (Oral Pill)", true, ["diphenhydramine"]],
    ["SOMNICIN (Oral Pill)", true, ["5-hydroxytryptophan", "magnesium oxide", "melatonin", "tryptophan", "vitamin B6"]],
    ["Sonidegib (Oral Pill)", true, ["sonidegib"]],
    ["Sonrotoclax (Oral Pill)", true, ["sonrotoclax"]],
    ["Sonrotoclax (Pack)", true, ["sonrotoclax"]],
    ["SOOLANTRA (Topical)", false, ["ivermectin"]],
    ["SOOTHE & COOL MOISTURE BARRIER (Topical)", false, ["petrolatum"]],
    ["SOOTHE & COOL POWDER (Topical)", false, ["corn starch"]],
    ["SOOTHE LUBRICANT EYE DROPS (Ophthalmic)", false, ["glycerin", "propylene glycol"]],
    ["SOOTHE MINERAL OIL (Ophthalmic)", false, ["mineral oil", "mineral oil, light"]],
    ["SOOTHE NIGHT TIME (Ophthalmic)", false, ["mineral oil", "petrolatum"]],
    ["SORAfenib (Oral Pill)", true, ["sorafenib"]],
    ["Sorbitol (Irrigation)", false, ["sorbitol"]],
    ["Sorbitol (Oral Liquid)", true, ["sorbitol"]],
    ["Sorbitol (Rectal)", false, ["sorbitol"]],
    ["SORILUX (Topical)", false, ["calcipotriene"]],
    ["Sotagliflozin (Oral Pill)", true, ["sotagliflozin"]],
    ["Sotalol (Injectable)", false, ["sotalol"]],
    ["Sotalol (Oral Liquid)", true, ["sotalol"]],
    ["Sotalol (Oral Pill)", true, ["sotalol"]],
    ["Sotatercept (Injectable)", false, ["sotatercept"]],
    ["Sotatercept (Pack)", false, ["sotatercept"]],
    ["Sotorasib (Oral Pill)", true, ["sotorasib"]],
    ["SOTRADECOL (Injectable)", false, ["sodium tetradecyl sulfate"]],
    ["SOTRET (Oral Pill)", true, ["isotretinoin"]],
    ["SOTYKTU (Oral Pill)", true, ["deucravacitinib"]],
    ["SOTYLIZE (Oral Liquid)", true, ["sotalol"]],
    ["SOVALDI (Oral Pellet)", true, ["sofosbuvir"]],
    ["SOVALDI (Oral Pill)", true, ["sofosbuvir"]],
    ["SOVUNA (Oral Pill)", true, ["hydroxychloroquine"]],
    ["Soy protein isolate (Oral Pill)", true, ["soy protein isolate"]],
    ["Soybean lecithin (Chewable)", true, ["soybean lecithin"]],
    ["Soybean lecithin (Oral Pill)", true, ["soybean lecithin"]],
    ["Soybean oil (Injectable)", false, ["soybean oil"]],
    ["Sparsentan (Oral Pill)", true, ["sparsentan"]],
    ["Spesolimab (Injectable)", false, ["spesolimab"]],
    ["SPEVIGO (Injectable)", false, ["spesolimab"]],
    ["SPHERUSOL (Injectable)", false, ["Coccidioides immitis spherule"]],
    ["SPIKEVAX 2025-2026 (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["SPIKEVAX 2026-2027 (Injectable)", false, ["SARS-CoV-2 (COVID-19) vaccine, mRNA spike protein"]],
    ["Spinosad (Shampoo)", false, ["spinosad"]],
    ["SPINRAZA (Injectable)", false, ["nusinersen"]],
    ["SPIRIVA (Inhalant)", false, ["tiotropium"]],
    ["Spironolactone (Oral Liquid)", true, ["spironolactone"]],
    ["Spironolactone (Oral Pill)", true, ["spironolactone"]],
    ["Spirulina (Oral Pill)", true, ["Spirulina"]],
    ["SPORANOX (Oral Liquid)", true, ["itraconazole"]],
    ["SPORANOX (Oral Pill)", true, ["itraconazole"]],
    ["SPORTSCREME (Topical)", false, ["trolamine salicylate"]],
    ["SPRAVATO (Nasal)", false, ["esketamine"]],
    ["SPRAVATO 56 MG DOSE KIT (Pack)", false, ["esketamine"]],
    ["SPRAVATO 84 MG DOSE KIT (Pack)", false, ["esketamine"]],
    ["SPRINTEC 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["SPRITAM (Oral Suspension Tablet)", true, ["levetiracetam"]],
    ["SPRIX (Nasal)", false, ["ketorolac"]],
    ["SPRYCEL (Oral Pill)", true, ["dasatinib"]],
    ["SPS (Oral Liquid)", true, ["sodium polystyrene sulfonate"]],
    ["SRONYX 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["SSD (Topical)", false, ["silver sulfadiazine"]],
    ["ST-37 (Topical)", false, ["hexylresorcinol"]],
    ["ST. IVES BLEMISH & BLACKHEAD CONTROL (Soap)", false, ["salicylic acid"]],
    ["STAHIST AD (Oral Pill)", true, ["chlorcyclizine", "pseudoephedrine"]],
    ["STALEVO (Oral Pill)", true, ["carbidopa", "entacapone", "levodopa"]],
    ["STAMARIL (Injectable)", false, ["yellow fever virus strain 17D-204 live antigen"]],
    ["STANBACK HEADACHE POWDER REFORMULATED JAN 2011 (Oral Powder)", true, ["aspirin", "caffeine"]],
    ["STANGARD (Mouthwash)", false, ["stannous fluoride"]],
    ["Stannous fluoride (Mouthwash)", false, ["stannous fluoride"]],
    ["Stannous fluoride (Oral Cream)", true, ["stannous fluoride"]],
    ["Stannous fluoride (Oral Gel)", true, ["stannous fluoride"]],
    ["Stannous fluoride (Paste)", false, ["stannous fluoride"]],
    ["Stannous fluoride (Toothpaste)", false, ["stannous fluoride"]],
    ["STAPHASEPTIC (Topical)", false, ["benzethonium", "lidocaine"]],
    ["Starch/Zinc oxide (Topical)", false, ["starch", "zinc oxide"]],
    ["STARJEMZA (Injectable)", false, ["ustekinumab"]],
    ["Stavudine (Oral Pill)", true, ["stavudine"]],
    ["STAXYN (Oral Disintegrating)", true, ["vardenafil"]],
    ["STEGLATRO (Oral Pill)", true, ["ertugliflozin"]],
    ["STEGLUJAN (Oral Pill)", true, ["ertugliflozin", "sitagliptin"]],
    ["STELARA (Injectable)", false, ["ustekinumab"]],
    ["STENDRA (Oral Pill)", true, ["avanafil"]],
    ["STEQEYMA (Injectable)", false, ["ustekinumab"]],
    ["STERITALC (Topical)", false, ["talc"]],
    ["STIMATE (Nasal)", false, ["desmopressin"]],
    ["STIMUFEND (Injectable)", false, ["pegfilgrastim"]],
    ["STING-KILL (Topical)", false, ["benzocaine", "menthol"]],
    ["STIOLTO (Inhalant)", false, ["olodaterol", "tiotropium"]],
    ["Stiripentol (Oral Pill)", true, ["stiripentol"]],
    ["Stiripentol (Oral Suspension Powder)", true, ["stiripentol"]],
    ["STIVARGA (Oral Pill)", true, ["regorafenib"]],
    ["STOBOCLO (Injectable)", false, ["denosumab"]],
    ["STOPAIN (Topical)", false, ["menthol"]],
    ["STRATAGRAFT (Topical)", false, ["allogeneic cultured keratinocytes and dermal fibroblasts in murine collagen"]],
    ["STRATTERA (Oral Pill)", true, ["atomoxetine"]],
    ["STRENSIQ (Injectable)", false, ["asfotase alfa"]],
    ["Streptomycin (Injectable)", false, ["streptomycin"]],
    ["Streptozocin (Injectable)", false, ["streptozocin"]],
    ["STRI-DEX (Soap)", false, ["salicylic acid"]],
    ["STRI-DEX (Topical)", false, ["salicylic acid"]],
    ["STRI-DEX CLEAR GEL (Topical)", false, ["salicylic acid"]],
    ["STRIBILD (Oral Pill)", true, ["cobicistat", "elvitegravir", "emtricitabine", "tenofovir disoproxil"]],
    ["STRIDEX (Soap)", false, ["salicylic acid"]],
    ["STRIDEX (Topical)", false, ["salicylic acid"]],
    ["STRIVERDI (Inhalant)", false, ["olodaterol"]],
    ["STROMECTOL (Oral Pill)", true, ["ivermectin"]],
    ["Strontium (Injectable)", false, ["strontium"]],
    ["Strontium (Oral Pill)", true, ["strontium"]],
    ["STYE (Ophthalmic)", false, ["mineral oil", "petrolatum"]],
    ["STYPTSTIX (Topical)", false, ["potassium nitrate", "silver nitrate"]],
    ["SUBLOCADE (Injectable)", false, ["buprenorphine"]],
    ["SUBOXONE (Sublingual)", false, ["buprenorphine", "naloxone"]],
    ["SUBVENITE (Oral Liquid)", true, ["lamotrigine"]],
    ["SUBVENITE (Oral Pill)", true, ["lamotrigine"]],
    ["SUBVENITE BLUE (FOR PATIENTS TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["SUBVENITE GREEN (FOR PATIENTS TAKING CARBAMAZEPINE, PHENYTOIN, PHENOBARBITAL, OR PRIMIDONE AND NOT TAKING VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["SUBVENITE ORANGE (FOR PATIENTS NOT TAKING CARBAMAZEPINE, PHENYTOIN, PHENOBARBITAL, PRIMIDONE, OR VALPROATE) (Pack)", true, ["lamotrigine"]],
    ["Succimer (Oral Pill)", true, ["succimer"]],
    ["Succinylcholine (Injectable)", false, ["succinylcholine"]],
    ["SUCRAID (Oral Liquid)", true, ["sacrosidase"]],
    ["Sucralfate (Oral Liquid)", true, ["sucralfate"]],
    ["Sucralfate (Oral Paste)", true, ["sucralfate"]],
    ["Sucralfate (Oral Pill)", true, ["sucralfate"]],
    ["SUCRETS (Oral Lozenge)", true, ["dyclonine"]],
    ["SUCRETS ORIGINAL (Oral Lozenge)", true, ["hexylresorcinol"]],
    ["SUCRETS SORE THROAT (Oral Lozenge)", true, ["dyclonine", "menthol"]],
    ["Sucroferric oxyhydroxide (Chewable)", true, ["sucroferric oxyhydroxide"]],
    ["SUDAFED (Oral Liquid)", true, ["pseudoephedrine"]],
    ["SUDAFED (Oral Pill)", true, ["pseudoephedrine"]],
    ["SUDAFED OM (Nasal)", false, ["oxymetazoline"]],
    ["SUDAFED PE (Oral Pill)", true, ["phenylephrine"]],
    ["SUDAFED XR (Oral Pill)", true, ["pseudoephedrine"]],
    ["SUDO-TAB (Oral Pill)", true, ["phenylephrine"]],
    ["SUDOGEST (Oral Pill)", true, ["pseudoephedrine"]],
    ["SUDOGEST XR (Oral Pill)", true, ["pseudoephedrine"]],
    ["SUFentanil (Injectable)", false, ["sufentanil"]],
    ["SUFentanil (Sublingual)", false, ["sufentanil"]],
    ["SUFLAVE (Pack)", false, ["magnesium sulfate", "polyethylene glycol 3350", "potassium chloride", "sodium chloride", "sodium sulfate"]],
    ["Sugammadex (Injectable)", false, ["sugammadex"]],
    ["SULAR XR (Oral Pill)", true, ["nisoldipine"]],
    ["Sulbutiamine (Oral Pill)", true, ["sulbutiamine"]],
    ["Sulconazole (Topical)", false, ["sulconazole"]],
    ["Sulfacetamide (Ophthalmic)", false, ["sulfacetamide"]],
    ["Sulfacetamide (Shampoo)", false, ["sulfacetamide"]],
    ["Sulfacetamide (Soap)", false, ["sulfacetamide"]],
    ["Sulfacetamide (Topical)", false, ["sulfacetamide"]],
    ["Sulfacetamide/Sulfur (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["Sulfacetamide/Sulfur (Topical)", false, ["sulfacetamide", "sulfur"]],
    ["sulfADIAZINE (Oral Pill)", true, ["sulfadiazine"]],
    ["Sulfamethoxazole/Trimethoprim (Injectable)", false, ["sulfamethoxazole", "trimethoprim"]],
    ["Sulfamethoxazole/Trimethoprim (Oral Liquid)", true, ["sulfamethoxazole", "trimethoprim"]],
    ["Sulfamethoxazole/Trimethoprim (Oral Pill)", true, ["sulfamethoxazole", "trimethoprim"]],
    ["SULFAMYLON (Topical)", false, ["mafenide"]],
    ["sulfaSALAzine (Oral Pill)", true, ["sulfasalazine"]],
    ["SULFATRIM (Oral Liquid)", true, ["sulfamethoxazole", "trimethoprim"]],
    ["SULFO-LO (Soap)", false, ["sulfur"]],
    ["SULFOAM (Shampoo)", false, ["sulfur"]],
    ["Sulfonated phenol/Sulfuric acid (Mucosal)", false, ["sulfonated phenol", "sulfuric acid"]],
    ["Sulfonated phenol/Sulfuric acid (Topical)", false, ["sulfonated phenol", "sulfuric acid"]],
    ["Sulfur (Shampoo)", false, ["sulfur"]],
    ["Sulfur (Soap)", false, ["sulfur"]],
    ["Sulfur (Topical)", false, ["sulfur"]],
    ["Sulindac (Oral Pill)", true, ["sulindac"]],
    ["SULPHO-LAC (Soap)", false, ["sulfur"]],
    ["SUMADAN WASH (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["SUMAtriptan (Injectable)", false, ["sumatriptan"]],
    ["SUMAtriptan (Nasal)", false, ["sumatriptan"]],
    ["SUMAtriptan (Oral Pill)", true, ["sumatriptan"]],
    ["SUMAXIN (Soap)", false, ["sulfacetamide", "sulfur"]],
    ["SUMAXIN (Topical)", false, ["sulfacetamide", "sulfur"]],
    ["SUMMER'S EVE MEDICATED (Vaginal)", false, ["povidone-iodine"]],
    ["SUMMERS EVE ANTI-ITCH (Topical)", false, ["pramoxine"]],
    ["SUNItinib (Oral Pill)", true, ["sunitinib"]],
    ["SUNLENCA (Injectable)", false, ["lenacapavir"]],
    ["SUNLENCA (Oral Pill)", true, ["lenacapavir"]],
    ["SUNLENCA 4-TABLET PACK (Pack)", true, ["lenacapavir"]],
    ["SUNLENCA 5-TABLET PACK (Pack)", true, ["lenacapavir"]],
    ["SUNLENCA 927 MG KIT (Pack)", false, ["lenacapavir"]],
    ["SUNOSI (Oral Pill)", true, ["solriamfetol"]],
    ["Sunvozertinib (Oral Pill)", true, ["sunvozertinib"]],
    ["SUPARTZ (Injectable)", false, ["hyaluronate"]],
    ["SUPPRELIN (Implant)", false, ["histrelin"]],
    ["SUPRANE (Inhalant)", false, ["desflurane"]],
    ["SUPRAX (Oral Liquid)", true, ["cefixime"]],
    ["SUPRAX (Oral Pill)", true, ["cefixime"]],
    ["SUPREP BOWEL PREP KIT (Pack)", false, ["magnesium sulfate", "potassium sulfate", "sodium sulfate"]],
    ["SUPREP PEDIATRIC BOWEL PREP KIT (Pack)", false, ["magnesium sulfate", "potassium sulfate", "sodium sulfate"]],
    ["SURFAK STOOL SOFTENER (Oral Pill)", true, ["docusate"]],
    ["SURVANTA (Intratracheal)", false, ["beractant"]],
    ["SUSTOL (Injectable)", false, ["granisetron"]],
    ["SUSVIMO (Injectable)", false, ["ranibizumab"]],
    ["SUTAB (Oral Pill)", true, ["magnesium sulfate", "potassium chloride", "sodium sulfate"]],
    ["SUTENT (Oral Pill)", true, ["sunitinib"]],
    ["Sutimlimab (Injectable)", false, ["sutimlimab"]],
    ["Suvorexant (Oral Pill)", true, ["suvorexant"]],
    ["Suzetrigine (Oral Pill)", true, ["suzetrigine"]],
    ["SYEDA 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["SYFOVRE (Injectable)", false, ["pegcetacoplan"]],
    ["SYLVANT (Injectable)", false, ["siltuximab"]],
    ["SYMAX (Oral Disintegrating)", true, ["hyoscyamine"]],
    ["SYMAX (Sublingual)", false, ["hyoscyamine"]],
    ["SYMAX XR (Oral Pill)", true, ["hyoscyamine"]],
    ["SYMBICORT (Inhalant)", false, ["budesonide", "formoterol"]],
    ["SYMBRAVO (Oral Pill)", true, ["meloxicam", "rizatriptan"]],
    ["SYMBYAX (Oral Pill)", true, ["fluoxetine", "olanzapine"]],
    ["SYMDEKO (100 MG / 150 MG; 150 MG) (Pack)", true, ["ivacaftor", "tezacaftor"]],
    ["SYMDEKO (50 MG / 75 MG; 75 MG) (Pack)", true, ["ivacaftor", "tezacaftor"]],
    ["SYMFI (Oral Pill)", true, ["efavirenz", "lamivudine", "tenofovir disoproxil"]],
    ["SYMJEPI (Injectable)", false, ["epinephrine"]],
    ["SYMLIN (Injectable)", false, ["pramlintide"]],
    ["SYMPAZAN (Oral Film)", true, ["clobazam"]],
    ["SYMPROIC (Oral Pill)", true, ["naldemedine"]],
    ["SYMTUZA (Oral Pill)", true, ["cobicistat", "darunavir", "emtricitabine", "tenofovir alafenamide"]],
    ["SYMVESS (Implant)", false, ["acellular tissue engineered vessel"]],
    ["SYNAGIS (Injectable)", false, ["palivizumab"]],
    ["SYNALAR (Topical)", false, ["fluocinolone"]],
    ["SYNAREL (Nasal)", false, ["nafarelin"]],
    ["SYNDROS (Oral Liquid)", true, ["dronabinol"]],
    ["SYNERA (Topical)", false, ["lidocaine", "tetracaine"]],
    ["SYNJARDY (Oral Pill)", true, ["empagliflozin", "metformin"]],
    ["SYNJARDY XR (Oral Pill)", true, ["empagliflozin", "metformin"]],
    ["SYNRIBO (Injectable)", false, ["omacetaxine mepesuccinate"]],
    ["SYNTHROID (Oral Pill)", true, ["levothyroxine"]],
    ["SYNVISC (Injectable)", false, ["hylan G-F 20"]],
    ["SYPRINE (Oral Pill)", true, ["trientine"]],
    ["TABLOID (Oral Pill)", true, ["thioguanine"]],
    ["TABRECTA (Oral Pill)", true, ["capmatinib"]],
    ["TACHOSIL (Topical)", false, ["fibrinogen", "thrombin"]],
    ["TACLONEX (Topical)", false, ["betamethasone", "calcipotriene"]],
    ["Tacrolimus (Injectable)", false, ["tacrolimus"]],
    ["Tacrolimus (Oral Pill)", true, ["tacrolimus"]],
    ["Tacrolimus (Oral Suspension Granules)", true, ["tacrolimus"]],
    ["Tacrolimus (Topical)", false, ["tacrolimus"]],
    ["Tacrolimus XR (Oral Pill)", true, ["tacrolimus"]],
    ["TACTINAL (Oral Pill)", true, ["acetaminophen"]],
    ["Tadalafil (Oral Liquid)", true, ["tadalafil"]],
    ["Tadalafil (Oral Pill)", true, ["tadalafil"]],
    ["TADLIQ (Oral Liquid)", true, ["tadalafil"]],
    ["Tafamidis (Oral Pill)", true, ["tafamidis"]],
    ["Tafasitamab (Injectable)", false, ["tafasitamab"]],
    ["Tafenoquine (Oral Pill)", true, ["tafenoquine"]],
    ["TAFINLAR (Oral Pill)", true, ["dabrafenib"]],
    ["TAFINLAR (Oral Suspension Tablet)", true, ["dabrafenib"]],
    ["Tafluprost (Ophthalmic)", false, ["tafluprost"]],
    ["TAGAMET (Oral Pill)", true, ["cimetidine"]],
    ["Tagraxofusp (Injectable)", false, ["tagraxofusp"]],
    ["TAGRISSO (Oral Pill)", true, ["osimertinib"]],
    ["TAKE ACTION (Oral Pill)", true, ["levonorgestrel"]],
    ["TAKHZYRO (Injectable)", false, ["lanadelumab"]],
    ["Talazoparib (Oral Pill)", true, ["talazoparib"]],
    ["Talc (Topical)", false, ["talc"]],
    ["Taletrectinib (Oral Pill)", true, ["taletrectinib"]],
    ["TALICIA (Oral Pill)", true, ["amoxicillin", "omeprazole", "rifabutin"]],
    ["Taliglucerase alfa (Injectable)", false, ["taliglucerase alfa"]],
    ["Talquetamab (Injectable)", false, ["talquetamab"]],
    ["TALTZ (Injectable)", false, ["ixekizumab"]],
    ["TALVEY (Injectable)", false, ["talquetamab"]],
    ["TALZENNA (Oral Pill)", true, ["talazoparib"]],
    ["TAMIFLU (Oral Liquid)", true, ["oseltamivir"]],
    ["TAMIFLU (Oral Pill)", true, ["oseltamivir"]],
    ["Tamoxifen (Oral Liquid)", true, ["tamoxifen"]],
    ["Tamoxifen (Oral Pill)", true, ["tamoxifen"]],
    ["Tamsulosin (Oral Pill)", true, ["tamsulosin"]],
    ["TANAC LIQUID (Mucosal)", false, ["benzocaine"]],
    ["TANDEM (Oral Pill)", true, ["ferrous fumarate", "polysaccharide iron complex"]],
    ["TANDEM PLUS (Oral Pill)", true, ["copper sulfate", "ferrous fumarate", "folic acid", "manganese sulfate", "niacinamide", "pantothenate", "polysaccharide iron complex", "pyridoxine", "riboflavin", "sodium ascorbate", "thiamine", "vitamin B12", "zinc sulfate"]],
    ["TANLOR (Oral Pill)", true, ["methocarbamol"]],
    ["Tapentadol (Oral Liquid)", true, ["tapentadol"]],
    ["Tapentadol (Oral Pill)", true, ["tapentadol"]],
    ["Tapentadol XR (Oral Pill)", true, ["tapentadol"]],
    ["TAPERDEX 12 DAY TAPER (Pack)", true, ["dexamethasone"]],
    ["TAPERDEX 6 DAY TAPER (Pack)", true, ["dexamethasone"]],
    ["TAPERDEX 7-DAY TAPER (Pack)", true, ["dexamethasone"]],
    ["Tapinarof (Topical)", false, ["tapinarof"]],
    ["TARCEVA (Oral Pill)", true, ["erlotinib"]],
    ["TARGADOX (Oral Pill)", true, ["doxycycline"]],
    ["TARGRETIN (Oral Pill)", true, ["bexarotene"]],
    ["TARGRETIN (Topical)", false, ["bexarotene"]],
    ["TARINA 24 FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["TARINA FE 1/20 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Tarlatamab (Injectable)", false, ["tarlatamab"]],
    ["TARPEYO (Oral Pill)", true, ["budesonide"]],
    ["TARSUM REFORMULATED (Shampoo)", false, ["coal tar"]],
    ["TASCENSO (Oral Disintegrating)", true, ["fingolimod"]],
    ["TASIGNA (Oral Pill)", true, ["nilotinib"]],
    ["Tasimelteon (Oral Liquid)", true, ["tasimelteon"]],
    ["Tasimelteon (Oral Pill)", true, ["tasimelteon"]],
    ["TASMAR (Oral Pill)", true, ["tolcapone"]],
    ["Taurine (Oral Pill)", true, ["taurine"]],
    ["Tavaborole (Topical)", false, ["tavaborole"]],
    ["TAVALISSE (Oral Pill)", true, ["fostamatinib"]],
    ["Tavapadon (Oral Pill)", true, ["tavapadon"]],
    ["Tavapadon (Pack)", true, ["tavapadon"]],
    ["TAVIST (Oral Pill)", true, ["clemastine"]],
    ["TAVIST NON-SEDATING (Oral Pill)", true, ["loratadine"]],
    ["TAVNEOS (Oral Pill)", true, ["avacopan"]],
    ["TAYSOFY 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["TAYTULLA 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Tazarotene (Topical)", false, ["tazarotene"]],
    ["Tazemetostat (Oral Pill)", true, ["tazemetostat"]],
    ["TAZICEF (Injectable)", false, ["ceftazidime"]],
    ["TAZORAC (Topical)", false, ["tazarotene"]],
    ["TAZTIA XR (Oral Pill)", true, ["diltiazem"]],
    ["TAZVERIK (Oral Pill)", true, ["tazemetostat"]],
    ["TDVAX (Injectable)", false, ["diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["Tea tree oil (Topical)", false, ["tea tree oil"]],
    ["TEARS NATURALE FORTE (Ophthalmic)", false, ["dextran 70", "glycerin", "hypromellose"]],
    ["TEARS NATURALE PM (Ophthalmic)", false, ["mineral oil", "petrolatum"]],
    ["Tebentafusp (Injectable)", false, ["tebentafusp"]],
    ["Tebipenem pivoxil (Oral Pill)", true, ["tebipenem pivoxil"]],
    ["TECARTUS (Injectable)", false, ["brexucabtagene autoleucel"]],
    ["TECELRA (Injectable)", false, ["afamitresgene autoleucel"]],
    ["TECENTRIQ (Injectable)", false, ["atezolizumab"]],
    ["TECENTRIQ HYBREZA (Injectable)", false, ["atezolizumab", "hyaluronidase"]],
    ["TECFIDERA (Oral Pill)", true, ["dimethyl fumarate"]],
    ["TECFIDERA 30-DAY STARTER PACK (Pack)", true, ["dimethyl fumarate"]],
    ["Teclistamab (Injectable)", false, ["teclistamab"]],
    ["Tecovirimat (Injectable)", false, ["tecovirimat"]],
    ["Tecovirimat (Oral Pill)", true, ["tecovirimat"]],
    ["TECVAYLI (Injectable)", false, ["teclistamab"]],
    ["Tedizolid (Injectable)", false, ["tedizolid"]],
    ["Tedizolid (Oral Pill)", true, ["tedizolid"]],
    ["Teduglutide (Injectable)", false, ["teduglutide"]],
    ["TEFLARO (Injectable)", false, ["ceftaroline fosamil"]],
    ["Tegaserod (Oral Pill)", true, ["tegaserod"]],
    ["TEGLUTIK (Oral Liquid)", true, ["riluzole"]],
    ["TEGRETOL (Oral Liquid)", true, ["carbamazepine"]],
    ["TEGRETOL (Oral Pill)", true, ["carbamazepine"]],
    ["TEGRETOL XR (Oral Pill)", true, ["carbamazepine"]],
    ["TEGRIN-LT SHAMPOO (Shampoo)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["TEGSEDI (Injectable)", false, ["inotersen"]],
    ["TEKTURNA (Oral Pill)", true, ["aliskiren"]],
    ["TEKTURNA HCT (Oral Pill)", true, ["aliskiren", "hydrochlorothiazide"]],
    ["Telavancin (Injectable)", false, ["telavancin"]],
    ["Telisotuzumab (Injectable)", false, ["telisotuzumab"]],
    ["Telmisartan (Oral Pill)", true, ["telmisartan"]],
    ["Telotristat ethyl (Oral Pill)", true, ["telotristat ethyl"]],
    ["Temazepam (Oral Pill)", true, ["temazepam"]],
    ["TEMBEXA (Oral Liquid)", true, ["brincidofovir"]],
    ["TEMBEXA (Oral Pill)", true, ["brincidofovir"]],
    ["TEMBEXA 4 TABLET PACK (Pack)", true, ["brincidofovir"]],
    ["TEMIXYS (Oral Pill)", true, ["lamivudine", "tenofovir disoproxil"]],
    ["TEMODAR (Injectable)", false, ["temozolomide"]],
    ["TEMODAR (Oral Pill)", true, ["temozolomide"]],
    ["TEMOVATE (Topical)", false, ["clobetasol"]],
    ["Temozolomide (Injectable)", false, ["temozolomide"]],
    ["Temozolomide (Oral Pill)", true, ["temozolomide"]],
    ["TEMPRA QUICKLETS (Chewable)", true, ["acetaminophen"]],
    ["Temsirolimus (Injectable)", false, ["temsirolimus"]],
    ["Tenapanor (Oral Pill)", true, ["tenapanor"]],
    ["TENCON (Oral Pill)", true, ["acetaminophen", "butalbital"]],
    ["Tenecteplase (Injectable)", false, ["tenecteplase"]],
    ["TENIVAC (Injectable)", false, ["diphtheria toxoid vaccine, inactivated", "tetanus toxoid vaccine, inactivated"]],
    ["Tenofovir alafenamide (Oral Pill)", true, ["tenofovir alafenamide"]],
    ["Tenofovir disoproxil (Oral Pill)", true, ["tenofovir disoproxil"]],
    ["Tenofovir disoproxil (Oral Powder)", true, ["tenofovir disoproxil"]],
    ["TENORETIC (Oral Pill)", true, ["atenolol", "chlorthalidone"]],
    ["TENORMIN (Oral Pill)", true, ["atenolol"]],
    ["TENUATE (Oral Pill)", true, ["diethylpropion"]],
    ["TENUATE XR (Oral Pill)", true, ["diethylpropion"]],
    ["TEPADINA (Injectable)", false, ["thiotepa"]],
    ["TEPEZZA (Injectable)", false, ["teprotumumab"]],
    ["Teplizumab (Injectable)", false, ["teplizumab"]],
    ["TEPMETKO (Oral Pill)", true, ["tepotinib"]],
    ["Tepotinib (Oral Pill)", true, ["tepotinib"]],
    ["Teprotumumab (Injectable)", false, ["teprotumumab"]],
    ["TEPYLUTE (Injectable)", false, ["thiotepa"]],
    ["Terazosin (Oral Liquid)", true, ["terazosin"]],
    ["Terazosin (Oral Pill)", true, ["terazosin"]],
    ["Terbinafine (Oral Pill)", true, ["terbinafine"]],
    ["Terbinafine (Topical)", false, ["terbinafine"]],
    ["Terbutaline (Injectable)", false, ["terbutaline"]],
    ["Terbutaline (Oral Pill)", true, ["terbutaline"]],
    ["Terconazole (Vaginal)", false, ["terconazole"]],
    ["Teriflunomide (Oral Pill)", true, ["teriflunomide"]],
    ["Teriparatide (Injectable)", false, ["teriparatide"]],
    ["Terlipressin (Injectable)", false, ["terlipressin"]],
    ["TERLIVAZ (Injectable)", false, ["terlipressin"]],
    ["TERRELL (Inhalant)", false, ["isoflurane"]],
    ["Tesamorelin (Injectable)", false, ["tesamorelin"]],
    ["TESSALON PERLES (Oral Pill)", true, ["benzonatate"]],
    ["TESTIM (Topical)", false, ["testosterone"]],
    ["TESTOPEL (Implant)", false, ["testosterone"]],
    ["Testosterone (Implant)", false, ["testosterone"]],
    ["Testosterone (Injectable)", false, ["testosterone"]],
    ["Testosterone (Nasal)", false, ["testosterone"]],
    ["Testosterone (Oral Pill)", true, ["testosterone"]],
    ["Testosterone (Topical)", false, ["testosterone"]],
    ["Tetanus immune globulin (Injectable)", false, ["tetanus immune globulin"]],
    ["TETCAINE (Ophthalmic)", false, ["tetracaine"]],
    ["Tetrabenazine (Oral Pill)", true, ["tetrabenazine"]],
    ["Tetracaine (Injectable)", false, ["tetracaine"]],
    ["Tetracaine (Ophthalmic)", false, ["tetracaine"]],
    ["Tetracaine (Topical)", false, ["tetracaine"]],
    ["Tetracycline (Oral Pill)", true, ["tetracycline"]],
    ["Tetracycline (Topical)", false, ["tetracycline"]],
    ["Tetrahydrozoline (Nasal)", false, ["tetrahydrozoline"]],
    ["Tetrahydrozoline (Ophthalmic)", false, ["tetrahydrozoline"]],
    ["Tetrahydrozoline/Zinc sulfate (Ophthalmic)", false, ["tetrahydrozoline", "zinc sulfate"]],
    ["TETTERINE (Topical)", false, ["miconazole"]],
    ["TEVIMBRA (Injectable)", false, ["tislelizumab"]],
    ["TEXACORT (Topical)", false, ["hydrocortisone"]],
    ["Tezepelumab (Injectable)", false, ["tezepelumab"]],
    ["TEZRULY (Oral Liquid)", true, ["terazosin"]],
    ["TEZSPIRE (Injectable)", false, ["tezepelumab"]],
    ["Thalidomide (Oral Pill)", true, ["thalidomide"]],
    ["THALITONE (Oral Pill)", true, ["chlorthalidone"]],
    ["THALOMID (Oral Pill)", true, ["thalidomide"]],
    ["THE ITCH ERASER (Topical)", false, ["diphenhydramine"]],
    ["THE MAGIC BULLET (Rectal)", false, ["bisacodyl"]],
    ["THEO-24 XR (Oral Pill)", true, ["theophylline"]],
    ["Theophylline (Injectable)", false, ["theophylline"]],
    ["Theophylline (Oral Liquid)", true, ["theophylline"]],
    ["Theophylline (Oral Pill)", true, ["theophylline"]],
    ["Theophylline XR (Oral Pill)", true, ["theophylline"]],
    ["THERA-D (Oral Pill)", true, ["cholecalciferol"]],
    ["THERA-GESIC (Topical)", false, ["menthol", "methyl salicylate"]],
    ["THERA-GESIC PLUS (Topical)", false, ["menthol", "methyl salicylate"]],
    ["THERAMYCIN (Topical)", false, ["erythromycin"]],
    ["THERAPLEX Z (Shampoo)", false, ["zinc pyrithione"]],
    ["THERASEAL HAND PROTECTION (Topical)", false, ["dimethicone"]],
    ["THERASTAT (Oral Lozenge)", true, ["menthol"]],
    ["THERATEARS (Ophthalmic)", false, ["carboxymethylcellulose"]],
    ["THERMAZENE (Topical)", false, ["silver sulfadiazine"]],
    ["Thiamine (Injectable)", false, ["thiamine"]],
    ["Thiamine (Oral Pill)", true, ["thiamine"]],
    ["Thioctate (Oral Pill)", true, ["thioctate"]],
    ["Thioctate/Ubidecarenone/Vitamin E (Oral Pill)", true, ["thioctate", "ubidecarenone", "vitamin E"]],
    ["Thioguanine (Oral Pill)", true, ["thioguanine"]],
    ["THIOLA (Oral Pill)", true, ["tiopronin"]],
    ["Thioridazine (Oral Pill)", true, ["thioridazine"]],
    ["Thiosulfate (Injectable)", false, ["thiosulfate"]],
    ["Thiotepa (Injectable)", false, ["thiotepa"]],
    ["Thiothixene (Oral Pill)", true, ["thiothixene"]],
    ["THORACOL (Oral Lozenge)", true, ["menthol"]],
    ["THRIVE (Chewable)", true, ["nicotine"]],
    ["THROMBATE III (Injectable)", false, ["antithrombin III"]],
    ["Thrombin (Nasal)", false, ["thrombin"]],
    ["Thrombin (Topical)", false, ["thrombin"]],
    ["THROMBIN-JMI (Nasal)", false, ["thrombin"]],
    ["THROMBIN-JMI (Topical)", false, ["thrombin"]],
    ["THYMOGLOBULIN (Injectable)", false, ["lymphocyte immune globulin, anti-thymocyte globulin"]],
    ["THYQUIDITY (Oral Liquid)", true, ["levothyroxine"]],
    ["THYROGEN (Injectable)", false, ["thyrotropin alfa"]],
    ["THYROGEN KIT (0.9 MG VIAL) (Pack)", false, ["thyrotropin alfa"]],
    ["Thyroid (USP) (Oral Pill)", true, ["thyroid (USP)"]],
    ["THYROLAR (Oral Pill)", true, ["levothyroxine", "liothyronine"]],
    ["THYROSAFE (Oral Pill)", true, ["potassium iodide"]],
    ["Thyrotropin alfa (Injectable)", false, ["thyrotropin alfa"]],
    ["Thyrotropin alfa (Pack)", false, ["thyrotropin alfa"]],
    ["TIADYLT XR (Oral Pill)", true, ["diltiazem"]],
    ["tiaGABine (Oral Pill)", true, ["tiagabine"]],
    ["TIAZAC XR (Oral Pill)", true, ["diltiazem"]],
    ["TIBSOVO (Oral Pill)", true, ["ivosidenib"]],
    ["Ticagrelor (Oral Pill)", true, ["ticagrelor"]],
    ["TICE BCG (Intravesical)", false, ["BCG, live, Tice strain"]],
    ["Tick-borne encephalitis purified antigen (Injectable)", false, ["tick-borne encephalitis purified antigen"]],
    ["TICOVAC (Injectable)", false, ["tick-borne encephalitis purified antigen"]],
    ["TIGAN (Injectable)", false, ["trimethobenzamide"]],
    ["Tigecycline (Injectable)", false, ["tigecycline"]],
    ["TIGLUTIK (Oral Liquid)", true, ["riluzole"]],
    ["TIKOSYN (Oral Pill)", true, ["dofetilide"]],
    ["Tildrakizumab (Injectable)", false, ["tildrakizumab"]],
    ["TILIA FE (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Timolol (Ophthalmic)", false, ["timolol"]],
    ["Timolol (Oral Pill)", true, ["timolol"]],
    ["TIMOPTIC (Ophthalmic)", false, ["timolol"]],
    ["Timothy grass pollen extract (Sublingual)", false, ["Timothy grass pollen extract"]],
    ["TINACTIN (Topical)", false, ["tolnaftate"]],
    ["TINADERM (Topical)", false, ["tolnaftate"]],
    ["TINDAMAX (Oral Pill)", true, ["tinidazole"]],
    ["TINEACIDE ANTIFUNGAL (Topical)", false, ["undecylenate"]],
    ["Tinidazole (Oral Pill)", true, ["tinidazole"]],
    ["Tioconazole (Vaginal)", false, ["tioconazole"]],
    ["TIOCYSTIN (Oral Pill)", true, ["tiopronin"]],
    ["Tiopronin (Oral Pill)", true, ["tiopronin"]],
    ["Tiotropium (Inhalant)", false, ["tiotropium"]],
    ["Tipiracil/Trifluridine (Oral Pill)", true, ["tipiracil", "trifluridine"]],
    ["Tipranavir (Oral Pill)", true, ["tipranavir"]],
    ["Tirbanibulin (Topical)", false, ["tirbanibulin"]],
    ["Tirofiban (Injectable)", false, ["tirofiban"]],
    ["TIROSINT (Oral Liquid)", true, ["levothyroxine"]],
    ["TIROSINT (Oral Pill)", true, ["levothyroxine"]],
    ["Tirzepatide (Injectable)", false, ["tirzepatide"]],
    ["TIS-U-SOL (Irrigation)", false, ["magnesium sulfate", "potassium chloride", "potassium phosphate", "sodium chloride", "sodium phosphate"]],
    ["Tisagenlecleucel (Injectable)", false, ["tisagenlecleucel"]],
    ["Tislelizumab (Injectable)", false, ["tislelizumab"]],
    ["Tisotumab (Injectable)", false, ["tisotumab"]],
    ["TISSEEL (Injectable)", false, ["fibrinogen", "thrombin"]],
    ["TISSEEL (Topical)", false, ["fibrinogen", "thrombin"]],
    ["TITRALAC (Chewable)", true, ["calcium carbonate"]],
    ["TIVDAK (Injectable)", false, ["tisotumab"]],
    ["TIVICAY (Oral Pill)", true, ["dolutegravir"]],
    ["TIVICAY (Oral Suspension Tablet)", true, ["dolutegravir"]],
    ["Tividenofusp alfa (Injectable)", false, ["tividenofusp alfa"]],
    ["TIVORBEX (Oral Pill)", true, ["indomethacin"]],
    ["Tivozanib (Oral Pill)", true, ["tivozanib"]],
    ["tiZANidine (Oral Liquid)", true, ["tizanidine"]],
    ["tiZANidine (Oral Pill)", true, ["tizanidine"]],
    ["TLANDO (Oral Pill)", true, ["testosterone"]],
    ["TNKASE (Injectable)", false, ["tenecteplase"]],
    ["TOBI (Inhalant)", false, ["tobramycin"]],
    ["TOBI PODHALER DAILY KIT (Pack)", false, ["tobramycin"]],
    ["TOBI PODHALER KIT (Pack)", false, ["tobramycin"]],
    ["TOBI PODHALER WEEKLY KIT (Pack)", false, ["tobramycin"]],
    ["TOBRADEX (Ophthalmic)", false, ["dexamethasone", "tobramycin"]],
    ["Tobramycin (Inhalant)", false, ["tobramycin"]],
    ["Tobramycin (Injectable)", false, ["tobramycin"]],
    ["Tobramycin (Ophthalmic)", false, ["tobramycin"]],
    ["Tobramycin (Pack)", false, ["tobramycin"]],
    ["TOBREX (Ophthalmic)", false, ["tobramycin"]],
    ["Tocilizumab (Injectable)", false, ["tocilizumab"]],
    ["Tocophersolan (Oral Liquid)", true, ["tocophersolan"]],
    ["Tofacitinib (Oral Liquid)", true, ["tofacitinib"]],
    ["Tofacitinib (Oral Pill)", true, ["tofacitinib"]],
    ["Tofacitinib XR (Oral Pill)", true, ["tofacitinib"]],
    ["Tofersen (Injectable)", false, ["tofersen"]],
    ["TOFIDENCE (Injectable)", false, ["tocilizumab"]],
    ["TOLAK (Topical)", false, ["fluorouracil"]],
    ["Tolcapone (Oral Pill)", true, ["tolcapone"]],
    ["TOLCYLEN (Topical)", false, ["tolnaftate"]],
    ["TOLECTIN 600 (Oral Pill)", true, ["tolmetin"]],
    ["TOLECTIN DS (Oral Pill)", true, ["tolmetin"]],
    ["Tolmetin (Oral Pill)", true, ["tolmetin"]],
    ["Tolnaftate (Topical)", false, ["tolnaftate"]],
    ["TOLSURA (Oral Pill)", true, ["itraconazole"]],
    ["Tolterodine (Oral Pill)", true, ["tolterodine"]],
    ["Tolterodine XR (Oral Pill)", true, ["tolterodine"]],
    ["Tolvaptan (Oral Pill)", true, ["tolvaptan"]],
    ["Tolvaptan (Pack)", true, ["tolvaptan"]],
    ["TONMYA (Sublingual)", false, ["cyclobenzaprine"]],
    ["TOPAMAX (Oral Pill)", true, ["topiramate"]],
    ["TOPICAINE (Rectal)", false, ["lidocaine"]],
    ["TOPICAINE (Topical)", false, ["lidocaine"]],
    ["TOPICAINE ULTRA (Topical)", false, ["lidocaine"]],
    ["TOPICALE (Mucosal)", false, ["benzocaine"]],
    ["TOPICALE (Oral Gel)", true, ["benzocaine"]],
    ["TOPICALE (Oral Ointment)", true, ["benzocaine"]],
    ["TOPICORT (Topical)", false, ["desoximetasone"]],
    ["Topiramate (Oral Liquid)", true, ["topiramate"]],
    ["Topiramate (Oral Pill)", true, ["topiramate"]],
    ["Topiramate XR (Oral Pill)", true, ["topiramate"]],
    ["TOPOSAR (Injectable)", false, ["etoposide"]],
    ["Topotecan (Injectable)", false, ["topotecan"]],
    ["Topotecan (Oral Pill)", true, ["topotecan"]],
    ["TOPROL XR (Oral Pill)", true, ["metoprolol"]],
    ["Toremifene (Oral Pill)", true, ["toremifene"]],
    ["Toripalimab (Injectable)", false, ["toripalimab"]],
    ["TORISEL (Injectable)", false, ["temsirolimus"]],
    ["TORPENZ (Oral Pill)", true, ["everolimus"]],
    ["Torsemide (Oral Pill)", true, ["torsemide"]],
    ["TOSYMRA (Nasal)", false, ["sumatriptan"]],
    ["TOTECT (Injectable)", false, ["dexrazoxane"]],
    ["TOUJEO (Injectable)", false, ["insulin glargine"]],
    ["TOVET (Topical)", false, ["clobetasol"]],
    ["TOVIAZ XR (Oral Pill)", true, ["fesoterodine"]],
    ["Tovorafenib (Oral Pill)", true, ["tovorafenib"]],
    ["Tovorafenib (Oral Suspension Powder)", true, ["tovorafenib"]],
    ["Tovorafenib (Pack)", true, ["tovorafenib"]],
    ["TPOXX (Injectable)", false, ["tecovirimat"]],
    ["TPOXX (Oral Pill)", true, ["tecovirimat"]],
    ["Trabectedin (Injectable)", false, ["trabectedin"]],
    ["TRACLEER (Oral Pill)", true, ["bosentan"]],
    ["TRACLEER (Oral Suspension Tablet)", true, ["bosentan"]],
    ["Tradipitant (Oral Pill)", true, ["tradipitant"]],
    ["TRADJENTA (Oral Pill)", true, ["linagliptin"]],
    ["TRALEMENT (Injectable)", false, ["copper sulfate", "manganese sulfate", "selenious acid", "zinc sulfate"]],
    ["Tralokinumab (Injectable)", false, ["tralokinumab"]],
    ["traMADol (Oral Liquid)", true, ["tramadol"]],
    ["traMADol (Oral Pill)", true, ["tramadol"]],
    ["traMADol XR (Oral Pill)", true, ["tramadol"]],
    ["Trametinib (Oral Liquid)", true, ["trametinib"]],
    ["Trametinib (Oral Pill)", true, ["trametinib"]],
    ["TRANDATE (Oral Pill)", true, ["labetalol"]],
    ["Trandolapril (Oral Pill)", true, ["trandolapril"]],
    ["Trandolapril/Verapamil XR (Oral Pill)", true, ["trandolapril", "verapamil"]],
    ["Tranexamic acid (Injectable)", false, ["tranexamic acid"]],
    ["Tranexamic acid (Oral Pill)", true, ["tranexamic acid"]],
    ["TRANSDERM SCOP (Transdermal)", false, ["scopolamine"]],
    ["TRANXENE (Oral Pill)", true, ["clorazepate"]],
    ["Tranylcypromine (Oral Pill)", true, ["tranylcypromine"]],
    ["TRANZAREL (Topical)", false, ["lidocaine"]],
    ["Trastuzumab (Injectable)", false, ["trastuzumab"]],
    ["TRAVASOL 10 (Injectable)", false, ["alanine", "arginine", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["TRAVATAN (Ophthalmic)", false, ["travoprost"]],
    ["Travoprost (Implant)", false, ["travoprost"]],
    ["Travoprost (Ophthalmic)", false, ["travoprost"]],
    ["TRAZIMERA (Injectable)", false, ["trastuzumab"]],
    ["traZODone (Oral Liquid)", true, ["trazodone"]],
    ["traZODone (Oral Pill)", true, ["trazodone"]],
    ["TREANDA (Injectable)", false, ["bendamustine"]],
    ["TRECATOR (Oral Pill)", true, ["ethionamide"]],
    ["TREGZI (Injectable)", false, ["allogeneic regulatory T cell immunotherapy with HSPC and T cells"]],
    ["TRELEGY (Inhalant)", false, ["fluticasone", "umeclidinium", "vilanterol"]],
    ["TRELSTAR (Injectable)", false, ["triptorelin"]],
    ["Tremelimumab (Injectable)", false, ["tremelimumab"]],
    ["TREMFYA (Injectable)", false, ["guselkumab"]],
    ["TREMFYA INDUCTION PACK FOR CROHN'S DISEASE (Pack)", false, ["guselkumab"]],
    ["TRENTAL XR (Oral Pill)", true, ["pentoxifylline"]],
    ["Treosulfan (Injectable)", false, ["treosulfan"]],
    ["Treprostinil (Inhalant)", false, ["treprostinil"]],
    ["Treprostinil (Injectable)", false, ["treprostinil"]],
    ["Treprostinil (Pack)", false, ["treprostinil"]],
    ["Treprostinil XR (Oral Pill)", true, ["treprostinil"]],
    ["TRESIBA (Injectable)", false, ["insulin degludec"]],
    ["TRETIN X (Topical)", false, ["tretinoin"]],
    ["Tretinoin (Oral Pill)", true, ["tretinoin"]],
    ["Tretinoin (Topical)", false, ["tretinoin"]],
    ["TRETTEN (Injectable)", false, ["factor XIII"]],
    ["TREXALL (Oral Pill)", true, ["methotrexate"]],
    ["TREXIMET (Oral Pill)", true, ["naproxen", "sumatriptan"]],
    ["TREZIX (Oral Pill)", true, ["acetaminophen", "caffeine", "dihydrocodeine"]],
    ["TRI BIOZENE (Topical)", false, ["bacitracin", "neomycin", "polymyxin B", "pramoxine"]],
    ["TRI FEMYNOR 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-CHLOR (Topical)", false, ["trichloroacetate"]],
    ["TRI-ESTARYLLA 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-LEGEST 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["TRI-LINYAH (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-LO- ESTARYLLA 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-LO-MARZIA 28-DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-LO-MILI (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-LO-SPRINTEC 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-LUMA (Topical)", false, ["fluocinolone", "hydroquinone", "tretinoin"]],
    ["TRI-MILI 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-NYMYO 28 DAY PACK (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-PAK (Pack)", true, ["azithromycin"]],
    ["TRI-SPRINTEC 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-VI-SOL (Oral Liquid)", true, ["ascorbic acid", "cholecalciferol", "vitamin A"]],
    ["TRI-VYLIBRA 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRI-VYLIBRA LO 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["Triacetin (Topical)", false, ["triacetin"]],
    ["Triamcinolone (Injectable)", false, ["triamcinolone"]],
    ["Triamcinolone (Nasal)", false, ["triamcinolone"]],
    ["Triamcinolone (Oral Paste)", true, ["triamcinolone"]],
    ["Triamcinolone (Topical)", false, ["triamcinolone"]],
    ["Triamterene (Oral Pill)", true, ["triamterene"]],
    ["TRIANEX (Topical)", false, ["triamcinolone"]],
    ["Triazolam (Oral Pill)", true, ["triazolam"]],
    ["TRIBENZOR (Oral Pill)", true, ["amlodipine", "hydrochlorothiazide", "olmesartan"]],
    ["Tricalcium phosphate (Oral Pill)", true, ["tricalcium phosphate"]],
    ["TRICHLOR FRESH PAK (Topical)", false, ["trichloroacetate"]],
    ["Trichloroacetate (Topical)", false, ["trichloroacetate"]],
    ["Trichophyton antigen (Injectable)", false, ["Trichophyton antigen"]],
    ["Triclabendazole (Oral Pill)", true, ["triclabendazole"]],
    ["Triclosan (Topical)", false, ["triclosan"]],
    ["TRICOR (Oral Pill)", true, ["fenofibrate"]],
    ["TRICYLATE (Topical)", false, ["menthol", "methyl salicylate"]],
    ["TRIDACAINE (Topical)", false, ["lidocaine"]],
    ["TRIDERGEL (Topical)", false, ["benzalkonium"]],
    ["TRIDERM (Topical)", false, ["triamcinolone"]],
    ["TRIDESILON (Topical)", false, ["desonide"]],
    ["Trientine (Oral Pill)", true, ["trientine"]],
    ["TRIESENCE (Injectable)", false, ["triamcinolone"]],
    ["Trifarotene (Topical)", false, ["trifarotene"]],
    ["TRIFENA (Topical)", false, ["diclofenac", "lidocaine", "menthol"]],
    ["TRIFERIC (Injectable)", false, ["ferric pyrophosphate"]],
    ["Trifluoperazine (Oral Pill)", true, ["trifluoperazine"]],
    ["Trifluridine (Ophthalmic)", false, ["trifluridine"]],
    ["Triheptanoin (Oral Liquid)", true, ["triheptanoin"]],
    ["Trihexyphenidyl (Oral Liquid)", true, ["trihexyphenidyl"]],
    ["Trihexyphenidyl (Oral Pill)", true, ["trihexyphenidyl"]],
    ["TRIJARDY XR (Oral Pill)", true, ["empagliflozin", "linagliptin", "metformin"]],
    ["TRIKAFTA (100 MG / 50 MG / 75 MG; 150 MG) (Pack)", true, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["TRIKAFTA (100 MG / 50 MG / 75 MG; 75 MG) GRANULES (Pack)", false, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["TRIKAFTA (50 MG / 37.5 MG / 25 MG; 75 MG) (Pack)", true, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["TRIKAFTA (80 MG / 40 MG / 60 MG; 59.5 MG) GRANULES (Pack)", false, ["elexacaftor", "ivacaftor", "tezacaftor"]],
    ["Trilaciclib (Injectable)", false, ["trilaciclib"]],
    ["TRILEPTAL (Oral Liquid)", true, ["oxcarbazepine"]],
    ["TRILEPTAL (Oral Pill)", true, ["oxcarbazepine"]],
    ["TRILIPIX (Oral Pill)", true, ["fenofibrate"]],
    ["TRILITAS (Topical)", false, ["tazarotene"]],
    ["Trilostane (Oral Pill)", true, ["trilostane"]],
    ["TRILURON (Injectable)", false, ["hyaluronate"]],
    ["TRILYTE (Oral Solution Powder)", true, ["polyethylene glycol 3350", "potassium chloride", "sodium bicarbonate", "sodium chloride"]],
    ["TRIMAZOLE (Topical)", false, ["clotrimazole"]],
    ["TRIMBOW (Inhalant)", false, ["beclomethasone", "formoterol", "glycopyrronium"]],
    ["Trimethobenzamide (Injectable)", false, ["trimethobenzamide"]],
    ["Trimethobenzamide (Oral Pill)", true, ["trimethobenzamide"]],
    ["Trimethoprim (Oral Liquid)", true, ["trimethoprim"]],
    ["Trimethoprim (Oral Pill)", true, ["trimethoprim"]],
    ["Trimipramine (Oral Pill)", true, ["trimipramine"]],
    ["TRIMO SAN (Vaginal)", false, ["dodecyl sulfate", "oxyquinoline"]],
    ["TRINESSA 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["TRINTELLIX (Oral Pill)", true, ["vortioxetine"]],
    ["Tripelennamine (Topical)", false, ["tripelennamine"]],
    ["TRIPENICOL (Topical)", false, ["undecylenate"]],
    ["TRIPLE PASTE (Topical)", false, ["zinc oxide"]],
    ["TRIPLE PASTE AF (Topical)", false, ["miconazole"]],
    ["Triprolidine (Chewable)", true, ["triprolidine"]],
    ["Triprolidine (Oral Liquid)", true, ["triprolidine"]],
    ["Triprolidine (Oral Pill)", true, ["triprolidine"]],
    ["TRIPTODUR (Injectable)", false, ["triptorelin"]],
    ["TRIPTONE (Oral Pill)", true, ["dimenhydrinate"]],
    ["Triptorelin (Injectable)", false, ["triptorelin"]],
    ["TRISENOX (Injectable)", false, ["arsenic trioxide"]],
    ["TRITOLNACIDE (Topical)", false, ["tolnaftate"]],
    ["TRIUMEQ (Oral Pill)", true, ["abacavir", "dolutegravir", "lamivudine"]],
    ["TRIUMEQ (Oral Suspension Tablet)", true, ["abacavir", "dolutegravir", "lamivudine"]],
    ["TRIVISC (Injectable)", false, ["hyaluronate"]],
    ["TRIVORA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["TRIZIVIR (Oral Pill)", true, ["abacavir", "lamivudine", "zidovudine"]],
    ["TRODELVY (Injectable)", false, ["sacituzumab"]],
    ["Trofinetide (Oral Liquid)", true, ["trofinetide"]],
    ["Trofinetide (Oral Solution Powder)", true, ["trofinetide"]],
    ["TROGARZO (Injectable)", false, ["ibalizumab"]],
    ["TROKENDI XR (Oral Pill)", true, ["topiramate"]],
    ["Trolamine salicylate (Topical)", false, ["trolamine salicylate"]],
    ["Tromethamine (Injectable)", false, ["tromethamine"]],
    ["TRONOLANE ANESTHETIC (Rectal)", false, ["pramoxine", "zinc oxide"]],
    ["TROPHAMINE 10 % (Injectable)", false, ["alanine", "arginine", "aspartate", "cysteine", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "sodium metabisulfite", "taurine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["TROPHAMINE 6 % (Injectable)", false, ["alanine", "arginine", "aspartate", "cysteine", "glutamate", "glycine", "histidine", "isoleucine", "leucine", "lysine", "methionine", "phenylalanine", "proline", "serine", "sodium acetate", "sodium chloride", "sodium metabisulfite", "taurine", "threonine", "tryptophan", "tyrosine", "valine"]],
    ["Tropicamide (Ophthalmic)", false, ["tropicamide"]],
    ["Trospium (Oral Pill)", true, ["trospium"]],
    ["Trospium XR (Oral Pill)", true, ["trospium"]],
    ["Trospium/Xanomeline (Oral Pill)", true, ["trospium", "xanomeline"]],
    ["Trospium/Xanomeline (Pack)", true, ["trospium", "xanomeline"]],
    ["TRU-MICIN (Topical)", false, ["trolamine salicylate"]],
    ["TRUDHESA (Nasal)", false, ["dihydroergotamine"]],
    ["TRULANCE (Oral Pill)", true, ["plecanatide"]],
    ["TRULICITY (Injectable)", false, ["dulaglutide"]],
    ["TRUMENBA (Injectable)", false, ["meningococcal group B vaccine"]],
    ["TRUQAP (Oral Pill)", true, ["capivasertib"]],
    ["TRUSELTIQ (Oral Pill)", true, ["infigratinib"]],
    ["TRUSELTIQ 100 MG DAILY DOSE CARTON (Pack)", true, ["infigratinib"]],
    ["TRUSELTIQ 125 MG DAILY DOSE CARTON (Pack)", true, ["infigratinib"]],
    ["TRUSELTIQ 50 MG DAILY DOSE CARTON (Pack)", true, ["infigratinib"]],
    ["TRUSELTIQ 75 MG DAILY DOSE CARTON (Pack)", true, ["infigratinib"]],
    ["TRUTAKNA (Injectable)", false, ["atacicept"]],
    ["TRUVADA (Oral Pill)", true, ["emtricitabine", "tenofovir disoproxil"]],
    ["TRUXIMA (Injectable)", false, ["rituximab"]],
    ["TRYNGOLZA (Injectable)", false, ["olezarsen"]],
    ["Tryptophan (Oral Pill)", true, ["tryptophan"]],
    ["TRYPTYR (Ophthalmic)", false, ["acoltremon"]],
    ["TRYVIO (Oral Pill)", true, ["aprocitentan"]],
    ["TUBERSOL (Injectable)", false, ["purified protein derivative of tuberculin"]],
    ["Tucatinib (Oral Pill)", true, ["tucatinib"]],
    ["TUCKS (Topical)", false, ["witch hazel"]],
    ["TUDORZA (Inhalant)", false, ["aclidinium"]],
    ["TUDRIQEV (Injectable)", false, ["vusolimogene oderparepvec"]],
    ["TUKYSA (Oral Pill)", true, ["tucatinib"]],
    ["TULANA 28 DAY (Pack)", true, ["norethindrone"]],
    ["TUMS (Chewable)", true, ["calcium carbonate"]],
    ["TUMS (Oral Powder)", true, ["calcium carbonate"]],
    ["TUMS DUAL ACTION (Chewable)", true, ["calcium carbonate", "famotidine", "magnesium hydroxide"]],
    ["TUMS WITH GAS RELIEF (Chewable)", true, ["calcium carbonate", "simethicone"]],
    ["TURALIO (Oral Pill)", true, ["pexidartinib"]],
    ["TURQOZ 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestrel"]],
    ["TUXARIN XR (Oral Pill)", true, ["chlorpheniramine", "codeine"]],
    ["TWILITE (Oral Pill)", true, ["diphenhydramine"]],
    ["TWINRIX (Injectable)", false, ["hepatitis A vaccine (inactivated) strain HM175", "hepatitis B surface antigen vaccine"]],
    ["TWIRLA (Transdermal)", false, ["ethinyl estradiol", "levonorgestrel"]],
    ["TWIRLA 3 COUNT WEEKLY PATCH (Pack)", false, ["ethinyl estradiol", "levonorgestrel"]],
    ["TWYNEO (Topical)", false, ["benzoyl peroxide", "tretinoin"]],
    ["TWYNSTA (Oral Pill)", true, ["amlodipine", "telmisartan"]],
    ["TYBLUME 28 DAY (Pack)", false, ["ethinyl estradiol", "levonorgestrel"]],
    ["TYBOST (Oral Pill)", true, ["cobicistat"]],
    ["TYCOLENE (Oral Pill)", true, ["acetaminophen"]],
    ["TYDEMY 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol", "levomefolate"]],
    ["TYENNE (Injectable)", false, ["tocilizumab"]],
    ["TYGACIL (Injectable)", false, ["tigecycline"]],
    ["TYKERB (Oral Pill)", true, ["lapatinib"]],
    ["TYLENOL (Chewable)", true, ["acetaminophen"]],
    ["TYLENOL (Oral Liquid)", true, ["acetaminophen"]],
    ["TYLENOL (Oral Pill)", true, ["acetaminophen"]],
    ["TYLENOL (Oral Powder)", true, ["acetaminophen"]],
    ["TYLENOL PM (Oral Liquid)", true, ["acetaminophen", "diphenhydramine"]],
    ["TYLENOL PM (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["TYLENOL WITH CODEINE (Oral Pill)", true, ["acetaminophen", "codeine"]],
    ["TYLENOL XR (Oral Pill)", true, ["acetaminophen"]],
    ["TYMLOS (Injectable)", false, ["abaloparatide"]],
    ["TYPHIM VI (Injectable)", false, ["typhoid Vi polysaccharide vaccine, S typhi Ty2 strain"]],
    ["Typhoid Vi polysaccharide vaccine, S typhi Ty2 strain (Injectable)", false, ["typhoid Vi polysaccharide vaccine, S typhi Ty2 strain"]],
    ["Tyrosine (Oral Pill)", true, ["tyrosine"]],
    ["TYRUKO (Injectable)", false, ["natalizumab"]],
    ["TYRVAYA (Nasal)", false, ["varenicline"]],
    ["TYSABRI (Injectable)", false, ["natalizumab"]],
    ["TYVASO (Inhalant)", false, ["treprostinil"]],
    ["TYVASO 16-32 MCG TITRATION PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 16-32-48 MCG TITRATION PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 16-48-64 MCG MAINTENANCE PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 32-48 MCG INSTITUTIONAL PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 32-48 MCG MAINTENANCE PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 32-64 MCG MAINTENANCE PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 48-64 MCG MAINTENANCE PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 48-80 MCG MAINTENANCE PACK (Pack)", false, ["treprostinil"]],
    ["TYVASO 64-80 MCG MAINTENANCE PACK (Pack)", false, ["treprostinil"]],
    ["TYZAVAN (Injectable)", false, ["vancomycin"]],
    ["TZIELD (Injectable)", false, ["teplizumab"]],
    ["U-CORT (Topical)", false, ["hydrocortisone"]],
    ["U-LACTIN (Topical)", false, ["lactate", "urea"]],
    ["Ubidecarenone (Chewable)", true, ["ubidecarenone"]],
    ["Ubidecarenone (Oral Disintegrating)", true, ["ubidecarenone"]],
    ["Ubidecarenone (Oral Liquid)", true, ["ubidecarenone"]],
    ["Ubidecarenone (Oral Pill)", true, ["ubidecarenone"]],
    ["Ubidecarenone (Oral Wafer)", true, ["ubidecarenone"]],
    ["Ubidecarenone/Vitamin E (Oral Liquid)", true, ["ubidecarenone", "vitamin E"]],
    ["Ubidecarenone/Vitamin E (Oral Pill)", true, ["ubidecarenone", "vitamin E"]],
    ["Ubiquinol (Oral Liquid)", true, ["ubiquinol"]],
    ["Ubiquinol (Oral Pill)", true, ["ubiquinol"]],
    ["Ublituximab (Injectable)", false, ["ublituximab"]],
    ["UBRELVY (Oral Pill)", true, ["ubrogepant"]],
    ["Ubrogepant (Oral Pill)", true, ["ubrogepant"]],
    ["UCERIS (Rectal)", false, ["budesonide"]],
    ["UCERIS XR (Oral Pill)", true, ["budesonide"]],
    ["UDENYCA (Injectable)", false, ["pegfilgrastim"]],
    ["ULCEREASE (Mouthwash)", false, ["phenol"]],
    ["ULESFIA (Topical)", false, ["benzyl alcohol"]],
    ["Ulipristal (Oral Pill)", true, ["ulipristal"]],
    ["ULORIC (Oral Pill)", true, ["febuxostat"]],
    ["ULSPIRA (Inhalant)", false, ["nitric oxide", "nitrogen"]],
    ["ULTACAN (Injectable)", false, ["articaine", "epinephrine"]],
    ["ULTANE (Inhalant)", false, ["sevoflurane"]],
    ["ULTIVA (Injectable)", false, ["remifentanil"]],
    ["ULTOMIRIS (Injectable)", false, ["ravulizumab"]],
    ["ULTRA MIDE (Topical)", false, ["urea"]],
    ["ULTRACET (Oral Pill)", true, ["acetaminophen", "tramadol"]],
    ["ULTRAM (Oral Pill)", true, ["tramadol"]],
    ["ULTRAM XR (Oral Pill)", true, ["tramadol"]],
    ["ULTRASAL (Topical)", false, ["salicylic acid"]],
    ["ULTRAVATE (Topical)", false, ["halobetasol"]],
    ["ULTRAVATE X OINTMENT (Pack)", false, ["halobetasol", "lactate"]],
    ["Umeclidinium (Inhalant)", false, ["umeclidinium"]],
    ["Umeclidinium/Vilanterol (Inhalant)", false, ["umeclidinium", "vilanterol"]],
    ["UMECTA (Topical)", false, ["urea"]],
    ["UNASYN (Injectable)", false, ["ampicillin", "sulbactam"]],
    ["UNDECATREX (Oral Pill)", true, ["testosterone"]],
    ["Undecylenate (Topical)", false, ["undecylenate"]],
    ["UNGUENTINE (Topical)", false, ["phenol"]],
    ["UNIFIBER (Oral Powder)", true, ["cellulose"]],
    ["UNISOM (Oral Pill)", true, ["doxylamine"]],
    ["UNISOM SLEEP (Oral Disintegrating)", true, ["diphenhydramine"]],
    ["UNISOM SLEEP (Oral Pill)", true, ["diphenhydramine"]],
    ["UNISOM WITH PAIN RELIEF (Oral Pill)", true, ["acetaminophen", "diphenhydramine"]],
    ["UNITHROID (Oral Pill)", true, ["levothyroxine"]],
    ["UNITUXIN (Injectable)", false, ["dinutuximab"]],
    ["UNLOXCYT (Injectable)", false, ["cosibelimab"]],
    ["Upadacitinib (Oral Liquid)", true, ["upadacitinib"]],
    ["Upadacitinib XR (Oral Pill)", true, ["upadacitinib"]],
    ["UPLIZNA (Injectable)", false, ["inebilizumab"]],
    ["UPLIZNA 3 VIAL KIT (Pack)", false, ["inebilizumab"]],
    ["UPNEEQ (Ophthalmic)", false, ["oxymetazoline"]],
    ["UPTRAVI (Injectable)", false, ["selexipag"]],
    ["UPTRAVI (Oral Pill)", true, ["selexipag"]],
    ["UPTRAVI TITRATION PACK (Pack)", true, ["selexipag"]],
    ["URAMAXIN (Topical)", false, ["urea"]],
    ["Urea (Paste)", false, ["urea"]],
    ["Urea (Shampoo)", false, ["urea"]],
    ["Urea (Topical)", false, ["urea"]],
    ["UREACIN-10 (Topical)", false, ["urea"]],
    ["UREACIN-20 (Topical)", false, ["urea"]],
    ["URELLE (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["URETRON DS (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["UREX (Oral Pill)", true, ["methenamine"]],
    ["URIBEL (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["URIBEL TABS (Oral Pill)", true, ["benzoate", "hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate"]],
    ["URICALM (Oral Pill)", true, ["phenazopyridine"]],
    ["Uridine triacetate (Oral Granules)", true, ["uridine triacetate"]],
    ["URIMAR REFORMULATED OCT 2013 (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["URISTAT (Oral Pill)", true, ["phenazopyridine"]],
    ["URO-BLUE (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "sodium phosphate, monobasic"]],
    ["URO-MAG (Oral Pill)", true, ["magnesium oxide"]],
    ["UROCIT-K XR (Oral Pill)", true, ["potassium citrate"]],
    ["UROGESIC BLUE REFORMULATED APR 2012 (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "sodium phosphate, monobasic"]],
    ["UROQID-ACID NO.2 (Oral Pill)", true, ["methenamine", "sodium phosphate, monobasic"]],
    ["UROXATRAL XR (Oral Pill)", true, ["alfuzosin"]],
    ["URSO (Oral Pill)", true, ["ursodeoxycholate"]],
    ["URSO FORTE (Oral Pill)", true, ["ursodeoxycholate"]],
    ["Ursodeoxycholate (Oral Pill)", true, ["ursodeoxycholate"]],
    ["URSOLIGN (Oral Pill)", true, ["ursodeoxycholate"]],
    ["Ustekinumab (Injectable)", false, ["ustekinumab"]],
    ["USTELL (Oral Pill)", true, ["hyoscyamine", "methenamine", "methylene blue", "phenyl salicylate", "sodium phosphate, monobasic"]],
    ["UTEBZI (Oral Pill)", true, ["tebipenem pivoxil"]],
    ["UTOPIC (Topical)", false, ["urea"]],
    ["UVADEX (Injectable)", false, ["methoxsalen"]],
    ["UZEDY (Injectable)", false, ["risperidone"]],
    ["VABOMERE (Injectable)", false, ["meropenem", "vaborbactam"]],
    ["VABRINTY (Injectable)", false, ["leuprolide"]],
    ["VABYSMO (Injectable)", false, ["faricimab"]],
    ["Vaccinia virus (Injectable)", false, ["vaccinia virus"]],
    ["Vadadustat (Oral Pill)", true, ["vadadustat"]],
    ["VAFSEO (Oral Pill)", true, ["vadadustat"]],
    ["VAGIFEM (Vaginal)", false, ["estradiol"]],
    ["VAGISIL ORIGINAL FORMULA (Vaginal)", false, ["benzocaine", "resorcinol"]],
    ["VAGISIL SATIN (Vaginal)", false, ["hydrocortisone"]],
    ["VAGISIL WIPES (Topical)", false, ["pramoxine"]],
    ["VAGISTAT (Vaginal)", false, ["miconazole"]],
    ["VAGISTAT 3 DAY COMBINATION PACK (Pack)", false, ["miconazole"]],
    ["VAGISTAT-1 (Vaginal)", false, ["tioconazole"]],
    ["valACYclovir (Oral Pill)", true, ["valacyclovir"]],
    ["Valbenazine (Oral Pill)", true, ["valbenazine"]],
    ["Valbenazine (Pack)", true, ["valbenazine"]],
    ["VALCHLOR (Topical)", false, ["mechlorethamine"]],
    ["VALCYTE (Oral Liquid)", true, ["valganciclovir"]],
    ["VALCYTE (Oral Pill)", true, ["valganciclovir"]],
    ["valGANciclovir (Oral Liquid)", true, ["valganciclovir"]],
    ["valGANciclovir (Oral Pill)", true, ["valganciclovir"]],
    ["VALIUM (Oral Pill)", true, ["diazepam"]],
    ["Valoctocogene roxaparvovec (Injectable)", false, ["valoctocogene roxaparvovec"]],
    ["Valproate (Injectable)", false, ["valproate"]],
    ["Valproate (Oral Liquid)", true, ["valproate"]],
    ["Valproate (Oral Pill)", true, ["valproate"]],
    ["Valproate XR (Oral Pill)", true, ["valproate"]],
    ["Valrubicin (Intravesical)", false, ["valrubicin"]],
    ["Valsartan (Oral Liquid)", true, ["valsartan"]],
    ["Valsartan (Oral Pill)", true, ["valsartan"]],
    ["VALSTAR (Intravesical)", false, ["valrubicin"]],
    ["VALTOCO (Nasal)", false, ["diazepam"]],
    ["VALTOCO 10 MG DOSE KIT (Pack)", false, ["diazepam"]],
    ["VALTOCO 15 MG DOSE KIT (Pack)", false, ["diazepam"]],
    ["VALTOCO 20 MG DOSE KIT (Pack)", false, ["diazepam"]],
    ["VALTOCO 5 MG DOSE KIT (Pack)", false, ["diazepam"]],
    ["VALTREX (Oral Pill)", true, ["valacyclovir"]],
    ["VALTYA 1/35 28 DAY (Pack)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["VALTYA 1/50 28 DAY (Pack)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["Vamorolone (Oral Liquid)", true, ["vamorolone"]],
    ["VANACOF AC (Oral Liquid)", true, ["chlophedianol", "pyrilamine"]],
    ["VANADOM (Oral Pill)", true, ["carisoprodol"]],
    ["VANALICE (Topical)", false, ["piperonyl butoxide", "pyrethrins"]],
    ["VANAMINE (Oral Liquid)", true, ["diphenhydramine"]],
    ["VANATOL (Oral Liquid)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["VANCOCIN (Oral Pill)", true, ["vancomycin"]],
    ["Vancomycin (Injectable)", false, ["vancomycin"]],
    ["Vancomycin (Oral Liquid)", true, ["vancomycin"]],
    ["Vancomycin (Oral Pill)", true, ["vancomycin"]],
    ["VANDAZOLE (Vaginal)", false, ["metronidazole"]],
    ["Vandetanib (Oral Pill)", true, ["vandetanib"]],
    ["VANFLYTA (Oral Pill)", true, ["quizartinib"]],
    ["VANOS (Topical)", false, ["fluocinonide"]],
    ["VANOXIDE-HC (Topical)", false, ["benzoyl peroxide", "hydrocortisone"]],
    ["VANQUISH (Oral Pill)", true, ["acetaminophen", "aspirin", "caffeine"]],
    ["VANRAFIA (Oral Pill)", true, ["atrasentan"]],
    ["VAPOREX (Topical)", false, ["Eucalyptus oil", "camphor", "menthol"]],
    ["VAPRISOL (Injectable)", false, ["conivaptan"]],
    ["VAQTA (Injectable)", false, ["hepatitis A virus strain CR 326F antigen, inactivated"]],
    ["Vardenafil (Oral Disintegrating)", true, ["vardenafil"]],
    ["Vardenafil (Oral Pill)", true, ["vardenafil"]],
    ["Varenicline (Nasal)", false, ["varenicline"]],
    ["Varenicline (Oral Pill)", true, ["varenicline"]],
    ["Varenicline (Pack)", true, ["varenicline"]],
    ["Varicella zoster virus glycoprotein E (Injectable)", false, ["varicella zoster virus glycoprotein E"]],
    ["Varicella-zoster immune globulin (Injectable)", false, ["varicella-zoster immune globulin"]],
    ["Varicella-zoster virus vaccine live (Oka-Merck) strain (Injectable)", false, ["varicella-zoster virus vaccine live (Oka-Merck) strain"]],
    ["VARITHENA (Injectable)", false, ["polidocanol"]],
    ["VARIVAX (Injectable)", false, ["varicella-zoster virus vaccine live (Oka-Merck) strain"]],
    ["VARIZIG (Injectable)", false, ["varicella-zoster immune globulin"]],
    ["VARUBI (Oral Pill)", true, ["rolapitant"]],
    ["VASCEPA (Oral Pill)", true, ["icosapent ethyl"]],
    ["VASELINE (Topical)", false, ["petrolatum"]],
    ["VASERETIC (Oral Pill)", true, ["enalapril", "hydrochlorothiazide"]],
    ["VASOFLEX D1 (Oral Pill)", true, ["diosmin", "hesperidin"]],
    ["Vasopressin (USP) (Injectable)", false, ["vasopressin (USP)"]],
    ["VASOSTRICT (Injectable)", false, ["vasopressin (USP)"]],
    ["VASOTEC (Oral Pill)", true, ["enalapril"]],
    ["VAXCHORA (Oral Liquid)", true, ["Vibrio cholerae CVD 103-HGR strain live antigen"]],
    ["VAXELIS (Injectable)", false, ["Haemophilus influenzae b (Ross strain) capsular polysaccharide meningococcal protein conjugate vaccine", "acellular pertussis vaccine, inactivated", "diphtheria toxoid vaccine, inactivated", "hepatitis B surface antigen vaccine", "poliovirus vaccine inactivated, type 1 (Mahoney)", "poliovirus vaccine inactivated, type 2 (MEF-1)", "poliovirus vaccine inactivated, type 3 (Saukett)", "tetanus toxoid vaccine, inactivated"]],
    ["VAXNEUVANCE (Injectable)", false, ["Streptococcus pneumoniae serotype 1 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 14 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 18C capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 19F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 22F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 23F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 3 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 33F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 4 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 5 capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6A capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 6B capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 7F capsular antigen diphtheria CRM197 protein conjugate vaccine", "Streptococcus pneumoniae serotype 9V capsular antigen diphtheria CRM197 protein conjugate vaccine"]],
    ["VAZALORE (Oral Pill)", true, ["aspirin"]],
    ["VAZCULEP (Injectable)", false, ["phenylephrine"]],
    ["VCF CONTRACEPTIVE (Vaginal)", false, ["nonoxynol-9"]],
    ["VECAMYL (Oral Pill)", true, ["mecamylamine"]],
    ["VECTIBIX (Injectable)", false, ["panitumumab"]],
    ["VECTICAL (Topical)", false, ["calcitriol"]],
    ["Vecuronium (Injectable)", false, ["vecuronium"]],
    ["Vedolizumab (Injectable)", false, ["vedolizumab"]],
    ["VEGZELMA (Injectable)", false, ["bevacizumab"]],
    ["VEKLURY (Injectable)", false, ["remdesivir"]],
    ["Velaglucerase alfa (Injectable)", false, ["velaglucerase alfa"]],
    ["VELCADE (Injectable)", false, ["bortezomib"]],
    ["VELETRI (Injectable)", false, ["epoprostenol"]],
    ["Veligrotug (Injectable)", false, ["veligrotug"]],
    ["VELIVET 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Velmanase alfa (Injectable)", false, ["velmanase alfa"]],
    ["VELPHORO (Chewable)", true, ["sucroferric oxyhydroxide"]],
    ["VELSIPITY (Oral Pill)", true, ["etrasimod"]],
    ["VELTASSA (Oral Suspension Powder)", true, ["patiromer"]],
    ["VELTIN (Topical)", false, ["clindamycin", "tretinoin"]],
    ["VEMLIDY (Oral Pill)", true, ["tenofovir alafenamide"]],
    ["Vemurafenib (Oral Pill)", true, ["vemurafenib"]],
    ["VENCLEXTA (Oral Pill)", true, ["venetoclax"]],
    ["VENCLEXTA STARTING PACK (Pack)", true, ["venetoclax"]],
    ["VENELEX (Topical)", false, ["Peruvian balsam", "castor oil"]],
    ["Venetoclax (Oral Pill)", true, ["venetoclax"]],
    ["Venetoclax (Pack)", true, ["venetoclax"]],
    ["Venlafaxine (Oral Pill)", true, ["venlafaxine"]],
    ["Venlafaxine XR (Oral Pill)", true, ["venlafaxine"]],
    ["VENOFER (Injectable)", false, ["iron sucrose"]],
    ["VENTAVIS (Inhalant)", false, ["iloprost"]],
    ["VENTOLIN (Inhalant)", false, ["albuterol"]],
    ["VENXXIVA (Oral Pill)", true, ["tiopronin"]],
    ["VEOPOZ (Injectable)", false, ["pozelimab"]],
    ["VEOZAH (Oral Pill)", true, ["fezolinetant"]],
    ["Vepdegestrant (Oral Pill)", true, ["vepdegestrant"]],
    ["VEPESID (Oral Pill)", true, ["etoposide"]],
    ["VEPPANU (Oral Pill)", true, ["vepdegestrant"]],
    ["Verapamil (Injectable)", false, ["verapamil"]],
    ["Verapamil (Oral Pill)", true, ["verapamil"]],
    ["Verapamil XR (Oral Pill)", true, ["verapamil"]],
    ["VERDESO (Topical)", false, ["desonide"]],
    ["VERDROCET (Oral Pill)", true, ["acetaminophen", "hydrocodone"]],
    ["VEREGEN (Topical)", false, ["sinecatechins"]],
    ["VERELAN XR (Oral Pill)", true, ["verapamil"]],
    ["Vericiguat (Oral Pill)", true, ["vericiguat"]],
    ["VERIPRED (Oral Liquid)", true, ["prednisolone"]],
    ["VERKAZIA (Ophthalmic)", false, ["cyclosporine"]],
    ["VERMOX (Chewable)", true, ["mebendazole"]],
    ["VERQUVO (Oral Pill)", true, ["vericiguat"]],
    ["VERSACLOZ (Oral Liquid)", true, ["clozapine"]],
    ["VERSICLEAR (Topical)", false, ["salicylic acid", "thiosulfate"]],
    ["Verteporfin (Injectable)", false, ["verteporfin"]],
    ["VERZENIO (Oral Pill)", true, ["abemaciclib"]],
    ["VESICARE (Oral Liquid)", true, ["solifenacin"]],
    ["VESICARE (Oral Pill)", true, ["solifenacin"]],
    ["Vestronidase alfa (Injectable)", false, ["vestronidase alfa"]],
    ["VESTURA (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["VEVYE (Ophthalmic)", false, ["cyclosporine"]],
    ["VFEND (Injectable)", false, ["voriconazole"]],
    ["VFEND (Oral Liquid)", true, ["voriconazole"]],
    ["VFEND (Oral Pill)", true, ["voriconazole"]],
    ["VIABECLINE (Topical)", false, ["tetracycline"]],
    ["VIACTIV CALCIUM PLUS D (Chewable)", true, ["calcium carbonate", "cholecalciferol", "vitamin K"]],
    ["VIAGRA (Oral Pill)", true, ["sildenafil"]],
    ["VIBATIV (Injectable)", false, ["telavancin"]],
    ["Vibegron (Oral Pill)", true, ["vibegron"]],
    ["VIBERZI (Oral Pill)", true, ["eluxadoline"]],
    ["VIBRAMYCIN (Oral Liquid)", true, ["doxycycline"]],
    ["VIBRAMYCIN (Oral Pill)", true, ["doxycycline"]],
    ["Vibrio cholerae CVD 103-HGR strain live antigen (Oral Liquid)", true, ["Vibrio cholerae CVD 103-HGR strain live antigen"]],
    ["VICOPROFEN (Oral Pill)", true, ["hydrocodone", "ibuprofen"]],
    ["VICTOZA (Injectable)", false, ["liraglutide"]],
    ["VIDAZA (Injectable)", false, ["azacitidine"]],
    ["VIENVA 28 DAY (Pack)", true, ["ethinyl estradiol", "levonorgestrel"]],
    ["Vigabatrin (Oral Liquid)", true, ["vigabatrin"]],
    ["Vigabatrin (Oral Pill)", true, ["vigabatrin"]],
    ["Vigabatrin (Oral Solution Powder)", true, ["vigabatrin"]],
    ["VIGADRONE (Oral Pill)", true, ["vigabatrin"]],
    ["VIGADRONE (Oral Solution Powder)", true, ["vigabatrin"]],
    ["VIGAFYDE (Oral Liquid)", true, ["vigabatrin"]],
    ["VIGAMOX (Ophthalmic)", false, ["moxifloxacin"]],
    ["VIGPODER (Oral Solution Powder)", true, ["vigabatrin"]],
    ["VIIBRYD (Oral Pill)", true, ["vilazodone"]],
    ["VIJOICE (Oral Granules)", true, ["alpelisib"]],
    ["VIJOICE (Oral Pill)", true, ["alpelisib"]],
    ["VIJOICE 125 MG 28 DAY (Pack)", true, ["alpelisib"]],
    ["VIJOICE 250 MG 28 DAY (Pack)", true, ["alpelisib"]],
    ["VIJOICE 50 MG 28 DAY (Pack)", true, ["alpelisib"]],
    ["VIJOICE 50 MG GRANULES 28 DAY (Pack)", false, ["alpelisib"]],
    ["Vilazodone (Oral Pill)", true, ["vilazodone"]],
    ["Vilobelimab (Injectable)", false, ["vilobelimab"]],
    ["Viloxazine XR (Oral Pill)", true, ["viloxazine"]],
    ["VILTEPSO (Injectable)", false, ["viltolarsen"]],
    ["Viltolarsen (Injectable)", false, ["viltolarsen"]],
    ["VIMIZIM (Injectable)", false, ["elosulfase alfa"]],
    ["VIMKUNYA (Injectable)", false, ["chikungunya virus antigen, recombinant Senegal strain 37997"]],
    ["VIMOVO (Oral Pill)", true, ["esomeprazole", "naproxen"]],
    ["VIMPAT (Injectable)", false, ["lacosamide"]],
    ["VIMPAT (Oral Liquid)", true, ["lacosamide"]],
    ["VIMPAT (Oral Pill)", true, ["lacosamide"]],
    ["Vimseltinib (Oral Pill)", true, ["vimseltinib"]],
    ["vinBLAStine (Injectable)", false, ["vinblastine"]],
    ["VINCASAR (Injectable)", false, ["vincristine"]],
    ["vinCRIStine (Injectable)", false, ["vincristine"]],
    ["Vinorelbine (Injectable)", false, ["vinorelbine"]],
    ["VIOKACE (Oral Pill)", true, ["amylase", "lipase", "protease"]],
    ["VIORELE 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["Vipivotide tetraxetan (Injectable)", false, ["vipivotide tetraxetan"]],
    ["VIRACEPT (Oral Pill)", true, ["nelfinavir"]],
    ["VIRAMUNE (Oral Pill)", true, ["nevirapine"]],
    ["VIRASAL (Topical)", false, ["salicylic acid"]],
    ["VIRAZOLE (Inhalant)", false, ["ribavirin"]],
    ["VIREAD (Oral Pill)", true, ["tenofovir disoproxil"]],
    ["VIREAD (Oral Powder)", true, ["tenofovir disoproxil"]],
    ["VISCO-3 (Injectable)", false, ["hyaluronate"]],
    ["VISCOAT (Injectable)", false, ["chondroitin sulfates", "hyaluronate"]],
    ["VISINE (Ophthalmic)", false, ["tetrahydrozoline"]],
    ["Vismodegib (Oral Pill)", true, ["vismodegib"]],
    ["VISTARIL (Oral Pill)", true, ["hydroxyzine"]],
    ["VISTASEAL (Injectable)", false, ["fibrinogen", "thrombin"]],
    ["VISTOGARD (Oral Granules)", true, ["uridine triacetate"]],
    ["VISUDYNE (Injectable)", false, ["verteporfin"]],
    ["VITA-RESPA (Oral Pill)", true, ["folic acid", "pyridoxine", "vitamin B12"]],
    ["VITAFOL-ONE (Oral Pill)", true, ["ascorbic acid", "cholecalciferol", "cuprous oxide", "folic acid", "magnesium oxide", "niacin", "polysaccharide iron complex", "potassium iodide", "pyridoxine", "riboflavin", "thiamine", "vitamin A", "vitamin B12", "vitamin E", "zinc oxide"]],
    ["Vitamin A (Injectable)", false, ["vitamin A"]],
    ["Vitamin A (Oral Pill)", true, ["vitamin A"]],
    ["Vitamin A (Sublingual)", false, ["vitamin A"]],
    ["Vitamin B12 (Chewable)", true, ["vitamin B12"]],
    ["Vitamin B12 (Injectable)", false, ["vitamin B12"]],
    ["Vitamin B12 (Nasal)", false, ["vitamin B12"]],
    ["Vitamin B12 (Oral Disintegrating)", true, ["vitamin B12"]],
    ["Vitamin B12 (Oral Film)", true, ["vitamin B12"]],
    ["Vitamin B12 (Oral Liquid)", true, ["vitamin B12"]],
    ["Vitamin B12 (Oral Lozenge)", true, ["vitamin B12"]],
    ["Vitamin B12 (Oral Pill)", true, ["vitamin B12"]],
    ["Vitamin B12 (Sublingual)", false, ["vitamin B12"]],
    ["Vitamin B12 XR (Oral Pill)", true, ["vitamin B12"]],
    ["Vitamin B6 (Oral Lozenge)", true, ["vitamin B6"]],
    ["Vitamin B6 (Oral Pill)", true, ["vitamin B6"]],
    ["Vitamin B6 XR (Oral Pill)", true, ["vitamin B6"]],
    ["Vitamin E (Chewable)", true, ["vitamin E"]],
    ["Vitamin E (Oral Liquid)", true, ["vitamin E"]],
    ["Vitamin E (Oral Pill)", true, ["vitamin E"]],
    ["Vitamin E (Rectal)", false, ["vitamin E"]],
    ["Vitamin E (Topical)", false, ["vitamin E"]],
    ["Vitamin K (Oral Pill)", true, ["vitamin K"]],
    ["Vitamin K1 (Injectable)", false, ["vitamin K1"]],
    ["Vitamin K1 (Oral Pill)", true, ["vitamin K1"]],
    ["Vitamin K1 (Sublingual)", false, ["vitamin K1"]],
    ["Vitamin K2 (Oral Pill)", true, ["vitamin K2"]],
    ["VITRAKVI (Oral Liquid)", true, ["larotrectinib"]],
    ["VITRAKVI (Oral Pill)", true, ["larotrectinib"]],
    ["VITRON-C REFORMULATED JUL 2016 (Oral Pill)", true, ["ascorbic acid", "iron carbonyl"]],
    ["VIVA-DROPS LUBRICATING EYE DROPS (Ophthalmic)", false, ["polysorbate 80"]],
    ["VIVACAINE (Injectable)", false, ["bupivacaine", "epinephrine"]],
    ["VIVARIN (Oral Pill)", true, ["caffeine"]],
    ["VIVELLE (Transdermal)", false, ["estradiol"]],
    ["VIVIMUSTA (Injectable)", false, ["bendamustine"]],
    ["VIVITROL (Injectable)", false, ["naltrexone"]],
    ["VIVJOA (Oral Pill)", true, ["oteseconazole"]],
    ["VIVJOA 18-COUNT (Pack)", true, ["oteseconazole"]],
    ["VIVLODEX (Oral Pill)", true, ["meloxicam"]],
    ["VIVOTIF (Oral Pill)", true, ["Salmonella typhi Ty21a live antigen"]],
    ["VIZIMPRO (Oral Pill)", true, ["dacomitinib"]],
    ["VIZZ (Ophthalmic)", false, ["aceclidine"]],
    ["VOCABRIA (Oral Pill)", true, ["cabotegravir"]],
    ["Voclosporin (Oral Pill)", true, ["voclosporin"]],
    ["VOGELXO (Topical)", false, ["testosterone"]],
    ["VOLNEA 28 DAY (Pack)", true, ["desogestrel", "ethinyl estradiol"]],
    ["VOLTAREN (Topical)", false, ["diclofenac"]],
    ["Vonicog alfa (Injectable)", false, ["vonicog alfa"]],
    ["VONJO (Oral Pill)", true, ["pacritinib"]],
    ["Vonoprazan (Oral Pill)", true, ["vonoprazan"]],
    ["VONVENDI (Injectable)", false, ["vonicog alfa"]],
    ["VOQUEZNA (Oral Pill)", true, ["vonoprazan"]],
    ["VOQUEZNA 14 DAY DUALPAK 20;500 (Pack)", true, ["amoxicillin", "vonoprazan"]],
    ["VOQUEZNA 14 DAY TRIPLEPAK 20;500;500 (Pack)", true, ["amoxicillin", "clarithromycin", "vonoprazan"]],
    ["VORANIGO (Oral Pill)", true, ["vorasidenib"]],
    ["Vorapaxar (Oral Pill)", true, ["vorapaxar"]],
    ["Vorasidenib (Oral Pill)", true, ["vorasidenib"]],
    ["VORAXAZE (Injectable)", false, ["glucarpidase"]],
    ["Voretigene neparvovec (Injectable)", false, ["voretigene neparvovec"]],
    ["Voriconazole (Injectable)", false, ["voriconazole"]],
    ["Voriconazole (Oral Liquid)", true, ["voriconazole"]],
    ["Voriconazole (Oral Pill)", true, ["voriconazole"]],
    ["Vorinostat (Oral Pill)", true, ["vorinostat"]],
    ["Vortioxetine (Oral Pill)", true, ["vortioxetine"]],
    ["VOSEVI (Oral Pill)", true, ["sofosbuvir", "velpatasvir", "voxilaprevir"]],
    ["Vosoritide (Injectable)", false, ["vosoritide"]],
    ["VOSTALLY (Oral Liquid)", true, ["ramipril"]],
    ["VOTRIENT (Oral Pill)", true, ["pazopanib"]],
    ["VOWST (Oral Pill)", true, ["fecal microbiota spores, live"]],
    ["VOXZOGO (Injectable)", false, ["vosoritide"]],
    ["VOYDEYA (Oral Pill)", true, ["danicopan"]],
    ["VOYDEYA 150 MG DOSE BOTTLE (Pack)", true, ["danicopan"]],
    ["VOYDEYA 200 MG DOSE BOTTLE (Pack)", true, ["danicopan"]],
    ["VOYDEYA 200 MG DOSE CARD (Pack)", true, ["danicopan"]],
    ["VOYXACT (Injectable)", false, ["sibeprenlimab"]],
    ["VPRIV (Injectable)", false, ["velaglucerase alfa"]],
    ["VRAYLAR (Oral Pill)", true, ["cariprazine"]],
    ["VRAYLAR 1.5/3 MIXED PACK (Pack)", true, ["cariprazine"]],
    ["VTAMA (Topical)", false, ["tapinarof"]],
    ["VTOL (Oral Liquid)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["VUITY (Ophthalmic)", false, ["pilocarpine"]],
    ["VUMERITY (Oral Pill)", true, ["diroximel fumarate"]],
    ["VUSION (Topical)", false, ["miconazole", "petrolatum", "zinc oxide"]],
    ["Vusolimogene oderparepvec (Injectable)", false, ["vusolimogene oderparepvec"]],
    ["Vutrisiran (Injectable)", false, ["vutrisiran"]],
    ["VYALEV (Injectable)", false, ["carbidopa", "levodopa"]],
    ["VYBRIQUE (Oral Film)", true, ["sildenafil"]],
    ["VYEPTI (Injectable)", false, ["eptinezumab"]],
    ["VYFEMLA 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["VYJUVEK (Topical)", false, ["beremagene geperpavec"]],
    ["VYKAT XR (Oral Pill)", true, ["diazoxide"]],
    ["VYKOURA (Injectable)", false, ["leucovorin"]],
    ["VYLEESI (Injectable)", false, ["bremelanotide"]],
    ["VYLIBRA 28 DAY (Pack)", true, ["ethinyl estradiol", "norgestimate"]],
    ["VYLOY (Injectable)", false, ["zolbetuximab"]],
    ["VYNDAMAX (Oral Pill)", true, ["tafamidis"]],
    ["VYNDAQEL (Oral Pill)", true, ["tafamidis"]],
    ["VYONDYS 53 (Injectable)", false, ["golodirsen"]],
    ["VYSCOXA (Oral Liquid)", true, ["celecoxib"]],
    ["VYTONE (Topical)", false, ["hydrocortisone", "iodoquinol"]],
    ["VYTORIN (Oral Pill)", true, ["ezetimibe", "simvastatin"]],
    ["VYVANSE (Chewable)", true, ["lisdexamfetamine"]],
    ["VYVANSE (Oral Pill)", true, ["lisdexamfetamine"]],
    ["VYVGART (Injectable)", false, ["efgartigimod alfa"]],
    ["VYVGART HYTRULO (Injectable)", false, ["efgartigimod alfa", "hyaluronidase"]],
    ["VYXEOS (Injectable)", false, ["cytarabine", "daunorubicin"]],
    ["VYZULTA (Ophthalmic)", false, ["latanoprostene bunod"]],
    ["WAINUA (Injectable)", false, ["eplontersen"]],
    ["WAKIX (Oral Pill)", true, ["pitolisant"]],
    ["WAL ZYR 24 HOUR ALLERGY (Oral Liquid)", true, ["cetirizine"]],
    ["WAL ZYR D XR (Oral Pill)", true, ["cetirizine", "pseudoephedrine"]],
    ["WAL-ACT (Oral Pill)", true, ["pseudoephedrine", "triprolidine"]],
    ["WAL-DRAM (Oral Pill)", true, ["dimenhydrinate"]],
    ["WAL-DRAM 2 (Oral Pill)", true, ["meclizine"]],
    ["WAL-DRYL (Topical)", false, ["diphenhydramine", "zinc acetate"]],
    ["WAL-DRYL ALLERGY (Oral Disintegrating)", true, ["diphenhydramine"]],
    ["WAL-DRYL ALLERGY (Oral Pill)", true, ["diphenhydramine"]],
    ["WAL-DRYL CHILDRENS (Oral Liquid)", true, ["diphenhydramine"]],
    ["WAL-DRYL PE (Oral Liquid)", true, ["diphenhydramine", "phenylephrine"]],
    ["WAL-DRYL-D (Oral Pill)", true, ["diphenhydramine", "phenylephrine"]],
    ["WAL-FEX (Oral Liquid)", true, ["fexofenadine"]],
    ["WAL-FEX (Oral Pill)", true, ["fexofenadine"]],
    ["WAL-FEX D XR (Oral Pill)", true, ["fexofenadine", "pseudoephedrine"]],
    ["WAL-FINATE (Oral Pill)", true, ["chlorpheniramine"]],
    ["WAL-FOUR (Nasal)", false, ["phenylephrine"]],
    ["WAL-HIST 12 HR RELIEF XR (Oral Pill)", true, ["clemastine"]],
    ["WAL-ITIN (Chewable)", true, ["loratadine"]],
    ["WAL-ITIN (Oral Disintegrating)", true, ["loratadine"]],
    ["WAL-ITIN (Oral Liquid)", true, ["loratadine"]],
    ["WAL-ITIN (Oral Pill)", true, ["loratadine"]],
    ["WAL-ITIN D XR (Oral Pill)", true, ["loratadine", "pseudoephedrine"]],
    ["WAL-MUCIL (Oral Pill)", true, ["psyllium"]],
    ["WAL-MUCIL (Oral Suspension Powder)", true, ["psyllium"]],
    ["WAL-PHED (Oral Pill)", true, ["pseudoephedrine"]],
    ["WAL-PHED PE (Oral Pill)", true, ["phenylephrine"]],
    ["WAL-PHED XR (Oral Pill)", true, ["pseudoephedrine"]],
    ["WAL-PROFEN (Oral Pill)", true, ["ibuprofen"]],
    ["WAL-PROXEN (Oral Pill)", true, ["naproxen"]],
    ["WAL-SLEEP Z (Oral Disintegrating)", true, ["diphenhydramine"]],
    ["WAL-SLEEP Z (Oral Liquid)", true, ["diphenhydramine"]],
    ["WAL-SLEEP Z (Oral Pill)", true, ["diphenhydramine"]],
    ["WAL-SOM (DOXYLAMINE) (Oral Pill)", true, ["doxylamine"]],
    ["WAL-SOM (Oral Disintegrating)", true, ["diphenhydramine"]],
    ["WAL-SOM MAXIMUM STRENGTH (Oral Pill)", true, ["diphenhydramine"]],
    ["WAL-VERT (Oral Disintegrating)", true, ["loratadine"]],
    ["WAL-ZYR (Chewable)", true, ["cetirizine"]],
    ["WAL-ZYR (Oral Pill)", true, ["cetirizine"]],
    ["WAL-ZYR ITCHY EYE (Ophthalmic)", false, ["ketotifen"]],
    ["Warfarin (Oral Pill)", true, ["warfarin"]],
    ["WASKYRA (Injectable)", false, ["etuvetidigene autotemcel"]],
    ["Wasp venom protein (Injectable)", false, ["wasp venom protein"]],
    ["Water (Inhalant)", false, ["water"]],
    ["Water (Irrigation)", false, ["water"]],
    ["Water (Ophthalmic)", false, ["water"]],
    ["WAYRILZ (Oral Pill)", true, ["rilzabrutinib"]],
    ["WEGOVY (Injectable)", false, ["semaglutide"]],
    ["WEGOVY (Oral Pill)", true, ["semaglutide"]],
    ["WELCHOL (Oral Pill)", true, ["colesevelam"]],
    ["WELCHOL (Oral Suspension Powder)", true, ["colesevelam"]],
    ["WELIREG (Oral Pill)", true, ["belzutifan"]],
    ["WELLBUTRIN XR (Oral Pill)", true, ["bupropion"]],
    ["WERA 28 DAY (Pack)", true, ["ethinyl estradiol", "norethindrone"]],
    ["WESTCORT (Topical)", false, ["hydrocortisone"]],
    ["WESTHROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["WEZLANA (Injectable)", false, ["ustekinumab"]],
    ["Wheat dextrin (Chewable)", true, ["wheat dextrin"]],
    ["Wheat dextrin (Oral Solution Powder)", true, ["wheat dextrin"]],
    ["WIDAPLIK (Oral Pill)", true, ["amlodipine", "indapamide", "telmisartan"]],
    ["WILATE (Injectable)", false, ["factor VIII", "von Willebrand factor"]],
    ["WILZIN (Oral Pill)", true, ["zinc acetate"]],
    ["WINLEVI (Topical)", false, ["clascoterone"]],
    ["WINREVAIR (Injectable)", false, ["sotatercept"]],
    ["WINREVAIR 45 MG, 2 VIAL KIT (Pack)", false, ["sotatercept"]],
    ["WINREVAIR 60 MG, 2 VIAL KIT (Pack)", false, ["sotatercept"]],
    ["WINRHO (Injectable)", false, ["Rho(D) immune globulin"]],
    ["Witch hazel (Topical)", false, ["witch hazel"]],
    ["WIXELA (Inhalant)", false, ["fluticasone", "salmeterol"]],
    ["WP THYROID (Oral Pill)", true, ["thyroid (USP)"]],
    ["WYMZYA FE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["WYNZORA (Topical)", false, ["betamethasone", "calcipotriene"]],
    ["WYOST (Injectable)", false, ["denosumab"]],
    ["X-SEB T PEARL (Shampoo)", false, ["coal tar", "salicylic acid"]],
    ["X-SEB T PLUS (Shampoo)", false, ["coal tar"]],
    ["XACDURO (Injectable)", false, ["durlobactam", "sulbactam"]],
    ["XACIATO (Vaginal)", false, ["clindamycin"]],
    ["XADAGO (Oral Pill)", true, ["safinamide"]],
    ["XALATAN (Ophthalmic)", false, ["latanoprost"]],
    ["XALIX (Topical)", false, ["salicylic acid"]],
    ["XALKORI (Oral Pellet)", true, ["crizotinib"]],
    ["XALKORI (Oral Pill)", true, ["crizotinib"]],
    ["XANAX (Oral Pill)", true, ["alprazolam"]],
    ["XANAX XR (Oral Pill)", true, ["alprazolam"]],
    ["XARACOLL (Implant)", false, ["bupivacaine"]],
    ["XARACOLL 3 IMPLANT DOSE (Pack)", false, ["bupivacaine"]],
    ["XARAH FE 28 DAY (Pack)", true, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["XARELTO (Oral Liquid)", true, ["rivaroxaban"]],
    ["XARELTO (Oral Pill)", true, ["rivaroxaban"]],
    ["XARELTO KIT (Pack)", true, ["rivaroxaban"]],
    ["XATMEP (Oral Liquid)", true, ["methotrexate"]],
    ["XBRYK (Injectable)", false, ["denosumab"]],
    ["XCOPRI (Oral Pill)", true, ["cenobamate"]],
    ["XCOPRI 250 MG MAINTENANCE PACK - 100 MG (28), 150 MG (28) 56 COUNT (Pack)", true, ["cenobamate"]],
    ["XCOPRI 350 MG MAINTENANCE PACK (Pack)", true, ["cenobamate"]],
    ["XCOPRI TITRATION PACK - 12.5 MG (14), 25 MG (14) 28 COUNT (Pack)", true, ["cenobamate"]],
    ["XCOPRI TITRATION PACK - 12.5 MG 14 COUNT (Pack)", true, ["cenobamate"]],
    ["XCOPRI TITRATION PACK - 150 MG (14), 200 MG (14) 28 COUNT (Pack)", true, ["cenobamate"]],
    ["XCOPRI TITRATION PACK - 50 MG (14), 100 MG (14) 28 COUNT (Pack)", true, ["cenobamate"]],
    ["XDEMVY (Ophthalmic)", false, ["lotilaner"]],
    ["XELJANZ (Oral Liquid)", true, ["tofacitinib"]],
    ["XELJANZ (Oral Pill)", true, ["tofacitinib"]],
    ["XELJANZ XR (Oral Pill)", true, ["tofacitinib"]],
    ["XELODA (Oral Pill)", true, ["capecitabine"]],
    ["XELPROS (Ophthalmic)", false, ["latanoprost"]],
    ["XELRIA FE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["XELSTRYM (Transdermal)", false, ["dextroamphetamine"]],
    ["XEMBIFY (Injectable)", false, ["immunoglobulin G"]],
    ["XENAZINE (Oral Pill)", true, ["tetrabenazine"]],
    ["XENICAL (Oral Pill)", true, ["orlistat"]],
    ["XENLETA (Injectable)", false, ["lefamulin"]],
    ["XENLETA (Oral Pill)", true, ["lefamulin"]],
    ["XENLETA 5 DAY (Pack)", true, ["lefamulin"]],
    ["XENPOZYME (Injectable)", false, ["olipudase alfa"]],
    ["XEOMIN (Injectable)", false, ["botulinum toxin type A"]],
    ["XEPI (Topical)", false, ["ozenoxacin"]],
    ["XERAC AC (Topical)", false, ["aluminum chloride"]],
    ["XERAVA (Injectable)", false, ["eravacycline"]],
    ["XERESE (Topical)", false, ["acyclovir", "hydrocortisone"]],
    ["XERMELO (Oral Pill)", true, ["telotristat ethyl"]],
    ["XGEVA (Injectable)", false, ["denosumab"]],
    ["XHANCE (Nasal)", false, ["fluticasone"]],
    ["XIAFLEX (Injectable)", false, ["collagenase Clostridium histolyticum"]],
    ["XICLO (Topical)", false, ["diclofenac"]],
    ["XIFAXAN (Oral Pill)", true, ["rifaximin"]],
    ["XIFYRM (Injectable)", false, ["meloxicam"]],
    ["XIGDUO XR (Oral Pill)", true, ["dapagliflozin", "metformin"]],
    ["XIIDRA (Ophthalmic)", false, ["lifitegrast"]],
    ["XIMINO XR (Oral Pill)", true, ["minocycline"]],
    ["XIPERE (Injectable)", false, ["triamcinolone"]],
    ["XOCOVA (Oral Pill)", true, ["ensitrelvir"]],
    ["XOCOVA 5-DAY (Pack)", true, ["ensitrelvir"]],
    ["XOFIGO (Injectable)", false, ["radium"]],
    ["XOFLUZA (Oral Pill)", true, ["baloxavir marboxil"]],
    ["XOFLUZA (Oral Suspension Granules)", true, ["baloxavir marboxil"]],
    ["XOFLUZA 40 MG DOSE PACK (2 X 20 MG TABLETS) (Pack)", true, ["baloxavir marboxil"]],
    ["XOFLUZA 80 MG DOSE PACK (2 X 40 MG TABLETS) (Pack)", true, ["baloxavir marboxil"]],
    ["XOLAIR (Injectable)", false, ["omalizumab"]],
    ["XOLEGEL (Topical)", false, ["ketoconazole"]],
    ["XOLIDO (Topical)", false, ["lidocaine"]],
    ["XOLREMDI (Oral Pill)", true, ["mavorixafor"]],
    ["XOPENEX (Inhalant)", false, ["levalbuterol"]],
    ["XOSPATA (Oral Pill)", true, ["gilteritinib"]],
    ["XOTEN (Topical)", false, ["menthol", "methyl salicylate"]],
    ["XOTEN-C (Topical)", false, ["capsaicin", "menthol", "methyl salicylate"]],
    ["XPHOZAH (Oral Pill)", true, ["tenapanor"]],
    ["XPOVIO (Oral Pill)", true, ["selinexor"]],
    ["XPOVIO 100 MG ONCE WEEKLY CARTON (Pack)", true, ["selinexor"]],
    ["XPOVIO 100 MG ONCE WEEKLY CARTON-50 MG TABLETS (Pack)", true, ["selinexor"]],
    ["XPOVIO 40 MG ONCE WEEKLY CARTON-10 MG TABLET (Pack)", true, ["selinexor"]],
    ["XPOVIO 40 MG ONCE WEEKLY CARTON-40 MG TABLET (Pack)", true, ["selinexor"]],
    ["XPOVIO 40 MG TWICE WEEKLY (80 MG TOTAL WEEKLY DOSE- 40 MG TABLETS) CARTON (Pack)", true, ["selinexor"]],
    ["XPOVIO 60 MG ONCE WEEKLY CARTON (Pack)", true, ["selinexor"]],
    ["XPOVIO 60 MG ONCE WEEKLY CARTON-60 MG TABLET (Pack)", true, ["selinexor"]],
    ["XPOVIO 60 MG TWICE WEEKLY (120 MG TOTAL WEEKLY DOSE) CARTON (Pack)", true, ["selinexor"]],
    ["XPOVIO 80 MG ONCE WEEKLY CARTON (Pack)", true, ["selinexor"]],
    ["XPOVIO 80 MG ONCE WEEKLY CARTON-40 MG TABLETS (Pack)", true, ["selinexor"]],
    ["XPOVIO 80 MG ONCE WEEKLY CARTON-80 MG TABLET (Pack)", true, ["selinexor"]],
    ["XPOVIO 80 MG TWICE WEEKLY (160 MG TOTAL WEEKLY DOSE) CARTON (Pack)", true, ["selinexor"]],
    ["XROMI (Oral Liquid)", true, ["hydroxyurea"]],
    ["XTAMPZA XR (Oral Pill)", true, ["oxycodone"]],
    ["XTANDI (Oral Pill)", true, ["enzalutamide"]],
    ["XTORO (Otic)", false, ["finafloxacin"]],
    ["XTRENBO (Injectable)", false, ["denosumab"]],
    ["XULANE (Transdermal)", false, ["ethinyl estradiol", "norelgestromin"]],
    ["XULTOPHY (Injectable)", false, ["insulin degludec", "liraglutide"]],
    ["XURIDEN (Oral Granules)", true, ["uridine triacetate"]],
    ["Xylitol (Oral Lozenge)", true, ["xylitol"]],
    ["XYLOCAINE (Injectable)", false, ["lidocaine"]],
    ["XYLOCAINE (Mucosal)", false, ["lidocaine"]],
    ["XYLOCAINE (Topical)", false, ["lidocaine"]],
    ["XYLOCAINE WITH EPINEPHrine (Injectable)", false, ["epinephrine", "lidocaine"]],
    ["Xylometazoline (Nasal)", false, ["xylometazoline"]],
    ["XYNTHA (Injectable)", false, ["factor VIII"]],
    ["XYOSTED (Injectable)", false, ["testosterone"]],
    ["XYREM (Oral Liquid)", true, ["oxybate"]],
    ["XYVONA (Oral Pill)", true, ["levorphanol"]],
    ["XYWAV (Oral Liquid)", true, ["oxybate"]],
    ["XYZAL (Oral Liquid)", true, ["levocetirizine"]],
    ["XYZAL (Oral Pill)", true, ["levocetirizine"]],
    ["YARGESA (Oral Pill)", true, ["miglustat"]],
    ["YARTEMLEA (Injectable)", false, ["narsoplimab"]],
    ["YASMIN 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["YAZ 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["YCANTH (Topical)", false, ["cantharidin"]],
    ["Yellow fever virus strain 17D-204 live antigen (Injectable)", false, ["yellow fever virus strain 17D-204 live antigen"]],
    ["Yellow hornet venom protein (Injectable)", false, ["yellow hornet venom protein"]],
    ["Yellow jacket venom protein (Injectable)", false, ["yellow jacket venom protein"]],
    ["YERVOY (Injectable)", false, ["ipilimumab"]],
    ["YESAFILI (Injectable)", false, ["aflibercept"]],
    ["YESCARTA (Injectable)", false, ["axicabtagene ciloleucel"]],
    ["YESINTEK (Injectable)", false, ["ustekinumab"]],
    ["YEZTUGO (Injectable)", false, ["lenacapavir"]],
    ["YEZTUGO (Oral Pill)", true, ["lenacapavir"]],
    ["YEZTUGO 927 MG KIT (Pack)", false, ["lenacapavir"]],
    ["YF-VAX (Injectable)", false, ["yellow fever virus strain 17D-204 live antigen"]],
    ["YIMMUGO (Injectable)", false, ["immunoglobulin G"]],
    ["YONDELIS (Injectable)", false, ["trabectedin"]],
    ["YONSA (Oral Pill)", true, ["abiraterone"]],
    ["YORVIPATH (Injectable)", false, ["teriparatide"]],
    ["YOSPRALA (Oral Pill)", true, ["aspirin", "omeprazole"]],
    ["YOUR CHOICE (Oral Pill)", true, ["levonorgestrel"]],
    ["YUFLYMA (Injectable)", false, ["adalimumab"]],
    ["YUFLYMA AUTO-INJECTOR 40 MG/0.4 ML STARTER PACK - PLAQUE PSORIASIS (Pack)", false, ["adalimumab"]],
    ["YUFLYMA AUTO-INJECTOR 40 MG/0.4 ML STARTER PACKAGE FOR CROHN'S DISEASE, PEDIATRIC CROHN'S DISEASE, ULCERATIVE COLITIS OR HIDRADENITIS SUPPURATIVA (Pack)", false, ["adalimumab"]],
    ["YUFLYMA AUTO-INJECTOR 80 MG/0.8 ML STARTER PACKAGE FOR CROHN'S DISEASE, ULCERATIVE COLITIS OR HIDRADENITIS SUPPURATIVA (Pack)", false, ["adalimumab"]],
    ["YUFLYMA PEDIATRIC CROHN'S DISEASE STARTER PACKAGE (3 COUNT) (Pack)", false, ["adalimumab"]],
    ["YUFLYMA PREFILLED SYRINGE 80 MG/0.8 ML AND 40 MG/0.4 ML STARTER PACKAGE FOR PEDIATRIC CROHN'S DISEASE (Pack)", false, ["adalimumab"]],
    ["YULITHIRA (Oral Pill)", true, ["everolimus"]],
    ["YUPELRI (Inhalant)", false, ["revefenacin"]],
    ["YUSIMRY (Injectable)", false, ["adalimumab"]],
    ["YUTIQ (Implant)", false, ["fluocinolone"]],
    ["YUTREPIA (Inhalant)", false, ["treprostinil"]],
    ["YUVAFEM (Vaginal)", false, ["estradiol"]],
    ["YUVEZZI (Ophthalmic)", false, ["brimonidine", "carbachol"]],
    ["YUVIWEL (Injectable)", false, ["navepegritide"]],
    ["Z-BUM (Topical)", false, ["zinc oxide"]],
    ["Z-GUARD (Paste)", false, ["petrolatum", "zinc oxide"]],
    ["Z-PAK (Pack)", true, ["azithromycin"]],
    ["Z-SLEEP (Oral Liquid)", true, ["diphenhydramine"]],
    ["ZADITOR (Ophthalmic)", false, ["ketotifen"]],
    ["ZAFEMY (Transdermal)", false, ["ethinyl estradiol", "norelgestromin"]],
    ["Zafirlukast (Oral Pill)", true, ["zafirlukast"]],
    ["Zaire ebolavirus envelope glycoprotein (Injectable)", false, ["Zaire ebolavirus envelope glycoprotein"]],
    ["Zaleplon (Oral Pill)", true, ["zaleplon"]],
    ["ZALTRAP (Injectable)", false, ["aflibercept"]],
    ["ZANAFLEX (Oral Pill)", true, ["tizanidine"]],
    ["Zanamivir (Inhalant)", false, ["zanamivir"]],
    ["Zanidatamab (Injectable)", false, ["zanidatamab"]],
    ["ZANOSAR (Injectable)", false, ["streptozocin"]],
    ["ZANTAC REFORMULATED AUG 2022 (Oral Pill)", true, ["famotidine"]],
    ["Zanubrutinib (Oral Pill)", true, ["zanubrutinib"]],
    ["ZANVASTRO (Injectable)", false, ["zilganersen"]],
    ["ZARAH (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["ZARONTIN (Oral Liquid)", true, ["ethosuximide"]],
    ["ZARONTIN (Oral Pill)", true, ["ethosuximide"]],
    ["ZARXIO (Injectable)", false, ["filgrastim"]],
    ["Zavegepant (Nasal)", false, ["zavegepant"]],
    ["ZAVESCA (Oral Pill)", true, ["miglustat"]],
    ["ZAVZPRET (Nasal)", false, ["zavegepant"]],
    ["ZAYNICH (Injectable)", false, ["cefepime", "zidebactam"]],
    ["ZCORT 7 DAY TAPER (Pack)", true, ["dexamethasone"]],
    ["ZEASORB (Topical)", false, ["miconazole"]],
    ["ZEBUTAL (Oral Pill)", true, ["acetaminophen", "butalbital", "caffeine"]],
    ["ZEGALOGUE (Injectable)", false, ["dasiglucagon"]],
    ["ZEGERID REFORMULATED AUG 2006 (Oral Pill)", true, ["omeprazole", "sodium bicarbonate"]],
    ["ZEGERID REFORMULATED AUG 2006 (Oral Suspension Powder)", true, ["omeprazole", "sodium bicarbonate"]],
    ["ZEGFROVY (Oral Pill)", true, ["sunvozertinib"]],
    ["ZEJULA (Oral Pill)", true, ["niraparib"]],
    ["ZELAPAR (Oral Disintegrating)", true, ["selegiline"]],
    ["ZELBORAF (Oral Pill)", true, ["vemurafenib"]],
    ["ZELNORM (Oral Pill)", true, ["tegaserod"]],
    ["ZELSUVMI (Topical)", false, ["berdazimer"]],
    ["ZELVYSIA (Oral Solution Powder)", true, ["sapropterin"]],
    ["ZEMAIRA (Injectable)", false, ["alpha 1-antitrypsin"]],
    ["ZEMBRACE (Injectable)", false, ["sumatriptan"]],
    ["ZEMDRI (Injectable)", false, ["plazomicin"]],
    ["ZEMPLAR (Injectable)", false, ["paricalcitol"]],
    ["ZEMPLAR (Oral Pill)", true, ["paricalcitol"]],
    ["ZENATANE (Oral Pill)", true, ["isotretinoin"]],
    ["ZENBEXUS (Oral Pill)", true, ["iberdomide"]],
    ["ZENCHENT FE 28 DAY (Pack)", false, ["ethinyl estradiol", "ferrous fumarate", "norethindrone"]],
    ["Zenocutuzumab (Injectable)", false, ["zenocutuzumab"]],
    ["ZENPEP (Oral Pill)", true, ["amylase", "lipase", "protease"]],
    ["ZENZEDI (Oral Pill)", true, ["dextroamphetamine"]],
    ["ZEPATIER (Oral Pill)", true, ["elbasvir", "grazoprevir"]],
    ["ZEPBOUND (Injectable)", false, ["tirzepatide"]],
    ["ZEPHREX-D (Oral Pill)", true, ["pseudoephedrine"]],
    ["ZEPOSIA (Oral Pill)", true, ["ozanimod"]],
    ["ZEPOSIA 28-DAY STARTER KIT (Pack)", true, ["ozanimod"]],
    ["ZEPOSIA 37-DAY STARTER KIT (Pack)", true, ["ozanimod"]],
    ["ZEPOSIA 7-DAY STARTER PACK (Pack)", true, ["ozanimod"]],
    ["ZEPZELCA (Injectable)", false, ["lurbinectedin"]],
    ["ZERBAXA (Injectable)", false, ["ceftolozane", "tazobactam"]],
    ["ZERVIATE (Ophthalmic)", false, ["cetirizine"]],
    ["ZESTORETIC (Oral Pill)", true, ["hydrochlorothiazide", "lisinopril"]],
    ["ZESTRIL (Oral Pill)", true, ["lisinopril"]],
    ["ZETIA (Oral Pill)", true, ["ezetimibe"]],
    ["ZETONNA (Nasal)", false, ["ciclesonide"]],
    ["ZEVASKYN (Topical)", false, ["prademagene zamikeracel"]],
    ["ZEVTERA (Injectable)", false, ["ceftobiprole"]],
    ["ZIAGEN (Oral Liquid)", true, ["abacavir"]],
    ["ZIAGEN (Oral Pill)", true, ["abacavir"]],
    ["ZIANA (Topical)", false, ["clindamycin", "tretinoin"]],
    ["ZICAM SINUS RELIEF (Nasal)", false, ["oxymetazoline"]],
    ["Ziconotide (Injectable)", false, ["ziconotide"]],
    ["Zidesamtinib (Oral Pill)", true, ["zidesamtinib"]],
    ["Zidovudine (Injectable)", false, ["zidovudine"]],
    ["Zidovudine (Oral Liquid)", true, ["zidovudine"]],
    ["Zidovudine (Oral Pill)", true, ["zidovudine"]],
    ["ZIEXTENZO (Injectable)", false, ["pegfilgrastim"]],
    ["Ziftomenib (Oral Pill)", true, ["ziftomenib"]],
    ["ZIIHERA (Injectable)", false, ["zanidatamab"]],
    ["ZIKS PAIN RELIEF (Topical)", false, ["capsaicin", "menthol", "methyl salicylate"]],
    ["ZILACTIN B (Oral Gel)", true, ["benzocaine"]],
    ["ZILACTIN COLD SORE (Oral Gel)", true, ["benzyl alcohol"]],
    ["ZILACTIN-L COLD SORE LIQUID (Topical)", false, ["benzyl alcohol"]],
    ["ZILBRYSQ (Injectable)", false, ["zilucoplan"]],
    ["Zileuton (Oral Pill)", true, ["zileuton"]],
    ["Zileuton XR (Oral Pill)", true, ["zileuton"]],
    ["Zilganersen (Injectable)", false, ["zilganersen"]],
    ["ZILRETTA (Injectable)", false, ["triamcinolone"]],
    ["Zilucoplan (Injectable)", false, ["zilucoplan"]],
    ["Zilurgisertib (Oral Pill)", true, ["zilurgisertib"]],
    ["ZILXI (Topical)", false, ["minocycline"]],
    ["ZIMHI (Injectable)", false, ["naloxone"]],
    ["Zinc acetate (Oral Pill)", true, ["zinc acetate"]],
    ["Zinc acetate (Topical)", false, ["zinc acetate"]],
    ["Zinc chloride (Injectable)", false, ["zinc chloride"]],
    ["Zinc citrate (Oral Pill)", true, ["zinc citrate"]],
    ["Zinc gluconate (Oral Lozenge)", true, ["zinc gluconate"]],
    ["Zinc gluconate (Oral Pill)", true, ["zinc gluconate"]],
    ["Zinc glycinate (Oral Pill)", true, ["zinc glycinate"]],
    ["Zinc oxide (Paste)", false, ["zinc oxide"]],
    ["Zinc oxide (Rectal)", false, ["zinc oxide"]],
    ["Zinc oxide (Topical)", false, ["zinc oxide"]],
    ["Zinc pyrithione (Shampoo)", false, ["zinc pyrithione"]],
    ["Zinc pyrithione (Soap)", false, ["zinc pyrithione"]],
    ["Zinc pyrithione (Topical)", false, ["zinc pyrithione"]],
    ["Zinc sulfate (Injectable)", false, ["zinc sulfate"]],
    ["Zinc sulfate (Oral Pill)", true, ["zinc sulfate"]],
    ["Zinc-DTPA (Injectable)", false, ["zinc-DTPA"]],
    ["ZINCON (Shampoo)", false, ["zinc pyrithione"]],
    ["ZINGO (Injectable)", false, ["lidocaine"]],
    ["ZINPLAVA (Injectable)", false, ["bezlotoxumab"]],
    ["ZIONODIL (Topical)", false, ["lidocaine"]],
    ["ZIOPTAN (Ophthalmic)", false, ["tafluprost"]],
    ["Ziprasidone (Injectable)", false, ["ziprasidone"]],
    ["Ziprasidone (Oral Pill)", true, ["ziprasidone"]],
    ["ZIPSOR (Oral Pill)", true, ["diclofenac"]],
    ["ZIRABEV (Injectable)", false, ["bevacizumab"]],
    ["ZIRGAN (Ophthalmic)", false, ["ganciclovir"]],
    ["ZITHRANOL (Shampoo)", false, ["anthralin"]],
    ["ZITHROMAX (Injectable)", false, ["azithromycin"]],
    ["ZITHROMAX (Oral Liquid)", true, ["azithromycin"]],
    ["ZITHROMAX (Oral Pill)", true, ["azithromycin"]],
    ["ZITHROMAX (Oral Suspension Powder)", true, ["azithromycin"]],
    ["ZITUVIMET (Oral Pill)", true, ["metformin", "sitagliptin"]],
    ["ZITUVIMET XR (Oral Pill)", true, ["metformin", "sitagliptin"]],
    ["ZITUVIO (Oral Pill)", true, ["sitagliptin"]],
    ["ZOCOR (Oral Pill)", true, ["simvastatin"]],
    ["ZOHYDRO XR (Oral Pill)", true, ["hydrocodone"]],
    ["ZOKINVY (Oral Pill)", true, ["lonafarnib"]],
    ["ZOLADEX (Implant)", false, ["goserelin"]],
    ["Zolbetuximab (Injectable)", false, ["zolbetuximab"]],
    ["Zoledronic acid (Injectable)", false, ["zoledronic acid"]],
    ["ZOLGENSMA (Injectable)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 10.1 - 10.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 10.6 - 11.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 11.1 - 11.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 11.6 - 12.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 12.1 - 12.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 12.6 - 13.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 13.1 - 13.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 13.6 - 14.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 14.1 - 14.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 14.6 - 15.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 15.1 - 15.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 15.6 - 16.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 16.1 - 16.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 16.6 - 17.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 17.1 - 17.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 17.6 - 18.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 18.1 - 18.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 18.6 - 19.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 19.1 - 19.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 19.6 - 20.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 2.6 - 3.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 20.1 - 20.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 20.6 - 21.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 3.1 - 3.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 3.6 - 4.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 4.1 - 4.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 4.6 - 5.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 5.1 - 5.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 5.6 - 6.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 6.1 - 6.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 6.6 - 7.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 7.1 - 7.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 7.6 - 8.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 8.1 - 8.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 8.6 - 9.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 9.1 - 9.5 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["ZOLGENSMA KIT 9.6 - 10.0 KG (Pack)", false, ["onasemnogene abeparvovec"]],
    ["Zoliflodacin (Oral Suspension Granules)", true, ["zoliflodacin"]],
    ["ZOLINZA (Oral Pill)", true, ["vorinostat"]],
    ["ZOLMitriptan (Nasal)", false, ["zolmitriptan"]],
    ["ZOLMitriptan (Oral Disintegrating)", true, ["zolmitriptan"]],
    ["ZOLMitriptan (Oral Pill)", true, ["zolmitriptan"]],
    ["ZOLOFT (Oral Liquid)", true, ["sertraline"]],
    ["ZOLOFT (Oral Pill)", true, ["sertraline"]],
    ["Zolpidem (Oral Pill)", true, ["zolpidem"]],
    ["Zolpidem (Sublingual)", false, ["zolpidem"]],
    ["Zolpidem XR (Oral Pill)", true, ["zolpidem"]],
    ["ZOLYMBUS (Ophthalmic)", false, ["bimatoprost"]],
    ["ZOMACTON (Injectable)", false, ["somatropin"]],
    ["ZOMIG (Nasal)", false, ["zolmitriptan"]],
    ["ZOMIG (Oral Pill)", true, ["zolmitriptan"]],
    ["ZONALON (Topical)", false, ["doxepin"]],
    ["ZONEGRAN (Oral Pill)", true, ["zonisamide"]],
    ["Zongertinib (Oral Pill)", true, ["zongertinib"]],
    ["ZONISADE (Oral Liquid)", true, ["zonisamide"]],
    ["Zonisamide (Oral Liquid)", true, ["zonisamide"]],
    ["Zonisamide (Oral Pill)", true, ["zonisamide"]],
    ["ZONTIVITY (Oral Pill)", true, ["vorapaxar"]],
    ["ZOOBY FLUORIDE FOAM (Oral Foam)", true, ["sodium fluoride"]],
    ["Zopapogene imadenovec (Injectable)", false, ["zopapogene imadenovec"]],
    ["ZORBTIVE (Injectable)", false, ["somatropin"]],
    ["ZORCAINE (Injectable)", false, ["articaine", "epinephrine"]],
    ["ZORTRESS (Oral Pill)", true, ["everolimus"]],
    ["ZORVOLEX (Oral Pill)", true, ["diclofenac"]],
    ["ZORYVE (Topical)", false, ["roflumilast"]],
    ["ZOSTRIX (Topical)", false, ["capsaicin"]],
    ["ZOSTRIX SPORTS (Topical)", false, ["capsaicin"]],
    ["ZOSYN (Injectable)", false, ["piperacillin", "tazobactam"]],
    ["ZOVIA 1/35E 28 DAY (Pack)", true, ["ethinyl estradiol", "ethynodiol"]],
    ["ZOVIRAX (Oral Liquid)", true, ["acyclovir"]],
    ["ZOVIRAX (Oral Pill)", true, ["acyclovir"]],
    ["ZOVIRAX (Topical)", false, ["acyclovir"]],
    ["ZTALMY (Oral Liquid)", true, ["ganaxolone"]],
    ["ZTLIDO (Topical)", false, ["lidocaine"]],
    ["ZUBSOLV (Sublingual)", false, ["buprenorphine", "naloxone"]],
    ["ZULRESSO (Injectable)", false, ["brexanolone"]],
    ["ZUMANDIMINE 28 DAY (Pack)", true, ["drospirenone", "ethinyl estradiol"]],
    ["ZUNVEYL (Oral Pill)", true, ["benzgalantamine"]],
    ["Zuranolone (Oral Pill)", true, ["zuranolone"]],
    ["ZURNAI (Injectable)", false, ["nalmefene"]],
    ["ZURZUVAE (Oral Pill)", true, ["zuranolone"]],
    ["ZUSDURI (Intravesical)", false, ["mitomycin"]],
    ["ZYBIC (Oral Liquid)", true, ["meloxicam"]],
    ["ZYCLARA (Topical)", false, ["imiquimod"]],
    ["ZYCUBO (Injectable)", false, ["copper histidinate"]],
    ["ZYDELIG (Oral Pill)", true, ["idelalisib"]],
    ["ZYFLO (Oral Pill)", true, ["zileuton"]],
    ["ZYKADIA (Oral Pill)", true, ["ceritinib"]],
    ["ZYLET (Ophthalmic)", false, ["loteprednol etabonate", "tobramycin"]],
    ["ZYLOPRIM (Oral Pill)", true, ["allopurinol"]],
    ["ZYMAXID (Ophthalmic)", false, ["gatifloxacin"]],
    ["ZYMFENTRA (Injectable)", false, ["infliximab"]],
    ["ZYNLONTA (Injectable)", false, ["loncastuximab tesirine"]],
    ["ZYNRELEF (Injectable)", false, ["bupivacaine", "meloxicam"]],
    ["ZYNTEGLO (Injectable)", false, ["betibeglogene autotemcel"]],
    ["ZYNYZ (Injectable)", false, ["retifanlimab"]],
    ["ZYPITAMAG (Oral Pill)", true, ["pitavastatin"]],
    ["ZyPREXA (Injectable)", false, ["olanzapine"]],
    ["ZyPREXA (Oral Disintegrating)", true, ["olanzapine"]],
    ["ZyPREXA (Oral Pill)", true, ["olanzapine"]],
    ["ZyrTEC (Chewable)", true, ["cetirizine"]],
    ["ZyrTEC (Oral Disintegrating)", true, ["cetirizine"]],
    ["ZyrTEC (Oral Liquid)", true, ["cetirizine"]],
    ["ZyrTEC (Oral Pill)", true, ["cetirizine"]],
    ["ZyrTEC-D XR (Oral Pill)", true, ["cetirizine", "pseudoephedrine"]],
    ["ZYTIGA (Oral Pill)", true, ["abiraterone"]],
    ["ZYVOX (Injectable)", false, ["linezolid"]],
    ["ZYVOX (Oral Liquid)", true, ["linezolid"]],
    ["ZYVOX (Oral Pill)", true, ["linezolid"]],
    ["ZZZQUIL (Oral Liquid)", true, ["diphenhydramine"]],
    ["ZZZQUIL (Oral Pill)", true, ["diphenhydramine"]]
  ];

  // dosewell-interactions/rules.js
  var labelId = {
    simvastatin: "8f55d5de-5a4f-4a39-8c84-c53976dd6af9",
    nimodipine: "e660fa26-b5c4-4d6d-8887-9e22b6666a10",
    atorvastatin: "e91c673d-c26c-4ff1-90d2-2b9d47a8d771",
    lisinopril: "838c2d78-d2d8-4981-9ec9-e50ef9e1a5d8",
    apixaban: "7be1f4c1-bb2f-4ded-ae9a-515d2a22f93e",
    rivaroxaban: "10db92f9-2300-4a80-836b-673e1ae91610",
    warfarin: "19a69a72-ac5d-45d5-a94d-a5aaecbe4730",
    clopidogrel: "de8b0b67-eb25-4684-83b5-7ad785314227"
  };
  var aspirinSource = "https://medlineplus.gov/druginfo/meds/a682878.html";
  var labelUrl = (drug) => "https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=" + labelId[drug];
  var brandNames = {
    simvastatin: ["Zocor"],
    "nirmatrelvir/ritonavir": ["Paxlovid"],
    ketoconazole: [],
    cyclosporine: [],
    danazol: [],
    erythromycin: [],
    nimodipine: ["Nymalize", "Nimotop"],
    atorvastatin: ["Lipitor", "Atorvastatin calcium"],
    lisinopril: ["Zestril", "Prinivil"],
    amlodipine: ["Norvasc"],
    metoprolol: ["Lopressor", "Toprol XL", "Metoprolol succinate", "Metoprolol tartrate"],
    losartan: ["Cozaar"],
    hydrochlorothiazide: ["Microzide", "HCTZ"],
    apixaban: ["Eliquis"],
    rivaroxaban: ["Xarelto"],
    warfarin: ["Coumadin", "Jantoven", "Warfarin sodium"],
    clopidogrel: ["Plavix", "Clopidogrel bisulfate"],
    aspirin: ["Acetylsalicylic acid", "ASA", "Ecotrin", "Bayer Aspirin", "Low dose aspirin", "Aspirin low dose"],
    ibuprofen: ["Advil", "Motrin"],
    naproxen: ["Aleve", "Naprosyn", "Naproxen sodium"],
    omeprazole: ["Prilosec", "Prilosec OTC"],
    esomeprazole: ["Nexium"],
    clarithromycin: ["Biaxin"],
    itraconazole: ["Sporanox"],
    ritonavir: ["Norvir"],
    carbamazepine: ["Tegretol", "Carbatrol"],
    phenytoin: ["Dilantin"],
    rifampin: ["Rifadin", "Rifampicin"],
    phenobarbital: [],
    "st johns wort": ["St. John\u2019s wort", "Saint John's wort"],
    gemfibrozil: ["Lopid"],
    "sacubitril/valsartan": ["Entresto", "sacubitril valsartan", "valsartan/sacubitril"],
    spironolactone: ["Aldactone"],
    amiloride: ["Midamor"],
    triamterene: ["Dyrenium"],
    "potassium chloride": ["Klor Con", "K Tab"],
    "potassium gluconate": [],
    lithium: ["Lithobid", "Lithium carbonate"],
    amiodarone: ["Pacerone", "Cordarone"],
    metronidazole: ["Flagyl"],
    fluconazole: ["Diflucan"],
    "trimethoprim/sulfamethoxazole": ["Bactrim", "Bactrim DS", "Septra", "Co-trimoxazole", "Sulfamethoxazole/trimethoprim", "TMP-SMX"],
    sertraline: ["Zoloft"],
    fluoxetine: ["Prozac"],
    venlafaxine: ["Effexor"],
    duloxetine: ["Cymbalta"]
  };
  function clean(s) {
    return s.toLowerCase().normalize("NFKD").replace(/[’'\.]/g, "").replace(/[-/(),]/g, " ").replace(/\s+/g, " ").trim();
  }
  var aliases = /* @__PURE__ */ new Map();
  for (const [drug, brands] of Object.entries(brandNames)) {
    for (const n of [drug, ...brands]) aliases.set(clean(n), drug);
  }
  var suggestions = Object.entries(brandNames).flatMap(([generic, brands]) => [generic, ...brands.slice(0, 1)]).sort();
  function ingredient(name) {
    let n = clean(name);
    if (aliases.has(n)) return aliases.get(n);
    n = n.replace(/\s+\d+(?:\.\d+)?\s*(?:mg|mcg|g)(?:\s+(?:oral\s+)?(?:tablet|capsule)s?)?$/i, "");
    if (aliases.has(n)) return aliases.get(n);
    const parens = name.match(/^([^()]+)\s*\(([^()]+)\)$/);
    if (parens) {
      const one = aliases.get(clean(parens[1])), two = aliases.get(clean(parens[2]));
      if (one && one === two) return one;
    }
    return null;
  }
  var rules = /* @__PURE__ */ new Map();
  function set(drug, others, level, reason, source = labelUrl(drug)) {
    for (const other of others) rules.set([drug, other].sort().join("|"), { level, reason, source });
  }
  var inducers = ["carbamazepine", "phenytoin", "rifampin", "st johns wort"];
  set("nimodipine", ["clarithromycin", "itraconazole", "ritonavir"], "avoid", "These medicines can raise nimodipine levels and cause a serious drop in blood pressure. The label generally advises avoiding this combination.");
  set("nimodipine", [...inducers, "phenobarbital"], "avoid", "This combination can lower nimodipine levels and reduce its effect. The label generally advises avoiding it.");
  set("nimodipine", ["lisinopril", "amlodipine", "metoprolol", "losartan", "hydrochlorothiazide"], "review", "Taking these together can lower blood pressure further. Ask your care team whether additional blood pressure checks are needed.");
  set("nimodipine", ["fluconazole", "fluoxetine", "amiodarone"], "review", "Nimodipine levels may rise and lower your blood pressure. Ask your prescriber about blood pressure checks.");
  set("atorvastatin", ["gemfibrozil"], "avoid", "This combination raises the risk of serious muscle injury. The atorvastatin label advises against using them together.");
  set("atorvastatin", ["clarithromycin", "itraconazole"], "review", "These medicines can raise atorvastatin levels and the risk of muscle injury. Ask your prescriber to review your dose.");
  set("lisinopril", ["sacubitril/valsartan"], "avoid", "Using these together can cause dangerous swelling. The label requires at least 36 hours between treatments when switching. Contact your prescriber promptly to confirm the plan.");
  set("lisinopril", ["spironolactone", "amiloride", "triamterene", "potassium chloride", "potassium gluconate"], "review", "Potassium levels can become too high. Ask your care team whether you need a potassium blood test.");
  set("lisinopril", ["lithium"], "review", "Lisinopril can increase the risk of lithium toxicity. Your prescriber may need to check your lithium level.");
  for (const drug of ["apixaban", "rivaroxaban"]) {
    set(drug, inducers, "avoid", "This combination can lower the blood thinner level and reduce protection against clots. The label advises avoiding concurrent use.");
    set(drug, ["aspirin", "clopidogrel", "ibuprofen", "naproxen", "warfarin"], "review", "Bleeding risk can increase when these are used together. Ask your pharmacist to confirm the plan, including any over the counter use.");
  }
  set("apixaban", ["rivaroxaban"], "review", "Both medicines reduce clotting. Taking them together can increase bleeding risk. Contact your prescriber to confirm whether this is a planned switch.");
  set("clopidogrel", ["aspirin"], "review", "Both reduce platelet activity and can increase bleeding. They are sometimes prescribed together. Confirm the planned duration with your prescriber before making a change.");
  set("clopidogrel", ["omeprazole", "esomeprazole"], "avoid", "This acid reducer can make clopidogrel less effective at preventing clots. The label advises avoiding the combination.");
  set("clopidogrel", ["ibuprofen", "naproxen", "warfarin", "sertraline", "fluoxetine", "venlafaxine", "duloxetine"], "review", "This combination can increase bleeding risk. Ask your pharmacist whether you need monitoring or a change in your plan.");
  set("warfarin", ["amiodarone", "metronidazole", "trimethoprim/sulfamethoxazole", "fluconazole"], "review", "This medicine can increase the effect of warfarin. Contact your anticoagulation team about INR checks when starting or stopping it.");
  set("warfarin", ["aspirin", "clopidogrel", "ibuprofen", "naproxen"], "review", "This combination can increase bleeding risk. Ask your pharmacist or anticoagulation team to review it.");
  set("aspirin", ["ibuprofen"], "review", "Ibuprofen can interfere with aspirin taken for stroke or heart protection. Ask your pharmacist before adding it.", aspirinSource);
  set("apixaban", ["ketoconazole", "itraconazole", "ritonavir"], "review", "These medicines can increase apixaban exposure and bleeding risk. The label gives different guidance for different apixaban doses. Ask the prescriber to review your exact dose.");
  set("rivaroxaban", ["ketoconazole", "ritonavir"], "avoid", "These medicines can raise rivaroxaban exposure and bleeding risk. The rivaroxaban label advises avoiding this combination.");
  for (const drug of ["warfarin", "apixaban", "rivaroxaban"]) {
    set(drug, ["sertraline", "fluoxetine", "venlafaxine", "duloxetine"], "review", "These medicines can increase bleeding risk when taken together. Ask your pharmacist what symptoms to watch for.");
  }
  set("simvastatin", ["clarithromycin", "erythromycin", "ketoconazole", "itraconazole", "ritonavir", "cyclosporine", "danazol", "gemfibrozil"], "avoid", "The simvastatin label lists this combination as contraindicated because it raises the risk of serious muscle injury. Ask your prescriber to review the combination.");
  var combos = {
    "nirmatrelvir/ritonavir": ["nirmatrelvir", "ritonavir"],
    "sacubitril/valsartan": ["sacubitril", "valsartan"],
    "trimethoprim/sulfamethoxazole": ["sulfamethoxazole", "trimethoprim"]
  };
  var namedProducts = /* @__PURE__ */ new Map();
  var bareProducts = /* @__PURE__ */ new Map();
  var catalog = [];
  for (const [display, oral, components] of products) {
    const full = display.trim().toLowerCase();
    const base = display.replace(/\s*\([^()]*\)\s*$/, "").trim().toLowerCase();
    const product = { display, oral, components, search: clean(display + " " + components.join(" ")) };
    catalog.push(product);
    namedProducts.set(full, product);
    if (!bareProducts.has(base)) bareProducts.set(base, []);
    bareProducts.get(base).push(product);
  }
  var catalogSize = products.length;
  var pairRuleCount = rules.size;
  function searchProducts(query, limit = 8) {
    const key3 = clean(query);
    if (!key3) return [];
    const terms = key3.split(" "), prefix = [], matches = [];
    for (const product of catalog) {
      if (product.display.toLowerCase().startsWith(query.trim().toLowerCase())) {
        prefix.push(product);
        if (prefix.length === limit) break;
      } else if (matches.length < limit && terms.every((term) => product.search.includes(term))) matches.push(product);
    }
    return [...prefix, ...matches].slice(0, limit);
  }
  function identify(name) {
    const full = name.trim().toLowerCase();
    const exact = namedProducts.get(full);
    if (exact) return { components: exact.components, route: exact.oral ? "oral" : "other", matched: true };
    const simple = full.replace(/\s+\d+(?:\.\d+)?\s*(?:mg|mcg|g)(?:\s+(?:oral\s+)?(?:tablet|capsule)s?)?$/, "");
    const variants = bareProducts.get(simple);
    if (variants?.length && variants.every((p) => p.components.join("|") === variants[0].components.join("|"))) {
      return { components: variants[0].components, route: variants.some((p) => p.oral) ? "unspecified" : "other", matched: true };
    }
    if (variants?.length) return { components: [], route: "unknown", matched: false };
    const known = ingredient(name);
    if (known) return { components: combos[known] || [known], route: "unspecified", matched: true };
    return { components: [], route: "unknown", matched: false };
  }
  function ruleIngredients(profile) {
    if (profile.route === "other") return [];
    const list = profile.components.map((c) => aliases.get(clean(c)) || c);
    for (const [pair, parts] of Object.entries(combos)) {
      if (parts.every((p) => list.includes(p))) list.push(pair);
    }
    return list;
  }
  var rank = { avoid: 0, duplicate: 1, review: 2, unassessed: 3 };
  var warningLabel = { avoid: "Label advises avoidance", review: "Pharmacist review", duplicate: "Possible duplicate", unassessed: "Unassessed" };
  function compare(meds) {
    const profiles = meds.map((m) => identify(m.name));
    const ingredients = profiles.map(ruleIngredients);
    const result = [];
    for (let i = 0; i < meds.length; i++) for (let j = i + 1; j < meds.length; j++) {
      const a = meds[i], b = meds[j], details = [];
      const shared = profiles[i].components.filter((c) => profiles[j].components.includes(c));
      if (shared.length || clean(a.name) === clean(b.name)) {
        const reason = shared.length ? "Both entries contain " + shared.join(", ") + "." : "The two entries have the same name.";
        details.push({ level: "duplicate", reason: reason + " Ask your pharmacist to confirm the intended products and doses." });
      }
      const seen = /* @__PURE__ */ new Set(), covered = /* @__PURE__ */ new Set();
      for (const x of ingredients[i]) for (const y of ingredients[j]) {
        const key3 = [x, y].sort().join("|"), match = rules.get(key3);
        if (match && !seen.has(key3)) {
          seen.add(key3);
          for (const left of combos[x] || [x]) for (const right of combos[y] || [y]) covered.add(left + "|" + right);
          details.push({ ...match, ingredients: [x, y] });
        }
      }
      details.sort((x, y) => rank[x.level] - rank[y.level]);
      const hasGaps = !profiles[i].matched || !profiles[j].matched || profiles[i].route === "other" || profiles[j].route === "other" || profiles[i].components.some((left) => profiles[j].components.some((right) => left !== right && !covered.has((aliases.get(clean(left)) || left) + "|" + (aliases.get(clean(right)) || right))));
      result.push({ a, b, details, hasGaps, ...details[0] || { level: "unassessed", reason: "No matching rule in Dosewell for this pair." } });
    }
    return result.sort((x, y) => rank[x.level] - rank[y.level]);
  }
  var notes = {
    nimodipine: [
      ["food", "Grapefruit", "Grapefruit and grapefruit juice can raise nimodipine levels. Its label recommends avoiding them."],
      ["condition", "Cirrhosis", "Cirrhosis can raise nimodipine levels. Your prescriber may need to adjust the dose and monitor blood pressure and pulse."]
    ],
    atorvastatin: [
      ["food", "Grapefruit juice", "Large amounts of grapefruit juice can raise atorvastatin levels. The label advises avoiding more than 1.2 liters per day."],
      ["condition", "Acute liver failure or decompensated cirrhosis", "The label lists these conditions as contraindications. If either applies to you, contact your prescriber to review your medication list."]
    ],
    warfarin: [["food", "Vitamin K in food", "A sudden change in vitamin K intake can change how warfarin works. Keep your usual intake of vitamin K foods consistent and discuss major diet changes with your anticoagulation team."]],
    lisinopril: [
      ["food", "Potassium salt substitutes", "Potassium-based salt substitutes can increase blood potassium. Ask your prescriber before using one."],
      ["condition", "Previous angioedema with an ACE inhibitor", "If an ACE inhibitor previously caused swelling of your lips, tongue, or throat, tell your prescriber. Lisinopril is contraindicated with that history."]
    ],
    apixaban: [["condition", "Active abnormal bleeding", "Active pathological bleeding is a contraindication. A past bleed is a different situation. Have your care team review your bleeding history and treatment plan."]],
    clopidogrel: [["condition", "Active abnormal bleeding", "The label lists active bleeding, including a bleeding ulcer or an active brain hemorrhage, as a contraindication. A clinician should assess whether this applies now."]],
    rivaroxaban: [
      ["food", "Food with 15 mg or 20 mg tablets", "These tablet strengths need food for adequate absorption. Follow the instructions on your own prescription."],
      ["condition", "Active abnormal bleeding", "The label lists active pathological bleeding as a contraindication. A clinician should assess current bleeding and your treatment plan."]
    ]
  };
  function labelNotes(meds) {
    const found = /* @__PURE__ */ new Map();
    for (const med of meds) for (const drug of ruleIngredients(identify(med.name))) {
      if (found.has(drug) || !notes[drug]) continue;
      found.set(drug, notes[drug].map(([group, title, reason]) => ({ drug, group, title, reason, source: labelUrl(drug) })));
    }
    return [...found.values()].flat();
  }

  // dosewell-interactions/schedule.js
  var medicationTitle = (med) => med.strength ? med.name + " " + med.strength : med.name;
  var pad = (value) => String(value).padStart(2, "0");
  var dayKey = (date) => [date.getFullYear(), pad(date.getMonth() + 1), pad(date.getDate())].join("-");
  var localDay = (key3) => /* @__PURE__ */ new Date(key3 + "T12:00:00");
  function shiftDay(day2, offset) {
    const d = localDay(day2);
    d.setDate(d.getDate() + offset);
    return dayKey(d);
  }
  var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  function timeLabel(time) {
    const [h2, m] = time.split(":").map(Number);
    return (h2 % 12 || 12) + ":" + pad(m) + " " + (h2 < 12 ? "AM" : "PM");
  }
  function clockTime(date) {
    return pad(date.getHours()) + ":" + pad(date.getMinutes());
  }
  function hoursLabel(value) {
    return value + " hour" + (Number(value) === 1 ? "" : "s");
  }
  function doseTimeLabel(row) {
    return row.med.mode === "interval" ? row.when.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" }) : timeLabel(row.time);
  }
  function scheduleLabel(med) {
    if (med.mode === "list") return "List only";
    if (med.mode === "interval") return "Every " + hoursLabel(med.intervalHours) + " \xB7 first dose " + new Date(med.anchorAt).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" });
    return (med.days.length === 7 ? "Daily" : med.days.map((d) => dayNames[d]).join(", ")) + " \xB7 " + med.times.map(timeLabel).join(", ");
  }
  function nextInterval(med, from) {
    const step = med.intervalHours * 36e5;
    if (!Number.isSafeInteger(step) || step < 36e5 || !Number.isFinite(med.anchorAt)) return null;
    const n = Math.max(0, Math.ceil((from - med.anchorAt) / step));
    const stamp = med.anchorAt + n * step;
    if (med.untilAt != null && stamp >= med.untilAt) return null;
    const when = new Date(stamp);
    if (!Number.isFinite(when.getTime())) return null;
    return { med, when, day: dayKey(when), time: clockTime(when), key: med.id + "|interval|" + stamp };
  }
  function applies(med, day2) {
    return med.mode !== "list" && day2 >= med.start && (!med.end || day2 <= med.end) && med.days.includes(localDay(day2).getDay());
  }
  function fixedDose(med, day2, time) {
    return { med, day: day2, time, when: /* @__PURE__ */ new Date(day2 + "T" + time + ":00"), key: med.id + "|" + day2 + "|" + time };
  }
  function dosesFor(meds, day2) {
    const start = /* @__PURE__ */ new Date(day2 + "T00:00:00"), end = /* @__PURE__ */ new Date(shiftDay(day2, 1) + "T00:00:00");
    const rows = [];
    for (const med of meds) {
      if (med.mode === "interval") {
        for (let row = nextInterval(med, start); row && row.when < end; row = nextInterval(med, row.when.getTime() + 1)) rows.push(row);
      } else if (applies(med, day2)) {
        for (const time of med.times) rows.push(fixedDose(med, day2, time));
      }
    }
    return rows.sort((a, b) => a.when - b.when || a.med.name.localeCompare(b.med.name));
  }
  function firstNext(med, time, now) {
    if (med.mode === "interval") return nextInterval(med, now);
    const start = dayKey(now) > med.start ? dayKey(now) : med.start;
    for (let i = 0; i <= 7; i++) {
      const day2 = shiftDay(start, i);
      if (!applies(med, day2)) continue;
      const row = fixedDose(med, day2, time);
      if (row.when >= now) return row;
    }
    return null;
  }
  var advanceMinutes = (med, settings) => med.advance === null ? settings.advance : med.advance;
  function dueEvents(state2, now, since) {
    const today = dayKey(now), following = shiftDay(today, 1);
    const result = [];
    const warningHorizon = dayKey(new Date(now.getTime() + 864e5));
    const last = warningHorizon > following ? warningHorizon : following;
    for (let day2 = shiftDay(today, -1); day2 <= last; day2 = shiftDay(day2, 1)) {
      for (const dose of dosesFor(state2.meds, day2)) {
        if (state2.taken[dose.key] || state2.history?.[dose.key]?.status === "skipped") continue;
        const advance = advanceMinutes(dose.med, state2.settings);
        const snooze = state2.snoozes?.[dose.key];
        const events = snooze ? [{ kind: "snooze", at: snooze }] : [{ kind: "due", at: dose.when.getTime() }];
        if (!snooze && advance > 0) events.push({ kind: "advance", at: dose.when.getTime() - advance * 6e4 });
        for (const e of events) {
          const id = dose.key + "|" + e.kind + (e.kind === "snooze" ? "|" + e.at : "");
          if (state2.fired[id] || e.at <= since || e.at > now.getTime()) continue;
          if (e.kind === "advance" && dose.when <= now) continue;
          result.push({ ...dose, ...e, id });
        }
      }
    }
    return result.sort((a, b) => a.at - b.at);
  }
  function escCalendar(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
  }
  function fold(line) {
    const enc = new TextEncoder();
    let out = "", length = 0;
    for (const char of line) {
      const n = enc.encode(char).length;
      if (length + n > 75) {
        out += "\r\n ";
        length = 1;
      }
      out += char;
      length += n;
    }
    return out;
  }
  var utcStamp = (date) => new Date(date).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  function calendarSeries(med, now) {
    if (med.mode === "interval") {
      const first = nextInterval(med, now);
      if (!first) return [];
      let divisor = 24;
      while (24 % divisor !== 0 || med.intervalHours % divisor !== 0) divisor--;
      const phases = 24 / divisor, days2 = med.intervalHours / divisor, step = med.intervalHours * 36e5;
      let rule2 = "FREQ=DAILY;INTERVAL=" + days2;
      if (med.untilAt != null) rule2 += ";UNTIL=" + utcStamp(med.untilAt - 1e3);
      const series = [];
      for (let i = 0; i < phases; i++) {
        const at = first.when.getTime() + i * step;
        if (med.untilAt != null && at >= med.untilAt) break;
        const phase = (at - med.anchorAt) / step % phases;
        series.push({ uid: med.id + "-interval-" + med.anchorAt + "-" + med.intervalHours + "-" + phase, start: utcStamp(at), rule: rule2 });
      }
      return series;
    }
    const days = med.days.map((d) => ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][d]).join(",");
    let rule = med.days.length === 7 ? "FREQ=DAILY" : "FREQ=WEEKLY;BYDAY=" + days;
    if (med.end) rule += ";UNTIL=" + med.end.replaceAll("-", "") + "T235959";
    return med.times.flatMap((time) => {
      const next = firstNext(med, time, now);
      return next ? [{ uid: med.id + "-" + time.replace(":", ""), start: next.day.replaceAll("-", "") + "T" + time.replace(":", "") + "00", rule }] : [];
    });
  }
  function calendarDocument(events, count) {
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Dosewell//Medication Schedule//EN", "CALSCALE:GREGORIAN", "X-WR-CALNAME:Dosewell medications", ...events, "END:VCALENDAR"];
    return { count, text: lines.map(fold).join("\r\n") + "\r\n" };
  }
  function displayAlarm(minutes, description) {
    return ["BEGIN:VALARM", "ACTION:DISPLAY", "TRIGGER:" + (minutes ? "-PT" + minutes + "M" : "PT0M"), "DESCRIPTION:" + escCalendar(description), "END:VALARM"];
  }
  function calendarFile(state2, now = /* @__PURE__ */ new Date()) {
    const lines = [];
    let count = 0;
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      for (const { uid, start, rule } of calendarSeries(med, now)) {
        count++;
        const summary = medicationTitle(med) + " \xB7 " + med.dose;
        lines.push("BEGIN:VEVENT", "UID:" + uid + "@dosewell", "DTSTAMP:" + utcStamp(now), "DTSTART:" + start, "DURATION:PT1M", "RRULE:" + rule, "SUMMARY:" + escCalendar(summary), "DESCRIPTION:Scheduled dose. Follow your current prescription.", "CLASS:PRIVATE", "TRANSP:TRANSPARENT");
        lines.push(...displayAlarm(0, "Scheduled dose. " + summary));
        const lead = advanceMinutes(med, state2.settings);
        if (lead > 0) lines.push(...displayAlarm(lead, "Upcoming dose in " + lead + " minutes. " + summary));
        lines.push("END:VEVENT");
      }
    }
    return calendarDocument(lines, count);
  }
  function calendarTestFile(now = /* @__PURE__ */ new Date()) {
    const at = new Date(Math.ceil(now.getTime() / 6e4) * 6e4 + 10 * 6e4);
    const stamp = utcStamp(at);
    const event = [
      "BEGIN:VEVENT",
      "UID:test-" + stamp + "@dosewell",
      "DTSTAMP:" + utcStamp(now),
      "DTSTART:" + stamp,
      "DURATION:PT1M",
      "SUMMARY:Dosewell calendar test",
      "DESCRIPTION:This is a test of your Calendar alerts.",
      "TRANSP:TRANSPARENT",
      ...displayAlarm(0, "Dosewell calendar test"),
      ...displayAlarm(2, "Dosewell calendar test in 2 minutes"),
      "END:VEVENT"
    ];
    return { ...calendarDocument(event, 1), at, warningAt: new Date(at.getTime() - 12e4) };
  }

  // dosewell-interactions/reminder-transfer.js
  var calendarName = "Dosewell-medication-schedule.ics";
  var maxLinkLength = 4200;
  var invalid = () => new Error("This reminder link is incomplete or invalid. Ask the sender for a new link or the calendar file.");
  var encode = (bytes) => btoa(Array.from(bytes, (b) => String.fromCharCode(b)).join("")).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  var validText = (v, n) => typeof v === "string" && v.trim().length > 0 && v.length <= n && !/[\u0000-\u001f\u007f]/.test(v);
  var validTime = (v) => typeof v === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  function validDate(v) {
    return typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) && dayKey(/* @__PURE__ */ new Date(v + "T12:00:00")) === v;
  }
  function transferLink(state2, base, now = /* @__PURE__ */ new Date()) {
    const rows = [];
    for (const m of state2.meds) {
      if (m.mode === "list" || !m.times.some((t) => firstNext(m, t, now))) continue;
      const timing = m.mode === "interval" ? ["h", m.intervalHours, m.anchorAt, m.untilAt ?? null] : ["d", m.start, m.end || "", m.days.reduce((bits, d) => bits | 1 << d, 0), m.times];
      rows.push([m.id, medicationTitle(m), m.dose, advanceMinutes(m, state2.settings), timing]);
    }
    if (!rows.length || rows.length > 100) return null;
    const raw = JSON.stringify([1, rows]);
    if (raw.length > maxLinkLength) return null;
    const url = new URL("./receive.html", base);
    url.hash = encode(new TextEncoder().encode(raw));
    if (url.href.length > maxLinkLength) return null;
    try {
      readTransfer(url.hash);
    } catch {
      return null;
    }
    return url.href;
  }
  function readTransfer(hash) {
    const value = hash.replace(/^#/, "");
    if (!value || value.length > maxLinkLength || !/^[A-Za-z0-9_-]+$/.test(value)) throw invalid();
    let packet;
    try {
      const ascii = atob(value.replace(/-/g, "+").replace(/_/g, "/"));
      packet = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(ascii, (c) => c.charCodeAt(0))));
    } catch {
      throw invalid();
    }
    if (!Array.isArray(packet) || packet[0] !== 1 || !Array.isArray(packet[1]) || !packet[1].length || packet[1].length > 100) throw invalid();
    const ids = /* @__PURE__ */ new Set(), meds = [];
    for (const row of packet[1]) {
      if (!Array.isArray(row) || row.length !== 5) throw invalid();
      const [id, name, dose, advance, spec] = row;
      if (typeof id !== "string" || !/^[a-z0-9_-]{1,96}$/i.test(id) || ids.has(id) || !validText(name, 250) || !validText(dose, 140) || !Number.isInteger(advance) || advance < 0 || advance > 1440 || !Array.isArray(spec)) throw invalid();
      ids.add(id);
      const med = { id, name, dose, advance };
      if (spec[0] === "h" && spec.length === 4) {
        const [, hours, anchorAt, untilAt] = spec;
        const validStamp = (n) => Number.isSafeInteger(n) && n >= -22089888e5 && n <= 2534022144e5;
        if (!Number.isInteger(hours) || hours < 1 || hours > 72 || hours > 24 && ![36, 48, 72].includes(hours) || !validStamp(anchorAt) || untilAt !== null && (!validStamp(untilAt) || untilAt <= anchorAt)) throw invalid();
        const anchor = new Date(anchorAt);
        Object.assign(med, { mode: "interval", intervalHours: hours, anchorAt, untilAt, start: dayKey(anchor), end: untilAt ? dayKey(new Date(untilAt - 1)) : "", times: [clockTime(anchor)], days: [0, 1, 2, 3, 4, 5, 6] });
      } else if (spec[0] === "d" && spec.length === 5) {
        const [, start, end, mask, times] = spec;
        if (!validDate(start) || end !== "" && (!validDate(end) || end < start) || !Number.isInteger(mask) || mask < 1 || mask > 127 || !Array.isArray(times) || !times.length || times.length > 1440 || !times.every(validTime) || new Set(times).size !== times.length) throw invalid();
        Object.assign(med, { mode: mask === 127 ? "daily" : "weekly", start, end, days: [0, 1, 2, 3, 4, 5, 6].filter((d) => mask & 1 << d), times });
      } else throw invalid();
      meds.push(med);
    }
    return { meds, settings: { advance: 0 } };
  }
  function saveCalendarFile(state2, now = /* @__PURE__ */ new Date()) {
    const cal = calendarFile(state2, now);
    return downloadCalendarFile(cal);
  }
  function downloadCalendarFile(cal, name = calendarName) {
    if (!cal.count) return false;
    const address = URL.createObjectURL(new Blob([cal.text], { type: "text/calendar;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = address;
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(address), 6e4);
    return true;
  }
  function shareableCalendar(cal, nav2 = navigator, name = calendarName) {
    if (typeof File !== "function" || typeof nav2.share !== "function" || typeof nav2.canShare !== "function") return null;
    const file = new File([cal.text], name, { type: "text/calendar" });
    try {
      return nav2.canShare({ files: [file] }) ? file : null;
    } catch {
      return null;
    }
  }
  function transferChoice(cal, url, nav2 = navigator) {
    const file = shareableCalendar(cal, nav2);
    if (file) return { kind: "file", data: { files: [file] } };
    if (url && typeof nav2.share === "function") {
      const data = { url, title: "Dosewell reminder file" };
      try {
        if (!nav2.canShare || nav2.canShare(data)) return { kind: "link", data };
      } catch {
      }
    }
    return { kind: "manual" };
  }

  // dosewell-interactions/icons.js
  var paths = {
    message: '<path d="M4 4.5h16a1.5 1.5 0 0 1 1.5 1.5v10a1.5 1.5 0 0 1-1.5 1.5H9L3 21V6A1.5 1.5 0 0 1 4.5 4.5Z"/><path d="M7 9h10M7 13h6"/>',
    history: '<path d="M3 12a9 9 0 1 0 2.7-6.4L3 8m0-5v5h5"/><path d="M12 7v5l3 2"/>',
    sunset: '<path d="M2 16h20M4 20h16M7 15a5 5 0 0 1 10 0M12 2v7m-3-3 3 3 3-3M3 9l2 2m14 0 2-2"/>',
    print: '<path d="M7 8V3h10v5M7 16H3V9h18v7h-4"/><path d="M7 13h10v8H7zM17 11h1"/>',
    camera: '<path d="M8 6l1.5-2h5L16 6h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z"/><circle cx="12" cy="13" r="3.5"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="m4 17 5-5 4 4 3-4 5 5"/>',
    overview: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    pill: '<path d="M8.2 20a5.7 5.7 0 0 1-4-9.7l6.2-6.2a5.7 5.7 0 0 1 8.1 8.1l-6.3 6.2A5.6 5.6 0 0 1 8.2 20Z"/><path d="m7.3 7.3 8.1 8.1"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 10h18c0-3-3-3-3-10Z"/><path d="M10 21a2.5 2.5 0 0 0 4 0"/>',
    shield: '<path d="M12 2.5c2.4 2.1 6 3.3 8 3.5v5.8c0 4.4-3 7.7-8 10-5-2.3-8-5.6-8-10V6c2-.2 5.6-1.4 8-3.5Z"/><path d="m8.5 12 2.3 2.3 4.7-5"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M7 3v4m10-4v4M3 10h18m-13 4h2m4 0h2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.3 2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
    go: '<path d="m8 16 9-9m-9 0h9v9"/>',
    right: '<path d="m9 6 6 6-6 6"/>',
    left: '<path d="m15 6-6 6 6 6"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 4 2c-1.2.8-1.5 1.3-1.5 2.5M12 17h.01"/>',
    lock: '<rect x="5.5" y="10" width="13" height="11" rx="2"/><path d="M8.5 10V7a3.5 3.5 0 0 1 7 0v3M12 14v3"/>',
    morning: '<path d="M2 17h20M4 21h16M6.5 16a5.5 5.5 0 0 1 11 0M12 3v4M3 10l2 2m14 0 2-2M2 14l1 .3M21 14l1-.3"/>',
    sun: '<circle cx="12" cy="12" r="4.2"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.6 1.6m10.8 10.8L19 19M5 19l1.6-1.6M17.4 6.6 19 5"/>',
    moon: '<path d="M20.3 14.3A8.8 8.8 0 0 1 9.7 3.7a8.8 8.8 0 1 0 10.6 10.6Z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-9h.01"/>',
    heart: '<path d="m12 21-8-7.4a5.5 5.5 0 0 1 8-7.3 5.5 5.5 0 0 1 8 7.3Z"/><path d="M3 12h5l1.7-3.5 3 6 2-4H20"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    list: '<path d="M9 6h12M9 12h12M9 18h12M3 6h1M3 12h1M3 18h1"/>',
    sound: '<path d="M3 9h4l5-4v14l-5-4H3Zm13-1a5 5 0 0 1 0 8m3-11a9 9 0 0 1 0 14"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/>',
    edit: '<path d="m14.5 5.5 4 4M3 21l4.8-1.1L20 7.6a2.8 2.8 0 0 0-4-4L3.9 16Z"/>',
    alert: '<path d="m10.4 4.5-8 14A1.6 1.6 0 0 0 3.8 21h16.4a1.6 1.6 0 0 0 1.4-2.5l-8-14a1.8 1.8 0 0 0-3.2 0Z"/><path d="M12 9v5m0 3h.01"/>',
    bottle: '<rect x="7" y="2.5" width="10" height="4.5" rx="1"/><rect x="5" y="7" width="14" height="14" rx="3"/><path d="M5 11h14M5 17h14"/>',
    book: '<path d="M12 6c-2-2-6-3-9-2v15c3-1 7 0 9 2 2-2 6-3 9-2V4c-3-1-7 0-9 2Zm0 0v15"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>'
  };
  function icon(name, size = 20) {
    return '<svg aria-hidden="true" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">' + (paths[name] || "") + "</svg>";
  }

  // dosewell-interactions/iphone-setup.js
  var exportKey = "dosewell.apple-calendar-export.v1";
  var onAppleMobile = () => /iPhone|iPad|iPod/i.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
  var fromHomeScreen = () => navigator.standalone === true || window.matchMedia("(display-mode: standalone)").matches;
  var section = (tag, label) => {
    const el = document.createElement(tag);
    el.textContent = label;
    return el;
  };
  var timeText = (date) => date.toLocaleTimeString(void 0, { hour: "numeric", minute: "2-digit" });
  async function scheduleSignature(state2) {
    const fields = state2.meds.filter((m) => m.mode !== "list").map((m) => [
      m.id,
      medicationTitle(m),
      m.dose,
      m.mode,
      m.start,
      m.end,
      m.anchorAt,
      m.untilAt,
      m.intervalHours,
      m.days,
      m.times,
      advanceMinutes(m, state2.settings)
    ]).sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(fields)));
    return Array.from(new Uint8Array(bytes), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  async function updateExportNote(note, state2) {
    try {
      const signature = await scheduleSignature(state2);
      const last = JSON.parse(localStorage.getItem(exportKey) || "null");
      if (!last || !note.isConnected) return;
      note.hidden = false;
      note.textContent = signature === last.signature ? "Last calendar file prepared on " + new Date(last.at).toLocaleDateString() + ". Check the imported events in Calendar." : "Your plan has changed since your last calendar file. Remove outdated Dosewell events from Calendar and import the current schedule.";
    } catch {
    }
  }
  async function recordExport(note, exportedState, getState) {
    try {
      const signature = await scheduleSignature(exportedState);
      localStorage.setItem(exportKey, JSON.stringify({ signature, at: Date.now() }));
      await updateExportNote(note, getState());
    } catch {
    }
  }
  function fileActions(container, getFile, filename, after) {
    const row = document.createElement("div");
    row.className = "export-choices";
    const status = section("p", "");
    status.className = "iphone-feedback";
    status.setAttribute("role", "status");
    const test = filename !== calendarName;
    const probe = shareableCalendar({ text: "BEGIN:VCALENDAR\r\nEND:VCALENDAR\r\n" }, navigator, filename);
    const save2 = section("button", test ? "Save test file" : "Save calendar file");
    save2.type = "button";
    save2.className = probe ? "btn outline" : "btn primary";
    function finished(cal, method) {
      status.textContent = (method === "share" ? "File shared. " : "File prepared. ") + (test ? "Import the test event in Calendar. With notifications allowed, check for alerts at " + timeText(cal.warningAt) + " and " + timeText(cal.at) + "." : "Confirm the events in Calendar. If you used Mail, open the .ics attachment there.");
      if (after) after(cal);
    }
    save2.onclick = () => {
      try {
        const cal = getFile();
        if (!downloadCalendarFile(cal, filename)) {
          status.textContent = "There are no upcoming doses to export.";
          return;
        }
        finished(cal, "save");
      } catch {
        status.textContent = "The file could not be saved. Try opening Dosewell in Safari.";
      }
    };
    if (probe) {
      const share = section("button", test ? "Share test file" : "Share calendar file");
      share.type = "button";
      share.className = "btn primary";
      share.onclick = async () => {
        try {
          const cal = getFile();
          if (!cal.count) {
            status.textContent = "There are no upcoming doses to export.";
            return;
          }
          const file = shareableCalendar(cal, navigator, filename);
          if (!file) {
            status.textContent = "File sharing is unavailable here. Choose Save instead.";
            return;
          }
          await navigator.share({ files: [file] });
          finished(cal, "share");
        } catch (e) {
          status.textContent = e.name === "AbortError" ? "Sharing canceled." : "Sharing is unavailable. Save the file and attach it in Mail.";
        }
      };
      row.append(share);
    }
    row.append(save2);
    container.append(row, status);
  }
  function mountAppleCalendar(container, getState, { remember = false, canEdit = false } = {}) {
    const state2 = getState(), now = /* @__PURE__ */ new Date();
    const meds = state2.meds.filter((m) => calendarFile({ meds: [m], settings: state2.settings }, now).count > 0);
    const last = section("p", "");
    last.className = "iphone-export-note";
    last.hidden = true;
    container.append(section("h2", "Apple Calendar reminders"));
    if (meds.length) {
      container.append(section("p", "One calendar file includes your upcoming dose times and the advance warnings you selected. It contains medication names and doses. Share it only with someone you choose."));
      const list = document.createElement("details");
      list.className = "iphone-details";
      list.append(section("summary", "Review " + meds.length + " scheduled medication" + (meds.length === 1 ? "" : "s")));
      const ul = document.createElement("ul");
      ul.className = "transfer-meds";
      for (const m of meds) {
        const item = document.createElement("li"), lead = advanceMinutes(m, state2.settings);
        item.append(section("b", medicationTitle(m) + " \xB7 " + m.dose), section("small", scheduleLabel(m)), section("small", lead ? "At dose time and " + lead + " minutes before." : "At dose time."));
        if (m.end) item.append(section("small", "Through " + m.end));
        ul.append(item);
      }
      list.append(ul);
      container.append(list);
      fileActions(container, () => {
        const exportedState = getState();
        return { ...calendarFile(exportedState), exportedState };
      }, calendarName, remember ? (cal) => recordExport(last, cal.exportedState, getState) : null);
    } else {
      container.append(section("p", "Add a medication with a future dose time to make your calendar file. You can try a test alert below first."));
      if (canEdit) {
        const add = section("button", "Add medication");
        add.className = "btn primary";
        add.type = "button";
        add.dataset.action = "add";
        container.append(add);
      }
    }
    container.append(last);
    if (remember) updateExportNote(last, state2);
    const instructions = document.createElement("details");
    instructions.className = "iphone-details";
    instructions.open = meds.length > 0;
    instructions.append(section("summary", "Import the alerts on your iPhone"));
    const ol = document.createElement("ol");
    for (const step of [
      "If Calendar is offered when you open the file, select it. Otherwise, attach the .ics file to an email to yourself and open the attachment in Apple Mail.",
      "Add the events to a personal calendar. A separate calendar named Dosewell makes it easier to replace them after a schedule change.",
      "Open the first event and check the dose time and both alerts if you chose an advance warning. If an alert is missing, edit the event in Calendar. Allow Calendar notifications in iPhone Settings."
    ]) ol.append(section("li", step));
    instructions.append(ol, section("p", "Apple Calendar delivers the imported alerts while Dosewell is closed. When you edit or stop a medication, replace the old calendar events. Marking a dose taken or snoozing it in Dosewell does not change an imported event."));
    container.append(instructions);
    const trial = document.createElement("details");
    trial.className = "iphone-details";
    trial.append(section("summary", "Try a test alert"), section("p", "Import one sample event about 10 minutes from now, then lock your iPhone. It includes an alert two minutes before the event and another when it starts. The test contains no medication information."));
    fileActions(trial, () => calendarTestFile(), "Dosewell-calendar-test.ics");
    container.append(trial);
  }
  function showIphoneSetup(main2, getState) {
    const installed = fromHomeScreen();
    main2.innerHTML = '<div class="page-head"><div><h1>Use Dosewell on iPhone</h1><p>Manage your medications in Safari. No account or App Store download is needed.</p></div></div><div class="iphone-layout"><section class="panel side-note iphone-card" id="apple-calendar"></section><aside><section class="panel side-note iphone-card"><h2>' + (installed ? "On your Home Screen" : "Add Dosewell to your Home Screen") + "</h2>" + (installed ? "<p>You opened Dosewell from its Home Screen icon.</p>" : "<p>For one-tap access, open Dosewell in Safari. Tap <strong>Share \u2192 Add to Home Screen</strong>, turn on <strong>Open as Web App</strong> if shown, then tap <strong>Add</strong>.</p>") + '<p>Safari and the Home Screen icon can keep separate plans. If you are starting fresh, enter your medications where you plan to use Dosewell.</p><a class="text-link" href="./move.html">Transfer a saved plan ' + icon("arrow", 16) + '</a></section><a class="btn outline iphone-today" href="#overview">Open my planner ' + icon("arrow", 16) + '</a> <a class="text-link" href="#reminders">All reminder settings</a></aside></div>';
    mountAppleCalendar(main2.querySelector("#apple-calendar"), getState, { remember: true, canEdit: true });
  }

  // dosewell-interactions/dose-log.js
  function prepareLog(state2) {
    state2.snoozes || (state2.snoozes = {});
    state2.supplies || (state2.supplies = {});
    state2.history || (state2.history = {});
    for (const [key3, recordedAt] of Object.entries(state2.taken)) {
      const [medId, day2, time] = key3.split("|");
      if (!day2 || !time || state2.history[key3]) continue;
      const med = state2.meds.find((item) => item.id === medId);
      state2.history[key3] = { medId, day: day2, time, recordedAt, status: "taken", name: med?.name || "Previously recorded medication", dose: "", legacy: true };
    }
    return state2;
  }
  function doseAt(state2, key3) {
    const [medId, kind, time] = key3.split("|");
    const day2 = kind === "interval" ? dayKey(new Date(Number(time))) : kind;
    if (kind === "interval") {
      const med2 = state2.meds.find((m) => m.id === medId && m.mode === "interval");
      return med2 ? dosesFor([med2], day2).find((row) => row.key === key3) || null : null;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day2) || !/^\d{2}:\d{2}$/.test(time)) return null;
    const med = state2.meds.find((m) => m.id === medId);
    return med ? dosesFor([med], day2).find((d) => d.key === key3) || null : null;
  }
  function recordedStatus(state2, key3) {
    return state2.history?.[key3]?.status || (state2.taken[key3] ? "taken" : "");
  }
  function debitSupply(state2, record) {
    const supply = state2.supplies[record.medId];
    if (!supply || supply.remaining <= 0) return;
    supply.remaining--;
    record.debited = supply.revision;
  }
  function logDose(state2, key3, status, now = /* @__PURE__ */ new Date()) {
    prepareLog(state2);
    if (!["taken", "skipped"].includes(status)) throw Error("Choose a dose status.");
    if (recordedStatus(state2, key3)) throw Error("This dose is already recorded. Undo the entry to change it.");
    const dose = doseAt(state2, key3);
    if (!dose || dose.when > now) throw Error("This scheduled dose is unavailable to record.");
    const { med, day: day2, time } = dose, record = { medId: med.id, day: day2, time, status, name: medicationTitle(med), dose: med.dose, recordedAt: now.getTime() };
    if (med.mode === "interval") record.scheduledLabel = doseTimeLabel(dose);
    if (status === "taken") {
      state2.taken[key3] = record.recordedAt;
      debitSupply(state2, record);
    }
    state2.history[key3] = record;
    delete state2.snoozes[key3];
  }
  function logAsNeeded(state2, medId, key3, now = /* @__PURE__ */ new Date()) {
    prepareLog(state2);
    if (state2.history[key3]) return;
    const med = state2.meds.find((m) => m.id === medId && m.mode === "list");
    if (!med) throw Error("Reopen the medication list to check this entry.");
    const record = { medId, day: dayKey(now), time: "", status: "taken", name: medicationTitle(med), dose: med.dose, recordedAt: now.getTime(), unscheduled: true };
    debitSupply(state2, record);
    state2.history[key3] = record;
  }
  function undoLog(state2, key3, expectedTime) {
    prepareLog(state2);
    const record = state2.history[key3];
    if (!record || record.recordedAt !== expectedTime) throw Error("This entry changed. Reopen its history to review it.");
    const supply = state2.supplies[record.medId];
    if (record.debited && supply?.revision === record.debited) supply.remaining++;
    delete state2.history[key3];
    delete state2.taken[key3];
    delete state2.snoozes[key3];
  }
  function snoozeDose(state2, key3, mins, now = /* @__PURE__ */ new Date()) {
    const dose = doseAt(state2, key3);
    if (!dose || dose.when > now || now - dose.when > 864e5 || recordedStatus(state2, key3) || ![5, 10, 15, 30, 60].includes(mins)) throw Error("This reminder cannot be snoozed.");
    state2.snoozes[key3] = now.getTime() + mins * 6e4;
  }
  function updateSupply(state2, medId, remaining, threshold, expected) {
    prepareLog(state2);
    if (!state2.meds.some((m) => m.id === medId)) throw Error("This medication is no longer on your list.");
    const old = state2.supplies[medId];
    if ((old?.revision || "") !== (expected?.revision || "") || old?.remaining !== expected?.remaining) throw Error("The supply changed. Reopen it to see the current count.");
    if (remaining === null) {
      delete state2.supplies[medId];
      return;
    }
    if (![remaining, threshold].every((v) => Number.isSafeInteger(v) && v >= 0 && v <= 99999)) throw Error("Enter whole numbers between 0 and 99999.");
    state2.supplies[medId] = { remaining, threshold, revision: crypto.randomUUID() };
  }
  function historyEntries(state2, period, now = /* @__PURE__ */ new Date()) {
    const first = localDay(dayKey(now));
    first.setDate(first.getDate() - (Number(period) || 1) + 1);
    const cutoff = period === "all" ? "" : dayKey(first);
    return Object.entries(state2.history || {}).filter(([, r]) => r.day >= cutoff).sort(([, a], [, b]) => b.day.localeCompare(a.day) || b.time.localeCompare(a.time) || b.recordedAt - a.recordedAt);
  }
  function recordClock(record) {
    return new Date(record.recordedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  }
  function recordTiming(record) {
    return record.unscheduled ? "Unscheduled dose" : (record.scheduledLabel || timeLabel(record.time)) + " scheduled";
  }
  function alignDoseKeys(state2, oldMed, newMed) {
    if (oldMed.mode === "interval" === (newMed.mode === "interval")) return;
    for (const [key3, record] of Object.entries(state2.history)) {
      if (record.medId !== oldMed.id || record.unscheduled) continue;
      const parts = key3.split("|");
      const instant = parts[1] === "interval" ? new Date(Number(parts[2])) : /* @__PURE__ */ new Date(record.day + "T" + record.time + ":00");
      if (!Number.isFinite(instant.getTime())) continue;
      const row = dosesFor([newMed], dayKey(instant)).find((r) => r.when.getTime() === instant.getTime());
      if (!row || row.key === key3 || state2.history[row.key]) continue;
      state2.history[row.key] = record;
      delete state2.history[key3];
      if (state2.taken[key3]) {
        state2.taken[row.key] = state2.taken[key3];
        delete state2.taken[key3];
      }
    }
  }

  // dosewell-interactions/store.js
  var key = "dosewell.planner.v1";
  var empty = () => ({ version: 1, meds: [], taken: {}, fired: {}, snoozes: {}, supplies: {}, history: {}, settings: { advance: 15, sound: true, notifications: false } });
  var memory = empty();
  var volatile = false;
  var broken = false;
  function read() {
    if (volatile) return memory;
    let raw;
    try {
      raw = localStorage.getItem(key);
    } catch {
      volatile = true;
      return memory;
    }
    if (!raw) return memory = empty();
    try {
      const data = JSON.parse(raw);
      if (data.version !== 1 || !Array.isArray(data.meds) || !data.settings || !data.taken || !data.fired) throw Error();
      return memory = prepareLog(data);
    } catch {
      broken = true;
      return memory;
    }
  }
  function storageStatus() {
    return broken ? "Saved data could not be read. Changes are paused to protect your existing medication list." : volatile ? "This browser cannot save your changes. Your plan will be lost when you leave." : "";
  }
  async function change(update) {
    const write = () => {
      const data = read();
      if (broken) throw Error(storageStatus());
      update(data);
      memory = data;
      if (!volatile) try {
        localStorage.setItem(key, JSON.stringify(data));
      } catch {
        volatile = true;
      }
      return data;
    };
    return navigator.locks ? await navigator.locks.request(key, write) : write();
  }
  function onLocalChange(fn) {
    window.addEventListener("storage", (e) => {
      if (e.key === key || e.key === null) fn();
    });
  }

  // dosewell-interactions/plan-backup.js
  var plain = (v) => v !== null && typeof v === "object" && !Array.isArray(v) && Object.getPrototypeOf(v) === Object.prototype;
  var allowedId = (v) => typeof v === "string" && /^[a-z0-9_-]{1,96}$/i.test(v) && !(v in Object.prototype);
  var text = (v) => typeof v === "string";
  var int = (v, min, max) => Number.isSafeInteger(v) && v >= min && v <= max;
  var timestamp = (v) => int(v, 0, 253402300799999);
  var day = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) && (/* @__PURE__ */ new Date(v + "T12:00:00Z")).toJSON()?.slice(0, 10) === v;
  var clock = (v) => typeof v === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  var objOf = (v, test) => plain(v) && Object.entries(v).every(([k, x]) => k.length > 0 && k.length < 250 && !(k in Object.prototype) && test(x, k));
  function validMedication(m) {
    if (!plain(m) || !allowedId(m.id) || !text(m.name) || !m.name.trim() || !text(m.dose) || !m.dose.trim() || !["stroke", "other"].includes(m.category)) return false;
    if (!["daily", "weekly", "interval", "list"].includes(m.mode) || !Array.isArray(m.days) || !m.days.length || !m.days.every((d) => int(d, 0, 6)) || !Array.isArray(m.times) || !m.times.every(clock) || new Set(m.times).size !== m.times.length) return false;
    if (!day(m.start) || m.end !== "" && (!day(m.end) || m.end < m.start) || m.advance !== null && !int(m.advance, 0, 1440)) return false;
    if (m.strength !== void 0 && !text(m.strength) || m.directions !== void 0 && !text(m.directions)) return false;
    if (m.mode !== "list" && !m.times.length) return false;
    return m.mode !== "interval" || int(m.intervalHours, 1, 72) && (m.intervalHours <= 24 || [36, 48, 72].includes(m.intervalHours)) && Number.isFinite(m.anchorAt) && (m.untilAt === null || Number.isFinite(m.untilAt) && m.untilAt > m.anchorAt) && m.times.length === 1;
  }
  function validHistory(r) {
    return plain(r) && allowedId(r.medId) && day(r.day) && (clock(r.time) || r.time === "" && r.unscheduled === true) && timestamp(r.recordedAt) && ["taken", "skipped"].includes(r.status) && text(r.name) && text(r.dose) && (r.scheduledLabel === void 0 || text(r.scheduledLabel));
  }
  function hasPlan(s) {
    return s.meds.length > 0 || Object.keys(s.history || {}).length > 0 || Object.keys(s.taken || {}).length > 0 || Object.keys(s.supplies || {}).length > 0;
  }
  function readBackup(raw) {
    const fail = () => {
      throw Error("Choose an unmodified private plan file exported from Dosewell.");
    };
    let wrapper;
    try {
      wrapper = JSON.parse(raw, (k, v) => {
        if (["__proto__", "prototype", "constructor"].includes(k)) fail();
        return v;
      });
    } catch {
      fail();
    }
    if (!plain(wrapper) || wrapper.format !== "dosewell-plan-backup-v1") fail();
    const s = wrapper.plan;
    if (!plain(s) || s.version !== 1 || !Array.isArray(s.meds) || !s.meds.every(validMedication) || new Set(s.meds.map((m) => m.id)).size !== s.meds.length) fail();
    if (!plain(s.settings) || !int(s.settings.advance, 0, 1440) || typeof s.settings.sound !== "boolean" || typeof s.settings.notifications !== "boolean") fail();
    if (!objOf(s.taken, timestamp) || !objOf(s.fired, timestamp) || !objOf(s.snoozes, timestamp) || !objOf(s.history, validHistory)) fail();
    if (!objOf(s.supplies, (v, k) => allowedId(k) && plain(v) && int(v.remaining, 0, 99999) && int(v.threshold, 0, 99999) && allowedId(v.revision))) fail();
    if (!hasPlan(s)) throw Error("This backup contains no medication entries or dose history.");
    return { version: 1, meds: s.meds, history: s.history, taken: s.taken, fired: s.fired, snoozes: s.snoozes, supplies: s.supplies, settings: { advance: s.settings.advance, sound: s.settings.sound, notifications: false } };
  }

  // dosewell-interactions/native-alarms.js
  var nativePlatform = window.DosewellNative ? "Android" : window.webkit?.messageHandlers?.dosewell ? "iPhone" : "";
  var lastStatus = "Open Reminders to enable Dosewell alarms.";
  function command(action, data = {}) {
    if (!nativePlatform) return;
    const message = JSON.stringify({ action, ...data });
    if (nativePlatform === "Android") window.DosewellNative.message(message);
    else window.webkit.messageHandlers.dosewell.postMessage(message);
  }
  function nativeStatus(message, attention) {
    lastStatus = String(message);
    const line = document.querySelector("#native-status");
    if (line) line.textContent = lastStatus;
    const banner = document.querySelector("#native-banner");
    if (banner) {
      banner.hidden = !attention;
      banner.querySelector("span").textContent = lastStatus;
    }
  }
  window.onDosewellAlarmStatus = nativeStatus;
  var soundDescription = "Dose and advance alarms use the Dosewell chime and vibration.";
  var usingOlderSound = false;
  window.onDosewellSoundStatus = (description, legacy) => {
    soundDescription = description;
    usingOlderSound = legacy;
    const note = document.getElementById("native-sound-status");
    if (note) note.textContent = description;
    const use = document.getElementById("use-dosewell-chime");
    if (use) use.hidden = !legacy;
  };
  function paintNative() {
    const p = document.getElementById("native-status");
    if (p) p.textContent = lastStatus;
    if (nativePlatform !== "Android" || !p) return;
    const section2 = document.createElement("section");
    section2.setAttribute("aria-label", "Alarm sound");
    const title = document.createElement("h3");
    title.textContent = "Alarm sound";
    const note = document.createElement("p");
    note.id = "native-sound-status";
    note.textContent = soundDescription;
    const choose = document.createElement("button");
    choose.type = "button";
    choose.className = "btn small outline";
    choose.id = "use-dosewell-chime";
    choose.textContent = "Use gentle chime and vibration";
    choose.hidden = !usingOlderSound;
    choose.onclick = () => command("gentle");
    const settings = document.createElement("button");
    settings.type = "button";
    settings.className = "btn small outline";
    settings.textContent = "Android sound settings";
    settings.onclick = () => command("channel-settings");
    section2.append(title, note, choose, settings);
    p.parentElement.append(section2);
  }
  function nextTime(rule, after, skip) {
    const lead = rule.lead * 6e4;
    if (rule.mode === "snooze") return rule.at > after ? rule.at : null;
    if (rule.mode === "interval") {
      let n = Math.max(0, Math.floor((after + lead - rule.anchor) / rule.step) + 1);
      for (; ; n++) {
        const at = rule.anchor + n * rule.step;
        if (rule.until && at >= rule.until) return null;
        if (!skip.has(rule.med + "|interval|" + at)) return at - lead;
      }
    }
    let day2 = dayKey(new Date(after + lead));
    if (day2 < rule.start) day2 = rule.start;
    while (!rule.end || day2 <= rule.end) {
      const dose = /* @__PURE__ */ new Date(day2 + "T" + rule.time + ":00");
      if (rule.days & 1 << (/* @__PURE__ */ new Date(day2 + "T12:00:00")).getDay() && dose.getTime() - lead > after && !skip.has(rule.med + "|" + day2 + "|" + rule.time)) return dose.getTime() - lead;
      day2 = shiftDay(day2, 1);
    }
    return null;
  }
  function alarmRules(state2) {
    const rules2 = [], skip = /* @__PURE__ */ new Set([...Object.keys(state2.taken), ...Object.entries(state2.history || {}).filter(([, r]) => r.status === "skipped" || r.status === "taken").map(([k]) => k), ...Object.keys(state2.snoozes || {})]);
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      const name = medicationTitle(med) + " \xB7 " + med.dose;
      for (const lead of /* @__PURE__ */ new Set([0, advanceMinutes(med, state2.settings) || 0])) {
        const base = { med: med.id, lead, label: (lead ? "In " + lead + " min: " : "Dose: ") + name };
        if (med.mode === "interval") rules2.push({ ...base, id: med.id + "|interval|" + lead, mode: "interval", anchor: med.anchorAt, step: med.intervalHours * 36e5, until: med.untilAt || 0 });
        else for (const time of med.times) rules2.push({ ...base, id: med.id + "|" + time + "|" + lead, mode: "weekly", time, start: med.start, end: med.end, days: med.days.reduce((mask, d) => mask | 1 << d, 0) });
      }
      for (const [key3, at] of Object.entries(state2.snoozes || {})) if (key3.startsWith(med.id + "|") && !state2.taken[key3] && !state2.history?.[key3])
        rules2.push({ id: key3 + "|snooze", med: med.id, lead: 0, label: "Snoozed: " + name, mode: "snooze", at });
    }
    return { rules: rules2, skip: [...skip] };
  }
  function weeklyPattern(r, at, now) {
    if (r.mode !== "weekly" || r.end || r.start > dayKey(new Date(now))) return null;
    const [h2, m] = r.time.split(":").map(Number), wall = h2 * 60 + m - r.lead;
    const minute = (wall % 1440 + 1440) % 1440;
    const mask = wall < 0 ? r.days >> 1 | (r.days & 1) << 6 : r.days;
    const time = String(Math.floor(minute / 60)).padStart(2, "0") + ":" + String(minute % 60).padStart(2, "0");
    const natural = nextTime({ mode: "weekly", start: r.start, end: "", time, days: mask, lead: 0, med: r.med }, now, /* @__PURE__ */ new Set());
    if (at !== natural) return null;
    if (r.lead) {
      let d = dayKey(new Date(now));
      for (let i = 0; i < 370; i++, d = shiftDay(d, 1)) {
        const dose = /* @__PURE__ */ new Date(d + "T" + r.time + ":00");
        if (r.days & 1 << dose.getDay() && clockTime(new Date(dose - r.lead * 6e4)) !== time) return null;
      }
    }
    return { days: mask, hour: Math.floor(minute / 60), minute: minute % 60 };
  }
  function iphoneQueue(plan, now = Date.now(), limit = 24) {
    const skip = new Set(plan.skip), weekly = [], dated = [];
    for (const r of plan.rules) {
      const at = nextTime(r, now, skip);
      if (at === null) continue;
      const pattern = weeklyPattern(r, at, now);
      const upcomingException = plan.skip.some((k) => k.startsWith(r.med + "|") && k.split("|")[1] >= dayKey(new Date(now)));
      if (pattern && !upcomingException) weekly.push({ key: r.id, label: r.label, ...pattern });
      else dated.push({ rule: r, at });
    }
    if (weekly.length >= limit && dated.length || weekly.length > limit) {
      weekly.length = 0;
      dated.length = 0;
      for (const r of plan.rules) {
        const at = nextTime(r, now, skip);
        if (at !== null) dated.push({ rule: r, at });
      }
    }
    const alarms = [...weekly];
    while (dated.length && alarms.length < limit) {
      const at = Math.min(...dated.map((e) => e.at)), same = dated.filter((e) => e.at === at);
      alarms.push({ key: "date|" + at, label: same.map((e) => e.rule.label).join(" \u2022 "), at });
      for (const item of same) {
        const next = nextTime(item.rule, at, skip);
        if (next === null) dated.splice(dated.indexOf(item), 1);
        else item.at = next;
      }
    }
    return { alarms, refill: dated.length ? Math.min(...dated.map((e) => e.at)) : 0 };
  }
  function syncNative() {
    if (!nativePlatform) return;
    const plan = alarmRules(read());
    command("sync", nativePlatform === "iPhone" ? iphoneQueue(plan) : plan);
  }
  function nativeAction(action) {
    if (action === "enable-app-alarms") {
      syncNative();
      command("enable");
    }
    if (action === "test-app-alarm") command("test");
    if (action === "stop-app-alarms") command("disable");
  }
  async function importNativeFile(file) {
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) throw Error("Choose a Dosewell plan file smaller than 12 MB.");
    const imported = readBackup(await file.text());
    await change((s) => {
      if (hasPlan(s)) throw Error("Import into an empty plan to preserve your existing entries.");
      Object.assign(s, imported);
    });
  }

  // dosewell-interactions/view.js
  var h = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  var dateLabel = (date, opts) => date.toLocaleDateString("en-US", opts);
  var btn = (action, label, ic, cls = "btn") => '<button class="' + cls + '" data-action="' + action + '">' + (ic ? icon(ic, 17) : "") + label + "</button>";
  var btnIcon = (action, label, ic) => '<button class="icon-button" aria-label="' + label + '" data-action="' + action + '">' + icon(ic, 17) + "</button>";
  var badge = (i, color = "mint", size = 22) => '<span class="badgeicon ' + color + '">' + icon(i, size) + "</span>";
  var counts = (meds) => ({ stroke: meds.filter((m) => m.category === "stroke").length, other: meds.filter((m) => m.category === "other").length });
  var plural = (n, s) => n + " " + s + (n === 1 ? "" : "s");
  var navItems = [["overview", "calendar", "Today"], ["medications", "pill", "Medications"], ["history", "history", "History"], ["reminders", "bell", "Reminders"], ["interactions", "shield", "Interactions"]];
  function nav(view2) {
    return navItems.map(([id, ic, label]) => {
      const route2 = id === "reminders" && !nativePlatform && onAppleMobile() ? "reminders/iphone" : id;
      return '<a href="#' + route2 + '" ' + (id === view2 ? 'aria-current="page"' : "") + ">" + icon(ic, 17) + "<span>" + label + "</span></a>";
    }).join("");
  }
  var periods = [
    { name: "Morning", icon: "morning", hours: "6 AM \u2013 noon" },
    { name: "Afternoon", icon: "sun", hours: "Noon \u2013 5 PM" },
    { name: "Evening", icon: "sunset", hours: "5 PM \u2013 9 PM" },
    { name: "Night", icon: "moon", hours: "9 PM \u2013 6 AM" }
  ];
  function periodIndex(time) {
    const h2 = Number(time.slice(0, 2));
    return h2 < 6 || h2 >= 21 ? 3 : h2 < 12 ? 0 : h2 < 17 ? 1 : 2;
  }
  function scheduleRows(state2, day2, rows, part2, now) {
    if (!rows.length) {
      const title = part2 === null ? "No doses scheduled" : "No " + periods[part2].name.toLowerCase() + " doses";
      return '<div class="schedule-empty">' + icon(part2 === null ? "pill" : periods[part2].icon, 26) + "<h3>" + title + "</h3><p>" + (state2.meds.length ? "Choose another day or review your medication schedule." : "Add a medication with a dose time to start your pillbox.") + "</p></div>";
    }
    return rows.map((d) => {
      const status = recordedStatus(state2, d.key), snooze = state2.snoozes[d.key], future = d.when > now;
      const label = status === "taken" ? "Taken" : status === "skipped" ? "Skipped" : future ? "Upcoming" : snooze > now ? "Snoozed" : "Unrecorded";
      const key3 = h(d.key);
      const logged = state2.history[d.key];
      const statusText = '<span class="dose-status ' + label.toLowerCase() + '">' + label + "</span>";
      let actions = "";
      if (status) {
        actions = '<button class="text-link" data-log-undo="' + key3 + '" data-stamp="' + state2.history[d.key].recordedAt + '">Undo</button>';
      } else if (!future) {
        actions = '<button class="btn small primary" data-take="' + key3 + '">' + icon("check", 16) + 'Mark taken</button><button class="btn small outline" data-skip="' + key3 + '">Log skipped</button>' + (day2 === dayKey(now) ? '<button class="btn small quiet" data-snooze="' + key3 + '">' + icon("clock", 15) + "Snooze</button>" : "");
      }
      const extra = snooze > now && !status ? "<small>Reminder at " + h(new Date(snooze).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })) + "</small>" : "";
      return '<article class="pillbox-dose"><div class="scheduled-time">' + icon(periods[periodIndex(d.time)].icon, 17) + doseTimeLabel(d) + '</div><div class="dose-copy"><b>' + h(logged?.name || medicationTitle(d.med)) + "</b><small>" + h(logged ? logged.dose : d.med.dose) + "</small>" + extra + "</div>" + statusText + (actions ? '<div class="dose-controls">' + actions + "</div>" : "") + "</article>";
    }).join("");
  }
  function schedule(state2, selected2, part2 = null) {
    const d = localDay(selected2), now = /* @__PURE__ */ new Date(), today = dayKey(now), all = dosesFor(state2.meds, selected2);
    const start = shiftDay(selected2, -((d.getDay() + 6) % 7));
    const strip = Array.from({ length: 7 }, (_, i) => {
      const key3 = shiftDay(start, i), date = localDay(key3);
      return '<button data-date="' + key3 + '" class="day ' + (key3 === selected2 ? "selected" : "") + '" aria-label="' + dateLabel(date, { dateStyle: "full" }) + '" aria-pressed="' + (key3 === selected2) + '"><span>' + dayNames[date.getDay()] + "</span><b>" + date.getDate() + "</b>" + (key3 === today ? '<i aria-label="Today"></i>' : "") + "</button>";
    }).join("");
    const cells = periods.map((p, i) => {
      const count = all.filter((dose) => periodIndex(dose.time) === i).length;
      return '<button class="compartment slot-' + i + '" data-part="' + i + '" aria-pressed="' + (part2 === i) + '" aria-label="' + p.name + ", " + p.hours + ", " + plural(count, "dose") + '">' + icon(p.icon, 23) + "<b>" + p.name + "</b><span>" + plural(count, "dose") + "</span></button>";
    }).join("");
    const shown = part2 === null ? all : all.filter((dose) => periodIndex(dose.time) === part2);
    return '<section class="panel schedule"><div class="panel-head"><div class="section-title">' + icon("pill", 21) + '<h2>Daily pillbox</h2></div><span class="count">' + plural(all.length, "dose") + '</span></div><div class="calendar-top"><b>' + dateLabel(d, { month: "long", year: "numeric" }) + "</b><div>" + btnIcon("prev-week", "Previous week", "left") + btn("today", "Today", "", "today-button") + btnIcon("next-week", "Next week", "right") + '</div></div><div class="week">' + strip + '</div><div class="compartments" aria-label="Filter doses by time of day">' + cells + '</div><div class="pillbox-list">' + (part2 === null ? "" : '<div class="part-filter"><b>' + periods[part2].name + '</b><button data-action="all-periods" class="text-link">Show all times</button></div>') + scheduleRows(state2, selected2, shown, part2, now) + "</div></section>";
  }
  function nextDose(state2, now) {
    let next = null;
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      for (const time of med.times) {
        let row = firstNext(med, time, now);
        while (row && recordedStatus(state2, row.key)) row = firstNext(med, time, new Date(row.when.getTime() + 1));
        if (row && (!next || row.when < next.when)) next = row;
      }
    }
    return next;
  }
  function dailySummary(state2, now) {
    if (!state2.meds.length) {
      return '<section class="day-summary"><div class="summary-top">' + icon("clock", 20) + '<h2>Medication reminders</h2></div><p class="next-time">Set up your first dose</p><p>Enter the name and dose from your prescription label, or use a photo to fill in the details.</p><button class="start-scan" data-action="add">' + icon("camera", 17) + "Add from a label</button></section>";
    }
    const day2 = dayKey(now), rows = dosesFor(state2.meds, day2);
    const taken = rows.filter((d) => recordedStatus(state2, d.key) === "taken").length;
    const skipped = rows.filter((d) => recordedStatus(state2, d.key) === "skipped").length;
    const next = nextDose(state2, now);
    const when = next ? (next.day === day2 ? "Today" : next.day === shiftDay(day2, 1) ? "Tomorrow" : dateLabel(localDay(next.day), { month: "short", day: "numeric" })) + " \xB7 " + doseTimeLabel(next) : "";
    return '<section class="day-summary"><div class="summary-top">' + icon("clock", 20) + "<h2>Next scheduled dose</h2></div>" + (next ? '<p class="next-time">' + h(when) + "</p><p><b>" + h(medicationTitle(next.med)) + "</b> \xB7 " + h(next.med.dose) + "</p>" : '<p class="next-time">No upcoming doses</p>') + '<div class="daily-progress"><div><span>Today\u2019s record</span><b>' + taken + " / " + rows.length + ' taken</b></div><progress max="' + (rows.length || 1) + '" value="' + taken + '" aria-label="Scheduled doses marked taken today"></progress><small>' + skipped + " skipped \xB7 " + (rows.length - taken - skipped) + ' unrecorded</small></div><a href="#history">View dose history ' + icon("arrow", 16) + "</a></section>";
  }
  function refillNotices(state2) {
    const low = state2.meds.filter((m) => state2.supplies[m.id] && state2.supplies[m.id].remaining <= state2.supplies[m.id].threshold);
    if (!low.length) return "";
    return '<section class="panel refill-notices"><div class="section-title">' + icon("bottle", 20) + "<h2>Refill reminders</h2></div>" + low.map((m) => '<button class="refill-item" data-supply="' + h(m.id) + '"><span><b>' + h(medicationTitle(m)) + "</b><small>" + plural(state2.supplies[m.id].remaining, "dose") + " remaining</small></span>" + icon("right", 16) + "</button>").join("") + "</section>";
  }
  function checkerCard(state2) {
    const n = counts(state2.meds);
    const alerts = compare(state2.meds).filter((p) => p.level !== "unassessed").length;
    return '<section class="panel safety-card"><div class="section-title">' + badge("shield", "lilac", 23) + '<h2>Interaction checker</h2></div><p>Review your saved medicines together or try adding another product in the checker.</p><div class="pair-lines"><a href="#medications/stroke">' + icon("heart", 18) + "Stroke medications <b>" + n.stroke + '</b></a><a href="#medications/other">' + icon("pill", 18) + "Other medications <b>" + n.other + "</b></a></div>" + (alerts ? '<div class="flag-line">' + icon("alert", 16) + plural(alerts, "warning") + " to review</div>" : "") + '<a href="#interactions" class="text-link">Review interactions ' + icon("arrow", 16) + "</a></section>";
  }
  function overview(state2, selected2, part2 = null) {
    const now = /* @__PURE__ */ new Date();
    return '<section class="planner-intro app-intro"><div class="intro-title"><p>' + dateLabel(now, { dateStyle: "full" }) + "</p><h1>Today</h1></div>" + btn("add", "Add medication", "plus", "btn primary") + "</section>" + (!nativePlatform && onAppleMobile() ? '<div class="iphone-entry"><span>' + icon("calendar", 19) + ' Get dose reminders on your Lock Screen</span><a class="text-link" href="#reminders/iphone">Set up Apple Calendar ' + icon("arrow", 16) + "</a></div>" : "") + '<div class="overview-grid">' + schedule(state2, selected2, part2) + "<aside>" + dailySummary(state2, now) + refillNotices(state2) + checkerCard(state2) + "</aside></div>";
  }
  var pageHead = (title, sub, action = "") => '<div class="page-head"><div><h1>' + title + "</h1><p>" + sub + "</p></div>" + action + "</div>";
  function medicationPage(state2, filter2) {
    const meds = state2.meds.filter((m) => filter2 === "all" || m.category === filter2);
    const tabs = [["all", "All medications"], ["stroke", "Stroke medications"], ["other", "Other medications"]];
    return pageHead("My medications", "Keep your prescribed doses and other medicines together.", btn("add", "Add medication", "plus", "btn primary")) + '<section class="panel listing"><div class="filters" aria-label="Filter medications">' + tabs.map(([v, t]) => "<a " + (filter2 === v ? 'aria-current="page"' : "") + ' href="#medications/' + v + '">' + t + " <span>" + (v === "all" ? state2.meds.length : state2.meds.filter((m) => m.category === v).length) + "</span></a>").join("") + "</div>" + (meds.length ? '<div class="med-list">' + meds.map((m) => '<article class="med-row">' + badge(m.category === "stroke" ? "heart" : "pill", m.category === "stroke" ? "mint" : "lilac") + '<div class="med-detail"><small>' + h(m.category === "stroke" ? "Stroke medication" : "Other medication") + "</small><h3>" + h(medicationTitle(m)) + "</h3><p>" + h(m.dose) + "</p>" + (m.directions ? '<div class="label-directions">' + h(m.directions) + "</div>" : "") + "<span>" + icon("clock", 14) + h(scheduleLabel(m)) + "</span>" + (m.end ? "<small>Through " + h(dateLabel(localDay(m.end), { dateStyle: "medium" })) + "</small>" : "") + '<div class="med-tools"><button class="text-link" data-supply="' + h(m.id) + '">' + icon("bottle", 15) + (state2.supplies[m.id] ? plural(state2.supplies[m.id].remaining, "dose") + " left \xB7 Update supply" : "Track refills") + "</button>" + (m.mode === "list" ? '<button class="text-link" data-as-needed="' + h(m.id) + '">' + icon("check", 16) + "Log a dose</button>" : "") + '</div></div><button class="icon-button" aria-label="Edit ' + h(m.name) + '" data-edit="' + h(m.id) + '">' + icon("edit", 18) + "</button></article>").join("") + "</div>" : '<div class="empty-state">' + badge("bottle", "mint", 29) + "<h3>No " + (filter2 === "all" ? "" : filter2 + " ") + "medications added</h3><p>Enter the name and dose exactly as they appear on your label.</p>" + btn("add", "Add medication", "plus", "btn outline") + "</div>") + "</section>";
  }
  function remindersPage(state2) {
    const enabled = state2.settings.notifications && window.Notification?.permission === "granted";
    const has = state2.meds.some((m) => m.mode !== "list");
    return pageHead("Reminders", "Choose how you receive dose alarms and advance warnings.", '<div class="device-clock">' + icon("clock", 16) + 'Device time <b id="device-clock">' + h((/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" })) + "</b></div>") + (nativePlatform ? '<section class="panel side-note"><h2>Dosewell alarms</h2><p id="native-status" role="status"></p><div class="export-choices">' + btn("enable-app-alarms", "Enable Dosewell alarms", "bell", "btn primary") + btn("test-app-alarm", "Test in 15 seconds", "clock", "btn outline") + btn("stop-app-alarms", "Turn off alarms", "", "text-link") + '</div><form id="default-form"><label for="default-warning">Default advance warning in minutes</label> <input type="number" id="default-warning" name="minutes" min="0" max="1440" required value="' + state2.settings.advance + '"> <button class="btn small outline">Save</button></form><p>After enabling alarms, try a test with the screen locked. Dismissing an alarm leaves your dose history unchanged.</p>' + (!state2.meds.length ? '<label class="btn outline">Import a saved plan<input id="native-import" type="file" accept=".json,application/json"></label>' : "") + "</section>" : '<div class="inner-grid"><section class="panel"><div class="panel-head"><div class="section-title">' + icon("bell", 21) + '<h2>Alarm preferences</h2></div></div><div class="settings"><div class="setting"><label for="default-warning"><b>Default advance warning</b><small>Minutes before a scheduled dose. Enter 0 to turn it off.</small></label><form id="default-form"><input id="default-warning" name="minutes" type="number" min="0" max="1440" step="1" value="' + state2.settings.advance + '" required><span>min</span><button class="btn small outline">Save</button></form></div><div class="setting"><div><b>Alarm sound</b><small>Chime when an in-page reminder appears.</small></div><button class="switch ' + (state2.settings.sound ? "on" : "") + '" data-action="sound" role="switch" aria-checked="' + state2.settings.sound + '" aria-label="Alarm sound"><i></i></button></div><div class="setting"><div><b>Device notifications</b><small>' + (enabled ? "Allowed on this device." : window.Notification?.permission === "denied" ? "Blocked in browser settings. In-page alerts still appear." : "Show notifications with the medication name and dose while the planner is running.") + "</small></div>" + btn("notify", enabled ? "Turn off" : "Enable", "", "btn small outline") + '</div><div class="setting"><div><b>Test reminder</b><small>Try a sample alert on this device.</small></div>' + btn("test", "Test alarm", "bell", "btn small outline") + "</div></div></section>" + (onAppleMobile() ? '<aside><section class="panel side-note calendar-note"><h2>Apple Calendar reminders</h2><p>Get alerts at dose time and ahead of each dose, including while the screen is locked.</p><a class="btn primary" href="#reminders/iphone">Set up Apple Calendar</a><details class="iphone-details"><summary>Other reminder options</summary>' + btn("phone-alarms", "Clock and Shortcuts", "clock", "btn small outline") + "</details></section></aside></div>" : '<aside><section class="panel side-note calendar-note"><h2>Reminders on your phone</h2><p><a class="btn primary" href="./mobile-apps.html">Get the Dosewell app</a></p><p>Choose Clock alarms to set alarms on your phone. Calendar reminders downloads or shares events for a calendar app.</p><div class="export-choices">' + btn("phone-alarms", "Clock alarms", "clock", "btn primary") + btn("calendar-options", "Calendar reminders", "calendar", "btn outline") + "</div></section></aside></div>")) + '<section class="panel reminder-list"><div class="panel-head"><div class="section-title">' + icon("clock", 20) + "<h2>Medication alarms</h2></div></div>" + (has ? state2.meds.filter((m) => m.mode !== "list").map((m) => '<div class="alarm-row"><div><b>' + h(medicationTitle(m)) + " \xB7 " + h(m.dose) + "</b><small>" + h(scheduleLabel(m)) + " \xB7 " + (advanceMinutes(m, state2.settings) ? advanceMinutes(m, state2.settings) + " min advance warning" : "At dose time only") + '</small></div><button class="icon-button" data-edit="' + h(m.id) + '" aria-label="Edit ' + h(m.name) + ' alarms">' + icon("edit", 18) + "</button></div>").join("") : '<p class="padded">Add a medication with a dose time to set up its alarms.</p>') + "</section>";
  }
  function historyPage(state2, period = "7") {
    const records = historyEntries(state2, period);
    const totals = { taken: 0, skipped: 0 };
    const days = /* @__PURE__ */ new Map();
    for (const [key3, r] of records) {
      totals[r.status]++;
      if (!days.has(r.day)) days.set(r.day, []);
      days.get(r.day).push([key3, r]);
    }
    const filters = [["7", "Last 7 days"], ["30", "Last 30 days"], ["all", "All history"]].map(([k, t]) => '<a href="#history/' + k + '" ' + (period === k ? 'aria-current="page"' : "") + ">" + t + "</a>").join("");
    const groups2 = [...days].map(([day2, entries]) => '<section class="history-day"><h2>' + h(dateLabel(localDay(day2), { dateStyle: "full" })) + "</h2>" + entries.map(([key3, r]) => '<article class="history-row"><div><b>' + h(r.name) + "</b>" + (r.dose ? " \xB7 " + h(r.dose) : "") + "<small>" + h(recordTiming(r)) + " \xB7 Logged " + h(recordClock(r)) + "</small>" + (r.legacy ? "<small>Earlier entry. Dose details were not saved.</small>" : "") + '</div><span class="dose-status ' + r.status + '">' + (r.status === "taken" ? "Taken" : "Skipped") + '</span><button class="text-link" data-log-undo="' + h(key3) + '" data-stamp="' + r.recordedAt + '">Undo</button></article>').join("") + "</section>").join("");
    return pageHead("Dose history", "Doses you have recorded on this device.", records.length ? btn("print-history", "Print / Save PDF", "print", "btn outline") : "") + '<section class="panel history-panel"><div class="filters">' + filters + '</div><div class="history-overview"><b>' + totals.taken + " taken</b><span>" + totals.skipped + " skipped</span><small>" + (period === "all" ? "All history" : "Last " + period + " days") + "</small></div>" + (groups2 || '<div class="empty-state">' + badge("history", "mint", 24) + '<h3>No doses recorded for this period</h3><p>Mark a scheduled dose as taken or skipped in Today. Your entries will appear here.</p><a class="text-link" href="#overview">Open daily pillbox ' + icon("arrow", 16) + "</a></div>") + "</section>";
  }

  // dosewell-interactions/interaction-checker.js
  var key2 = "dosewell.interaction-draft.v1";
  var groups = [["all", "All results"], ["drug", "Drug interactions"], ["duplicate", "Shared ingredients"], ["food", "Food and drink"], ["condition", "Health conditions"], ["unknown", "Unassessed pairs"]];
  var draft;
  function loadDraft() {
    if (draft) return draft;
    try {
      const stored = JSON.parse(sessionStorage.getItem(key2));
      if (Array.isArray(stored?.extra) && Array.isArray(stored?.hidden)) {
        draft = { extra: stored.extra.filter((n) => typeof n === "string" && n.trim() && n.length <= 240), hidden: stored.hidden.filter((id) => typeof id === "string") };
      }
    } catch {
    }
    return draft || (draft = { extra: [], hidden: [] });
  }
  function keepDraft() {
    try {
      sessionStorage.setItem(key2, JSON.stringify(draft));
    } catch {
    }
  }
  function includeSavedInCheck(id) {
    const current = loadDraft();
    current.hidden = current.hidden.filter((value) => value !== id);
    keepDraft();
  }
  function sourceLink(url) {
    return url ? '<a class="text-link" href="' + h(url) + '" target="_blank" rel="noopener noreferrer">' + (url.includes("medlineplus.gov") ? "Read MedlinePlus guidance" : "Read the DailyMed label") + " " + icon("go", 14) + "</a>" : "";
  }
  function profileText(name) {
    const profile = identify(name);
    if (!profile.matched) return "Name unrecognized. Check the spelling and formulation.";
    const form = profile.route === "other" ? " \xB7 Outside the oral warning list" : profile.route === "unspecified" ? " \xB7 Confirm the formulation" : "";
    return profile.components.join(" + ") + form;
  }
  function results(entries) {
    const pairs = compare(entries), notes2 = labelNotes(entries);
    const items = [];
    for (const pair of pairs) {
      const title = pair.a.name + " + " + pair.b.name;
      if (pair.hasGaps || !pair.details.length) items.push({ group: "unknown", title });
      for (const detail of pair.details) {
        items.push({ ...detail, group: detail.level === "duplicate" ? "duplicate" : "drug", title });
      }
    }
    return items.concat(notes2);
  }
  function reportItem(item) {
    if (item.group === "unknown") return '<li class="ic-unknown">' + h(item.title) + "</li>";
    const marker = warningLabel[item.level] || (item.group === "food" ? "Food and drink" : "If this condition applies");
    return '<li class="ic-finding ' + (item.level === "avoid" ? "ic-avoid" : "") + '"><span class="ic-marker">' + h(marker) + "</span><h4>" + h(item.title) + "</h4>" + (item.drug ? '<p class="ic-ingredient">' + h(item.drug) + "</p>" : item.ingredients ? '<p class="ic-ingredient">Ingredients reviewed \xB7 ' + h(item.ingredients.join(" + ")) + "</p>" : "") + "<p>" + h(item.reason) + "</p>" + sourceLink(item.source) + "</li>";
  }
  function showInteractionChecker(main2, state2) {
    const current = loadDraft();
    current.hidden = current.hidden.filter((id) => state2.meds.some((m) => m.id === id));
    let filter2 = "all", unknownLimit = 12, rows = [], findings = [];
    main2.innerHTML = '<div class="page-head"><div><h1>Drug interaction checker</h1><p>Review medicines together before adding something new to your routine.</p></div></div><div class="ic-layout"><section class="panel ic-list" aria-labelledby="ic-list-title"><h2 id="ic-list-title">Medicines to check</h2><p>Your saved medicines are included. Changes here apply only to this check.</p><form id="ic-form"><label for="ic-query">Drug or supplement name</label><div class="ic-input-row"><input id="ic-query" type="search" maxlength="240" autocomplete="off" placeholder="Enter a brand or generic name" aria-describedby="ic-hint"><button class="btn primary" type="submit">Add</button></div><small id="ic-hint">Choose a matching product or add the name as entered.</small></form><div id="ic-matches"></div><p id="ic-feedback" role="status"></p><ul id="ic-selection" aria-label="Selected medicines"></ul><div class="ic-list-actions"><button id="ic-check" class="btn primary" type="button">Check interactions</button><button id="ic-restore" class="text-link" type="button">Use my saved list</button><button id="ic-clear" class="text-link" type="button">Clear checker</button></div></section><section class="panel ic-results" aria-labelledby="ic-results-title"><h2 id="ic-results-title" tabindex="-1">Interaction report</h2><p>Dosewell checks ' + pairRuleCount + ' selected oral drug pairs. Other interactions may be missing, even for recognized medicines. Ask your pharmacist before changing a prescribed dose.</p><div id="ic-report"></div><details class="ic-coverage"><summary>Coverage and sources</summary><p>Search ' + catalogSize.toLocaleString("en-US") + " product names and forms from the November 2026 NLM RxTerms catalog. Dosewell screens " + pairRuleCount + " selected oral ingredient pairs using DailyMed labels and MedlinePlus guidance. An ingredient match identifies a medicine and does not establish safety.</p><p>Food and condition notes cover selected label precautions. They do not use your medical history. Dose, route, supplements and other health factors may change the risk.</p></details></section></div>";
    const el = (id) => main2.querySelector("#" + id);
    const input = el("ic-query"), matches = el("ic-matches"), feedback = el("ic-feedback"), report = el("ic-report");
    function drawReport() {
      const pairCount = rows.length * (rows.length - 1) / 2;
      const counts2 = {};
      for (const [id] of groups) counts2[id] = findings.filter((f) => f.group === id).length;
      const nav2 = groups.map(([id, label]) => '<button type="button" class="ic-filter" data-ic-filter="' + id + '" aria-pressed="' + (filter2 === id) + '">' + label + (id === "all" ? "" : " (" + counts2[id] + ")") + "</button>").join("");
      if (!rows.length) {
        report.innerHTML = '<p class="ic-empty">Add your first medicine. With two or more, Dosewell can compare the pairs.</p>';
        return;
      }
      let content = '<p class="ic-count">' + rows.length + " selected \xB7 " + pairCount + " possible " + (pairCount === 1 ? "pair" : "pairs") + '</p><div class="ic-filters" aria-label="Filter report">' + nav2 + "</div>";
      if (rows.length === 1) content += '<p class="ic-empty">Add a second medicine to check a combination.</p>';
      for (const [id, label] of groups.slice(1)) {
        if (filter2 !== "all" && filter2 !== id) continue;
        const items = findings.filter((x) => x.group === id);
        if (!items.length) {
          if (filter2 === id) content += '<p class="ic-empty">No entries in this category for the current selection. Coverage is limited to the listed rules and precautions.</p>';
          continue;
        }
        content += '<section class="ic-group"><h3>' + label + " <small>(" + items.length + ")</small></h3>";
        if (id === "unknown") content += "<p>At least part of each pair falls outside the available rules. A pharmacist can check the full combination.</p>";
        if (id === "condition") content += "<p>These are label precautions to discuss if the condition applies to you.</p>";
        content += "<ul>" + (id === "unknown" ? items.slice(0, unknownLimit) : items).map(reportItem).join("") + "</ul>";
        if (id === "unknown" && items.length > unknownLimit) content += '<button type="button" data-ic-more class="text-link">Show more (' + (items.length - unknownLimit) + " remaining)</button>";
        content += "</section>";
      }
      report.innerHTML = content;
    }
    function drawList() {
      rows = state2.meds.filter((m) => !current.hidden.includes(m.id)).map((m) => ({ ...m, saved: true })).concat(current.extra.map((name, index) => ({ id: "trial:" + index, name, saved: false, index })));
      const list = el("ic-selection");
      list.innerHTML = rows.map((m, i) => "<li><div><strong>" + h(m.name) + "</strong><small>" + h(profileText(m.name)) + '</small></div><button class="ic-remove" type="button" data-ic-remove="' + i + '" aria-label="Remove ' + h(m.name) + ' from this check">' + icon("close", 18) + "</button></li>").join("");
      el("ic-check").disabled = rows.length === 0;
      el("ic-clear").hidden = rows.length === 0;
      el("ic-restore").hidden = !state2.meds.length || !current.extra.length && !current.hidden.length;
      findings = results(rows);
      unknownLimit = 12;
      drawReport();
    }
    function add(name) {
      const value = name.trim();
      if (!value) {
        feedback.textContent = "Enter a medication name first.";
        input.focus();
        return;
      }
      if (rows.some((m) => m.name.toLowerCase() === value.toLowerCase())) {
        feedback.textContent = "This entry is already in the checker.";
        input.focus();
        return;
      }
      current.extra.push(value);
      filter2 = "all";
      keepDraft();
      drawList();
      input.value = "";
      matches.replaceChildren();
      feedback.textContent = value + " added.";
      input.focus();
    }
    function suggest() {
      feedback.textContent = "";
      matches.replaceChildren();
      if (input.value.trim().length < 2) return;
      const options = searchProducts(input.value);
      if (!options.length) {
        matches.textContent = "No matching product. You can still add the name for review.";
        return;
      }
      const list = document.createElement("ul");
      list.className = "ic-suggestions";
      list.setAttribute("aria-label", "Matching medicines");
      for (const p of options) {
        const li = document.createElement("li"), b = document.createElement("button");
        b.type = "button";
        b.textContent = p.display;
        b.onclick = () => add(p.display);
        li.append(b);
        list.append(li);
      }
      matches.append(list);
    }
    input.oninput = suggest;
    input.onkeydown = (e) => {
      if (e.key === "ArrowDown" && matches.querySelector("button")) {
        e.preventDefault();
        matches.querySelector("button").focus();
      } else if (e.key === "Escape") matches.replaceChildren();
    };
    matches.onkeydown = (e) => {
      const choices = [...matches.querySelectorAll("button")], idx = choices.indexOf(e.target);
      if (e.key === "Escape") {
        matches.replaceChildren();
        input.focus();
        return;
      }
      if (idx < 0 || !["ArrowDown", "ArrowUp"].includes(e.key)) return;
      e.preventDefault();
      const target = idx + (e.key === "ArrowDown" ? 1 : -1);
      (choices[target] || input).focus();
    };
    el("ic-form").onsubmit = (e) => {
      e.preventDefault();
      add(input.value);
    };
    el("ic-selection").onclick = (e) => {
      const b = e.target.closest("[data-ic-remove]");
      if (!b) return;
      const item = rows[Number(b.dataset.icRemove)];
      if (item.saved) current.hidden.push(item.id);
      else current.extra.splice(item.index, 1);
      filter2 = "all";
      keepDraft();
      drawList();
      input.focus();
      feedback.textContent = item.name + " removed from this check.";
    };
    el("ic-clear").onclick = () => {
      current.extra = [];
      current.hidden = state2.meds.map((m) => m.id);
      keepDraft();
      filter2 = "all";
      drawList();
      input.focus();
      feedback.textContent = "Checker cleared. Your medication plan is unchanged.";
    };
    el("ic-restore").onclick = () => {
      current.extra = [];
      current.hidden = [];
      keepDraft();
      filter2 = "all";
      drawList();
      input.focus();
      feedback.textContent = "Your current saved medication list is loaded.";
    };
    el("ic-check").onclick = () => {
      filter2 = "all";
      drawList();
      el("ic-results-title").focus();
      el("ic-results-title").scrollIntoView({ block: "start" });
    };
    report.onclick = (e) => {
      const b = e.target.closest("[data-ic-filter]");
      if (b) {
        filter2 = b.dataset.icFilter;
        drawReport();
        report.querySelector('[data-ic-filter="' + filter2 + '"]').focus();
        return;
      }
      if (e.target.closest("[data-ic-more]")) {
        const prior = unknownLimit;
        unknownLimit += 12;
        drawReport();
        const first = report.querySelectorAll(".ic-unknown")[prior];
        if (first) {
          first.tabIndex = -1;
          first.focus();
        }
      }
    };
    drawList();
  }

  // dosewell-interactions/label-reader.js
  var strengthPattern = /(?:\d+(?:\.\d+)?|\.\d+)\s*(?:mcg|µg|μg|mg|grams?|g|units?|iu|%)(?![a-z])(?:\s*\/\s*(?:\d+(?:\.\d+)?\s*)?(?:ml|l|hr|h|g|actuation|dose)\b)?/i;
  var directionStart = /^(?:(?:sig|directions?|instructions?)\s*:\s*)?(?:take|give|use|apply|inject|instill|place|inhale|chew|dissolve|insert|swallow)\b/i;
  var metadata = /\b(?:doctor|prescriber|patient|pharmacist|pharmacy|refills?|quantity|qty|ndc|discard|expires?|expiration|rx|store|warning|caution|manufacturer|birth|DOB)\b/i;
  var continuation = /^(?:by|on|as|at|for|with|without|before|after|every|each|once|twice|three|four|daily|weekly|morning|evening|night|and|then|if|until|except|do not|one|two|half|\d|mouth|needed|day|hours?|times?|tablets?|capsules?)\b/i;
  var variableDose = /\b(?:or|then|except|alternate|alternating|sliding|taper|increase|decrease|needed|prn|directed|if|and|up to|hold|follow)\b|\d\s*[-–]\s*\d/i;
  var amountPattern = /^(?:take|give|use|apply|inject|instill|place|inhale|chew|dissolve|insert|swallow)\s+((?:\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?|\.\d+|one[- ]half|one[- ]quarter|one|two|three|four|half|½|¼)\s*(?:tablets?|tabs?|capsules?|caps?|milliliters?|ml|mcg|mg|grams?|units?|puffs?|drops?|patch(?:es)?))\b/i;
  function fieldLine(line) {
    return line.replace(/^(?:(?:medication|drug|medicine)(?: name)?|name of drug)\s*:\s*/i, "");
  }
  function cleanLine(s) {
    return s.trim().replace(/\s+/g, " ");
  }
  function normalized(s) {
    return cleanLine(s).toLowerCase();
  }
  function looksLikeName(s) {
    return s.length >= 3 && s.length <= 80 && /^[a-z][a-z0-9]*(?:[ '-][a-z0-9]+){0,8}$/i.test(s) && !/\d$/.test(s) && !metadata.test(s) && !directionStart.test(s) && !/\b(?:strength|each|contains|maximum|per|tablet|tablets|bottle|ref|daily|generic for)\b/i.test(s);
  }
  function readLabel(text3, confidence = 100, weakLines = []) {
    const empty2 = { name: "", strength: "", dose: "", directions: "" };
    if (!Number.isFinite(confidence) || confidence < 60) return { fields: empty2, issue: "unclear" };
    const lines = text3.split(/\r?\n/).map(cleanLine).filter(Boolean);
    const weak = new Set(weakLines.map(normalized));
    const candidates = [];
    let uncertainProduct = false;
    for (let i = 0; i < lines.length; i++) {
      const line = fieldLine(lines[i]);
      if (metadata.test(line) || directionStart.test(line)) continue;
      const strength = line.match(strengthPattern);
      if (!strength) continue;
      let name = line.slice(0, strength.index).trim();
      let nameLine = lines[i];
      if (!name && i && ingredient(fieldLine(lines[i - 1]))) {
        name = fieldLine(lines[i - 1]);
        nameLine = lines[i - 1];
      }
      if (!looksLikeName(name)) {
        uncertainProduct = true;
        continue;
      }
      const tail = line.slice(strength.index + strength[0].length);
      if (/\d|^\s*[/+–-]/.test(tail)) {
        uncertainProduct = true;
        continue;
      }
      const formulation = /\b(?:extended[- ]release|delayed[- ]release|sustained[- ]release|controlled[- ]release|immediate[- ]release|enteric[- ]coated|XR|ER|SR|CR|DR|XL|EC|LA)\b/i.exec(tail);
      const printedStrength = formulation ? strength[0] + " " + formulation[0] : strength[0];
      candidates.push({ name, strength: printedStrength, weak: weak.has(normalized(lines[i])) || weak.has(normalized(nameLine)), index: i });
    }
    const distinct = new Set(candidates.map((c) => normalized(c.name + " " + c.strength)));
    if (distinct.size > 1 || uncertainProduct && candidates.length) return { fields: empty2, issue: "multiple" };
    const product = candidates[0];
    if (!product || product.weak) return { fields: empty2, issue: "unclear" };
    const fields = { ...empty2, name: product.name, strength: product.strength };
    const start = lines.findIndex((line, i) => i > product.index && directionStart.test(line));
    if (start < 0) return { fields, issue: "partial" };
    const sig = [lines[start].replace(/^(?:sig|directions?|instructions?)\s*:\s*/i, "")];
    let unsafe = weak.has(normalized(lines[start]));
    for (let i = start + 1; i < lines.length; i++) {
      const line = lines[i];
      if (metadata.test(line)) break;
      if (directionStart.test(line) || continuation.test(line)) {
        sig.push(line);
        unsafe || (unsafe = weak.has(normalized(line)) || directionStart.test(line));
      } else break;
    }
    const directions = sig.join(" ");
    if (unsafe || directions.length > 500) return { fields, issue: "partial" };
    fields.directions = directions;
    const amount = directions.match(amountPattern);
    if (amount && !variableDose.test(directions) && !/\b(?:take|give|use)\b/i.test(directions.slice(amount[0].length))) fields.dose = amount[1];
    return { fields, issue: fields.dose ? "" : "partial" };
  }

  // dosewell-interactions/scan.js
  var asset = (path) => new URL("./ocr/" + path, document.baseURI).href;
  var fieldNames = ["name", "strength", "dose", "directions"];
  var fieldTitles = { name: "Medication", strength: "Strength", dose: "Amount per dose", directions: "Directions" };
  var scanControls = '<section class="scan-panel" aria-labelledby="scan-heading"><h3 id="scan-heading">' + icon("camera", 20) + 'Scan a prescription label</h3><p>Photograph one English label with the name, strength, and directions in focus. The photo stays on this device.</p><div class="scan-actions"><button id="take-label" class="btn small outline" type="button">' + icon("camera", 16) + 'Take photo</button><button id="choose-label" class="btn small outline" type="button">' + icon("image", 16) + 'Choose photo</button><button id="stop-scan" type="button" class="btn small outline" hidden>Cancel scan</button></div><input type="file" id="camera-file" accept="image/*" capture="environment" hidden><input type="file" id="label-file" accept="image/*" hidden><div id="camera-view" hidden><video muted playsinline autoplay aria-label="Camera preview"></video><button type="button" id="capture-label" class="btn primary">Use this photo</button></div><p id="scan-status" role="status" aria-live="polite"></p><div id="scan-suggestion" hidden></div><details id="label-preview" hidden><summary>View label photo</summary></details></section>';
  function toCanvas(image, width, height) {
    if (!width || !height) throw Error("The photo could not be opened. Try a JPEG or PNG image.");
    const scale = Math.min(1, 2200 / Math.max(width, height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw Error("This browser cannot read the photo. You can enter the label below.");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", "Prescription label photo, available until the form closes");
    return canvas;
  }
  async function fileCanvas(file) {
    if (file.size > 32 * 1024 * 1024) throw Error("This photo is too large. Choose a smaller photo under 32 MB.");
    if (file.type === "image/svg+xml" || file.type && !file.type.startsWith("image/")) throw Error("Choose a photo such as JPEG or PNG.");
    const url = URL.createObjectURL(file), img = new Image();
    try {
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = () => reject(Error("This photo format could not be opened. Try a JPEG, PNG, or screenshot."));
        img.src = url;
      });
      return toCanvas(img, img.naturalWidth, img.naturalHeight);
    } finally {
      URL.revokeObjectURL(url);
    }
  }
  function attachScanner(dialog2, form) {
    const byId = (id) => form.querySelector("#" + id);
    const take = byId("take-label"), choose = byId("choose-label"), stop = byId("stop-scan");
    const preview = byId("label-preview"), suggest = byId("scan-suggestion"), message = byId("scan-status");
    const camera = byId("camera-view"), video = camera.querySelector("video");
    const review = byId("scan-review"), check = review.querySelector("input");
    const save2 = form.querySelector("[type=submit]");
    let generation = 0, worker = null, stream = null, timer = null, disposed = false;
    const valid = (id) => id === generation && !disposed && dialog2.open && form.isConnected;
    function endCamera() {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      stream = null;
      video.srcObject = null;
      camera.hidden = true;
    }
    function endJob() {
      clearTimeout(timer);
      endCamera();
      if (worker) {
        worker.terminate().catch(() => {
        });
        worker = null;
      }
    }
    function busy(value) {
      take.disabled = value;
      choose.disabled = value;
      stop.hidden = !value;
      save2.disabled = value;
    }
    function clearSuggestion() {
      suggest.replaceChildren();
      suggest.hidden = true;
    }
    function cancel(status = "Scan canceled. You can enter the label below.") {
      generation++;
      endJob();
      busy(false);
      clearSuggestion();
      message.textContent = status;
    }
    function dispose() {
      if (disposed) return;
      disposed = true;
      cancel("");
      preview.querySelector("canvas")?.remove();
      window.removeEventListener("pagehide", dispose);
      dialog2.removeEventListener("close", dispose);
    }
    dialog2.addEventListener("close", dispose, { once: true });
    window.addEventListener("pagehide", dispose, { once: true });
    stop.onclick = () => cancel();
    for (const key3 of fieldNames) form.elements.namedItem(key3).addEventListener("input", () => {
      if (!review.hidden) check.checked = false;
    });
    function apply(fields) {
      for (const key3 of fieldNames) form.elements.namedItem(key3).value = fields[key3];
      check.checked = false;
      check.required = true;
      review.hidden = false;
      clearSuggestion();
      message.textContent = "Fields filled. Compare them with the label, complete any blanks, and choose the schedule below.";
      form.elements.namedItem("name").focus({ preventScroll: true });
    }
    function finishScan(result) {
      if (!result.fields.name) {
        message.textContent = result.issue === "multiple" ? "There may be more than one medicine or strength. Photograph one label or enter its details below." : "The name or strength could not be read clearly. Try a closer photo, or enter the details below.";
        return;
      }
      if (!fieldNames.some((key3) => form.elements.namedItem(key3).value.trim())) {
        apply(result.fields);
        return;
      }
      message.textContent = "Review this scan before replacing the medication fields you already entered.";
      const dl = document.createElement("dl");
      for (const key3 of fieldNames) {
        const dt = document.createElement("dt"), dd = document.createElement("dd");
        dt.textContent = fieldTitles[key3];
        dd.textContent = result.fields[key3] || "Enter manually";
        dl.append(dt, dd);
      }
      const replace = document.createElement("button"), keep = document.createElement("button");
      replace.type = keep.type = "button";
      replace.className = "btn small primary";
      keep.className = "btn small outline";
      replace.textContent = "Use scanned fields";
      keep.textContent = "Keep my entries";
      replace.onclick = () => apply(result.fields);
      keep.onclick = () => {
        clearSuggestion();
        message.textContent = "Your existing entries were kept.";
      };
      suggest.replaceChildren(dl, replace, keep);
      suggest.hidden = false;
    }
    async function recognize(canvas, id) {
      if (!valid(id)) return;
      preview.querySelector("canvas")?.remove();
      preview.append(canvas);
      preview.hidden = false;
      preview.open = false;
      message.textContent = "Preparing the label reader\u2026";
      const { default: ocr } = await import("./ocr/tesseract.esm.min.js");
      if (!valid(id)) return;
      const initialized = await ocr.createWorker("eng", ocr.OEM.LSTM_ONLY, {
        workerPath: asset("worker.min.js"),
        workerBlobURL: false,
        corePath: asset("").replace(/\/$/, ""),
        langPath: asset("").replace(/\/$/, ""),
        errorHandler: () => {
        },
        logger: (step) => {
          if (valid(id) && step.status === "recognizing text") {
            const percent = Math.round(step.progress * 10) * 10;
            const note = "Reading the label\u2026 " + percent + "%";
            if (message.textContent !== note) message.textContent = note;
          }
        }
      });
      if (!valid(id)) {
        await initialized.terminate();
        return;
      }
      worker = initialized;
      const { data } = await worker.recognize(canvas, { rotateAuto: true }, { text: true, blocks: true });
      if (!valid(id)) return;
      const weak = [];
      for (const block of data.blocks || []) for (const para of block.paragraphs || []) for (const line of para.lines || []) {
        if (line.words?.some((w) => /[a-z0-9]/i.test(w.text) && w.confidence < 63)) weak.push(line.text);
      }
      finishScan(readLabel(data.text, data.confidence, weak));
    }
    async function scan2(getCanvas) {
      const id = ++generation;
      endJob();
      clearSuggestion();
      busy(true);
      check.checked = false;
      message.textContent = "Opening the photo\u2026";
      timer = setTimeout(() => {
        if (valid(id)) cancel("The scan took too long. Try a smaller, clearer photo or enter the label below.");
      }, 9e4);
      try {
        await recognize(await getCanvas(), id);
      } catch (err) {
        if (valid(id)) message.textContent = err instanceof Error && /^(This (photo|browser)|The photo|Choose a photo)/.test(err.message) ? err.message : "The label reader could not finish. Try another photo or enter the label below.";
      } finally {
        if (valid(id)) {
          endJob();
          busy(false);
        }
      }
    }
    for (const input of [byId("camera-file"), byId("label-file")]) {
      input.onchange = () => {
        const file = input.files[0];
        input.value = "";
        if (file) scan2(() => fileCanvas(file));
      };
    }
    choose.onclick = () => byId("label-file").click();
    take.onclick = async () => {
      if (navigator.maxTouchPoints > 0 || !navigator.mediaDevices?.getUserMedia) {
        byId("camera-file").click();
        return;
      }
      const id = ++generation;
      endJob();
      clearSuggestion();
      busy(true);
      message.textContent = "Allow camera access and center one label.";
      try {
        const live = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1440 } }, audio: false });
        if (!valid(id)) {
          live.getTracks().forEach((t) => t.stop());
          return;
        }
        stream = live;
        video.srcObject = stream;
        camera.hidden = false;
        await video.play();
        if (valid(id)) message.textContent = "When the label is sharp, select Use this photo.";
      } catch {
        if (valid(id)) cancel("The camera is unavailable. Choose a saved photo or enter the label below.");
      }
    };
    byId("capture-label").onclick = () => {
      if (!video.videoWidth) {
        message.textContent = "Wait for the camera preview to appear.";
        return;
      }
      const canvas = toCanvas(video, video.videoWidth, video.videoHeight);
      scan2(() => canvas);
    };
  }

  // dosewell-interactions/form.js
  function timeRow(t = "") {
    return '<div class="time-row"><input type="time" aria-label="Dose time" name="times" required value="' + h(t) + '"><button type="button" class="icon-button" data-remove-time aria-label="Remove dose time">' + icon("close", 16) + "</button></div>";
  }
  var hourChoices = [...Array.from({ length: 24 }, (_, i) => i + 1), 36, 48, 72];
  function intervalOptions(value) {
    return '<option value="">Choose hours</option>' + hourChoices.map((n) => '<option value="' + n + '" ' + (n === value ? "selected" : "") + ">" + hoursLabel(n) + "</option>").join("");
  }
  function intervalSettings(original, date, time, hours, end) {
    if (!date || !time || !hourChoices.includes(hours)) return null;
    const typed = /* @__PURE__ */ new Date(date + "T" + time + ":00");
    if (!Number.isFinite(typed.getTime()) || dayKey(typed) !== date || clockTime(typed) !== time) return null;
    const originalStart = original?.mode === "interval" ? new Date(original.anchorAt) : null;
    const anchorAt = originalStart && dayKey(originalStart) === date && clockTime(originalStart) === time ? original.anchorAt : typed.getTime();
    let untilAt = null;
    if (end) {
      untilAt = original?.untilAt && dayKey(new Date(original.untilAt - 1)) === end ? original.untilAt : (/* @__PURE__ */ new Date(shiftDay(end, 1) + "T00:00:00")).getTime();
      if (!Number.isFinite(untilAt) || untilAt <= anchorAt) return null;
    }
    return { anchorAt, untilAt, intervalHours: hours };
  }
  function showEditor(dialog2, med, category, settings, onSave, onRemove) {
    const existing = med?.mode === "interval" ? { ...med, start: dayKey(new Date(med.anchorAt)), times: [clockTime(new Date(med.anchorAt))], end: med.untilAt == null ? "" : dayKey(new Date(med.untilAt - 1)) } : med;
    const m = existing || { category, name: "", dose: "", mode: category === "other" ? "list" : "daily", times: [""], days: [0, 1, 2, 3, 4, 5, 6], start: dayKey(/* @__PURE__ */ new Date()), end: "", advance: null };
    dialog2.innerHTML = '<div class="modal-head"><div><h2 id="dialog-title">' + (med ? "Edit medication" : "Add medication") + "</h2><p>Use the dose and schedule on your current label.</p></div>" + btnIcon("close", "Close dialog", "close") + '</div><form id="med-form" class="med-form">' + (med ? "" : scanControls) + '<fieldset><legend>Medication group</legend><div class="group-picker">' + ["stroke", "other"].map((c) => '<label><input type="radio" name="category" value="' + c + '" ' + (m.category === c ? "checked" : "") + "><span>" + icon(c === "stroke" ? "heart" : "pill", 17) + (c === "stroke" ? "Stroke medication" : "Other medication") + "</span></label>").join("") + '</div></fieldset><label>Medication name<input name="name" list="drug-names" autocomplete="off" placeholder="Name on the label" maxlength="120" required value="' + h(m.name) + '"></label><datalist id="drug-names">' + suggestions.map((s) => '<option value="' + h(s[0].toUpperCase() + s.slice(1)) + '"></option>').join("") + '</datalist><label>Strength on label <small>(optional)</small><input name="strength" maxlength="100" placeholder="Amount per tablet or concentration" value="' + h(m.strength) + '"></label><label>Dose per administration<input name="dose" maxlength="140" placeholder="Amount and unit from your label" required value="' + h(m.dose) + '"></label><label>Label directions <small>(optional)</small><textarea name="directions" maxlength="500" rows="2" placeholder="Instructions printed on the label">' + h(m.directions) + '</textarea></label><label>Schedule<select name="mode">' + [["daily", "Every day"], ["interval", "Every X hours"], ["weekly", "Selected days of the week"], ["list", "List only / as needed"]].map(([v, t]) => '<option value="' + v + '" ' + (m.mode === v ? "selected" : "") + ">" + t + "</option>").join("") + '</select></label><div class="schedule-fields"><fieldset id="weekdays"><legend>Days of the week</legend><div class="days-input">' + dayNames.map((n, i) => '<label><input type="checkbox" name="days" value="' + i + '" ' + (m.days.includes(i) ? "checked" : "") + "><span>" + n + "</span></label>").join("") + '</div></fieldset><fieldset id="fixed-times"><legend>Dose times</legend><div id="time-inputs">' + (m.times.length ? m.times : [""]).map(timeRow).join("") + '</div><button type="button" class="text-link add-time" id="add-time">' + icon("plus", 14) + 'Add another time</button><button type="button" class="text-link interval-shortcut" id="choose-interval">' + icon("clock", 14) + 'Use an hourly interval</button></fieldset><fieldset id="interval-fields" hidden><legend>Dose times</legend><div class="interval-grid"><label>Repeat every<select name="intervalHours" required>' + intervalOptions(m.intervalHours) + '</select></label><label>First dose time<input type="time" name="firstTime" required value="' + h(m.times[0] || "") + '"></label></div><p class="form-tip">The interval repeats around the clock from your first dose.</p></fieldset><label>Advance warning<select name="warning-mode"><option value="default" ' + (m.advance === null ? "selected" : "") + ">Use default (" + settings.advance + ' min)</option><option value="custom" ' + (m.advance > 0 ? "selected" : "") + '>Custom warning</option><option value="off" ' + (m.advance === 0 ? "selected" : "") + '>At dose time only</option></select></label><label id="custom-warning">Minutes before dose<input type="number" min="1" max="1440" step="1" required name="advance" value="' + (m.advance || 15) + '"></label><div class="date-inputs"><label><span id="start-label">Start date</span><input type="date" name="start" required value="' + h(m.start) + '"></label><label>End date <small>(optional)</small><input type="date" name="end" value="' + h(m.end) + '"></label></div><div id="interval-preview" class="interval-preview" aria-live="polite" hidden></div><p class="form-tip">' + icon("info", 16) + "Alarms use this device\u2019s local time. For alerts with the site closed, choose Set up phone reminders after saving.</p></div>" + (med ? "" : '<label id="scan-review" class="scan-review" hidden><input type="checkbox">I checked the medication name, strength, dose, and directions against the label.</label>') + '<p id="form-error" class="error" role="alert" hidden></p><div class="form-buttons">' + (med ? '<button class="danger-text" type="button" id="remove-med">Remove</button>' : "") + '<button type="button" class="btn outline" data-action="close">Cancel</button><button type="submit" class="btn primary">Save medication</button></div></form>';
    const form = dialog2.querySelector("form");
    const f = form.elements;
    if (!med) attachScanner(dialog2, form);
    const fixed = form.querySelector("#fixed-times"), interval = form.querySelector("#interval-fields"), preview = form.querySelector("#interval-preview");
    function updatePreview() {
      preview.hidden = f.mode.value !== "interval";
      if (preview.hidden) return;
      const settings2 = intervalSettings(med, f.start.value, f.firstTime.value, Number(f.intervalHours.value), f.end.value);
      if (!settings2) {
        preview.textContent = "Choose the interval, first dose date, and first dose time to preview your schedule.";
        return;
      }
      const draft2 = { ...settings2, mode: "interval", id: "preview" };
      const labels = [];
      let from = settings2.anchorAt;
      for (let i = 0; i < 4; i++) {
        const row = nextInterval(draft2, from);
        if (!row) break;
        labels.push(row.when.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }) + " \xB7 " + doseTimeLabel(row));
        from = row.when.getTime() + 1;
      }
      preview.innerHTML = "<b>First scheduled doses</b><ul>" + labels.map((t) => "<li>" + h(t) + "</li>").join("") + "</ul>";
    }
    function sync() {
      const scheduled = f.mode.value !== "list", weekly = f.mode.value === "weekly", custom = f["warning-mode"].value === "custom";
      const fields = form.querySelector(".schedule-fields");
      fields.hidden = !scheduled;
      fields.querySelectorAll("input, select, button").forEach((el) => el.disabled = !scheduled);
      const hourly = f.mode.value === "interval";
      fixed.hidden = hourly;
      fixed.disabled = !scheduled || hourly;
      interval.hidden = !hourly;
      interval.disabled = !hourly;
      form.querySelector("#start-label").textContent = hourly ? "First dose date" : "Start date";
      form.querySelector("#weekdays").hidden = !weekly;
      form.querySelector("#custom-warning").hidden = !custom;
      f.advance.disabled = !scheduled || !custom;
      f.end.min = f.start.value;
      const rows = form.querySelectorAll(".time-row");
      rows.forEach((row) => row.querySelector("button").hidden = rows.length === 1);
      updatePreview();
    }
    function error(msg) {
      const e = form.querySelector("#form-error");
      e.hidden = !msg;
      e.textContent = msg;
    }
    form.addEventListener("change", (e) => {
      if (e.target.name === "category" && !med && form.dataset.modeSet !== "1") f.mode.value = e.target.value === "other" ? "list" : "daily";
      if (e.target.name === "mode") {
        form.dataset.modeSet = "1";
        if (f.mode.value === "interval" && !f.firstTime.value) f.firstTime.value = form.querySelector("[name=times]")?.value || "";
      }
      sync();
      error("");
    });
    form.querySelector("#choose-interval").onclick = () => {
      f.mode.value = "interval";
      f.mode.dispatchEvent(new Event("change", { bubbles: true }));
      f.intervalHours.focus();
    };
    form.addEventListener("input", (e) => {
      if (["firstTime", "intervalHours", "start", "end"].includes(e.target.name)) updatePreview();
    });
    form.querySelector("#add-time").onclick = () => {
      form.querySelector("#time-inputs").insertAdjacentHTML("beforeend", timeRow());
      sync();
      form.querySelector(".time-row:last-child input").focus();
    };
    form.addEventListener("click", (e) => {
      const r = e.target.closest("[data-remove-time]");
      if (r) {
        r.closest(".time-row").remove();
        sync();
      }
    });
    if (med) form.querySelector("#remove-med").onclick = () => onRemove(med);
    form.onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(form), mode = fd.get("mode");
      const name = fd.get("name").trim(), dose = fd.get("dose").trim();
      if (!name || !dose) {
        error("Enter the medication name and dose from the label.");
        return;
      }
      const times = mode === "list" ? [] : mode === "interval" ? [fd.get("firstTime")] : fd.getAll("times").sort();
      const days = mode === "weekly" ? fd.getAll("days").map(Number) : [0, 1, 2, 3, 4, 5, 6];
      if (!days.length) {
        error("Select at least one day for this schedule.");
        return;
      }
      if (new Set(times).size !== times.length) {
        error("Each dose time must be different.");
        return;
      }
      const start = mode === "list" ? m.start : fd.get("start"), end = mode === "list" ? "" : fd.get("end");
      if (end && end < start) {
        error("Choose an end date on or after the start date.");
        return;
      }
      const hourly = mode === "interval" ? intervalSettings(med, start, times[0], Number(fd.get("intervalHours")), end) : null;
      if (mode === "interval" && !hourly) {
        error("Choose an interval and a valid local first dose time. Check the start and end dates.");
        return;
      }
      const advance = mode === "list" || fd.get("warning-mode") === "default" ? null : fd.get("warning-mode") === "off" ? 0 : Number(fd.get("advance"));
      const save2 = form.querySelector('button[type="submit"]');
      save2.disabled = true;
      try {
        await onSave({ id: med?.id || crypto.randomUUID(), category: fd.get("category"), name, dose, strength: fd.get("strength").trim(), directions: fd.get("directions").trim(), mode, times, days, start, end, advance, ...hourly });
      } catch (err) {
        error(err.message);
        save2.disabled = false;
      }
    };
    sync();
    if (!dialog2.open) dialog2.showModal();
    dialog2.querySelector('[data-action="close"]').focus();
  }

  // dosewell-interactions/clock-bridge.js
  var keySpec = { name: "ECDSA", namedCurve: "P-256" };
  var utf8 = new TextEncoder();
  var currentIdentity;
  function base64url(bytes) {
    return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
  }
  async function openKeys() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("dosewell-clock-pairing", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("keys");
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function browserIdentity() {
    const db = await openKeys();
    try {
      const candidate = await crypto.subtle.generateKey(keySpec, false, ["sign", "verify"]);
      const pair = await new Promise((resolve, reject) => {
        const tx = db.transaction("keys", "readwrite");
        const store = tx.objectStore("keys");
        const read2 = store.get("browser");
        let selected2;
        read2.onsuccess = () => {
          selected2 = read2.result || candidate;
          if (!read2.result) store.put(selected2, "browser");
        };
        tx.oncomplete = () => resolve(selected2);
        tx.onabort = () => reject(tx.error);
      });
      const spki = await crypto.subtle.exportKey("spki", pair.publicKey);
      const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", spki));
      const code = Array.from(hash.slice(0, 4), (byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase();
      return { privateKey: pair.privateKey, pub: base64url(spki), code: code.slice(0, 4) + " " + code.slice(4) };
    } finally {
      db.close();
    }
  }
  function clockIdentity() {
    if (!currentIdentity) currentIdentity = browserIdentity().catch((error) => {
      currentIdentity = null;
      throw error;
    });
    return currentIdentity;
  }
  async function clockLink(identity, item, now = Date.now()) {
    const { entry, repeat } = item;
    const days = repeat ? entry.days.reduce((bits, d) => bits | 1 << d, 0) : 0;
    const nonce = base64url(crypto.getRandomValues(new Uint8Array(16)));
    const data = {
      v: 1,
      issued: now,
      nonce,
      at: entry.at.getTime(),
      hour: entry.at.getHours(),
      minute: entry.at.getMinutes(),
      days,
      label: "Dosewell \xB7 " + entry.label
    };
    const body = base64url(utf8.encode(JSON.stringify(data)));
    const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, identity.privateKey, utf8.encode(body));
    const fallback = encodeURIComponent(new URL("clock-install.html", document.baseURI).href);
    return "intent://alarm/set?p=" + body + "&s=" + base64url(signature) + "&k=" + identity.pub + "#Intent;scheme=dosewellclock;package=org.williamsindustries.dosewellclock;S.browser_fallback_url=" + fallback + ";end";
  }

  // dosewell-interactions/phone-alarms.js
  function nextAlert(state2, med, time, minutes, now) {
    let from = new Date(now.getTime() + minutes * 6e4);
    let dose = firstNext(med, time, from);
    while (dose && (state2.taken?.[med.id + "|" + dose.day + "|" + time] || state2.history?.[med.id + "|" + dose.day + "|" + time]?.status === "skipped")) {
      from = new Date(dose.when.getTime() + 1);
      dose = firstNext(med, time, from);
    }
    if (!dose) return null;
    const at = new Date(dose.when.getTime() - minutes * 6e4);
    const alarmDay = dayKey(at);
    const previousDay = alarmDay < dose.day;
    const days = med.days.map((day2) => (day2 + (previousDay ? 6 : 0)) % 7).sort((a, b) => a - b);
    const label = (minutes ? "Upcoming in " + minutes + " min: " : "Dose: ") + medicationTitle(med) + " \xB7 " + med.dose;
    let lastDay2 = med.end;
    if (lastDay2) {
      while (!med.days.includes(localDay(lastDay2).getDay())) lastDay2 = shiftDay(lastDay2, -1);
      const lastDose = /* @__PURE__ */ new Date(lastDay2 + "T" + time + ":00");
      lastDay2 = dayKey(new Date(lastDose.getTime() - minutes * 6e4));
    }
    return {
      key: [med.id, time, minutes, alarmDay].join("|"),
      at,
      label,
      minutes,
      days,
      name: medicationTitle(med),
      dose: med.dose,
      doseTime: time,
      time: pad(at.getHours()) + ":" + pad(at.getMinutes()),
      until: lastDay2
    };
  }
  function intervalAlerts(state2, med, minutes, now) {
    const entries = [];
    const margin = minutes * 6e4, limit = now.getTime() + 864e5;
    let next = nextInterval(med, now.getTime() + margin);
    while (next) {
      const at = new Date(next.when.getTime() - margin);
      const outsideWindow = at.getTime() >= limit;
      if (outsideWindow && entries.length) break;
      if (!state2.taken?.[next.key] && state2.history?.[next.key]?.status !== "skipped") {
        entries.push({
          key: next.key + "|" + minutes,
          at,
          minutes,
          oneTime: true,
          label: (minutes ? "Upcoming in " + minutes + " min: " : "Dose: ") + medicationTitle(med) + " \xB7 " + med.dose,
          name: medicationTitle(med),
          dose: med.dose,
          doseTime: next.time,
          doseDay: next.day,
          time: clockTime(at)
        });
        if (outsideWindow) break;
      }
      next = nextInterval(med, next.when.getTime() + 1);
    }
    return entries;
  }
  function phoneAlarms(state2, now = /* @__PURE__ */ new Date()) {
    const alarms = [];
    for (const med of state2.meds) {
      if (med.mode === "list") continue;
      const warning = advanceMinutes(med, state2.settings);
      if (med.mode === "interval") {
        alarms.push(...intervalAlerts(state2, med, 0, now));
        if (warning > 0) alarms.push(...intervalAlerts(state2, med, warning, now));
        continue;
      }
      for (const time of med.times) {
        for (const minutes of warning > 0 ? [warning, 0] : [0]) {
          const entry = nextAlert(state2, med, time, minutes, now);
          if (entry) alarms.push(entry);
        }
      }
    }
    return alarms.sort((a, b) => a.at - b.at || a.name.localeCompare(b.name));
  }
  function clockCanSet(entry, now = /* @__PURE__ */ new Date()) {
    const next = new Date(now);
    next.setHours(entry.at.getHours(), entry.at.getMinutes(), 0, 0);
    if (next < now) next.setDate(next.getDate() + 1);
    return entry.at.getTime() === next.getTime();
  }
  function phoneHandoff(entry, platform, now = /* @__PURE__ */ new Date()) {
    if (!clockCanSet(entry, now)) return null;
    if (platform === "apple") {
      const input = entry.time + "\n" + entry.label;
      return "shortcuts://run-shortcut?name=Dosewell%20Alarm&input=text&text=" + encodeURIComponent(input);
    }
    return null;
  }
  function alarmTimeLabel(entry) {
    return entry.oneTime ? entry.at.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" }) : timeLabel(entry.time);
  }
  function repeatText(entry) {
    if (entry.oneTime) return "One time (Repeat off)";
    return entry.days.length === 7 ? "Every day" : entry.days.map((d) => dayNames[d]).join(", ");
  }
  function readableDate(day2) {
    return localDay(day2).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  }
  function alarmText(entry) {
    return [
      entry.label,
      "Alarm time: " + alarmTimeLabel(entry),
      "Next: " + readableDate(dayKey(entry.at)),
      "Repeat: " + repeatText(entry),
      ...entry.until ? ["Last alarm date: " + readableDate(entry.until)] : []
    ].join("\n");
  }
  function alarmFile(entries) {
    return "Dosewell phone alarms\nLocal device time\n\n" + entries.map(alarmText).join("\n\n") + (entries.some((e) => e.oneTime) ? "\n\nHourly schedules use dated, one-time alarms for the next 24 hours (or the next upcoming alert if later). Export to Calendar for the complete repeating schedule." : "") + "\n\nConfirm each time, label and repeat schedule in Clock. Remove alarms after the last scheduled date or if the prescription changes.\n";
  }

  // dosewell-interactions/android-clock.js
  var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  var button = (title, cls = "btn small outline") => {
    const el = document.createElement("button");
    el.type = "button";
    el.className = cls;
    el.textContent = title;
    return el;
  };
  var text2 = (tag, value) => {
    const el = document.createElement(tag);
    el.textContent = value;
    return el;
  };
  function canRepeat(entry, now) {
    if (entry.oneTime || entry.until || !entry.days?.length) return false;
    const [hour, minute] = entry.time.split(":").map(Number);
    for (let offset = 0; offset <= 7; offset++) {
      const next = new Date(now);
      next.setDate(next.getDate() + offset);
      next.setHours(hour, minute, 0, 0);
      if (next >= now && entry.days.includes(next.getDay())) return next.getTime() === entry.at.getTime();
    }
    return false;
  }
  function androidRequests(state2, now = /* @__PURE__ */ new Date()) {
    return phoneAlarms(state2, now).map((entry) => {
      const repeat = canRepeat(entry, now);
      const schedule2 = repeat ? entry.days.length === 7 ? "every day" : "every " + entry.days.map((d) => weekdays[d]).join(" and ") : "once on " + readableDate(dayKey(entry.at));
      const label = "Dosewell \xB7 " + entry.label;
      const clock2 = entry.at.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
      const zone = entry.at.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" });
      const request = "Set an alarm on this phone at " + (repeat ? clock2 : zone) + " " + schedule2 + " named " + JSON.stringify(label) + ".";
      return { entry, schedule: schedule2, repeat, request };
    });
  }
  function androidSetupText(items) {
    if (!items.length) return "";
    const prefix = "Use the Clock app on this phone. Keep any alarm that already matches. If exactly one existing alarm and one requested repeating alarm share the same Dosewell name, update its time and repeat days. If a match is ambiguous, ask me before changing it. Leave other alarms alone.";
    return [prefix, ...items.map((r) => r.request), "Show me which alarms you set and flag any you could not create."].join("\n");
  }
  function showAndroidClock(container, getState, { allowShare = true } = {}) {
    const render2 = () => {
      const now = /* @__PURE__ */ new Date(), items = androidRequests(getState(), now);
      container.replaceChildren();
      if (!items.length) {
        container.append(text2("p", "There are no future scheduled doses to set in Clock."));
        return;
      }
      const native = document.createElement("section");
      const app = text2("a", "Get alarms from the Dosewell app");
      app.href = "./mobile-apps.html";
      app.className = "text-link";
      native.append(app, text2("h3", "Send an alarm to Android Clock"));
      const install = text2("a", "Download Dosewell Clock for Android");
      install.href = "./dosewell-clock.apk";
      install.download = "dosewell-clock.apk";
      install.className = "btn outline";
      native.append(text2("p", "On your Android phone, open the download and confirm installation once. Return here and tap a dose or warning to send it to Clock."), install);
      const connection = text2("p", "");
      connection.setAttribute("role", "status");
      native.append(connection);
      if (items.some((r) => !r.repeat)) native.append(text2("p", "Hourly reminders are individual alarms for the upcoming 24 hours. A course with an end date uses individual alarms for each upcoming time. Return for later alarms."));
      const links = [];
      for (const item of items) {
        const { entry } = item, card = document.createElement("article");
        card.className = "phone-entry";
        card.append(text2("b", entry.label), text2("p", alarmTimeLabel(entry) + " \xB7 " + item.schedule));
        if (item.repeat || clockCanSet(entry, now)) {
          const link = text2("a", "Set in Android Clock");
          link.className = "btn small primary";
          link.setAttribute("aria-label", "Set in Android Clock: " + entry.label + " at " + alarmTimeLabel(entry));
          link.hidden = true;
          link.onclick = (event) => {
            const current = androidRequests(getState()).find((r) => r.entry.key === entry.key && r.request === item.request);
            if (!current || !current.repeat && !clockCanSet(current.entry) || Date.now() - Number(link.dataset.issued) > 24e4) {
              event.preventDefault();
              render2();
              return;
            }
            connection.textContent = "If this is your first alarm, match the code " + link.dataset.code + " in Dosewell Clock. Check the alarm in Clock after the handoff.";
          };
          links.push({ link, item });
          card.append(link);
        } else card.append(text2("p", "This alarm starts later. Return closer to the date shown to add it to Clock."));
        native.append(card);
      }
      container.append(native);
      if (links.length) {
        const refresh = async () => {
          try {
            const identity = await clockIdentity(), issued = Date.now();
            await Promise.all(links.map(async ({ link, item }) => {
              link.href = await clockLink(identity, item, issued);
              link.dataset.issued = String(issued);
              link.dataset.code = identity.code;
              link.hidden = false;
            }));
            connection.textContent = "For the first alarm, match " + identity.code + " in the companion and approve. When a schedule changes, review older alarms in Clock.";
            setTimeout(() => {
              if (native.isConnected && native.closest("dialog:not([open])") === null) refresh();
            }, 18e4);
          } catch {
            connection.textContent = "This browser could not save a connection. Open Dosewell in Chrome on Android or use the other setup options below.";
          }
        };
        refresh();
      }
      const alternate = document.createElement("details");
      alternate.className = "export-guide";
      alternate.append(text2("summary", "Other ways to set up Clock"));
      container.append(alternate);
      const steps = document.createElement("ol");
      steps.className = "clock-steps";
      steps.append(text2("li", "Copy the alarm request below."), text2("li", "Open the Gemini mobile app on your phone, paste the request, and submit it. On Galaxy, you can also say an individual request to Bixby."), text2("li", "Open Clock \u2192 Alarm. Verify each dose time, advance warning, repeat day, and enabled switch. If an alarm is missing, use its individual request below. Review old Dosewell alarms after a schedule change."));
      const feedback = text2("p", "");
      feedback.setAttribute("role", "status");
      const display = document.createElement("textarea");
      display.readOnly = true;
      display.rows = 5;
      display.className = "transfer-copy";
      display.hidden = true;
      display.setAttribute("aria-label", "Text to copy");
      const copy = async (value, ok) => {
        try {
          await navigator.clipboard.writeText(value);
          feedback.textContent = ok;
          display.hidden = true;
        } catch {
          display.value = value;
          display.hidden = false;
          display.focus();
          display.select();
          feedback.textContent = "The text is selected. Choose Copy on your phone.";
        }
      };
      const copyAll = button("Copy Clock setup request", "btn primary");
      copyAll.onclick = () => {
        const current = androidRequests(getState());
        if (current.map((r) => r.entry.key).join("|") !== items.map((r) => r.entry.key).join("|") || androidSetupText(current) !== androidSetupText(items)) {
          render2();
          return;
        }
        copy(androidSetupText(current), "Copied. Paste into Gemini on your phone and submit, then check Clock.");
      };
      alternate.append(text2("p", "Downloading an .ics file adds calendar events when imported. Android Clock needs its own alarms."), steps, copyAll);
      container.append(feedback, display);
      alternate.append(text2("p", "The request includes the medication names, doses, and times shown below. Your phone assistant receives them when you paste or speak the request."));
      if (items.some((r) => !r.repeat)) alternate.append(text2("p", "Dated alarms are one-time entries. For an hourly schedule, this list covers the next 24 hours, or the first upcoming alert if later. For a course with an end date, it shows the next alarm for each scheduled time. Return here for later alarms."));
      const individual = document.createElement("details");
      individual.className = "export-guide";
      individual.open = items.length <= 3;
      individual.append(text2("summary", "Individual alarm requests (" + items.length + ")"));
      for (const item of items) {
        const { entry } = item, card = document.createElement("article");
        card.className = "phone-entry";
        card.append(text2("div", alarmTimeLabel(entry)), text2("b", entry.label), text2("p", item.schedule[0].toUpperCase() + item.schedule.slice(1)));
        const details = document.createElement("details");
        details.className = "export-guide";
        details.append(text2("summary", "View or copy this alarm"), text2("p", item.request));
        const single = button("Copy this alarm");
        single.onclick = () => {
          const current = androidRequests(getState()).find((r) => r.entry.key === entry.key && r.request === item.request);
          if (!current) {
            render2();
            return;
          }
          copy(current.request, "Alarm request copied. Paste or say it to your phone assistant.");
        };
        details.append(single);
        card.append(details);
        individual.append(card);
      }
      alternate.append(individual);
      const manual = document.createElement("details");
      manual.className = "export-guide";
      manual.append(text2("summary", "Set an alarm directly in Clock"), text2("p", "Open Clock \u2192 Alarm. Tap an existing alarm to update it, or tap + to add one. Enter the time, choose the repeat days, paste or type the label, and save. Set advance warnings as separate alarms."));
      alternate.append(manual);
      if (allowShare) {
        const send = button("Share Clock setup link");
        send.onclick = async () => {
          const link = transferLink(getState(), document.baseURI);
          if (!link) {
            feedback.textContent = "The full schedule does not fit in a setup link. Use the Clock requests on this device.";
            feedback.scrollIntoView({ block: "nearest" });
            return;
          }
          const url = new URL(link);
          url.searchParams.set("setup", "clock");
          if (navigator.share) {
            try {
              await navigator.share({ title: "Dosewell Clock setup", url: url.href });
              return;
            } catch (error) {
              if (error.name === "AbortError") return;
            }
          }
          await copy(url.href, "Clock setup link copied. Paste it into a message to your phone.");
          feedback.scrollIntoView({ block: "nearest" });
        };
        container.append(text2("p", "To open this setup on another phone, share the link with its intended recipient. Anyone with it can read these reminders."), send);
      }
    };
    render2();
  }

  // dosewell-interactions/exports.js
  var shortcutHelp = '<details class="export-guide"><summary>Set up the iPhone shortcut once</summary><ol><li>In Shortcuts, create a shortcut named <b>Dosewell Alarm</b>.</li><li>Add <b>Split Text</b>. Set the input to <b>Shortcut Input</b> and the separator to <b>New Lines</b>.</li><li>Add <b>Get Item from List</b> twice. Use the split text list for both actions. Get the first item for the time and the last item for the label.</li><li>Add <b>Create Alarm</b>. For the time, choose the first item. For the label, choose the last item. Leave Repeat set to Never. Save your shortcut.</li></ol><p>Choose <b>Send to Shortcuts</b> for each alarm. Open Clock to verify it and set any repeat days. For a simpler setup, ask Siri to set an alarm at the time shown and give it the medication label.</p></details>';
  function download(name, type, text3) {
    const url = URL.createObjectURL(new Blob([text3], { type }));
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 6e4);
  }
  function calendarOptions(state2, openDialog2) {
    const cal = calendarFile(state2);
    if (!cal.count) {
      openDialog2("Calendar reminders", '<p>Add a medication with a future dose time to create a reminder file.</p><button class="btn primary" data-action="add-stroke">Add medication</button>');
      return;
    }
    openDialog2("Calendar reminders", '<p>The .ics file is for your calendar. Downloading or texting it does not add or update Android Clock alarms. To create Clock alarms, choose Android Clock setup.</p><div class="export-choices"><button class="btn primary" data-action="text-reminders">' + icon("message", 18) + 'Text to a phone</button><button class="btn outline" data-action="export">' + icon("calendar", 18) + 'Get calendar file (.ics)</button></div><p class="transfer-privacy">The file and reminder link include medication names, doses, and times. Anyone who receives them can read the schedule.</p><p id="calendar-feedback" role="status"></p><details class="export-guide"><summary>How to add the alerts</summary><p>In Messages, choose the phone number and tap Send. On the receiving phone, open the attachment or reminder link and confirm the calendar import. Check a dose alert and its advance warning.</p><p>Apple Mail can import an .ics attachment on iPhone. For Google Calendar, import the file on a computer into the calendar that syncs to your Android phone. Other calendar apps may open the file directly.</p><p>This file is a snapshot. Replace the old events when the schedule changes. Calendar alerts and Clock alarms are managed separately on your phone.</p></details><div class="export-choices"><button class="btn outline" data-action="android-clock">Android Clock setup</button><button class="text-link" data-action="manual-transfer">Other ways to send</button></div>');
  }
  function manualTransfer(state2, openDialog2, dialog2, reason = "") {
    if (!calendarFile(state2).count) {
      calendarOptions(state2, openDialog2);
      return;
    }
    const link = transferLink(state2, document.baseURI);
    const apple = /iPad|iPhone|iPod/.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
    const sms = apple ? "sms:" : "sms:?body=" + encodeURIComponent("Open your Dosewell reminder file: " + link);
    const actions = link ? '<div class="export-choices"><a class="btn primary" rel="noreferrer" href="' + h(sms) + '">' + icon("message", 17) + 'Open Messages</a><button type="button" class="btn outline" id="copy-transfer">Copy reminder link</button></div><p>' + (apple ? "Copy the reminder link, open Messages, and paste it into a text." : "Choose your phone number in the draft and send. If Messages does not open or the draft is empty, copy the link and paste it into your messaging app.") + "</p>" : "<p>This schedule is too large for a reliable text link. Download the complete calendar file and attach it in Messages or Mail.</p>";
    openDialog2("Text your reminders", (reason ? "<p>" + h(reason) + "</p>" : "") + actions + '<p class="transfer-privacy">Anyone with the message or file can see these medication names, doses, and times.</p><button class="btn outline" data-action="export">' + icon("download", 17) + 'Download calendar attachment</button><p id="calendar-feedback" role="status"></p>');
    if (!link) return;
    dialog2.querySelector("#copy-transfer").onclick = async () => {
      const feedback = dialog2.querySelector("#calendar-feedback");
      try {
        await navigator.clipboard.writeText(link);
        feedback.textContent = "Reminder link copied. Paste it into your message.";
      } catch {
        let input = dialog2.querySelector(".transfer-copy");
        if (!input) {
          input = document.createElement("textarea");
          input.className = "transfer-copy";
          input.readOnly = true;
          input.setAttribute("aria-label", "Reminder link to copy");
          input.value = link;
          feedback.after(input);
        }
        input.focus();
        input.select();
        feedback.textContent = "Copy the selected link and paste it into your message.";
      }
    };
  }
  async function textReminders(state2, openDialog2, dialog2, manual = false) {
    if (manual) {
      manualTransfer(state2, openDialog2, dialog2);
      return;
    }
    const cal = calendarFile(state2);
    if (!cal.count) {
      calendarOptions(state2, openDialog2);
      return;
    }
    const link = transferLink(state2, document.baseURI);
    const choice = transferChoice(cal, link);
    if (choice.kind === "manual") {
      manualTransfer(state2, openDialog2, dialog2);
      return;
    }
    const feedback = dialog2.querySelector("#calendar-feedback");
    feedback.textContent = choice.kind === "file" ? "Choose Messages to send your calendar attachment." : "Choose Messages to send the link to your calendar file.";
    try {
      await navigator.share(choice.data);
      if (feedback.isConnected) feedback.textContent = "On the receiving phone, open the attachment or link and confirm the calendar import.";
    } catch (error) {
      if (!feedback.isConnected) return;
      if (error.name === "AbortError") {
        feedback.textContent = "Sharing canceled. Your schedule is ready when you are.";
        return;
      }
      manualTransfer(state2, openDialog2, dialog2, "Sharing is unavailable in this browser. You can still send the reminders below.");
    }
  }
  function phoneExport(getState, openDialog2, dialog2, requestedPlatform = "") {
    const apple = /iPhone|iPad|iPod/i.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
    let platform = requestedPlatform || (apple ? "apple" : /Android/i.test(navigator.userAgent) ? "android" : "");
    const render2 = () => {
      const entries = phoneAlarms(getState());
      if (!entries.length && platform === "android") {
        openDialog2("Android Clock setup", '<p>Install the companion once. Add a medication with a future dose time to send your first alarm.</p><div class="export-choices"><a class="btn outline" href="./clock-install.html">Install Dosewell Clock</a><button class="btn primary" data-action="add-stroke">Add medication</button></div>');
        return;
      }
      if (!entries.length) {
        openDialog2("Phone alarms", '<p>Add a future dose time in your medication list to export a phone alarm.</p><button class="btn primary" data-action="add-stroke">Add medication</button>');
        return;
      }
      const option = (key3, text3) => '<button class="btn outline" data-platform="' + key3 + '" aria-pressed="' + (platform === key3) + '">' + text3 + "</button>";
      const tabs = '<div class="platform-picker">' + option("android", "Android") + option("apple", "iPhone") + "</div>";
      const bindTabs = () => dialog2.querySelectorAll("[data-platform]").forEach((b) => b.onclick = () => {
        platform = b.dataset.platform;
        render2();
        dialog2.querySelector('[data-platform="' + platform + '"]').focus();
      });
      if (platform === "android") {
        openDialog2("Android Clock setup", tabs + '<div id="android-clock-setup"></div>');
        showAndroidClock(dialog2.querySelector("#android-clock-setup"), getState);
        bindTabs();
        return;
      }
      const cards = entries.map((entry, i) => {
        const can = clockCanSet(entry);
        const name = "Send to Shortcuts";
        return '<article class="phone-entry"><div class="phone-time">' + h(alarmTimeLabel(entry)) + "</div><div><b>" + h(entry.name) + " \xB7 " + h(entry.dose) + "</b><p>" + (entry.minutes ? "Advance warning \xB7 dose at " + h(timeLabel(entry.doseTime)) + (entry.doseDay && entry.doseDay !== dayKey(entry.at) ? " on " + h(readableDate(entry.doseDay)) : "") : "Dose time") + "</p><p>Next " + h(readableDate(dayKey(entry.at))) + " \xB7 " + h(repeatText(entry)) + "</p>" + (entry.until ? "<p>Last alarm " + h(readableDate(entry.until)) + "</p>" : "") + '</div><div class="phone-actions">' + (platform && can ? '<button class="btn small primary" data-send="' + i + '">' + name + "</button>" : "") + '<button class="btn small outline" data-copy="' + i + '">Copy details</button></div>' + (platform && !can ? "<small>This alarm starts on a later date. Use the calendar export or set it in Clock on the date shown.</small>" : "") + "</article>";
      }).join("");
      openDialog2("Phone alarms", "<p>Each entry is one alarm, including advance warnings. Choose the phone you use.</p>" + tabs + (platform === "apple" ? shortcutHelp : "") + '<p class="export-note">Check the time and label in Clock. ' + (entries.some((e) => e.oneTime) ? "Hourly schedules show one-time alarms for the next 24 hours, or the first upcoming alert if later. Leave Repeat off for these alarms. Use Calendar alerts for the full repeating schedule." : "Set repeat days there and remove alarms when a course ends or a dose changes.") + '</p><div class="phone-entries">' + cards + '</div><button class="btn outline" id="download-alarms">' + icon("download", 17) + 'Download alarm list (.txt)</button><p class="export-feedback" role="status"></p>');
      const feedback = dialog2.querySelector(".export-feedback");
      bindTabs();
      dialog2.querySelector("#download-alarms").onclick = () => {
        download("Dosewell-phone-alarms.txt", "text/plain;charset=utf-8", alarmFile(phoneAlarms(getState())));
        feedback.textContent = "Reference list downloaded. A text file cannot install Clock alarms.";
      };
      dialog2.querySelectorAll("[data-copy]").forEach((b) => b.onclick = async () => {
        const txt = alarmText(entries[Number(b.dataset.copy)]);
        try {
          await navigator.clipboard.writeText(txt);
          b.textContent = "Copied";
        } catch {
          const field = document.createElement("textarea");
          field.readOnly = true;
          field.setAttribute("aria-label", "Alarm details to copy");
          field.value = txt;
          b.parentElement.after(field);
          field.focus();
          field.select();
        }
      });
      dialog2.querySelectorAll("[data-send]").forEach((b) => b.onclick = () => {
        const old = entries[Number(b.dataset.send)], current = phoneAlarms(getState()).find((a) => a.key === old.key && a.label === old.label);
        const href = current && phoneHandoff(current, platform);
        if (!href) {
          render2();
          return;
        }
        feedback.textContent = "Check your Clock app to confirm this alarm was created.";
        window.location.href = href;
      });
    };
    render2();
  }

  // dosewell-interactions/app.js
  var main = document.querySelector("#main");
  var dialog = document.querySelector("#dialog");
  var state = read();
  var view = "overview";
  var filter = "all";
  var selected = dayKey(/* @__PURE__ */ new Date());
  var lastDay = selected;
  var part = null;
  var toastTimer;
  var audioContext;
  var workerRegistration;
  var checking = false;
  var lastCheck = Date.now() - 6e4;
  var visibleEvents = [];
  document.querySelector("#new-address").hidden = location.hostname !== "dosewell-medication-planner.starryfable2.chatgpt.site";
  var offerPhoneSetup = false;
  var alarmContainer = document.querySelector("#alarms");
  for (const el of document.querySelectorAll("[data-icon]")) el.innerHTML = icon(el.dataset.icon, 16);
  if (!nativePlatform && "serviceWorker" in navigator) navigator.serviceWorker.register("./worker.js").then((r) => {
    workerRegistration = r;
  }).catch(() => {
  });
  navigator.serviceWorker?.addEventListener("message", (e) => {
    if (e.data?.view === "overview") location.hash = "overview";
  });
  function toast(msg) {
    const t = document.querySelector("#toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.hidden = true, 5200);
  }
  function render() {
    state = read();
    const parts = location.hash.slice(1).split("/");
    view = navItems.some(([v]) => v === parts[0]) ? parts[0] : "overview";
    filter = ["all", "stroke", "other"].includes(parts[1]) ? parts[1] : "all";
    document.querySelector("#nav").innerHTML = nav(view);
    const period = ["7", "30", "all"].includes(parts[1]) ? parts[1] : "7";
    const iphoneSetup = !nativePlatform && view === "reminders" && parts[1] === "iphone";
    if (iphoneSetup) showIphoneSetup(main, read);
    else if (view === "interactions") showInteractionChecker(main, state);
    else main.innerHTML = view === "overview" ? overview(state, selected, part) : view === "history" ? historyPage(state, period) : view === "medications" ? medicationPage(state, filter) : remindersPage(state);
    paintNative();
    document.title = (iphoneSetup ? "iPhone setup" : navItems.find(([v]) => view === v)?.[2] || "Overview") + " | Dosewell";
    document.querySelector("#setup-prompt").hidden = !offerPhoneSetup || view === "reminders" || view === "interactions" || !state.meds.some((m) => m.mode !== "list");
    const msg = storageStatus(), warning = document.querySelector("#storage-warning");
    warning.textContent = msg;
    warning.hidden = !msg;
  }
  function route() {
    if (location.hash === "#overview") {
      selected = dayKey(/* @__PURE__ */ new Date());
      part = null;
    }
    render();
    window.scrollTo({ top: 0 });
    main.focus({ preventScroll: true });
    if (location.hash === "#reminders/android-clock") phoneExport(read, openDialog, dialog, "android");
    if (location.hash === "#overview/schedule") {
      selected = dayKey(/* @__PURE__ */ new Date());
      render();
      document.querySelector(".schedule")?.scrollIntoView({ block: "start" });
    }
  }
  window.addEventListener("hashchange", route);
  onLocalChange(() => {
    render();
    refreshAlarms();
  });
  async function save(fn) {
    await change(fn);
    render();
    refreshAlarms();
    syncNative();
  }
  function openDialog(title, content) {
    dialog.innerHTML = '<div class="modal-head"><h2 id="dialog-title">' + title + "</h2>" + btnIcon("close", "Close dialog", "close") + '</div><div class="dialog-content">' + content + "</div>";
    if (!dialog.open) dialog.showModal();
  }
  function openEditor(med, cat) {
    showEditor(dialog, med, cat, state.settings, async (item) => {
      await save((s) => {
        const pos = s.meds.findIndex((m) => m.id === item.id);
        if (med && pos < 0) throw Error("This medication was removed in another tab. Close this form and review your list.");
        if (med && JSON.stringify(s.meds[pos]) !== JSON.stringify(med)) throw Error("This medication was edited in another tab. Reopen it to view the latest schedule.");
        if (pos < 0) s.meds.push(item);
        else {
          alignDoseKeys(s, s.meds[pos], item);
          s.meds[pos] = item;
          for (const key3 of Object.keys(s.snoozes)) if (key3.startsWith(item.id + "|")) delete s.snoozes[key3];
        }
      });
      includeSavedInCheck(item.id);
      if (view === "interactions") render();
      dialog.close();
      const pairs = compare(state.meds).filter((p) => p.a.id === item.id || p.b.id === item.id);
      const flags = pairs.filter((p) => p.level !== "unassessed");
      if (flags.length) {
        location.hash = "interactions";
        toast("Medication saved. Review the interaction warning" + (flags.length === 1 ? "" : "s") + ".");
      } else if (pairs.length) {
        toast("Medication saved. This combination needs pharmacist review.");
        location.hash = "interactions";
      } else toast("Medication saved.");
      if (item.mode !== "list" && !nativePlatform) {
        offerPhoneSetup = true;
        render();
      }
      await scan();
    }, (m) => {
      openDialog("Remove medication?", "<p>Remove <b>" + h(m.name) + '</b> from this list and cancel its in-page reminders? Remove any exported calendar events and phone alarms for this entry as well.</p><p>This removes the entry from Dosewell only. Follow your prescriber\u2019s instructions for treatment.</p><div class="form-buttons"><button class="btn outline" id="keep-editing">Keep medication</button><button class="btn danger" id="confirm-remove">Remove entry</button></div>');
      document.querySelector("#keep-editing").onclick = () => openEditor(m, m.category);
      document.querySelector("#confirm-remove").onclick = async () => {
        await save((s) => {
          s.meds = s.meds.filter((v) => v.id !== m.id);
          delete s.supplies[m.id];
          for (const k of Object.keys(s.snoozes)) if (k.startsWith(m.id + "|")) delete s.snoozes[k];
        });
        dialog.close();
        toast("Medication removed from this planner.");
      };
    });
  }
  function openSupply(id) {
    const data = read(), med = data.meds.find((m) => m.id === id);
    if (!med) return;
    const prior = data.supplies[id];
    openDialog("Refill tracking", "<p><b>" + h(medicationTitle(med)) + '</b></p><p>Count how many complete prescribed doses you have. Recording a dose as taken subtracts one. A refill reminder appears in Today at the limit you choose.</p><form class="inventory-form"><label>Doses remaining<input type="number" name="remaining" min="0" max="99999" step="1" required value="' + (prior?.remaining ?? "") + '"></label><label>Show a refill reminder at this many doses<input type="number" name="threshold" min="0" max="99999" step="1" required value="' + (prior?.threshold ?? 5) + '"></label><div class="form-buttons">' + (prior ? '<button type="button" class="danger-text" id="stop-refills">Stop tracking</button>' : "") + '<button type="button" class="btn outline" data-action="close">Cancel</button><button class="btn primary" type="submit">Save supply</button></div><p role="status" class="inventory-feedback"></p></form>');
    const form = dialog.querySelector("form");
    async function commit(remaining, threshold) {
      try {
        await save((s) => updateSupply(s, id, remaining, threshold, prior));
        dialog.close();
        toast(remaining === null ? "Refill tracking turned off." : "Supply saved.");
      } catch (error) {
        form.querySelector(".inventory-feedback").textContent = error.message;
      }
    }
    form.onsubmit = (e) => {
      e.preventDefault();
      const data2 = new FormData(form);
      commit(Number(data2.get("remaining")), Number(data2.get("threshold")));
    };
    if (prior) form.querySelector("#stop-refills").onclick = () => commit(null, null);
  }
  function openSnooze(key3) {
    const row = doseAt(read(), key3);
    if (!row) return;
    openDialog("Snooze reminder", "<p><b>" + h(medicationTitle(row.med)) + "</b> \xB7 " + h(row.med.dose) + "</p><p>Choose when Dosewell should alert you again for the " + doseTimeLabel(row) + " dose. The prescribed time stays the same. " + (nativePlatform ? "Keep Dosewell alarms enabled." : "Keep the page open for this reminder.") + '</p><div class="snooze-options">' + [5, 10, 15, 30, 60].map((n) => '<button class="btn outline" data-snooze-minutes="' + n + '">' + n + " min</button>").join("") + '</div><p class="snooze-feedback" role="status"></p>');
    dialog.querySelectorAll("[data-snooze-minutes]").forEach((b) => b.onclick = async () => {
      try {
        await save((s) => snoozeDose(s, key3, Number(b.dataset.snoozeMinutes)));
        dialog.close();
        toast("Reminder snoozed for " + b.dataset.snoozeMinutes + " minutes.");
      } catch (err) {
        dialog.querySelector(".snooze-feedback").textContent = err.message;
      }
    });
  }
  function confirmUnscheduled(id) {
    const med = read().meds.find((m) => m.id === id && m.mode === "list");
    if (!med) return;
    const key3 = "unscheduled|" + crypto.randomUUID();
    openDialog("Record a dose already taken", "<p>Record <b>" + h(medicationTitle(med)) + " \xB7 " + h(med.dose) + '</b> in your history using the current time.</p><div class="form-buttons"><button class="btn outline" data-action="close">Cancel</button><button class="btn primary" id="confirm-unscheduled">Record as taken</button></div>');
    dialog.querySelector("#confirm-unscheduled").onclick = async (e) => {
      e.currentTarget.disabled = true;
      try {
        await save((s) => logAsNeeded(s, id, key3));
        dialog.close();
        toast("Dose recorded in History.");
      } catch (error) {
        toast(error.message);
        dialog.close();
      }
    };
  }
  function audioReady() {
    if (!state.settings.sound) return;
    try {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!Context) return;
      audioContext || (audioContext = new Context());
      if (audioContext.state === "suspended") audioContext.resume().catch(() => {
      });
    } catch {
    }
  }
  window.addEventListener("pointerdown", audioReady, { passive: true });
  window.addEventListener("keydown", audioReady, { passive: true });
  function chime() {
    if (!state.settings.sound || !audioContext || audioContext.state !== "running") return;
    for (const [i, f] of [660, 880, 740].entries()) {
      const osc = audioContext.createOscillator(), gain = audioContext.createGain(), t = audioContext.currentTime + i * 0.23;
      osc.frequency.value = f;
      gain.gain.setValueAtTime(1e-3, t);
      gain.gain.exponentialRampToValueAtTime(0.12, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(1e-3, t + 0.45);
      osc.connect(gain);
      gain.connect(audioContext.destination);
      osc.start(t);
      osc.stop(t + 0.48);
    }
  }
  function refreshAlarms() {
    visibleEvents = visibleEvents.filter((e) => {
      if (e.test) return true;
      const m = state.meds.find((m2) => m2.id === e.medId);
      return m && medicationTitle(m) === e.name && m.dose === e.dose && !recordedStatus(state, e.doseKey) && !(state.snoozes[e.doseKey] > Date.now()) && dosesFor([m], e.day).some((d) => d.key === e.doseKey) && (e.kind !== "advance" || Date.now() < e.when);
    });
    alarmContainer.innerHTML = visibleEvents.map((e) => {
      const key3 = h(e.doseKey);
      const actions = e.test || e.kind === "advance" ? "" : '<button class="btn small primary" data-take="' + key3 + '">Mark taken</button><button class="btn small outline" data-skip="' + key3 + '">Log skipped</button><button class="btn small outline" data-snooze="' + key3 + '">Snooze</button>';
      return '<div class="live-alarm">' + icon("bell", 23) + "<div><b>" + h(e.title) + "</b><p>" + h(e.body) + '</p></div><div class="alarm-actions">' + actions + '<button class="btn small outline" data-dismiss="' + h(e.id) + '">Dismiss</button></div></div>';
    }).join("");
  }
  async function present(event) {
    visibleEvents.push(event);
    refreshAlarms();
    chime();
    if (!state.settings.notifications || window.Notification?.permission !== "granted") return;
    const options = { body: event.body, tag: event.id, icon: "./icon.svg" };
    try {
      if (workerRegistration?.active) await workerRegistration.showNotification(event.title, options);
      else new Notification(event.title, options);
    } catch {
      toast("Device notifications could not be shown. The reminder is visible on this page.");
    }
  }
  async function scan() {
    if (checking || nativePlatform) return;
    checking = true;
    try {
      const now = /* @__PURE__ */ new Date(), day2 = dayKey(now);
      let changed = false;
      if (lastDay !== day2) {
        if (selected === lastDay) selected = day2;
        lastDay = day2;
        changed = true;
      }
      state = read();
      const clock2 = document.querySelector("#device-clock");
      if (clock2) clock2.textContent = now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" });
      const since = Math.max(lastCheck, now.getTime() - 6e4);
      lastCheck = now.getTime();
      let events = dueEvents(state, now, since);
      if (events.length) {
        state = await change((s) => {
          events = dueEvents(s, now, since);
          for (const e of events) s.fired[e.id] = now.getTime();
          for (const [k, v] of Object.entries(s.fired)) if (now - v > 3 * 864e5) delete s.fired[k];
        });
        for (const e of events) {
          const title = e.kind === "snooze" ? "Snoozed reminder" : e.kind === "due" ? "Scheduled dose reminder" : "Upcoming medication reminder";
          const body = medicationTitle(e.med) + " \xB7 " + e.med.dose + " \xB7 " + doseTimeLabel(e) + (e.day === day2 ? "" : e.day === shiftDay(day2, 1) ? " tomorrow" : e.day === shiftDay(day2, -1) ? " yesterday" : " on " + e.day) + ".";
          await present({ id: e.id, title, body, day: e.day, when: e.when.getTime(), kind: e.kind, medId: e.med.id, name: medicationTitle(e.med), dose: e.med.dose, doseKey: e.key });
        }
        changed = true;
      }
      if (changed) render();
      if (visibleEvents.length) refreshAlarms();
    } catch (err) {
      toast(err.message || "Unable to check reminders.");
    } finally {
      checking = false;
    }
  }
  async function notifications() {
    if (state.settings.notifications && window.Notification?.permission === "granted") {
      await save((s) => s.settings.notifications = false);
      toast("Device notifications turned off.");
      return;
    }
    if (!window.Notification) {
      toast("This browser does not support device notifications. Use the calendar export for device alerts.");
      return;
    }
    let permission;
    try {
      permission = await Notification.requestPermission();
    } catch {
      permission = "denied";
    }
    await save((s) => s.settings.notifications = permission === "granted");
    toast(permission === "granted" ? "Device notifications enabled. Test an alarm on this device." : "Permission unavailable. In-page alarms remain available while this page is open.");
  }
  document.addEventListener("submit", async (e) => {
    if (e.target.id !== "default-form") return;
    e.preventDefault();
    const value = Number(new FormData(e.target).get("minutes"));
    if (Number.isInteger(value) && value >= 0 && value <= 1440) {
      await save((s) => s.settings.advance = value);
      toast("Default advance warning saved.");
    }
  });
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("button, a");
    if (!b) return;
    if (b.classList.contains("skip")) {
      e.preventDefault();
      main.focus();
      main.scrollIntoView({ block: "start" });
      return;
    }
    const d = b.dataset;
    try {
      if (d.date) {
        selected = d.date;
        part = null;
        render();
        document.querySelector('[data-date="' + selected + '"]')?.focus({ preventScroll: true });
        return;
      }
      if (d.edit) {
        const m = state.meds.find((v) => v.id === d.edit);
        if (m) openEditor(m, m.category);
        return;
      }
      if (d.part !== void 0) {
        part = part === Number(d.part) ? null : Number(d.part);
        render();
        main.querySelector('[data-part="' + d.part + '"]')?.focus({ preventScroll: true });
        return;
      }
      if (d.take || d.skip) {
        const key3 = d.take || d.skip;
        await save((s) => logDose(s, key3, d.take ? "taken" : "skipped"));
        const supply = state.supplies[state.history[key3].medId];
        toast(d.take ? "Dose recorded as taken." + (supply && supply.remaining <= supply.threshold ? " Refill reminder: " + supply.remaining + " doses left." : "") : "Dose recorded as skipped.");
        return;
      }
      if (d.logUndo) {
        await save((s) => undoLog(s, d.logUndo, Number(d.stamp)));
        toast("Dose record undone.");
        return;
      }
      if (d.snooze) {
        openSnooze(d.snooze);
        return;
      }
      if (d.supply) {
        openSupply(d.supply);
        return;
      }
      if (d.asNeeded) {
        confirmUnscheduled(d.asNeeded);
        return;
      }
      if (d.dismiss) {
        visibleEvents = visibleEvents.filter((v) => v.id !== d.dismiss);
        refreshAlarms();
        return;
      }
      switch (d.action) {
        case "add":
        case "add-stroke":
        case "add-other":
          openEditor(null, d.action === "add-other" || d.action === "add" && filter === "other" ? "other" : "stroke");
          break;
        case "close":
          dialog.close();
          break;
        case "prev-week":
        case "next-week":
          selected = shiftDay(selected, d.action === "prev-week" ? -7 : 7);
          render();
          document.querySelector('[data-action="' + d.action + '"]')?.focus({ preventScroll: true });
          break;
        case "today":
          selected = dayKey(/* @__PURE__ */ new Date());
          part = null;
          render();
          break;
        case "all-periods":
          part = null;
          render();
          break;
        case "print-history":
          window.print();
          break;
        case "sound":
          await save((s) => s.settings.sound = !s.settings.sound);
          audioReady();
          break;
        case "notify":
          await notifications();
          break;
        case "test":
          audioReady();
          await present({ id: "sample", test: true, title: "Test reminder", body: "This is a sample alarm. No medication dose is due from this test." });
          break;
        case "dismiss-setup":
          offerPhoneSetup = false;
          render();
          break;
        case "phone-setup":
          offerPhoneSetup = false;
          document.querySelector("#setup-prompt").hidden = true;
          if (onAppleMobile()) location.hash = "reminders/iphone";
          else if (/Android/i.test(navigator.userAgent)) phoneExport(read, openDialog, dialog, "android");
          else calendarOptions(read(), openDialog);
          break;
        case "android-clock":
          phoneExport(read, openDialog, dialog, "android");
          break;
        case "calendar-options":
          offerPhoneSetup = false;
          document.querySelector("#setup-prompt").hidden = true;
          if (onAppleMobile() && !nativePlatform) {
            location.hash = "reminders/iphone";
            break;
          }
          calendarOptions(read(), openDialog);
          break;
        case "text-reminders":
          await textReminders(read(), openDialog, dialog);
          break;
        case "manual-transfer":
          await textReminders(read(), openDialog, dialog, true);
          break;
        case "export":
          if (saveCalendarFile(read())) {
            const feedback = document.querySelector("#calendar-feedback");
            feedback.textContent = "Open the .ics file in your calendar, or attach it in Messages. Confirm the import and check the alerts on the receiving phone.";
            b.textContent = "Download again";
          } else calendarOptions(read(), openDialog);
          break;
        case "phone-alarms":
          phoneExport(read, openDialog, dialog);
          break;
        case "enable-app-alarms":
        case "test-app-alarm":
        case "stop-app-alarms":
          nativeAction(d.action);
          break;
        case "iphone-help":
          dialog.close();
          break;
        case "help":
          if (nativePlatform) {
            openDialog("Dosewell help", "<p>Enter your medications and schedules, then enable Dosewell alarms in Reminders. Dosewell stores your plan on this device. Record doses in Today. Dismissing an alarm does not record a dose.</p><p>Names and doses may appear on the lock screen. Ask your pharmacist to review your full medication list for interactions.</p>");
            break;
          }
          openDialog("Help & privacy", '<h3>Use Dosewell from your home screen</h3><p><a class="text-link" href="#reminders/iphone" data-action="iphone-help">Set up Dosewell in Safari and Apple Calendar</a></p><p>On iPhone, use Safari\u2019s Share menu and choose Add to Home Screen. On Android, look for Install app or Add to Home screen in the browser menu.</p><h3>Your medication list</h3><p>Enter each medicine and dose from your current prescription, or use Take photo in Add medication to fill the label fields. Check the suggested text before saving. The photo is processed on this device and discarded when the form closes. Choose daily times, an hourly interval, selected days, or list only. In Today, record a dose after taking it, log a skipped dose, or snooze its reminder. History keeps your recorded entries. For a list only medicine, use Log a dose on the Medications page.</p><h3>Where your plan is saved</h3><p>Medication entries and dose history, and refill counts stay in this browser on this device. Anyone with access to this browser profile can view them. Clearing browser data removes the plan.</p><h3>Reminder delivery</h3><p>Keep the page open and your device awake for in-page alarms. Test the sound in Reminders. For alerts with the site closed on iPhone, use iPhone setup to import your schedule into Apple Calendar. You can also choose Clock alarms for supported phone setup options. Confirm the alerts on your device. Medication names may appear on the lock screen if you enable notifications.</p><h3>Interaction warnings</h3><p>The checker covers selected pairs. Ask a pharmacist to review your complete list, especially before adding a new medicine or changing a dose.</p>');
          break;
      }
    } catch (err) {
      toast(err.message || "The change could not be saved.");
    }
  });
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close();
    }
  });
  render();
  if (location.hash === "#reminders/android-clock") phoneExport(read, openDialog, dialog, "android");
  scan();
  setInterval(scan, 3e3);
  var currentMinute = (/* @__PURE__ */ new Date()).getMinutes();
  setInterval(() => {
    const m = (/* @__PURE__ */ new Date()).getMinutes();
    if (m !== currentMinute) {
      currentMinute = m;
      if (view === "overview" && !dialog.open && (document.activeElement === main || !main.contains(document.activeElement))) render();
    }
  }, 5e3);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      render();
      scan();
    }
  });
  if (nativePlatform) {
    document.querySelector(".app-download-link").hidden = true;
    document.querySelector(".plan-move-link").hidden = true;
    document.addEventListener("change", async (event) => {
      if (event.target.id !== "native-import") return;
      try {
        await importNativeFile(event.target.files[0]);
        render();
        syncNative();
        toast("Plan imported. Check your alarms in Reminders.");
      } catch (error) {
        toast(error.message);
      }
    });
    window.refreshDosewellAlarms = syncNative;
    window.addEventListener("pageshow", syncNative);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) syncNative();
    });
    syncNative();
  }
})();
