#!/usr/bin/env bash
set -euo pipefail
apk=$1
src=$(cd "$(dirname "$0")" && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
export CLOCK_KEYSTORE="$tmp/test.p12" CLOCK_KEY_PASSWORD_FILE="$tmp/password"
openssl rand -hex 32 > "$CLOCK_KEY_PASSWORD_FILE"
keytool -genkeypair -alias dosewell -keystore "$CLOCK_KEYSTORE" -storetype PKCS12 -keyalg RSA -keysize 2048 -storepass:file "$CLOCK_KEY_PASSWORD_FILE" -dname "CN=Disposable emulator test" -validity 3
signer="$ANDROID_BUILD_TOOLS/lib/apksigner.jar"
java -jar "$signer" verify --verbose "$apk"
# A release awaiting its original signing key can still be tested on this disposable device.
source_code=$(sed -n 's/.*android:versionCode="\([0-9]*\)".*/\1/p' "$src/../AndroidManifest.xml" | head -1)
apk_code=$("$ANDROID_BUILD_TOOLS/aapt2" dump badging "$apk" | sed -n "s/^package:.*versionCode='\([0-9]*\)'.*/\1/p")
if [[ -n "$source_code" && "$source_code" == "$apk_code" ]]; then
  java -jar "$signer" sign --ks "$CLOCK_KEYSTORE" --ks-pass "file:$CLOCK_KEY_PASSWORD_FILE" --out "$tmp/planner.apk" "$apk"
else
  echo "Testing Android source version $source_code with a disposable certificate (published APK code $apk_code)."
  bash "$src/../build.sh" "$tmp/planner.apk"
fi
bash "$src/build.sh" "$tmp/probe.apk"
adb install -r "$tmp/planner.apk"
adb install -r "$tmp/probe.apk"
adb shell pm grant org.williamsindustries.dosewell android.permission.POST_NOTIFICATIONS
adb shell appops set org.williamsindustries.dosewell SCHEDULE_EXACT_ALARM allow
adb shell cmd notification set_dnd off
adb shell cmd media_session volume --stream 4 --set 5
adb shell cmd audio set-ringer-mode SILENT
adb shell dumpsys audio | grep -i -- '- mode (internal) = SILENT' >/dev/null
adb shell wm dismiss-keyguard
adb shell am instrument -w org.williamsindustries.dosewellqa/.Probe | tee "$tmp/probe.log"
grep -q 'Created sample dose through planner' "$tmp/probe.log"
adb shell input keyevent 3
adb shell am kill org.williamsindustries.dosewell
adb shell input keyevent 223
# Only the app receiver can post these three synthetic notifications.
uid=$(adb shell cmd package list packages -U org.williamsindustries.dosewell | sed -n 's/^package:org.williamsindustries.dosewell uid:\([0-9]*\).*/\1/p' | tr -d '\r')
test -n "$uid"
for i in $(seq 1 130); do
  adb shell dumpsys notification --noredact > "$tmp/notifications"
  adb shell dumpsys audio > "$tmp/playback"
  if grep -i -- "- mode (internal) = SILENT" "$tmp/playback" >/dev/null &&
     grep -E "u/pid:${uid}/[0-9]+ state:started .*USAGE_ALARM" "$tmp/playback" >/dev/null; then
    grep -q 'Your Dosewell alarm is working' "$tmp/notifications" && touch "$tmp/test-confirmed"
    grep -q 'In 1 min: Dosewell Sample' "$tmp/notifications" && touch "$tmp/warning-confirmed"
    grep -q 'Dose: Dosewell Sample' "$tmp/notifications" && touch "$tmp/dose-confirmed"
  fi
  if [[ -f "$tmp/test-confirmed" && -f "$tmp/warning-confirmed" && -f "$tmp/dose-confirmed" ]]; then
    echo 'Android reports active Dosewell alarm-stream playback for test, advance warning and dose with a silent ringer and locked screen.'
    exit 0
  fi
  sleep 2
done
exit 1
