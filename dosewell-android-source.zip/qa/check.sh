#!/usr/bin/env bash
set -euo pipefail
apk=$1
src=$(cd "$(dirname "$0")" && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
export CLOCK_KEYSTORE="$tmp/test.p12" CLOCK_KEY_PASSWORD_FILE="$tmp/password"
openssl rand -hex 32 > "$CLOCK_KEY_PASSWORD_FILE"
keytool -genkeypair -alias dosewell -keystore "$CLOCK_KEYSTORE" -storetype PKCS12 -keyalg RSA -keysize 2048 -storepass:file "$CLOCK_KEY_PASSWORD_FILE" -dname "CN=Disposable emulator test" -validity 3
signer="$ANDROID_BUILD_TOOLS/lib/apksigner.jar"
java -jar "$signer" verify --verbose "$apk"
java -jar "$signer" sign --ks "$CLOCK_KEYSTORE" --ks-pass "file:$CLOCK_KEY_PASSWORD_FILE" --out "$tmp/planner.apk" "$apk"
bash "$src/build.sh" "$tmp/probe.apk"
adb install -r "$tmp/planner.apk"
adb install -r "$tmp/probe.apk"
adb shell pm grant org.williamsindustries.dosewell android.permission.POST_NOTIFICATIONS
adb shell appops set org.williamsindustries.dosewell SCHEDULE_EXACT_ALARM allow
adb shell wm dismiss-keyguard
adb shell am instrument -w org.williamsindustries.dosewellqa/.Probe | tee "$tmp/probe.log"
grep -q 'Created sample dose through planner' "$tmp/probe.log"
adb shell input keyevent 3
adb shell am kill org.williamsindustries.dosewell
adb shell input keyevent 223
# Only the app receiver can post these three synthetic notifications.
for i in $(seq 1 130); do
  adb shell dumpsys notification --noredact > "$tmp/notifications"
  grep -q 'Your Dosewell alarm is working' "$tmp/notifications" && touch "$tmp/test-confirmed"
  grep -q 'In 1 min: Dosewell Sample' "$tmp/notifications" && touch "$tmp/warning-confirmed"
  grep -q 'Dose: Dosewell Sample' "$tmp/notifications" && touch "$tmp/dose-confirmed"
  if [[ -f "$tmp/test-confirmed" && -f "$tmp/warning-confirmed" && -f "$tmp/dose-confirmed" ]]; then
    echo 'Dosewell posted the test, advance warning and scheduled dose with the screen locked.'
    exit 0
  fi
  sleep 2
done
exit 1
