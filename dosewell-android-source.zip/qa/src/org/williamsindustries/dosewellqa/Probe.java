package org.williamsindustries.dosewellqa;
import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import android.view.*;import java.util.concurrent.*;
public class Probe extends Instrumentation{
 WebView web; Activity page;
 public void onCreate(Bundle b){super.onCreate(b);start();}
 WebView find(View v){if(v instanceof WebView)return (WebView)v;if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++){WebView w=find(g.getChildAt(i));if(w!=null)return w;}}return null;}
 String eval(String js)throws Exception{CountDownLatch latch=new CountDownLatch(1);String[] value={""};runOnMainSync(()->web.evaluateJavascript(js,s->{value[0]=s;latch.countDown();}));if(!latch.await(40,TimeUnit.SECONDS))throw new Exception("JS timeout");return value[0];}
 void ready(String check)throws Exception{for(int i=0;i<55;i++){if("true".equals(eval(check)))return;Thread.sleep(500);}throw new Exception("Missing "+check+": "+eval("document.body.innerText.slice(0,450)"));}
 public void onStart(){Bundle result=new Bundle();try{
  page=startActivitySync(new Intent().setClassName("org.williamsindustries.dosewell","org.williamsindustries.dosewell.Planner").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));runOnMainSync(()->web=find(page.getWindow().getDecorView()));
  ready("!!document.querySelector('#nav a')");eval("location.hash='interactions'");ready("!!document.getElementById('ic-form')");
  eval("for(const name of ['NIMOTOP (Oral Pill)','Conivaptan']){document.getElementById('ic-query').value=name;document.querySelector('#ic-form button').click()}");
  ready("document.getElementById('ic-report').innerText.includes('Contraindicated · capsule label')");eval("document.getElementById('ic-clear').click()");
  eval("location.hash='medications'");ready("!!document.querySelector('[data-action=add]')");eval("document.querySelector('[data-action=add]').click()");ready("!!document.querySelector('#med-form')");
  eval("(()=>{let f=document.querySelector('#med-form'),d=new Date(Date.now()+210000),v=k=>String(k).padStart(2,'0');f.elements.namedItem('name').value='Dosewell Sample';f.elements.dose.value='Test amount';f.elements.times.value=v(d.getHours())+':'+v(d.getMinutes());f.elements['warning-mode'].value='custom';f.elements['warning-mode'].dispatchEvent(new Event('change',{bubbles:true}));f.elements.advance.value=1;f.requestSubmit();})()");
  ready("!document.querySelector('#dialog').open");eval("location.hash='reminders'");ready("!!document.querySelector('[data-action=enable-app-alarms]')");
  eval("document.querySelector('[data-action=enable-app-alarms]').click()");ready("document.querySelector('#native-status').innerText.includes('Next alarm:')");
  android.app.NotificationChannel channel=getTargetContext().getSystemService(android.app.NotificationManager.class).getNotificationChannel("dosewell_gentle_chime_v1");
  if(channel==null||channel.getSound()==null||!channel.shouldVibrate()||channel.getAudioAttributes().getUsage()!=android.media.AudioAttributes.USAGE_ALARM)throw new Exception("Missing alarm chime or vibration");
  android.media.MediaPlayer player=new android.media.MediaPlayer();
  try{player.setAudioAttributes(channel.getAudioAttributes());player.setDataSource(getTargetContext(),channel.getSound());player.prepare();if(player.getDuration()<6800)throw new Exception("Invalid gentle chime");}finally{player.release();}
  result.putString("scheduled",eval("document.querySelector('#native-status').innerText"));eval("document.querySelector('[data-action=test-app-alarm]').click()");ready("document.querySelector('#native-status').innerText.includes('15 seconds')");
  result.putString("result","Created sample dose through planner, enabled native alarms and scheduled test");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("failure",e.toString());finish(Activity.RESULT_CANCELED,result);}}
}
