package org.williamsindustries.dosewell;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.os.*;

public final class AlarmSound extends Service {
    static final long MAX_MILLIS=90_000L;
    static final AudioAttributes ATTRIBUTES=new AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
    private static AlarmSound running;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private AudioFocusRequest focus;
    private Vibrator vibrator;
    private boolean ready,hasFocus;
    private int id;
    private long token;

    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){super.onCreate();running=this;}

    static void dismiss(Context c,int which,long expected){
        SharedPreferences p=Alarms.prefs(c);
        if(p.getLong("ring."+which,0)!=expected)return;
        if(expected==0){c.getSystemService(NotificationManager.class).cancel(which);return;}
        p.edit().remove("ring."+which).apply();
        if(running!=null && running.id==which && running.token==expected)running.finishRing();
        c.getSystemService(NotificationManager.class).cancel(which);
    }
    static void stopAll(Context c){
        Alarms.prefs(c).edit().remove("ring.1").remove("ring.2").apply();
        if(running!=null)running.finishRing();
        c.stopService(new Intent(c,AlarmSound.class));
    }
    private void releasePlayers(){
        handler.removeCallbacksAndMessages(null);
        if(player!=null){player.release();player=null;}
        if(focus!=null){getSystemService(AudioManager.class).abandonAudioFocusRequest(focus);focus=null;}
        if(vibrator!=null){vibrator.cancel();vibrator=null;}
        ready=false;hasFocus=false;
    }
    private void finishRing(){
        releasePlayers();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null){stopSelf(startId);return START_NOT_STICKY;}
        final int nextId=intent.getIntExtra("id",0);
        final long nextToken=intent.getLongExtra("token",0);
        if(nextId==2 && id==1 && Alarms.prefs(this).getLong("ring.1",0)==token)return START_NOT_STICKY;
        releasePlayers();
        if(id!=0 && id!=nextId)stopForeground(STOP_FOREGROUND_REMOVE);
        id=nextId;token=nextToken;
        String label=intent.getStringExtra("label");
        Notification notice=Alarms.notice(this,label,id,token,true);
        if(Build.VERSION.SDK_INT>=29)startForeground(id,notice,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(id,notice);
        if(!Alarms.prefs(this).getBoolean("enabled",false) || Alarms.prefs(this).getLong("ring."+id,0)!=token || !Alarms.notifications(this)){
            finishRing();return START_NOT_STICKY;
        }
        handler.postDelayed(this::finishRing,MAX_MILLIS);
        NotificationManager notices=getSystemService(NotificationManager.class);
        NotificationChannel channel=notices.getNotificationChannel(Alarms.channelId(this));
        if(channel.getImportance()<NotificationManager.IMPORTANCE_DEFAULT ||
           notices.getCurrentInterruptionFilter()==NotificationManager.INTERRUPTION_FILTER_NONE)return START_NOT_STICKY;
        if(channel.shouldVibrate()){
            vibrator=getSystemService(Vibrator.class);
            if(vibrator!=null && vibrator.hasVibrator())
                vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0,200,180,200,6500},0),ATTRIBUTES);
        }
        AudioManager audio=getSystemService(AudioManager.class);
        if(channel.getSound()==null || audio.getStreamVolume(AudioManager.STREAM_ALARM)==0 || audio.isStreamMute(AudioManager.STREAM_ALARM))
            return START_NOT_STICKY;
        try{
            final MediaPlayer next=new MediaPlayer();
            player=next;
            next.setAudioAttributes(ATTRIBUTES);
            next.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);
            next.setDataSource(this,channel.getSound());
            next.setLooping(true);
            focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(ATTRIBUTES).setOnAudioFocusChangeListener(change->{
                    if(player!=next)return;
                    hasFocus=change==AudioManager.AUDIOFOCUS_GAIN;
                    if(change==AudioManager.AUDIOFOCUS_LOSS){next.release();player=null;return;}
                    if(!ready)return;
                    if(hasFocus)next.start();
                    else if(next.isPlaying())next.pause();
                },handler).build();
            hasFocus=audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            next.setOnPreparedListener(p->{if(player==p){ready=true;if(hasFocus)p.start();}});
            next.setOnErrorListener((p,what,extra)->{if(player==p){player=null;p.release();}return true;});
            next.prepareAsync();
        }catch(Exception e){
            if(player!=null){player.release();player=null;}
        }
        return START_NOT_STICKY;
    }
    @Override public void onDestroy(){
        releasePlayers();
        SharedPreferences p=Alarms.prefs(this);
        if(p.getLong("ring."+id,0)==token)p.edit().remove("ring."+id).apply();
        running=null;
        super.onDestroy();
    }
}
