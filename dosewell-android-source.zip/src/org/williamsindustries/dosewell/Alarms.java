package org.williamsindustries.dosewell;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.Build;
import org.json.*;
import java.time.*;
import java.util.*;

public final class Alarms extends BroadcastReceiver {
    static final String FIRE="org.williamsindustries.dosewell.FIRE", TEST="org.williamsindustries.dosewell.TEST", STOP="org.williamsindustries.dosewell.STOP", LEGACY="dose_reminders", GENTLE="dosewell_gentle_chime_v1";
    static final String EMPTY="{\"rules\":[],\"skip\":[]}";
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("reminders",Context.MODE_PRIVATE);}
    static AlarmManager manager(Context c){return c.getSystemService(AlarmManager.class);}
    static PendingIntent open(Context c){return PendingIntent.getActivity(c,0,new Intent(c,Planner.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_IMMUTABLE);}
    static PendingIntent signal(Context c,String action){
        return PendingIntent.getBroadcast(c,0,new Intent(c,Alarms.class).setAction(action),PendingIntent.FLAG_IMMUTABLE);
    }
    static android.net.Uri chimeUri(Context c){
        return new android.net.Uri.Builder().scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
            .authority(c.getPackageName()).appendPath("raw").appendPath("dosewell_chime").build();
    }
    static String channelId(Context c){
        SharedPreferences p=prefs(c);
        String selected=p.getString("alarmChannel",null);
        if(selected!=null)return selected;
        NotificationChannel old=c.getSystemService(NotificationManager.class).getNotificationChannel(LEGACY);
        // Android keeps channel settings across upgrades. Preserve a user's existing
        // mute, vibration preference or custom tone until they choose the new chime.
        boolean customized=old!=null&&(old.getImportance()<NotificationManager.IMPORTANCE_DEFAULT
            ||!old.shouldVibrate()||!android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI.equals(old.getSound()));
        selected=customized?LEGACY:GENTLE;
        p.edit().putString("alarmChannel",selected).commit();
        return selected;
    }
    static void channel(Context c){
        NotificationManager manager=c.getSystemService(NotificationManager.class);
        if(manager.getNotificationChannel(GENTLE)==null){
            NotificationChannel ch=new NotificationChannel(GENTLE,"Gentle chime and vibration",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Dosewell medication doses and advance warnings");
            ch.setSound(chimeUri(c),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            ch.setVibrationPattern(new long[]{0,200,180,200});
            ch.enableVibration(true);
            manager.createNotificationChannel(ch);
        }
        channelId(c);
    }
    static boolean exact(Context c){return Build.VERSION.SDK_INT<31||manager(c).canScheduleExactAlarms();}
    static boolean notifications(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);return n.areNotificationsEnabled()&&n.getNotificationChannel(channelId(c)).getImportance()!=NotificationManager.IMPORTANCE_NONE;}
    static void schedule(Context c,String action,long at){manager(c).setAlarmClock(new AlarmManager.AlarmClockInfo(at,open(c)),signal(c,action));}
    static long next(JSONObject r,Set<String> skip,long from,ZoneId zone)throws JSONException{
        String mode=r.getString("mode"),med=r.getString("med");long lead=r.getLong("lead")*60_000L;
        if(mode.equals("snooze")){long at=r.getLong("at");return at>from?at:Long.MAX_VALUE;}
        if(mode.equals("interval")){
            long first=r.getLong("anchor"),step=r.getLong("step"),until=r.optLong("until");
            if(step<3_600_000L)return Long.MAX_VALUE;
            long dose=first+Math.max(0,Math.floorDiv(from+lead-first,step)+1)*step;
            while(until==0||dose<until){if(!skip.contains(med+"|interval|"+dose))return dose-lead;dose+=step;}
            return Long.MAX_VALUE;
        }
        LocalDate start=LocalDate.parse(r.getString("start")),end=r.optString("end").isEmpty()?null:LocalDate.parse(r.getString("end"));
        String time=r.getString("time");LocalTime local=LocalTime.parse(time);int mask=r.getInt("days");
        if(mask<=0||mask>127)return Long.MAX_VALUE;
        LocalDate day=Instant.ofEpochMilli(from+lead).atZone(zone).toLocalDate();
        if(day.isBefore(start))day=start;
        for(;end==null||!day.isAfter(end);day=day.plusDays(1)){
            if((mask&(1<<(day.getDayOfWeek().getValue()%7)))==0)continue;
            long at=day.atTime(local).atZone(zone).toInstant().toEpochMilli()-lead;
            if(at>from&&!skip.contains(med+"|"+day+"|"+time))return at;
        }
        return Long.MAX_VALUE;
    }
    static void reset(Context c,long from)throws JSONException{
        SharedPreferences p=prefs(c);
        if(!p.getBoolean("enabled",false)||!exact(c)||!notifications(c)){
            manager(c).cancel(signal(c,FIRE));p.edit().remove("next").remove("label").commit();return;
        }
        JSONObject plan=new JSONObject(p.getString("plan",EMPTY));JSONArray rules=plan.getJSONArray("rules"),skipList=plan.getJSONArray("skip");
        Set<String> skip=new HashSet<>();for(int i=0;i<skipList.length();i++)skip.add(skipList.getString(i));
        long next=Long.MAX_VALUE;List<String> labels=new ArrayList<>();ZoneId zone=ZoneId.systemDefault();
        for(int i=0;i<rules.length();i++){
            JSONObject r=rules.getJSONObject(i);long at=next(r,skip,from,zone);
            if(at==Long.MAX_VALUE||at>next)continue;
            if(at<next){labels.clear();next=at;}labels.add(r.getString("label"));
        }
        if(next==Long.MAX_VALUE){manager(c).cancel(signal(c,FIRE));p.edit().remove("next").remove("label").commit();return;}
        p.edit().putLong("next",next).putString("label",String.join("\n",labels)).commit();schedule(c,FIRE,next);
    }
    static Notification notice(Context c,String label,int id,long token,boolean managed){
        Intent stop=new Intent(c,Alarms.class).setAction(STOP).putExtra("id",id).putExtra("token",token);
        PendingIntent dismiss=PendingIntent.getBroadcast(c,id,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent tap=new Intent(c,Planner.class).setAction("org.williamsindustries.dosewell.OPEN_ALARM")
            .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("id",id).putExtra("token",token);
        PendingIntent view=PendingIntent.getActivity(c,id,tap,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        int icon=c.getResources().getIdentifier("reminder","drawable",c.getPackageName());
        Notification.Builder builder=new Notification.Builder(c,channelId(c)).setSmallIcon(icon).setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PRIVATE).setContentTitle(id==2?"Dosewell test alarm":"Dosewell medication reminder").setContentText(label)
            .setStyle(new Notification.BigTextStyle().bigText(label)).setContentIntent(view).setDeleteIntent(dismiss).setAutoCancel(true)
            .setTimeoutAfter(AlarmSound.MAX_MILLIS).addAction(new Notification.Action.Builder(null,"Silence",dismiss).build());
        // Audio and vibration are provided by the service. Suppress the notification's second alert.
        if(managed)builder.setGroup("dosewell.ringing").setGroupAlertBehavior(Notification.GROUP_ALERT_SUMMARY);
        Notification result=builder.build();
        if(!managed)result.flags|=Notification.FLAG_INSISTENT;
        return result;
    }
    static void ring(Context c,String label,boolean test){
        int id=test?2:1;
        long token=android.os.SystemClock.elapsedRealtimeNanos();
        prefs(c).edit().putLong("ring."+id,token).apply();
        Intent play=new Intent(c,AlarmSound.class).putExtra("id",id).putExtra("token",token).putExtra("label",label);
        try{c.startForegroundService(play);}
        catch(IllegalStateException|SecurityException blocked){
            c.getSystemService(NotificationManager.class).notify(id,notice(c,label,id,token,false));
        }
    }
    @Override public void onReceive(Context c,Intent intent){
        channel(c);String action=intent.getAction();SharedPreferences p=prefs(c);long now=System.currentTimeMillis();
        try{
            if(STOP.equals(action)){AlarmSound.dismiss(c,intent.getIntExtra("id",1),intent.getLongExtra("token",0));return;}
            if(TEST.equals(action)){if(p.getBoolean("enabled",false)&&notifications(c))ring(c,"Your Dosewell alarm is working.",true);return;}
            if(FIRE.equals(action)){
                long due=p.getLong("next",0);
                if(due>0&&now>=due&&now-due<5*60000L&&p.getBoolean("enabled",false)&&notifications(c))ring(c,p.getString("label","Scheduled dose"),false);
            }
            reset(c,now);
        }catch(Exception error){p.edit().putBoolean("error",true).apply();}
    }
}
