package org.williamsindustries.dosewell;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.*;
import java.io.*;
import java.util.*;

public final class Planner extends Activity {
    private static final String ORIGIN="https://appassets.androidplatform.net/";
    WebView web;ValueCallback<Uri[]> picker;PermissionRequest camera;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);Alarms.channel(this);dismissOpenedAlarm(getIntent());
        FrameLayout root=new FrameLayout(this);root.setFitsSystemWindows(true);web=new WebView(this);root.addView(web);setContentView(root);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(),"DosewellNative");
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){
                Uri u=r.getUrl();String path=u.getPath();
                if(u.toString().startsWith(ORIGIN)&&path!=null&&!path.contains(".."))try{
                    String f=path.equals("/")?"index.html":path.substring(1);
                    String mime=f.endsWith(".js")?"application/javascript":f.endsWith(".html")?"text/html":f.endsWith(".css")?"text/css":f.endsWith(".svg")?"image/svg+xml":f.endsWith(".png")?"image/png":f.endsWith(".woff2")?"font/woff2":"application/octet-stream";
                    return new WebResourceResponse(mime,null,getAssets().open("web/"+f));
                }catch(IOException ignored){}
                return new WebResourceResponse("text/plain","UTF-8",404,"Unavailable",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){
                Uri u=r.getUrl();if(u.toString().startsWith(ORIGIN+"index.html"))return false;
                if(r.isForMainFrame()&&"https".equals(u.getScheme())&&!u.toString().startsWith(ORIGIN))try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(ActivityNotFoundException ignored){}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params){
                if(picker!=null)picker.onReceiveValue(null);picker=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE);
                boolean photo=Arrays.asList(params.getAcceptTypes()).contains("image/*");i.setType(photo?"image/*":"*/*");
                try{startActivityForResult(i,9);}catch(ActivityNotFoundException e){picker.onReceiveValue(null);picker=null;}return true;
            }
            @Override public void onPermissionRequest(PermissionRequest p){runOnUiThread(()->{
                if(!p.getOrigin().toString().startsWith(ORIGIN)||!Arrays.asList(p.getResources()).contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)){p.deny();return;}
                if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)p.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                else{camera=p;requestPermissions(new String[]{Manifest.permission.CAMERA},12);}
            });}
            @Override public void onPermissionRequestCanceled(PermissionRequest p){if(camera==p)camera=null;}
        });
        web.loadUrl(ORIGIN+"index.html");
    }
    private void dismissOpenedAlarm(Intent intent){
        if(intent!=null && "org.williamsindustries.dosewell.OPEN_ALARM".equals(intent.getAction()))
            AlarmSound.dismiss(this,intent.getIntExtra("id",0),intent.getLongExtra("token",0));
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);dismissOpenedAlarm(intent);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==9&&picker!=null){picker.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);picker=null;}}
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] results){super.onRequestPermissionsResult(req,perms,results);
        if(req==12&&camera!=null){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)camera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});else camera.deny();camera=null;}
        if(req==11){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)enable();else status();}
    }
    final class Bridge{
        @JavascriptInterface public void message(String json){runOnUiThread(()->receive(json));}
    }
    void receive(String json){
        try{
            JSONObject j=new JSONObject(json);SharedPreferences p=Alarms.prefs(this);
            switch(j.getString("action")){
                case "sync":
                    JSONObject plan=new JSONObject().put("rules",j.getJSONArray("rules")).put("skip",j.getJSONArray("skip"));
                    String value=plan.toString();if(!value.equals(p.getString("plan",""))){p.edit().putString("plan",value).commit();Alarms.reset(this,System.currentTimeMillis());}
                    status();break;
                case "enable":enable();break;
                case "disable":AlarmSound.stopAll(this);p.edit().putBoolean("enabled",false).commit();Alarms.reset(this,System.currentTimeMillis());Alarms.manager(this).cancel(Alarms.signal(this,Alarms.TEST));getSystemService(NotificationManager.class).cancelAll();status();break;
                case "gentle":
                    p.edit().putString("alarmChannel",Alarms.GENTLE).commit();
                    Alarms.reset(this,System.currentTimeMillis());status();break;
                case "channel-settings":
                    String channelId=Alarms.channelId(this);
                    startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,channelId));
                    break;
                case "test":
                    if(!p.getBoolean("enabled",false)||!Alarms.notifications(this)||!Alarms.exact(this)){report("Enable Dosewell alarms before testing.",true);break;}
                    Alarms.schedule(this,Alarms.TEST,System.currentTimeMillis()+15000);report("Test alarm scheduled in 15 seconds. You can lock the screen.",false);break;
            }
        }catch(Exception e){report("Dosewell could not update the alarms. Reopen Reminders and check permissions.",true);}
    }
    void enable(){
        Alarms.prefs(this).edit().putBoolean("enabled",true).commit();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);return;}
        if(!Alarms.exact(this)){try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(ActivityNotFoundException ignored){}status();return;}
        if(!Alarms.notifications(this)){startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));return;}
        try{Alarms.reset(this,System.currentTimeMillis());status();}catch(Exception e){report("Could not schedule the reminders.",true);}
    }
    void soundStatus(){
        String id=Alarms.channelId(this);
        NotificationChannel ch=getSystemService(NotificationManager.class).getNotificationChannel(id);
        if(ch==null)return;
        boolean legacy=Alarms.LEGACY.equals(id);
        String info;
        if(ch.getImportance()<NotificationManager.IMPORTANCE_DEFAULT||ch.getSound()==null)info="Sound is silenced in Android notification settings.";
        else if(getSystemService(android.media.AudioManager.class).getStreamVolume(android.media.AudioManager.STREAM_ALARM)==0)info="Alarm volume is at zero. Raise your phone’s alarm volume to hear the chime.";
        else if(Alarms.chimeUri(this).equals(ch.getSound()))info="Gentle chime is selected.";
        else info="Your Android notification sound is selected.";
        info += " The chime uses Android alarm volume, including in Silent or Vibrate mode. For Do Not Disturb, allow alarms in your phone settings.";
        info += ch.shouldVibrate()?" Vibration is on.":" Vibration is off in Android notification settings.";
        web.evaluateJavascript("window.onDosewellSoundStatus&&window.onDosewellSoundStatus("+JSONObject.quote(info)+","+legacy+")",null);
    }
    void status(){
        soundStatus();
        SharedPreferences p=Alarms.prefs(this);
        if(!p.getBoolean("enabled",false)){report("Dosewell alarms are off. Enable them in Reminders.",true);return;}
        if(!Alarms.notifications(this)||!Alarms.exact(this)){report("Allow notifications and Alarms & reminders for Dosewell in Android Settings.",true);return;}
        long next=p.getLong("next",0);report(next>0?"Dosewell alarms are on. Next alarm: "+java.text.DateFormat.getDateTimeInstance().format(new Date(next))+".":"Dosewell alarms are on. There are no upcoming scheduled doses.",false);
    }
    void report(String message,boolean attention){web.evaluateJavascript("window.onDosewellAlarmStatus&&window.onDosewellAlarmStatus("+JSONObject.quote(message)+","+attention+")",null);}
    @Override public void onResume(){super.onResume();if(web!=null){try{Alarms.reset(this,System.currentTimeMillis());status();}catch(Exception e){report("Check your alarm settings in Reminders.",true);}}}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
