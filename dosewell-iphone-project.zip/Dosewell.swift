import SwiftUI
import WebKit
import AlarmKit
import CryptoKit
import UIKit

struct DoseMetadata: AlarmMetadata {}
struct Entry: Codable, Equatable {
    let key: String
    let label: String
    var at: Double?
    var days: Int?
    var hour: Int?
    var minute: Int?
    var id: UUID {
        let bytes = Array(SHA256.hash(data: Data(key.utf8)).prefix(16))
        return bytes.withUnsafeBufferPointer { NSUUID(uuidBytes: $0.baseAddress!) as UUID }
    }
}
struct Request: Decodable {
    let action: String
    var alarms: [Entry]?
    var refill: Double?
}

@MainActor
final class AlarmBridge: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    weak var page: WKWebView?
    private let preferences = UserDefaults.standard
    private let manager = AlarmManager.shared
    private var previousWork: Task<Void,Never>?
    private let test = Entry(key:"dosewell-test",label:"Dosewell test alarm")

    private func status(_ message: String, _ attention: Bool) {
        page?.callAsyncJavaScript("window.onDosewellAlarmStatus(message, attention)", arguments:["message":message,"attention":attention],in:nil,in:.page,completionHandler:nil)
    }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.isFileURL == true,
              let raw=message.body as? String, let request=try? JSONDecoder().decode(Request.self,from:Data(raw.utf8)) else { return }
        let previous=previousWork
        previousWork=Task { [weak self] in
            await previous?.value
            guard let self else { return }
            do { try await self.handle(request) }
            catch { self.status("Dosewell could not finish updating its alarms. Open Reminders and enable alarms to retry. Check alarm access in Settings.",true) }
        }
    }
    private func handle(_ request: Request) async throws {
        switch request.action {
        case "sync":
            guard let entries=request.alarms, entries.count<=24 else {return}
            preferences.set(try JSONEncoder().encode(entries),forKey:"plan")
            preferences.set(request.refill ?? 0,forKey:"refill")
            try await reconcile()
        case "enable":
            let permission=try await manager.requestAuthorization()
            guard permission == .authorized else {status("Allow alarms for Dosewell in iPhone Settings, then return here.",true);return}
            preferences.set(true,forKey:"enabled")
            try await reconcile()
        case "disable":
            preferences.set(false,forKey:"enabled")
            for alarm in try manager.alarms {try manager.cancel(id:alarm.id)}
            preferences.removeObject(forKey:"installed")
            status("Dosewell alarms are off. Enable them in Reminders.",true)
        case "test":
            guard preferences.bool(forKey:"enabled"),manager.authorizationState == .authorized else {status("Enable Dosewell alarms before testing.",true);return}
            if try manager.alarms.contains(where:{$0.id==test.id}) {try manager.cancel(id:test.id)}
            var item=test;item.at=Date().addingTimeInterval(15).timeIntervalSince1970*1000
            try await schedule(item)
            status("Test alarm scheduled in 15 seconds. You can lock the screen.",false)
        default: break
        }
    }
    private func schedule(_ entry: Entry) async throws {
        let schedule: Alarm.Schedule
        if let at=entry.at {
            schedule = .fixed(Date(timeIntervalSince1970:at/1000))
        } else {
            guard let mask=entry.days,let hour=entry.hour,let minute=entry.minute,mask>0,mask<128,(0...23).contains(hour),(0...59).contains(minute) else {throw CocoaError(.coderInvalidValue)}
            let weekdays:[Locale.Weekday]=[.sunday,.monday,.tuesday,.wednesday,.thursday,.friday,.saturday]
            let chosen=weekdays.enumerated().compactMap { (mask & (1 << $0.offset))==0 ? nil : $0.element }
            schedule = .relative(.init(time:.init(hour:hour,minute:minute),repeats:.weekly(chosen)))
        }
        let stop=AlarmButton(text:"Dismiss",textColor:.white,systemImageName:"bell.slash")
        let alert=AlarmPresentation.Alert(title:LocalizedStringResource(stringLiteral:entry.label),stopButton:stop)
        let attributes=AlarmAttributes(presentation:AlarmPresentation(alert:alert),metadata:DoseMetadata(),tintColor:Color(red:0.1,green:0.41,blue:0.35))
        _ = try await manager.schedule(id:entry.id,configuration:.alarm(schedule:schedule,attributes:attributes))
    }
    private func reconcile() async throws {
        guard preferences.bool(forKey:"enabled") else {status("Dosewell alarms are off. Enable them in Reminders.",true);return}
        guard manager.authorizationState == .authorized else {status("Allow Dosewell alarms in iPhone Settings.",true);return}
        var entries=(try? JSONDecoder().decode([Entry].self,from:preferences.data(forKey:"plan") ?? Data())) ?? []
        let now=Date().timeIntervalSince1970*1000
        entries.removeAll { ($0.at ?? .greatestFiniteMagnitude)<=now }
        let refill=preferences.double(forKey:"refill")
        if refill>now {
            // Give the user a distinct app-owned reminder before the first omitted alarm.
            let early=max(now+30_000,refill-min(3_600_000,(refill-now)/2))
            if early<refill {entries.append(Entry(key:"renew",label:"Open Dosewell to schedule the next reminders",at:early))}
        }
        var saved=(try? JSONDecoder().decode([String:Entry].self,from:preferences.data(forKey:"installed") ?? Data())) ?? [:]
        var existing=Set(try manager.alarms.map(\.id))
        let desired=Set(entries.map(\.id))
        for id in existing where !desired.contains(id) && id != test.id {
            try manager.cancel(id:id);saved[id.uuidString]=nil;existing.remove(id)
        }
        for entry in entries {
            if existing.contains(entry.id),saved[entry.id.uuidString]==entry {continue}
            if existing.contains(entry.id) {try manager.cancel(id:entry.id)}
            try await schedule(entry)
            saved[entry.id.uuidString]=entry
            preferences.set(try JSONEncoder().encode(saved),forKey:"installed")
        }
        saved=saved.filter{desired.contains($0.value.id)}
        preferences.set(try JSONEncoder().encode(saved),forKey:"installed")
        if refill>0 {
            let until=Date(timeIntervalSince1970:refill/1000).formatted(date:.abbreviated,time:.shortened)
            status("Dosewell alarms are on. Reopen Dosewell before "+until+" to load more dated alarms.",true)
        } else { status(entries.isEmpty ? "Dosewell alarms are on. There are no upcoming scheduled doses." : "Dosewell alarms are on. Your schedule is saved on this iPhone.",false) }
    }
    func webView(_ webView: WKWebView,decidePolicyFor action: WKNavigationAction,decisionHandler: @escaping (WKNavigationActionPolicy)->Void) {
        guard let url=action.request.url else {decisionHandler(.cancel);return}
        let webRoot=Bundle.main.bundleURL.appendingPathComponent("web").standardizedFileURL.path+"/"
        if url.isFileURL && url.standardizedFileURL.path.hasPrefix(webRoot) {decisionHandler(.allow);return}
        if action.navigationType == .linkActivated && url.scheme=="https" {UIApplication.shared.open(url)}
        decisionHandler(.cancel)
    }
    func webView(_ webView: WKWebView,didFinish navigation: WKNavigation!) {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--dosewell-smoke") {
            Task {
                do {
                    let result=try await webView.callAsyncJavaScript("""
                    location.hash='interactions';
                    await new Promise(resolve=>setTimeout(resolve,250));
                    for (const name of ['Plavix','Prilosec']) {
                        document.getElementById('ic-query').value=name;
                        document.querySelector('#ic-form button').click();
                    }
                    if (!document.getElementById('ic-report').innerText.includes('Label advises avoidance')) return false;
                    document.getElementById('ic-clear').click();
                    location.hash='reminders';
                    await new Promise(resolve=>setTimeout(resolve,250));
                    return !!document.getElementById('native-status') && !!document.querySelector('[data-action="enable-app-alarms"]') && !!document.querySelector('[data-action="test-app-alarm"]');
                    """,arguments:[:],in:nil,contentWorld:.page)
                    let text=(result as? Bool)==true ? "Dosewell planner and native alarm controls ready" : "Missing planner controls"
                    let file=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent("dosewell-smoke.txt")
                    try text.write(to:file,atomically:true,encoding:.utf8)
                } catch {}
            }
        }
        #endif
    }
}
struct Planner: UIViewRepresentable {
    func makeCoordinator()->AlarmBridge {AlarmBridge()}
    func makeUIView(context:Context)->WKWebView {
        let config=WKWebViewConfiguration()
        config.userContentController.add(context.coordinator,name:"dosewell")
        config.allowsInlineMediaPlayback=true
        let w=WKWebView(frame:.zero,configuration:config);context.coordinator.page=w
        w.navigationDelegate=context.coordinator;w.uiDelegate=context.coordinator
        if let index=Bundle.main.url(forResource:"index",withExtension:"html",subdirectory:"web") {w.loadFileURL(index,allowingReadAccessTo:index.deletingLastPathComponent())}
        return w
    }
    func updateUIView(_ w:WKWebView,context:Context){}
    static func dismantleUIView(_ w:WKWebView,coordinator:AlarmBridge){w.configuration.userContentController.removeScriptMessageHandler(forName:"dosewell")}
}
@main struct DosewellApp: App {
    var body: some Scene { WindowGroup { Planner() } }
}
